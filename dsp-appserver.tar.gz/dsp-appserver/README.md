# Application Server

## Project architecture

```
.
├── Dockerfile
├── Dockerfile1
├── Makefile
├── README.md
├── cmd
│   └── appserver
│       └── appserver.go
├── docs
│   └── api
│       ├── apiresources.md
│       ├── application.md
│       ├── cmd.md
│       ├── configmap.md
│       ├── deployemtconfig.md
│       ├── deployment.md
│       ├── grafana.md
│       ├── horizontalpodautoscaler.md
│       ├── imagestreams.md
│       ├── ingress.md
│       ├── olm.md
│       ├── pod.md
│       ├── pvc.md
│       ├── replicationcontroller.md
│       ├── resourcequota.md
│       ├── route.md
│       ├── secret.md
│       ├── service.md
│       ├── statefulset.md
│       └── zone.md
├── go.mod
├── go.sum
├── k8smod.sh
├── pkg
│   ├── app
│   │   ├── application.go
│   │   ├── types.go
│   │   └── util.go
│   ├── config
│   │   └── config.go
│   ├── database
│   │   └── database.go
│   ├── handlers
│   │   ├── app
│   │   ├── cluster
│   │   ├── common
│   │   ├── logging
│   │   └── resources
│   ├── kube
│   │   ├── history.go
│   │   └── log.go
│   ├── logi
│   │   └── log.go
│   ├── model
│   │   └── zone
│   ├── multicluster
│   │   ├── clientset
│   │   ├── multcluster.go
│   │   └── svc
│   ├── server
│   │   └── server.go
│   ├── trace
│   │   └── trace.go
│   └── util
│       ├── caller
│       ├── configmap
│       ├── gmsm
│       ├── http
│       ├── namespace
│       ├── pod
│       ├── podtemplatespec
│       ├── promhttp
│       ├── pvc
│       ├── resource
│       ├── route
│       ├── secret
│       └── service
└── vendor
```

## How to contribute

### Configure env

依赖了`github.com/daocloud/dsp-authorizer/proto`，需要设置`GOPRIVATE`环境变量。

```sh
export GOPRIVATE=github.com/daocloud,$GOPRIVATE

make go-mod
```

### Run on local
```sh
make run
```
