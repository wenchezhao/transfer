package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// +genclient
// +kubebuilder:subresource:status
// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object

type HelmOperation struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	// Status represents the status of helmoperation.
	// +optional
	Status OperationStatus `json:"status"`
}

type JobStatus string

const (
	RunningStatus   JobStatus = "Running"
	SucceededStatus JobStatus = "Succeeded"
	FailedStatus    JobStatus = "Failed"
	BlockedStatus   JobStatus = "Blocked"
)

type OperationStatus struct {
	ObservedGeneration int64       `json:"observedGeneration"`
	Action             string      `json:"action,omitempty"`
	Chart              string      `json:"chart,omitempty"`
	Version            string      `json:"version,omitempty"`
	Release            string      `json:"releaseName,omitempty"`
	Namespace          string      `json:"namespace,omitempty"`
	ProjectID          string      `json:"projectId,omitempty"`
	Token              string      `json:"token,omitempty"`
	Command            []string    `json:"command,omitempty"`
	JobName            string      `json:"jobName,omitempty"`
	JobNamespace       string      `json:"jobNamespace,omitempty"`
	JobCreated         bool        `json:"jobCreated,omitempty"`
	Phase              JobStatus   `json:"phase,omitempty"`
	PodCreated         bool        `json:"podCreated,omitempty"`
	Conditions         []Condition `json:"conditions,omitempty"`
}

// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object

// HelmOperationList contains a list of member HelmOperation.
type HelmOperationList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`

	// Items holds a list of HelmOperation.
	Items []HelmOperation `json:"items"`
}
