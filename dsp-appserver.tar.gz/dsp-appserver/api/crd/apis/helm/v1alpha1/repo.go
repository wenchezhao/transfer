package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// +genclient
// +genclient:nonNamespaced
// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object
// +kubebuilder:resource:scope="Cluster",path=helmrepos
// +kubebuilder:subresource:status

type HelmRepo struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec RepoSpec `json:"spec"`

	// Status represents the status of helmrepo.
	// +optional
	Status RepoStatus `json:"status"`
}

// SecretReference a reference to a secret object.
type SecretReference struct {
	// Namespace is the namespace for the resource being referenced.
	Namespace string `json:"namespace"`

	// Name is the name of resource being referenced.
	Name string `json:"name"`

	// ResourceVersion is the version of resource being referenced.
	// +optional
	ResourceVersion string `json:"resourceVersion"`
}

type RepoSpec struct {
	// URL A http URL of the helmrepo to connect to
	URL string `json:"url,omitempty"`

	// CABundle is a PEM encoded CA bundle which will be used to validate the helmrepo's certificate.
	// If unspecified, system trust roots will be used.
	CABundle []byte `json:"caBundle,omitempty"`

	// InsecureSkipTLSVerify will use insecure HTTPS to download the helmrepo's index.
	InsecureSkipTLSVerify bool `json:"insecureSkipTLSVerify,omitempty"`

	// ClientSecret is the client secret to be used to connect to the helmrepo
	// It is expected the secret be of type "kubernetes.io/basic-auth" or "kubernetes.io/tls" for Helm repos
	// and "kubernetes.io/basic-auth" or "kubernetes.io/ssh-auth" for git repos.
	// For a helmrepo the Namespace file will be ignored
	ClientSecret *SecretReference `json:"clientSecret,omitempty"`

	// BasicAuthSecretName is the client secret to be used to connect to the helmrepo
	BasicAuthSecretName string `json:"basicAuthSecretName,omitempty"`

	// ForceUpdate will cause the helmrepo index to be downloaded if it was last download before the specified time
	// If ForceUpdate is greater than time.Now() it will not trigger an update
	ForceUpdate *metav1.Time `json:"forceUpdate,omitempty"`

	// ServiceAccount this service account will be used to deploy charts instead of the end users credentials
	ServiceAccount string `json:"serviceAccount,omitempty"`

	// ServiceAccountNamespace namespace of the service account to use. This value is used only on
	// ClusterRepo and will be ignored on helmrepo
	ServiceAccountNamespace string `json:"serviceAccountNamespace,omitempty"`

	// If disabled the helmrepo clone will not be updated or allowed to be installed from
	Enabled *bool `json:"enabled,omitempty"`

	// DisableSameOriginCheck attaches the Basic Auth Header to all helmrelease client API calls, regardless of whether the destination of the API call matches the origin of the helmrepo's URL
	DisableSameOriginCheck bool `json:"disableSameOriginCheck,omitempty"`
}

type RepoCondition string

const (
	Unknown        RepoCondition = "Unknown"
	RepoDownloaded RepoCondition = "Downloaded"
)

type RepoStatus struct {
	ObservedGeneration int64 `json:"observedGeneration"`

	// IndexConfigMapName is the configmap with the store index in it
	IndexConfigMapName string `json:"indexConfigMapName,omitempty"`

	IndexConfigMapNamespace string `json:"indexConfigMapNamespace,omitempty"`

	IndexConfigMapResourceVersion string `json:"indexConfigMapResourceVersion,omitempty"`

	// DownloadTime the time when the index was last downloaded
	DownloadTime metav1.Time `json:"downloadTime,omitempty"`

	// The URL used for the last successful index
	URL string `json:"url,omitempty"`

	Conditions []Condition `json:"conditions,omitempty"`
}

type Condition struct {
	// Type of clusterRepo condition.
	Type RepoCondition `json:"type"`

	// Status of the condition, one of True, False, Unknown.
	Status metav1.ConditionStatus `json:"status"`

	// The last time this condition was updated.
	LastUpdateTime metav1.Time `json:"lastUpdateTime,omitempty"`

	// Last time the condition transitioned from one status to another.
	LastTransitionTime metav1.Time `json:"lastTransitionTime,omitempty"`

	// The reason for the condition's last transition.
	Reason string `json:"reason,omitempty"`

	// Human-readable message indicating details about last transition
	Message string `json:"message,omitempty"`
}

// +k8s:deepcopy-gen:interfaces=k8s.io/apimachinery/pkg/runtime.Object

// HelmRepoList  contains a list of member helmRepo.
type HelmRepoList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`

	// Items holds a list of helmRepo.
	Items []HelmRepo `json:"items"`
}
