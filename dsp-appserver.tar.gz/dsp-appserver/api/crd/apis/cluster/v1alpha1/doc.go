// Package v1alpha1 is the v1alpha1 version of the API.
// +k8s:deepcopy-gen=package,register
// +groupName=cluster.kpanda.io
package v1alpha1
