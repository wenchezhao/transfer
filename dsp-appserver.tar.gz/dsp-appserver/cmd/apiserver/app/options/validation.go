package options

// Validate validates server run options, to find
// options' misconfiguration.
func (s *Options) Validate() []error {
	var errors []error

	errors = append(errors, s.KubernetesOptions.Validate()...)

	return errors
}
