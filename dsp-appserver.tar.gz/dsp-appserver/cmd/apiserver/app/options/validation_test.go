package options

import (
	"testing"

	apiserverconfig "github.com/daocloud/dsp-appserver/pkg/apiserver/config"
	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
)

func TestOptions_Validate(t *testing.T) {
	type fields struct {
		ConfigFile       string
		ServerRunOptions *ServerRunOptions
		Config           *apiserverconfig.Config
		Debug            bool
	}
	tests := []struct {
		name   string
		fields fields
		want   []string
	}{
		{
			name: "test options validate",
			fields: fields{
				ConfigFile:       "file",
				ServerRunOptions: NewServerRunOptions(),
				Config: &apiserverconfig.Config{
					KubernetesOptions: &kubeclient.KubernetesOptions{
						KubeConfig: "config",
						Master:     "master",
					},
				},
				Debug: false,
			},
			want: []string{"stat config: no such file or directory"},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &Options{
				ConfigFile:       tt.fields.ConfigFile,
				ServerRunOptions: tt.fields.ServerRunOptions,
				Config:           tt.fields.Config,
				Debug:            tt.fields.Debug,
			}
			if got := s.Validate(); len(got) != len(tt.want) {
				t.Errorf("Validate() = %v, want %v", got, tt.want)
			}
		})
	}
}
