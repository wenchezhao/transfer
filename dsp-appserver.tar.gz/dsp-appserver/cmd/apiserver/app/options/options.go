package options

import (
	"context"
	"flag"
	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
	"log"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/opentracing/opentracing-go"
	cliflag "k8s.io/component-base/cli/flag"
	"k8s.io/klog/v2"

	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	"github.com/daocloud/dsp-appserver/pkg/apiserver"
	apiserverconfig "github.com/daocloud/dsp-appserver/pkg/apiserver/config"
	"github.com/daocloud/dsp-appserver/pkg/config"
	"github.com/daocloud/dsp-appserver/pkg/informermanager"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
	"github.com/daocloud/dsp-appserver/pkg/sharedcli/profileflag"
	"github.com/daocloud/dsp-appserver/pkg/trace"
)

type Options struct {
	ConfigFile string
	*apiserverconfig.Config

	Debug bool

	ProfileOpts profileflag.Options
	Tracer      opentracing.Tracer
}

func NewAPIServerRunOptions() *Options {
	return &Options{
		Config: apiserverconfig.New(),
	}
}

func (s *Options) Flags() cliflag.NamedFlagSets {
	fss := cliflag.NamedFlagSets{}
	fs := fss.FlagSet("generic")
	fs.BoolVar(&s.Debug, "debug", false, "apiserver server mode")
	s.ProfileOpts.AddFlags(fss.FlagSet("profile"))
	s.KubernetesOptions.AddFlags(fss.FlagSet("kubernetes"), s.KubernetesOptions)

	fs = fss.FlagSet("klog")
	local := flag.NewFlagSet("klog", flag.ExitOnError)
	klog.InitFlags(local)
	local.VisitAll(func(fl *flag.Flag) {
		fl.Name = strings.Replace(fl.Name, "_", "-", -1)
		fs.AddGoFlag(fl)
	})

	return fss
}

// NewAPIServer creates an APIServer instance using given options.
func (o *Options) NewAPIServer(ctx context.Context) (*apiserver.APIServer, error) {
	conf, err := config.NewForEnv()
	if err != nil {
		return nil, err
	}
	apiServer := apiserver.APIServer{
		Engine:      gin.Default(),
		Cfg:         conf,
		ProfileOpts: o.ProfileOpts,
		HttpServer: &http.Server{
			Addr:           ":" + conf.Port,
			Handler:        http.DefaultServeMux,
			ReadTimeout:    300 * time.Second,
			WriteTimeout:   300 * time.Second,
			MaxHeaderBytes: 1 << 20,
		},
	}

	kubernetesClient, err := kubeclient.NewKubernetesClient(o.KubernetesOptions)
	if err != nil {
		return nil, err
	}
	apiServer.KubernetesClient = kubernetesClient

	informerFactory := informers.NewSharedInformerFactory(kubernetesClient.Generated(), 600*time.Second)
	apiServer.InformerFactory = informerFactory

	apiServer.ClusterClient = clusterclient.NewClusterClient(apiServer.KubernetesClient.Kubernetes(), apiServer.InformerFactory.Cluster().V1alpha1().Clusters())

	tracer, err := trace.SetupTrace(ctx)
	if err != nil {
		log.Fatalf("err: %+v", err.Error())
	}
	apiServer.Cfg.Tracer = tracer

	clusterMgr, err := multicluster.NewClusterClientManager(conf)
	if err != nil {
		return nil, err
	}
	apiServer.ClusterClientManager = clusterMgr

	clientConfigGetter, err := informermanager.NewClientConfigGetter(*conf)
	if err != nil {
		return nil, err
	}
	apiServer.InformerManager = informermanager.NewInformerManager(ctx.Done(), informermanager.DefaultGVRs, clientConfigGetter)

	return &apiServer, nil
}
