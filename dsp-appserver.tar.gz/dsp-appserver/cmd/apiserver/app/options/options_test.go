package options

import (
	"reflect"
	"testing"

	apiserverconfig "github.com/daocloud/dsp-appserver/pkg/apiserver/config"
)

func Test_Flags(t *testing.T) {
	s := NewAPIServerRunOptions()
	fss := s.Flags()
	if fss.FlagSet("debug") == nil {
		t.Fail()
	}
}

func TestNewAPIServerRunOptions(t *testing.T) {
	tests := []struct {
		name string
		want *Options
	}{
		{
			name: "test new apisever",
			want: &Options{
				Config: apiserverconfig.New(),
				Debug:  false,
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewAPIServerRunOptions(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewAPIServerRunOptions() = %v, want %v", got, tt.want)
			}
		})
	}
}
