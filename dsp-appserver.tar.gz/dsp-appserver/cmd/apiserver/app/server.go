/*
Copyright 2022 The Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package app

import (
	"context"

	"github.com/spf13/cobra"
	utilerrors "k8s.io/apimachinery/pkg/util/errors"
	"sigs.k8s.io/controller-runtime/pkg/manager/signals"

	"github.com/daocloud/dsp-appserver/cmd/apiserver/app/options"
	"github.com/daocloud/dsp-appserver/pkg/version"
)

func NewAPIServerCommand(ctx context.Context) *cobra.Command {
	s := options.NewAPIServerRunOptions()

	cmd := &cobra.Command{
		Use:  "ccp-apiserver",
		Long: `The CCP API server define the Cloud Native Platform multi-cluster interface`,
		RunE: func(cmd *cobra.Command, args []string) error {
			if errs := s.Validate(); len(errs) != 0 {
				return utilerrors.NewAggregate(errs)
			}

			return Run(signals.SetupSignalHandler(), s)
		},
		SilenceUsage: true,
	}

	fs := cmd.Flags()
	namedFlagSets := s.Flags()
	for _, f := range namedFlagSets.FlagSets {
		fs.AddFlagSet(f)
	}

	versionCmd := &cobra.Command{
		Use:   "version",
		Short: "Print the version of ccp-apiserver",
		Run: func(cmd *cobra.Command, args []string) {
			cmd.Println(version.Get())
		},
	}

	cmd.AddCommand(versionCmd)

	return cmd
}

func Run(ctx context.Context, s *options.Options) error {
	apiserver, err := s.NewAPIServer(ctx)
	if err != nil {
		return err
	}

	err = apiserver.PrepareRun(ctx)
	if err != nil {
		return err
	}

	return apiserver.Run(ctx)
}
