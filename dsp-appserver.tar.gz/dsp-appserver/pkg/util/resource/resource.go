package resource

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"

	discoveryutil "github.com/daocloud/dsp-appserver/pkg/util/discovery"
	routeapi "github.com/openshift/api/route/v1"
	routescheme "github.com/openshift/client-go/route/clientset/versioned/scheme"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/util/sets"
	yamlutil "k8s.io/apimachinery/pkg/util/yaml"
	"k8s.io/client-go/kubernetes/scheme"
	"sigs.k8s.io/yaml"

	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	routeutil "github.com/daocloud/dsp-appserver/pkg/util/route"
	serviceutil "github.com/daocloud/dsp-appserver/pkg/util/service"
)

var log = logi.Log.Sugar()

func CheckFromReader(client clientset.Interface, namespace string, reader io.Reader) error {
	validator, err := client.Validator(true)
	if err != nil {
		return fmt.Errorf("failed to get validator: %v", err)
	}

	refs := sets.NewString()
	decoder := yamlutil.NewYAMLOrJSONDecoder(reader, 4096)
	for {
		// unmarshals the next object from the underlying stream into the provide object
		ext := runtime.RawExtension{}
		if err := decoder.Decode(&ext); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return err
		}
		ext.Raw = bytes.TrimSpace(ext.Raw)
		if len(ext.Raw) == 0 || bytes.Equal(ext.Raw, []byte("null")) {
			continue
		}

		if err := validator.ValidateBytes(ext.Raw); err != nil {
			return err
		}

		obj := &unstructured.Unstructured{}
		if err := yaml.Unmarshal(ext.Raw, obj); err != nil {
			return err
		}

		// find the object's resource interface
		gvk := obj.GroupVersionKind()
		_, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			log.Errorf("failed to discovery GVR for the resource %v: %v", gvk, err)
			return err
		}

		// name can not be null
		if obj.GetName() == "" {
			log.Errorf("resource %s name can not be null", obj.GetKind())
			return fmt.Errorf("resource %s name can not be null", obj.GetKind())
		}

		// if the resource duplicated
		ref := fmt.Sprintf("%s %s", obj.GroupVersionKind().String(), obj.GetName())
		if refs.Has(ref) {
			log.Errorf("the resource %s is duplicated", ref)
			return fmt.Errorf("the resource %s is duplicated", ref)
		} else {
			refs.Insert(ref)
		}

		// check the object's namespace
		if obj.GetNamespace() != "" && obj.GetNamespace() != namespace {
			log.Errorf("expected namespace %q or blank, but got namespace %q: %v", namespace, obj.GetNamespace(), obj)
			return fmt.Errorf("expected namespace %q or blank, but got namespace %q: %v", namespace, obj.GetNamespace(), obj)
		}

		// check the nodePort
		obj.SetNamespace(namespace)
		if err := CheckNodePort(client, obj); err != nil {
			return err
		}
	}
	return nil
}

// GetObjectFromData will process YAML documents or JSON documents from the given
// reader, then get it by order.
func GetObjectFromData(data unstructured.Unstructured) (runtime.Object, error) {
	j, err := data.MarshalJSON()
	if err != nil {
		log.Errorf("failed to marshal unstructured to json, err %+v", err)
		return nil, err
	}

	if data.GetKind() == "Route" {
		openshiftDecode := routescheme.Codecs.UniversalDeserializer().Decode
		obj, _, err := openshiftDecode([]byte(j), nil, nil)
		if err != nil {
			log.Errorf("failed to decode route, err %+v", err)
			return nil, err
		}
		return obj, nil
	}

	kubeDecode := scheme.Codecs.UniversalDeserializer().Decode
	obj, _, err := kubeDecode([]byte(j), nil, nil)
	if err != nil {
		log.Errorf("failed to decode kubernetes resources, err %+v", err)
		return nil, err
	}
	return obj, nil
}

// CheckNodePort check service nodePort
func CheckNodePort(client clientset.Interface, obj *unstructured.Unstructured) error {
	switch obj.GetKind() {
	case "Route":
		b, err := obj.MarshalJSON()
		if err != nil {
			log.Errorf("failed to marshal obj to json: %v", err)
			return err
		}

		route := routeapi.Route{}
		if err := json.Unmarshal(b, &route); err != nil {
			log.Errorf("failed to unmarshal json to Route: %v", err)
			return err
		}
		// check target port
		err = routeutil.CheckRoutePortAndHost(context.TODO(), client, &route)
		if err != nil {
			log.Errorf("nodePort is conflict: %v", err)
			return err
		}

	case "Service":
		b, err := obj.MarshalJSON()
		if err != nil {
			log.Errorf("failed to marshal obj to json: %v", err)
			return err
		}

		service := corev1.Service{}
		if err := json.Unmarshal(b, &service); err != nil {
			log.Errorf("failed to unmarshal json to Route: %v", err)
			return err
		}

		// check service nodePort, can not be null and not exit
		if service.Spec.Type == corev1.ServiceTypeNodePort {
			for _, port := range service.Spec.Ports {
				if port.NodePort == 0 {
					log.Errorf("the service type is NodePort, so spec.ports.nodePort filed can not be null")
					return fmt.Errorf("the service type is NodePort, so spec.ports.nodePort filed can not be null")
				}
				err = serviceutil.CheckServiceNodePort(context.TODO(), client, fmt.Sprint(port.NodePort))
				if err != nil {
					log.Errorf("nodePort %s  is conflict", port)
					return err
				}
			}
		}

	}

	return nil
}
