package util

import (
	"fmt"
	"strconv"

	"k8s.io/apimachinery/pkg/util/json"

	"github.com/daocloud/dsp-appserver/pkg/constants"
)

func GenRestartPatchData(restartTimestamp int64) ([]byte, error) {
	data := map[string]interface{}{
		"spec": map[string]interface{}{
			"template": map[string]interface{}{
				"metadata": map[string]interface{}{
					"annotations": map[string]interface{}{
						constants.WorkloadSnapshotAnnotationLastRestartTimestamp: strconv.Itoa(int(restartTimestamp)),
					},
				},
			},
		},
	}
	return json.Marshal(data)
}

func GenStartPatchData(annotations map[string]string) ([]byte, error) {
	if annotations == nil {
		return nil, fmt.Errorf("can not start a workload which has no historical replicas")
	}

	replicasString, ok := annotations[constants.WorkloadLastReplicasAnnoKey]
	if !ok {
		return nil, fmt.Errorf("can not start a workload which has no historical replicas")
	}

	replicas, err := strconv.Atoi(replicasString)
	if err != nil {
		return nil, fmt.Errorf("historical replicas must be a positive integer")
	}

	data := map[string]interface{}{
		"spec": map[string]interface{}{
			"replicas": int32(replicas),
		},
	}
	return json.Marshal(data)
}

func GenStopPatchData(replicas *int32) ([]byte, error) {
	if replicas == nil || *replicas == 0 {
		return nil, fmt.Errorf("can not stop a workload whose replicas is empty or zero")
	}

	data := map[string]interface{}{
		"metadata": map[string]interface{}{
			"annotations": map[string]interface{}{
				constants.WorkloadLastReplicasAnnoKey: strconv.Itoa(int(*replicas)),
			},
		},
		"spec": map[string]interface{}{
			"replicas": 0,
		},
	}
	return json.Marshal(data)
}
