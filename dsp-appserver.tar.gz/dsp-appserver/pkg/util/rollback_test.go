package util

import (
	"testing"
)

func TestGenRestartPatchData(t *testing.T) {
	type args struct {
		restartTimestamp int64
	}
	tests := []struct {
		name    string
		args    args
		want    []byte
		wantErr bool
	}{
		{
			name: "test data",
			args: args{
				restartTimestamp: 11,
			},
			want:    []byte{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := GenRestartPatchData(tt.args.restartTimestamp)
			if (err != nil) != tt.wantErr {
				t.Errorf("GenRestartPatchData() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
