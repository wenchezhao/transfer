package util

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util/sliceutil"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	"sigs.k8s.io/controller-runtime/pkg/client"
)

// IsClusterReady tells whether the cluster status in 'Ready' condition.
func IsClusterReady(clusterStatus *clusterv1alpha1.ClusterStatus) bool {
	for _, condition := range clusterStatus.Conditions {
		if condition.Type == clusterv1alpha1.ClusterConditionRunning && condition.Status == metav1.ConditionTrue {
			return true
		}
	}
	return false
}

// GetCluster returns the given Cluster resource.
func GetCluster(hostClient client.Client, clusterName string) (*clusterv1alpha1.Cluster, error) {
	cluster := &clusterv1alpha1.Cluster{}
	if err := hostClient.Get(context.TODO(), types.NamespacedName{Name: clusterName}, cluster); err != nil {
		return nil, err
	}
	return cluster, nil
}

// LabelsConvert converts labels data structure to JSONPatchType.
func LabelsConvert(labels map[string]string) ([]byte, error) {
	return AddJSONPatch(&JSONPatch{
		Operation: JSONPatchOperationReplace,
		Path:      "/metadata/labels",
		Value:     labels,
	}).ToBytes()
}

// AnnotationsConvert converts labels data structure to JSONPatchType.
func AnnotationsConvert(annotations map[string]string) ([]byte, error) {
	return AddJSONPatch(&JSONPatch{
		Operation: JSONPatchOperationReplace,
		Path:      "/metadata/annotations",
		Value:     annotations,
	}).ToBytes()
}

// PersistentVolumeClaimCapacity converts pvc capacity structure to JSONPatchType.
func PersistentVolumeClaimCapacityConvert(capacity string) ([]byte, error) {
	return AddJSONPatch(&JSONPatch{
		Operation: JSONPatchOperationReplace,
		Path:      "/spec/resources/requests/storage",
		Value:     capacity,
	}).ToBytes()
}

// NodeTaintsConvert converts node taints data structure to JSONPatchType.
func NodeTaintsConvert(taints []*corev1.Taint) ([]byte, error) {
	return AddJSONPatch(&JSONPatch{
		Operation: JSONPatchOperationReplace,
		Path:      "/spec/taints",
		Value:     taints,
	}).ToBytes()
}

// NodeScheduleConvert converts node spec.unschedulable to JSONPatchType.
func NodeScheduleConvert(unschedulable bool) ([]byte, error) {
	return AddJSONPatch(&JSONPatch{
		Operation: JSONPatchOperationReplace,
		Path:      "/spec/unschedulable",
		Value:     unschedulable,
	}).ToBytes()
}

// GetCurrentNS fetch namespace the current pod running in. reference to client-go (config *inClusterClientConfig) Namespace() (string, bool, error).
func GetCurrentNS() (string, error) {
	if ns := os.Getenv("POD_NAMESPACE"); ns != "" {
		return ns, nil
	}

	if data, err := os.ReadFile("/var/run/secrets/kubernetes.io/serviceaccount/namespace"); err == nil {
		if ns := strings.TrimSpace(string(data)); len(ns) > 0 {
			return ns, nil
		}
	}
	return "", fmt.Errorf("can not get namespace where pods running in")
}

func GetCurrentNSOrDefault() string {
	ns, err := GetCurrentNS()
	if err != nil {
		return "default"
	}
	return ns
}

func ExcludeBuiltInLabels(originLabels map[string]string) map[string]string {
	for key := range originLabels {
		if sliceutil.HasString(BuiltInLabels, key) {
			delete(originLabels, key)
		}
	}
	return originLabels
}

func ExcludeBuiltInAnnotations(originAnnotations map[string]string) map[string]string {
	for key := range originAnnotations {
		if sliceutil.HasString(BuiltInAnnotations, key) {
			delete(originAnnotations, key)
		}
	}
	return originAnnotations
}

func MakeConfigSkipTLS(config *rest.Config) {
	if config == nil {
		return
	}
	config.CAData = nil
	config.Insecure = true
}

func ShouldUseEgress(cluster *clusterv1alpha1.Cluster, config *rest.Config) bool {
	if config == nil || cluster == nil {
		return false
	}
	if len(cluster.Status.ProxyURL) != 0 && cluster.Status.ProxyURL == config.Host {
		// if the Host from kubeConfig in secret != OriginAPIEndPoint(k8s), so The Host must be egress proxy addr
		return true
	}
	// sets environment variables to disable egress access to subclusters
	if !DisableEgressProxy {
		return true
	}
	return false
}

func GenWorkClusterLabels() map[string]string {
	return map[string]string{fmt.Sprintf(constants.ClusterRoleLabelTemplate, constants.ClusterRoleWorker): ""}
}

func GenThirdPartyLabels() map[string]string {
	return map[string]string{fmt.Sprintf(constants.ClusterRoleLabelTemplate, constants.ClusterRoleThirdParty): ""}
}

func FetchManagerCluster(labels map[string]string) string {
	if labels == nil {
		return ""
	}
	return labels[constants.ManagedByLabelKey]
}

func GetKubeConfigFromCluster(ctx context.Context, cluster *clusterv1alpha1.Cluster, c client.Client) (*rest.Config, error) {
	if cluster.Spec.SecretRef == nil {
		return nil, fmt.Errorf("cluster %s secret ref is empty", cluster.Name)
	}

	localSecret := cluster.Spec.SecretRef

	// get the secret from kpanda server
	secret := &corev1.Secret{}
	err := c.Get(ctx, client.ObjectKey{Namespace: localSecret.Namespace, Name: localSecret.Name}, secret)
	if err != nil {
		return nil, err
	}

	if len(secret.Data) == 0 {
		return nil, fmt.Errorf("unable get the cluster %s secret: %s", cluster.Name, secret.Name)
	}

	// get the ca and cert
	clientConfig, err := clientcmd.NewClientConfigFromBytes(secret.Data["kubeconfig"])
	if err != nil {
		return nil, err
	}
	config, err := clientConfig.ClientConfig()
	if err != nil {
		return nil, err
	}
	skipTLSVerify := false
	if ShouldUseEgress(cluster, config) {
		skipTLSVerify = true
	} else {
		// use cluster.Spec.APIEndpoint access member cluster
		config.Host = cluster.Spec.APIEndpoint
	}
	if cluster.Spec.InsecureSkipTLSVerification || skipTLSVerify {
		// the key point to use egress proxy
		// specifying a root certificates file with the insecure flag is not allowed
		MakeConfigSkipTLS(config)
	}

	return config, nil
}

func IsMangerCluster(labels map[string]string) bool {
	if labels == nil {
		return false
	}
	_, ok := labels[fmt.Sprintf(constants.ClusterRoleLabelTemplate, constants.ClusterRoleManager)]
	return ok
}

func IsVirtualCluster(labels map[string]string) bool {
	if labels == nil {
		return false
	}
	_, ok := labels[clusterv1alpha1.VirtualClusterLabelKey]
	return ok
}
