package app

import (
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func SetReadyCondition(appStatus *ApplicationStatus, reason, message string) {
	setCondition(appStatus, ConditionTypeReady, corev1.ConditionTrue, reason, message)
}

// NotReady - shortcut to set ready condition to false
func SetNotReadyCondition(appStatus *ApplicationStatus, reason, message string) {
	setCondition(appStatus, ConditionTypeReady, corev1.ConditionFalse, reason, message)
}

// Unknown - shortcut to set ready condition to unknown
func SetReadyUnknownCondition(appStatus *ApplicationStatus, reason, message string) {
	setCondition(appStatus, ConditionTypeReady, corev1.ConditionUnknown, reason, message)
}

// setErrorCondition - shortcut to set error condition
func SetErrorCondition(appStatus *ApplicationStatus, reason, message string) {
	setCondition(appStatus, ConditionTypeError, corev1.ConditionTrue, reason, message)
}

// clearErrorCondition - shortcut to set error condition
func ClearErrorCondition(appStatus *ApplicationStatus) {
	setCondition(appStatus, ConditionTypeError, corev1.ConditionFalse, "NoError", "No error seen")
}

func setCondition(appStatus *ApplicationStatus, ctype ConditionType, status corev1.ConditionStatus, reason, message string) {
	var c *Condition
	for i := range appStatus.Conditions {
		if appStatus.Conditions[i].Type == ctype {
			c = &appStatus.Conditions[i]
		}
	}
	if c == nil {
		addCondition(appStatus, ctype, status, reason, message)
	} else {
		// check message ?
		if c.Status == status && c.Reason == reason && c.Message == message {
			return
		}
		now := metav1.Now()
		c.LastUpdateTime = now
		c.Status = status
		c.Reason = reason
		c.Message = message
	}
}

func addCondition(appStatus *ApplicationStatus, ctype ConditionType, status corev1.ConditionStatus, reason, message string) {
	now := metav1.Now()
	c := Condition{
		Type:           ctype,
		LastUpdateTime: now,
		Status:         status,
		Reason:         reason,
		Message:        message,
	}
	appStatus.Conditions = append(appStatus.Conditions, c)
}
