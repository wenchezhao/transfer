package app

import (
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// ApplicationStatus defines the observed state of application
type ApplicationStatus struct {
	// Conditions represents the lastest state of the objects
	Conditions []Condition `json:"conditions,omitempty"`
	// Components embeds a list of object statuses
	Components []ObjectStatus `json:"components,omitempty"`
	// ComponentsReady records status of the objects in the format ready/total
	ComponentsReady string `json:"componentsReady,omitempty"`
}

// ConditionType encodes information on the condition
type ConditionType string

const (
	ConditionTypeReady = "Ready"
	ConditionTypeError = "Error"
)

// Condition describes the state of an object at a certain point.
type Condition struct {
	// Type of condition.
	Type ConditionType `json:"type"`
	// Status of the condition, one of True, False, Unknown.
	Status corev1.ConditionStatus `json:"status"`
	// The reason for the condition's last transition.
	Reason string `json:"reason,omitempty"`
	// A human readable message indicating details about the transition.
	Message string `json:"message,omitempty"`
	// Last time the condition was probed
	LastUpdateTime metav1.Time `json:"lastUpdateTime,omitempty"`
}

// ObjectStatus is a generic status holder for objects
type ObjectStatus struct {
	// APIGroup is the group for the resource being referenced
	APIGroup string `json:"group,omitempty"`
	// Kind is the type of resource being referenced
	Kind string `json:"kind,omitempty"`
	// Name is the name of resource being referenced
	Name string `json:"name,omitempty"`
	// Status. Values: InProgress, Ready, Unknown
	Status string `json:"status,omitempty"`
}
