package maputil

import "testing"

func TestContainsMap(t *testing.T) {
	type args struct {
		src map[string]string
		sub map[string]string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "src contains sub map",
			args: args{
				src: map[string]string{"aaa": "aaa", "bbb": "bbb"},
				sub: map[string]string{"aaa": "aaa"},
			},
			want: true,
		},
		{
			name: "src doesn't contains sub map",
			args: args{
				src: map[string]string{"aaa": "aaa"},
				sub: map[string]string{"aaa": "aaa", "bbb": "bbb"},
			},
			want: false,
		},
		{
			name: "src is nil",
			args: args{
				src: nil,
				sub: map[string]string{"aaa": "aaa", "bbb": "bbb"},
			},
			want: false,
		},
		{
			name: "sub is nil",
			args: args{
				src: map[string]string{"aaa": "aaa", "bbb": "bbb"},
				sub: nil,
			},
			want: true,
		},
		{
			name: "src and sub is nil",
			args: args{
				src: nil,
				sub: nil,
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := ContainsMap(tt.args.src, tt.args.sub); got != tt.want {
				t.Errorf("ContainsMap() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_EqualMap(t *testing.T) {
	type args struct {
		map1 map[string]string
		map2 map[string]string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "map1 == map2",
			args: args{
				map1: map[string]string{"aaa": "aaa"},
				map2: map[string]string{"aaa": "aaa"},
			},
			want: true,
		},
		{
			name: "map1 != map2",
			args: args{
				map1: map[string]string{"aaa": "aaa1", "sdsdsd": "qaasdsd"},
				map2: map[string]string{"aaa": "aaa"},
			},
			want: false,
		},
		{
			name: "map1 != map2",
			args: args{
				map1: map[string]string{"aaa": "aaa1"},
				map2: map[string]string{"aaa": "aaa"},
			},
			want: false,
		},
		{
			name: "map1 is nil, map2 is not nil",
			args: args{
				map1: nil,
				map2: map[string]string{"aaa": "aaa"},
			},
			want: false,
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if EqualMap(test.args.map1, test.args.map2) != test.want {
				t.Fail()
			}
		})
	}
}
