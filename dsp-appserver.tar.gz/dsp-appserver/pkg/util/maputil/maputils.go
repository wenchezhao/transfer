package maputil

// ContainsMap return src contains sub.
func ContainsMap(src, sub map[string]string) bool {
	for k, v := range sub {
		if value, ok := src[k]; !ok || v != value {
			return false
		}
	}
	return true
}

func EqualMap(map1, map2 map[string]string) bool {
	if len(map1) != len(map2) {
		return false
	}
	for key1, value1 := range map1 {
		if value2, ok := map2[key1]; value1 != value2 || !ok {
			return false
		}
	}
	return true
}
