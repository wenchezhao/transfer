package helper

import (
	"reflect"
	"testing"

	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	certificatesv1 "k8s.io/api/certificates/v1"
	corev1 "k8s.io/api/core/v1"
	discoveryv1beta1 "k8s.io/api/discovery/v1beta1"
	networkingv1 "k8s.io/api/networking/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"sigs.k8s.io/controller-runtime/pkg/client"
)

func TestConvertToDaemonSet(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *appsv1.DaemonSet
		wantErr bool
	}{
		{
			name: "valid daemonset",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": "apps/v1",
						"kind":       "DaemonSet",
					},
				},
			},
			want: &appsv1.DaemonSet{
				TypeMeta: metav1.TypeMeta{
					Kind:       "DaemonSet",
					APIVersion: "apps/v1",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid daemonset",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": 2,
						"kind":       3,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToDaemonSet(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToDaemonSet() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToDaemonSet() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToDeployment(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *appsv1.Deployment
		wantErr bool
	}{
		{
			name: "valid deployment",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": "apps/v1",
						"kind":       "Deployment",
					},
				},
			},
			want: &appsv1.Deployment{
				TypeMeta: metav1.TypeMeta{
					Kind:       "Deployment",
					APIVersion: "apps/v1",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid deployment",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": 1,
						"kind":       2,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToDeployment(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToDeployment() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToDeployment() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToEndpointSlice(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *discoveryv1beta1.EndpointSlice
		wantErr bool
	}{
		{
			name: "valid endpoints",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": "discovery.k8s.io/v1",
						"kind":       "EndpointSlice",
					},
				},
			},
			want: &discoveryv1beta1.EndpointSlice{
				TypeMeta: metav1.TypeMeta{
					Kind:       "EndpointSlice",
					APIVersion: "discovery.k8s.io/v1",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid endpoints",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": 1,
						"kind":       2,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToEndpointSlice(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToEndpointSlice() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToEndpointSlice() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToJob(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *batchv1.Job
		wantErr bool
	}{
		{
			name: "valid job",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": "batch/v1",
						"kind":       "Job",
					},
				},
			},
			want: &batchv1.Job{
				TypeMeta: metav1.TypeMeta{
					Kind:       "Job",
					APIVersion: "batch/v1",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid job",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": 1,
						"kind":       2,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToJob(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToJob() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToJob() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToNode(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *corev1.Node
		wantErr bool
	}{
		{
			name: "valid node",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": "v1",
						"kind":       "Node",
					},
				},
			},
			want: &corev1.Node{
				TypeMeta: metav1.TypeMeta{
					Kind:       "Node",
					APIVersion: "v1",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid node",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": 1,
						"kind":       2,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToNode(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToNode() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToNode() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToPod(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *corev1.Pod
		wantErr bool
	}{
		{
			name: "valid pod",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": "v1",
						"kind":       "Pod",
					},
				},
			},
			want: &corev1.Pod{
				TypeMeta: metav1.TypeMeta{
					Kind:       "Pod",
					APIVersion: "v1",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid pod",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": 1,
						"kind":       2,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToPod(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToPod() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToPod() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToReplicaSet(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *appsv1.ReplicaSet
		wantErr bool
	}{
		{
			name: "valid replicaset",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": "apps/v1",
						"kind":       "ReplicaSet",
					},
				},
			},
			want: &appsv1.ReplicaSet{
				TypeMeta: metav1.TypeMeta{
					Kind:       "ReplicaSet",
					APIVersion: "apps/v1",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid replicaset",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": 1,
						"kind":       2,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToReplicaSet(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToReplicaSet() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToReplicaSet() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToStatefulSet(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *appsv1.StatefulSet
		wantErr bool
	}{
		{
			name: "valid statefulSet",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": "apps/v1",
						"kind":       "StatefulSet",
					},
				},
			},
			want: &appsv1.StatefulSet{
				TypeMeta: metav1.TypeMeta{
					Kind:       "StatefulSet",
					APIVersion: "apps/v1",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid statefulSet",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"apiVersion": 1,
						"kind":       2,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToStatefulSet(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToStatefulSet() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToStatefulSet() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToClusterRole(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *rbacv1.ClusterRole
		wantErr bool
	}{
		{
			name: "valid clusterRole",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": "cr",
						},
					},
				},
			},
			want: &rbacv1.ClusterRole{
				ObjectMeta: metav1.ObjectMeta{
					Name: "cr",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid clusterRole",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": 1,
						},
					},
				},
			},
			want:    &rbacv1.ClusterRole{},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToClusterRole(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToClusterRole() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != nil && !reflect.DeepEqual(got.Name, tt.want.Name) {
				t.Errorf("ConvertToClusterRole() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToClusterRoleBinding(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *rbacv1.ClusterRoleBinding
		wantErr bool
	}{
		{
			name: "valid clusterRoleBinding",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": "cr",
						},
					},
				},
			},
			want: &rbacv1.ClusterRoleBinding{
				ObjectMeta: metav1.ObjectMeta{
					Name: "cr",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid clusterRoleBinding",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": 1,
						},
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToClusterRoleBinding(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToClusterRole() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != nil && !reflect.DeepEqual(got.Name, tt.want.Name) {
				t.Errorf("ConvertToClusterRole() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToCSR(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *certificatesv1.CertificateSigningRequest
		wantErr bool
	}{
		{
			name: "valid csr",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": "csr",
						},
					},
				},
			},
			want: &certificatesv1.CertificateSigningRequest{
				ObjectMeta: metav1.ObjectMeta{
					Name: "csr",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid csr",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": 123,
						},
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToCSR(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToCSR() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToCSR() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToUnstructured(t *testing.T) {
	type args struct {
		obj client.Object
	}
	tests := []struct {
		name    string
		args    args
		want    *unstructured.Unstructured
		wantErr bool
	}{
		{
			name: "object is valid",
			args: args{
				obj: &corev1.ConfigMap{
					TypeMeta: metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{
						Name: "cm",
					},
					Immutable:  nil,
					Data:       nil,
					BinaryData: nil,
				},
			},
			want: &unstructured.Unstructured{
				Object: map[string]interface{}{
					"metadata": map[string]interface{}{
						"creationTimestamp": nil,
						"name":              "cm",
					},
				},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToUnstructured(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToUnstructured() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToUnstructured() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToIngress(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *networkingv1.Ingress
		wantErr bool
	}{
		{
			name: "valid ingress",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": "ingress",
						},
					},
				},
			},
			want: &networkingv1.Ingress{
				TypeMeta: metav1.TypeMeta{},
				ObjectMeta: metav1.ObjectMeta{
					Name: "ingress",
				},
				Spec:   networkingv1.IngressSpec{},
				Status: networkingv1.IngressStatus{},
			},
			wantErr: false,
		},
		{
			name: "invalid ingress",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": 1,
						},
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToIngress(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToIngress() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToIngress() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToCronjob(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *batchv1.CronJob
		wantErr bool
	}{
		{
			name: "valid cronjob",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"kind":       "CronJob",
						"apiVersion": "batch/v1beta1",
						"metadata": map[string]interface{}{
							"name": "cronjob",
						},
					},
				},
			},
			want:    &batchv1.CronJob{ObjectMeta: metav1.ObjectMeta{Name: "cronjob"}},
			wantErr: false,
		},
		{
			name: "not cronjob",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"kind":       "ConfigMap",
						"apiVersion": "",
						"metadata": map[string]interface{}{
							"name": "configmap",
						},
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToCronjob(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToCronjob() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !tt.wantErr && !reflect.DeepEqual(got.Name, tt.want.Name) {
				t.Errorf("ConvertToCronjob() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToConfigMap(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *corev1.ConfigMap
		wantErr bool
	}{
		{
			name: "valid configmap",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": "configmap",
						},
					},
				},
			},
			want: &corev1.ConfigMap{
				TypeMeta: metav1.TypeMeta{},
				ObjectMeta: metav1.ObjectMeta{
					Name: "configmap",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid configmap",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": 1,
						},
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToConfigMap(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToConfigMap() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToConfigMap() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToNamespace(t *testing.T) {
	type args struct {
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		args    args
		want    *corev1.Namespace
		wantErr bool
	}{
		{
			name: "valid namespace",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": "namespace",
						},
					},
				},
			},
			want: &corev1.Namespace{
				TypeMeta: metav1.TypeMeta{},
				ObjectMeta: metav1.ObjectMeta{
					Name: "namespace",
				},
			},
			wantErr: false,
		},
		{
			name: "invalid namespace",
			args: args{
				obj: &unstructured.Unstructured{
					Object: map[string]interface{}{
						"metadata": map[string]interface{}{
							"name": 1,
						},
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ConvertToNamespace(tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("ConvertToNamespace() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToNamespace() got = %v, want %v", got, tt.want)
			}
		})
	}
}
