package helper

import (
	"reflect"
	"testing"

	corev1 "k8s.io/api/core/v1"
)

func TestGetReadyPodNum(t *testing.T) {
	type args struct {
		pods []*corev1.Pod
	}
	tests := []struct {
		name string
		args args
		want int32
	}{
		{
			name: "pod list is null",
			args: args{},
			want: 0,
		},
		{
			name: "pod ready num is 1",
			args: args{
				pods: []*corev1.Pod{newReadyPod(), newUnreadyReadyPod()},
			},
			want: 1,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetReadyPodNum(tt.args.pods); got != tt.want {
				t.Errorf("GetReadyPodNum() = %v, want %v", got, tt.want)
			}
		})
	}
}

func newReadyPod() *corev1.Pod {
	return &corev1.Pod{
		Status: corev1.PodStatus{
			Phase: corev1.PodRunning,
			Conditions: []corev1.PodCondition{
				{
					Type:   corev1.PodReady,
					Status: corev1.ConditionTrue,
				},
			},
		},
	}
}

func newUnreadyReadyPod() *corev1.Pod {
	return &corev1.Pod{
		Status: corev1.PodStatus{
			Phase: corev1.PodRunning,
			Conditions: []corev1.PodCondition{
				{
					Type:   corev1.PodReady,
					Status: corev1.ConditionFalse,
				},
			},
		},
	}
}

func Test_hasPodReadyCondition(t *testing.T) {
	type args struct {
		conditions []corev1.PodCondition
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "pod condition is null",
			args: args{},
			want: false,
		},
		{
			name: "pod is ready",
			args: args{
				newReadyPod().Status.Conditions,
			},
			want: true,
		},
		{
			name: "pod is not ready",
			args: args{
				newUnreadyReadyPod().Status.Conditions,
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := hasPodReadyCondition(tt.args.conditions); got != tt.want {
				t.Errorf("hasPodReadyCondition() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetNodeNonTerminatedPodsList(t *testing.T) {
	type args struct {
		pods []*corev1.Pod
	}
	tests := []struct {
		name string
		args args
		want []*corev1.Pod
	}{
		{
			name: "pod list is null",
			args: args{},
			want: []*corev1.Pod{},
		},
		{
			name: "pod list is null",
			args: args{
				pods: []*corev1.Pod{
					newReadyPod(),
					{
						Status: corev1.PodStatus{Phase: corev1.PodSucceeded},
					},
				},
			},
			want: []*corev1.Pod{newReadyPod()},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetNodeNonTerminatedPodsList(tt.args.pods); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetNodeNonTerminatedPodsList() = %v, want %v", got, tt.want)
			}
		})
	}
}
