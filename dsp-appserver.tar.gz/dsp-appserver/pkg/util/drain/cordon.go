package drain

import (
	"context"
	"encoding/json"

	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/strategicpatch"
	"k8s.io/client-go/kubernetes"
)

func RunCordonOrUncordon(client kubernetes.Interface, node *v1.Node, desired bool) (*v1.Node, error) {
	oldData, err := json.Marshal(node)
	if err != nil {
		return nil, err
	}

	node.Spec.Unschedulable = desired

	newData, err := json.Marshal(node)
	if err != nil {
		return nil, err
	}

	var newNode *v1.Node
	patchBytes, patchErr := strategicpatch.CreateTwoWayMergePatch(oldData, newData, node)
	if patchErr == nil {
		newNode, err = client.CoreV1().Nodes().Patch(context.TODO(), node.Name, types.StrategicMergePatchType, patchBytes, metav1.PatchOptions{})
	} else {
		newNode, err = client.CoreV1().Nodes().Update(context.TODO(), node, metav1.UpdateOptions{})
	}
	return newNode, err
}
