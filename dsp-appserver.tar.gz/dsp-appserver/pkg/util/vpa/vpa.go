package vpa

import (
	corev1 "k8s.io/api/core/v1"
	api "k8s.io/kubernetes/pkg/apis/core"
)

// RecommendedContainerResources is the recommendation of resources computed by
// autoscaler for a specific container. Respects the container resource policy
// if present in the spec. In particular the recommendation is not produced for
// containers with `ContainerScalingMode` set to 'Off'.
type RecommendedContainerResources struct {
	// Name of the container.
	ContainerName string
	// Recommended amount of resources.
	Target api.ResourceList
	// Minimum recommended amount of resources.
	// This amount is not guaranteed to be sufficient for the application to operate in a stable way, however
	// running with less resources is likely to have significant impact on performance/availability.
	// +optional
	LowerBound api.ResourceList
	// Maximum recommended amount of resources.
	// Any resources allocated beyond this value are likely wasted. This value may be larger than the maximum
	// amount of application is actually capable of consuming.
	// +optional
	UpperBound api.ResourceList
}

// RevertContainerResourcesUnit revert containers information to resources information
func RevertContainerResourcesUnit(cs []corev1.Container) map[string]map[string]int64 {
	results := make(map[string]map[string]int64)
	for _, c := range cs {
		var (
			requestsCpu int64
			requestsMem int64
			limitsCpu   int64
			limitsMem   int64
		)
		requestsCpu = c.Resources.Requests.Cpu().MilliValue()
		requestsMem = c.Resources.Requests.Memory().Value()
		limitsCpu = c.Resources.Limits.Cpu().MilliValue()
		limitsMem = c.Resources.Limits.Memory().Value()
		results[c.Name] = map[string]int64{
			"requestsCpu": requestsCpu,
			"requestsMem": requestsMem,
			"limitsCpu":   limitsCpu,
			"limitsMem":   limitsMem,
		}
	}
	return results
}
