package util

import (
	"time"

	"github.com/daocloud/dsp-appserver/pkg/constants"
)

// Define finalizers used by kpanda system.
const (
	// ClusterControllerFinalizer is added to Cluster to ensure Work as well as the
	// execution space (namespace) is deleted before itself is deleted.
	ClusterControllerFinalizer = "kpanda.io/cluster-controller"

	ClusterBindingSyncerControllerFinalizer = "kpanda.io/bindings-syncer-controller"
)

// Define labels used by kpanda system.
const (
	// Tag Cluster kube-system uuid
	// ref : https://github.com/kubernetes-sigs/mcs-api/blob/master/pkg/apis/v1alpha1/well_known_labels.go
	// ref : https://komodor.com/blog/best-practices-guide-for-kubernetes-labels-and-annotations/
	ClusterSystemIDLabel = "kpanda.io/kube-system-id"
)

const (
	// ClusterSystemNameLabel tags Secret clusterName which cluster the secret belongs to.
	ClusterSystemNameLabel = "kpanda.io/cluster-name"
)

const (
	// The description annotation of cluster.
	ClusterDescribeAnnotation = "kpanda.io/describe"
)

// BuiltInLabels the built-in label used in the kpanda system will be automatically ignored
// when edited through the api, and can only be maintained and updated through the kpanda-controllermanager.
var BuiltInLabels = []string{ClusterSystemIDLabel, ClusterSystemNameLabel}

// BuiltInAnnotations the built-in label used in the kpanda system will be automatically ignored
// when edited through the api, and can only be maintained and updated through describe field when creating or updating cluster.
var BuiltInAnnotations = []string{constants.AliasNameAnnotation}

const (
	// ProviderField indicates the 'provider' field of a cluster.
	ProviderField = "provider"
	// RegionField indicates the 'region' field of a cluster.
	RegionField = "region"
	// ZoneField indicates the 'zone' field of a cluster.
	ZoneField = "zone"
)

// Define resource kind.
const (
	// DeploymentKind indicates the target resource is a deployment.
	DeploymentKind = "Deployment"
	// ServiceKind indicates the target resource is a service.
	ServiceKind = "Service"
	// IngressKind indicates the target resource is a ingress.
	IngressKind = "Ingress"
	// JobKind indicates the target resource is a job.
	JobKind = "Job"
	// CronJobKind indicates the target resource is a CronJob.
	CronJobKind = "CronJob"
	// PodKind indicates the target resource is a pod.
	PodKind = "Pod"
	// ServiceAccountKind indicates the target resource is a serviceaccount.
	ServiceAccountKind = "ServiceAccount"
	// ReplicaSetKind indicates the target resource is a replicaset.
	ReplicaSetKind = "ReplicaSet"
	// StatefulSetKind indicates the target resource is a statefulset.
	StatefulSetKind = "StatefulSet"
	// DaemonSetKind indicates the target resource is a daemonset.
	DaemonSetKind = "DaemonSet"
	// EndpointSliceKind indicates the target resource is a endpointslice.
	EndpointSliceKind = "EndpointSlice"
	// PersistentVolumeClaimKind indicated the target resource is a persistentvolumeclaim.
	PersistentVolumeClaimKind = "PersistentVolumeClaim"
	// HorizontalPodAutoscalerKind indicated the target resource is a horizontalpodautoscaler.
	HorizontalPodAutoscalerKind = "HorizontalPodAutoscaler"

	// ServiceExportKind indicates the target resource is a serviceexport crd.
	ServiceExportKind = "ServiceExport"
	// ServiceImportKind indicates the target resource is a serviceimport crd.
	ServiceImportKind = "ServiceImport"

	// CRDKind indicated the target resource is a CustomResourceDefinition.
	CRDKind = "CustomResourceDefinition"
)

// Define resource filed.
const (
	// SpecField indicates the 'spec' field of a resource.
	SpecField = "spec"
	// ReplicasField indicates the 'replicas' field of a resource.
	ReplicasField = "replicas"
	// ParallelismField indicates the 'parallelism' field of a job.
	ParallelismField = "parallelism"
	// CompletionsField indicates the 'completions' field of a job.
	CompletionsField = "completions"
	// TemplateField indicates the 'template' field of a resource.
	TemplateField = "template"
)

// ContextKey is the key of context.
type ContextKey string

const (
	// ContextKeyObject is the context value key of a resource.
	ContextKeyObject ContextKey = "object"
)

const (
	// CacheSyncTimeout refers to the time limit set on waiting for cache to sync.
	CacheSyncTimeout = 30 * time.Second
)

const (
	ClusterRoleBindingUserNameLabel = "kpanda.io/cluster-role-binding-user"
	ClusterRoleBindingRoleNameLabel = "kpanda.io/cluster-role-binding-role"
)

const (
	CSRApproved = "Approved"
)
