package pvc

import (
	"context"
	corev1 "k8s.io/api/core/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	podutil "github.com/daocloud/dsp-appserver/pkg/util/pod"
)

// ListObjectReference returns a set of object references that use the given pvc.
func ListObjectReference(ctx context.Context, client clientset.Interface, namespace, pvcName string) ([]corev1.ObjectReference, error) {
	refs := []corev1.ObjectReference{}
	allDeploys, err := client.AppsV1().Deployments(namespace).List(ctx, metav1.ListOptions{})
	if err != nil && !kapierrors.IsForbidden(err) {
		return nil, err
	}
	for _, d := range allDeploys.Items {
		podutil.VisitPodSpecPersistentVolumeClaimNames(d.Spec.Template.Spec, func(name string) bool {
			if name != pvcName {
				return true
			}
			ref := corev1.ObjectReference{
				Kind:            "Deployment",
				Namespace:       d.Namespace,
				Name:            d.Name,
				UID:             d.UID,
				APIVersion:      "apps/v1",
				ResourceVersion: d.ResourceVersion,
			}
			refs = append(refs, ref)
			return false
		})
	}
	allSts, err := client.AppsV1().StatefulSets(namespace).List(ctx, metav1.ListOptions{})
	if err != nil && !kapierrors.IsForbidden(err) {
		return nil, err
	}
	for _, sts := range allSts.Items {
		podutil.VisitPodSpecPersistentVolumeClaimNames(sts.Spec.Template.Spec, func(name string) bool {
			if name != pvcName {
				return true
			}
			ref := corev1.ObjectReference{
				Kind:            "StatefulSet",
				Namespace:       sts.Namespace,
				Name:            sts.Name,
				UID:             sts.UID,
				APIVersion:      "apps/v1",
				ResourceVersion: sts.ResourceVersion,
			}
			refs = append(refs, ref)
			return false
		})
	}
	allDS, err := client.AppsV1().DaemonSets(namespace).List(ctx, metav1.ListOptions{})
	if err != nil && !kapierrors.IsForbidden(err) {
		return nil, err
	}
	for _, ds := range allDS.Items {
		podutil.VisitPodSpecPersistentVolumeClaimNames(ds.Spec.Template.Spec, func(name string) bool {
			if name != pvcName {
				return true
			}
			ref := corev1.ObjectReference{
				Kind:            "DaemonSet",
				Namespace:       ds.Namespace,
				Name:            ds.Name,
				UID:             ds.UID,
				APIVersion:      "apps/v1",
				ResourceVersion: ds.ResourceVersion,
			}
			refs = append(refs, ref)
			return false
		})
	}
	allCJ, err := client.BatchV1beta1().CronJobs(namespace).List(ctx, metav1.ListOptions{})
	if err != nil && !kapierrors.IsForbidden(err) {
		return nil, err
	}
	for _, cj := range allCJ.Items {
		podutil.VisitPodSpecPersistentVolumeClaimNames(cj.Spec.JobTemplate.Spec.Template.Spec, func(name string) bool {
			if name != pvcName {
				return true
			}
			ref := corev1.ObjectReference{
				Kind:            "CronJob",
				Namespace:       cj.Namespace,
				Name:            cj.Name,
				UID:             cj.UID,
				APIVersion:      "batch/v1beta1",
				ResourceVersion: cj.ResourceVersion,
			}
			refs = append(refs, ref)
			return false
		})
	}
	return refs, nil
}

// list pod of pvc
func ListPodOfPersistentVolumeClaim(ctx context.Context, client clientset.Interface, namespace, pvcName string) ([]corev1.Pod, error) {
	pods := []corev1.Pod{}
	podList, err := client.CoreV1().Pods(namespace).List(ctx, metav1.ListOptions{})
	if err != nil {
		return nil, err
	}

	for _, pod := range podList.Items {
		podutil.VisitPodSpecPersistentVolumeClaimNames(pod.Spec, func(name string) bool {
			if name != pvcName {
				return true
			}
			pod.Kind = "Pod"
			pod.APIVersion = "v1"
			pods = append(pods, pod)
			return false
		})
	}
	return pods, nil
}
