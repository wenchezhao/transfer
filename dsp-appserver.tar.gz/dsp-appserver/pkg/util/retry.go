package util

import (
	"errors"
	"time"

	"k8s.io/klog/v2"
)

// DoWithCount is a helper function to retry function with retry count.
// Copy from dxi-controller.retry.
func DoWithCount(attempts int, interval, timeout time.Duration, info string, f func() (err error)) (attempt int, err error) {
	if attempts <= 0 {
		klog.Error("Retry count cannot be less than 1 ", attempts)
		return attempts, errors.New("retry count cannot be less than 1")
	}
	for i := 0; ; i++ {
		err := doWithTimeout(timeout, f)
		if err == nil {
			return i, nil
		}
		if i >= (attempts - 1) {
			klog.Error("Retry deadline exceeded ", timeout)
			return i + 1, err
		}
		klog.Error("Retry failed with error, retry later ", err, info, i+1)
		time.Sleep(interval)
	}
}

func doWithTimeout(timeout time.Duration, f func() (err error)) error {
	if timeout <= 1 {
		return errors.New("time cannot be less than 1 Microsecond")
	}
	ticker := time.NewTimer(timeout)
	c1 := make(chan error, 1)
	go func() {
		err := f()
		c1 <- err
	}()

	// Listen on our channel AND a timeout channel - which ever happens first.
	select {
	case err := <-c1:
		return err
	case <-ticker.C:
		return errors.New("timeout to invoke")
	}
}
