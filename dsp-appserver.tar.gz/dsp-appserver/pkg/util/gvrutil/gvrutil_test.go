package gvrutil

import (
	"reflect"
	"testing"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
)

func TestGetSupportsCronJobGVR(t *testing.T) {
	tests := []struct {
		args []clusterv1alpha1.APIEnablement
		want schema.GroupVersionResource
	}{
		{
			args: []clusterv1alpha1.APIEnablement{},
			want: schema.GroupVersionResource{},
		},
	}
	for _, tt := range tests {
		t.Run("", func(t *testing.T) {
			got, _ := GetSupportsCronJobGVR(tt.args)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetSupportsCronJobGVR() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_fetchGVR(t *testing.T) {
	type args struct {
		apiEnablements []clusterv1alpha1.APIEnablement
		gvrs           []schema.GroupVersionResource
		kind           string
	}

	tests := []struct {
		name    string
		args    args
		want    schema.GroupVersionResource
		wantErr bool
	}{
		{
			name: "failed to get group and version for kind",
			args: args{
				apiEnablements: []clusterv1alpha1.APIEnablement{{
					GroupVersion: "batch/v1",
					Resources:    []*clusterv1alpha1.APIResource{{Name: "cronjobs", Kind: "CronJob"}},
				}},
				gvrs: []schema.GroupVersionResource{},
				kind: "CronJob",
			},
			wantErr: true,
		},
		{
			name: "successful to got group and version for kind",
			args: args{
				apiEnablements: []clusterv1alpha1.APIEnablement{{
					GroupVersion: "batch/v1",
					Resources:    []*clusterv1alpha1.APIResource{{Name: "cronjobs", Kind: "CronJob"}},
				}},
				gvrs: []schema.GroupVersionResource{{Group: "batch", Version: "v1", Resource: "cronjobs"}, {Group: "batch", Version: "v1beta1", Resource: "cronjobs"}},
				kind: "CronJob",
			},
			want: schema.GroupVersionResource{Group: "batch", Version: "v1", Resource: "cronjobs"},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := fetchGVR(tt.args.apiEnablements, tt.args.gvrs, tt.args.kind)
			if (err != nil) != tt.wantErr {
				t.Errorf("Run() error = %v, wantErr %v", err, tt.wantErr)
				return
			}

			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("fetchGVR() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetSupportsCsrGVR(t *testing.T) {
	tests := []struct {
		name string
		args []clusterv1alpha1.APIEnablement
		want schema.GroupVersionResource
	}{
		{
			name: "get supports csr GVR",
			args: []clusterv1alpha1.APIEnablement{},
			want: schema.GroupVersionResource{},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, _ := GetSupportsCsrGVR(tt.args)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetSupportsCsrGVR() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetSupportsIngressGVR(t *testing.T) {
	tests := []struct {
		name string
		args []clusterv1alpha1.APIEnablement
		want schema.GroupVersionResource
	}{
		{
			name: "get supports ingress GVR",
			args: []clusterv1alpha1.APIEnablement{},
			want: schema.GroupVersionResource{},
		},
	}
	for _, tt := range tests {
		t.Run("", func(t *testing.T) {
			got, _ := GetSupportsIngressGVR(tt.args)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetSupportsIngressGVR() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertToVersion(t *testing.T) {
	emptyCronJob := &batchv1.CronJob{}
	unstructuredCronJob, _ := runtime.DefaultUnstructuredConverter.ToUnstructured(emptyCronJob)
	emptyUnstructured := &unstructured.Unstructured{Object: unstructuredCronJob}

	v1CronJob := &batchv1.CronJob{
		TypeMeta:   metav1.TypeMeta{Kind: "CronJob", APIVersion: "batch/v1"},
		ObjectMeta: metav1.ObjectMeta{Name: "cronJob", Namespace: "default"},
		Spec: batchv1.CronJobSpec{
			Schedule: "* * * * *",
			JobTemplate: batchv1.JobTemplateSpec{
				Spec: batchv1.JobSpec{
					Template: corev1.PodTemplateSpec{
						Spec: corev1.PodSpec{
							RestartPolicy: corev1.RestartPolicyOnFailure,
							Containers: []corev1.Container{
								{
									Name:            "container",
									Image:           "image",
									ImagePullPolicy: corev1.PullIfNotPresent,
									Command:         []string{"/bin/sh", "-c", "date; echo Hello from the Kubernetes cluster"},
								},
							},
						},
					},
				},
			},
		},
	}
	unstructuredCronJob, _ = runtime.DefaultUnstructuredConverter.ToUnstructured(v1CronJob)
	v1UnstructuredObj := &unstructured.Unstructured{Object: unstructuredCronJob}
	unstructuredObj := &unstructured.Unstructured{
		Object: map[string]interface{}{
			"apiVersion": "batch/v1beta1",
			"kind":       "CronJob",
			"metadata": map[string]interface{}{
				"creationTimestamp": nil,
				"name":              "cronJob",
				"namespace":         "default",
			},
			"spec": map[string]interface{}{
				"schedule": "* * * * *",
				"jobTemplate": map[string]interface{}{
					"metadata": map[string]interface{}{
						"creationTimestamp": nil,
					},
					"spec": map[string]interface{}{
						"template": map[string]interface{}{
							"metadata": map[string]interface{}{
								"creationTimestamp": nil,
							},
							"spec": map[string]interface{}{
								"containers": []interface{}{
									map[string]interface{}{
										"command":         []interface{}{"/bin/sh", "-c", "date; echo Hello from the Kubernetes cluster"},
										"image":           "image",
										"imagePullPolicy": "IfNotPresent",
										"name":            "container",
										"resources":       map[string]interface{}{},
									},
								},
								"restartPolicy":   "OnFailure",
								"securityContext": map[string]interface{}{},
							},
						},
					},
				},
			},
			"status": map[string]interface{}{},
		},
	}

	type args struct {
		obj *unstructured.Unstructured
		gvr schema.GroupVersionResource
	}

	tests := []struct {
		name string
		args args
		want *unstructured.Unstructured
	}{
		{
			name: "same version, no need to convert",
			args: args{
				obj: &unstructured.Unstructured{},
			},
			want: &unstructured.Unstructured{},
		},
		{
			name: "internal Obj error",
			args: args{
				obj: emptyUnstructured,
				gvr: schema.GroupVersionResource{Group: "batch", Version: "v1beta1", Resource: "cronjobs"},
			},
			want: nil,
		},
		{
			name: "internal Obj error",
			args: args{
				obj: emptyUnstructured,
				gvr: schema.GroupVersionResource{Group: "batch", Version: "v1beta1", Resource: "cronjobs"},
			},
			want: nil,
		},
		{
			name: "different version, need to convert",
			args: args{
				obj: v1UnstructuredObj,
				gvr: schema.GroupVersionResource{Group: "batch", Version: "v1beta1", Resource: "cronjobs"},
			},
			want: unstructuredObj,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, _ := ConvertToVersion(tt.args.obj, tt.args.gvr)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertToVersion() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetSupportsHPAGVR(t *testing.T) {
	tests := []struct {
		name string
		args []clusterv1alpha1.APIEnablement
		want schema.GroupVersionResource
	}{
		{
			name: "get supported HPA GVR",
			args: []clusterv1alpha1.APIEnablement{},
			want: schema.GroupVersionResource{},
		},
	}
	for _, tt := range tests {
		t.Run("", func(t *testing.T) {
			got, _ := GetSupportsHPAGVR(tt.args)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetSupportsHPAGVR() got = %v, want %v", got, tt.want)
			}
		})
	}
}
