package gvrutil

import (
	"fmt"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"

	"k8s.io/kubernetes/pkg/api/legacyscheme"
)

var (
	LegacyResourceScheme         = legacyscheme.Scheme
	LegacyResourceCodecs         = legacyscheme.Codecs
	LegacyResourceParameterCodec = legacyscheme.ParameterCodec

	UnstructuredCodecs = unstructured.UnstructuredJSONScheme
)

func GetSupportsCronJobGVR(apiEnablements []clusterv1alpha1.APIEnablement) (schema.GroupVersionResource, error) {
	supportCronJobsGVRs := []schema.GroupVersionResource{{Group: "batch", Version: "v1", Resource: "cronjobs"}, {Group: "batch", Version: "v1beta1", Resource: "cronjobs"}}
	return fetchGVR(apiEnablements, supportCronJobsGVRs, "CronJob")
}

func fetchGVR(apiEnablements []clusterv1alpha1.APIEnablement, gvrs []schema.GroupVersionResource, kind string) (schema.GroupVersionResource, error) {
	for _, gvr := range gvrs {
		for _, apiEnablement := range apiEnablements {
			if apiEnablement.GroupVersion == gvr.GroupVersion().String() {
				for _, resource := range apiEnablement.Resources {
					if resource.Name == gvr.Resource && resource.Kind == kind {
						return gvr, nil
					}
				}
			}
		}
	}
	return schema.GroupVersionResource{}, fmt.Errorf("failed to get group and version for kind: %s", kind)
}

func GetSupportsCsrGVR(apiEnablements []clusterv1alpha1.APIEnablement) (schema.GroupVersionResource, error) {
	supportCronJobsGVRs := []schema.GroupVersionResource{{Group: "certificates.k8s.io", Version: "v1", Resource: "certificatesigningrequests"}, {Group: "certificates.k8s.io", Version: "v1beta1", Resource: "certificatesigningrequests"}}
	return fetchGVR(apiEnablements, supportCronJobsGVRs, "CertificateSigningRequest")
}

func GetSupportsIngressGVR(apiEnablements []clusterv1alpha1.APIEnablement) (schema.GroupVersionResource, error) {
	supportIngressGVRs := []schema.GroupVersionResource{{Group: "networking.k8s.io", Version: "v1", Resource: "ingresses"}, {Group: "networking.k8s.io", Version: "v1beta1", Resource: "ingresses"}}
	return fetchGVR(apiEnablements, supportIngressGVRs, "Ingress")
}

func ConvertToVersion(obj *unstructured.Unstructured, gvr schema.GroupVersionResource) (*unstructured.Unstructured, error) {
	if obj.GetObjectKind().GroupVersionKind().Group == gvr.Group && obj.GetObjectKind().GroupVersionKind().Version == gvr.Version {
		return obj, nil
	}

	internalObj, err := LegacyResourceScheme.ConvertToVersion(obj, schema.GroupVersion{Group: obj.GroupVersionKind().Group, Version: runtime.APIVersionInternal})
	if err != nil {
		return nil, err
	}

	convertedObj, err := LegacyResourceScheme.ConvertToVersion(internalObj, gvr.GroupVersion())
	if err != nil {
		return nil, err
	}

	convertedObj.GetObjectKind().SetGroupVersionKind(schema.GroupVersionKind{
		Group:   gvr.Group,
		Version: gvr.Version,
		Kind:    obj.GroupVersionKind().Kind,
	})

	unstructuredObj, err := runtime.DefaultUnstructuredConverter.ToUnstructured(convertedObj)
	return &unstructured.Unstructured{Object: unstructuredObj}, err
}

func GetSupportsHPAGVR(apiEnablements []clusterv1alpha1.APIEnablement) (schema.GroupVersionResource, error) {
	supportHPAGVRs := []schema.GroupVersionResource{{Group: "autoscaling", Version: "v2", Resource: "horizontalpodautoscalers"}, {Group: "autoscaling", Version: "v1", Resource: "horizontalpodautoscalers"}}
	return fetchGVR(apiEnablements, supportHPAGVRs, "HorizontalPodAutoscaler")
}
