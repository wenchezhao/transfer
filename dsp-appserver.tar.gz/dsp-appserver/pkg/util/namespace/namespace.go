package namespace

import (
	"context"
	"fmt"
	"time"

	openshiftv1 "github.com/openshift/api/project/v1"
	corev1 "k8s.io/api/core/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/util/wait"

	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
)

var log = logi.Log.Sugar()

// default label key and dce default information
const (
	DceBestEffortName         = "best-effort"
	DceLimitRangeName         = "dce-default-limit-range"
	NamespaceDefaultLabelName = "ccnp.cib/system-code"
)

// CreateNamespaceOrProjectIfNotPresent creates a namespace if the given namespace doesn't exist.
func CreateNamespaceOrProjectIfNotPresent(
	ctx context.Context,
	client clientset.Interface,
	namespace string,
	systemCode string,
	verInfo *clientset.Version,
) error {
	_, err := client.CoreV1().Namespaces().Get(ctx, namespace, metav1.GetOptions{})
	if err != nil && kapierrors.IsNotFound(err) {
		switch verInfo.Type {
		case clientset.K8S, clientset.DCE:
			ns := &corev1.Namespace{
				TypeMeta: metav1.TypeMeta{
					APIVersion: "v1",
					Kind:       "Namespace",
				},
				ObjectMeta: metav1.ObjectMeta{
					Name:   namespace,
					Labels: map[string]string{NamespaceDefaultLabelName: systemCode},
				},
			}

			_, err = client.CoreV1().Namespaces().Create(ctx, ns, metav1.CreateOptions{})
			if err != nil && !kapierrors.IsAlreadyExists(err) {
				log.Errorf("failed to create Namespace %s: %v", namespace, err)
				return err
			}
		case clientset.OCP:
			pr := openshiftv1.ProjectRequest{
				TypeMeta: metav1.TypeMeta{
					APIVersion: "v1",
					Kind:       "ProjectRequest",
				},
				ObjectMeta: metav1.ObjectMeta{
					Name:   namespace,
					Labels: map[string]string{NamespaceDefaultLabelName: systemCode},
				},
			}

			_, err := client.OpenshiftProjectV1().ProjectRequests().Create(ctx, &pr, metav1.CreateOptions{})
			if err != nil && !kapierrors.IsAlreadyExists(err) {
				log.Errorf("failed to create ProjectRequest %s: %v", namespace, err)
				return err
			}
		default:
			log.Errorf("unsupported cluster: %s", verInfo.Type)
			return fmt.Errorf("unsupported cluster: %s", verInfo.Type)
		}
	}

	go UpdateNamespaceLabel(client, namespace, systemCode)
	return nil
}

// 因为ocp命名空间获取后，可能被控制器更改，当更新label的时候会报错，所以异步重试更新labels
func UpdateNamespaceLabel(client clientset.Interface, namespace, systemCode string) {
	err := wait.PollImmediate(2*time.Second, 2*time.Minute, func() (bool, error) {
		// 给系统添加新的标签,如果标签存在也要能接管该ns
		getNs, err := client.CoreV1().Namespaces().Get(context.TODO(), namespace, metav1.GetOptions{})
		var oldLabel labels.Set
		oldLabel = getNs.Labels

		getNs.Labels = labels.Merge(oldLabel, labels.Set{
			NamespaceDefaultLabelName: systemCode,
			"name":                    namespace,
		})
		_, err = client.CoreV1().Namespaces().Update(context.TODO(), getNs, metav1.UpdateOptions{})
		if err != nil && kapierrors.IsConflict(err) {
			log.Infof("namespace is conflict retry err: %v", err)
			return false, nil
		} else if err != nil {
			log.Errorf("failed to update label err: %v", err)
			return true, err
		}

		log.Infof("update namespace %s label success", namespace)
		return true, nil
	})
	if err != nil {
		log.Errorf("failed to update namespace label err: %v", err)
	}

}

// update best-effort and delete limitRange in dce cluster
func UpdateDceQuotaAndDeleteDceLimitRange(client clientset.Interface, namespace string) {
	// 删除 dce-default-limit-range
	err := wait.PollImmediate(50*time.Millisecond, 1*time.Minute, func() (bool, error) {
		limitRange, err := client.CoreV1().LimitRanges(namespace).Get(context.TODO(), DceLimitRangeName, metav1.GetOptions{})
		if err != nil && kapierrors.IsNotFound(err) {
			log.Infof("%s not found in namespace %s err: %v", DceLimitRangeName, namespace, err)
			return false, nil
		} else if err != nil {
			log.Infof("can not get %s in namespace %s err: %v", DceLimitRangeName, namespace, err)
			return true, err
		}
		err = client.CoreV1().LimitRanges(namespace).Delete(context.TODO(), limitRange.Name, metav1.DeleteOptions{})
		if err != nil {
			log.Infof("delete %s in namespace %s err: %v", DceLimitRangeName, namespace, err)
			return true, err
		}
		log.Infof("delete %s success in namespace %s", DceLimitRangeName, namespace)
		return true, nil
	})
	if err != nil {
		log.Infof("failed to delete limitRange: %v", err)
	}

	// 更新 best-effort
	err = wait.PollImmediate(2*time.Second, 2*time.Minute, func() (bool, error) {
		effort, err := client.CoreV1().ResourceQuotas(namespace).Get(context.TODO(), DceBestEffortName, metav1.GetOptions{})
		if err != nil && kapierrors.IsNotFound(err) {
			log.Infof("%s not found in namespace %s: %v", DceBestEffortName, namespace, err)
			return false, nil
		} else if err != nil {
			// 如果是其他错误，直接终止，并返回错误
			log.Infof("can not get %s in namespace %s err: %v", DceBestEffortName, namespace, err)
			return true, err
		}
		if effort.Spec.Hard.Pods().IsZero() {
			effort.Spec.Hard = corev1.ResourceList{}
			_, err = client.CoreV1().ResourceQuotas(namespace).Update(context.TODO(), effort, metav1.UpdateOptions{})
			// 如果更新失败了，那么也终止，并返回错误
			if err != nil {
				log.Infof("can not update %s in namespace %s err: %v", DceBestEffortName, namespace, err)
				return true, err
			}
		}
		log.Infof("update %s success in namespace %s", DceBestEffortName, namespace)
		return true, nil
	})
	if err != nil {
		log.Infof("failed to delete best-effort: %v", err)
	}
}
