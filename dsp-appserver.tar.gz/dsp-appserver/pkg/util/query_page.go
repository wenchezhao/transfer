package util

import (
	"math"
	"strings"

	"k8s.io/apimachinery/pkg/labels"

	"github.com/daocloud/dsp-appserver/pkg/constants"
)

// Define events for execute space objects.
const (
	// DefaultPageSize indicates that default query page size.
	DefaultPageSize = 10
	// DefaultPage indicates that default query page index.
	DefaultPage = 1
	// MaxPageSize indicates that max query page size without paging.
	MaxPageSize = math.MaxInt32
	// MaxPerPageSize indicates that max query page size with paging.
	MaxPerPageSize = 100
)

type (
	NameSearchType int32
	SearchParam    string
)

const (
	SearchParamRoleRef           SearchParam = "roleRef"
	SearchParamIsVirtualCluster  SearchParam = "virtualCluster"
	SearchParamNonVirtualCluster SearchParam = "nonVirtualCluster"
	SearchParamFuzzyName         SearchParam = "fuzzyName"
	SearchParamManagedBy         SearchParam = "managedBy"
	SearchParamKubernetesVersion SearchParam = "kubernetesVersion"
	SearchParamWorkspaceAlias    SearchParam = "workspaceAlias"
	SearchParamOnlyMetadata      SearchParam = "onlyMetadata"
	SearchParamNodeRole          SearchParam = "nodeRole"

	SearchParamSecretType SearchParam = "secretType"

	SearchParamSCProvisioner   SearchParam = "scProvisioner"
	SearchParamSCReclaimPolicy SearchParam = "scReclaimPolicy"

	SearchParamPVCPhase            SearchParam = "pvcPhase"
	SearchParamPVCAccessMode       SearchParam = "pvcAccessMode"
	SearchParamWorkspaceUnassigned SearchParam = "workspaceUnassigned"
	SearchParamExcludeSystem       SearchParam = "excludeSystem"
)

const (
	DefaultNameSearchType NameSearchType = iota
	NameSearchTypeRoleBinding
)

type QueryPage struct {
	Page         int32 // query page number, default start from 1
	Pages        int32
	PageSize     int32             // total number
	Name         string            // fuzzy search by name
	Names        []string          // search by names
	Labels       map[string]string // filter by metadata.labels
	Phase        string            // filter by status
	ClusterPhase string
	NodePhases   []string
	SortBy       string // sort
	Total        int32  // for page turning
	NodeIps      string

	FieldSelector map[string][]string
	//  Determines whether the first search result returned is the highest number of matches (desc)
	//  or lowest number of matches (asc). This parameter is ignored unless you provide sort.
	SortDir string // result order, default asc

	NameSearchType NameSearchType

	Selector labels.Selector

	// Additional parameters to search
	Params map[SearchParam]interface{}
}

func (qp *QueryPage) SetTotalByRemainCount(resultCount int32, remain *int64) {
	if qp != nil {
		if remain != nil {
			qp.Total = (qp.Page-1)*qp.PageSize + resultCount + int32(*remain)
		} else {
			qp.Total = (qp.Page-1)*qp.PageSize + resultCount
		}
		if qp.Total > 0 && qp.PageSize > 0 {
			pages := qp.Total / qp.PageSize
			if qp.Total%qp.PageSize > 0 {
				pages++
			}
			qp.Pages = pages
		}
	}
}

// QueryPageSelect configures how we set up the select options.
type QueryPageSelect interface {
	Apply(options *QueryPage)
}

type SelectOption struct {
	fc func(options *QueryPage)
}

// Pagination is for data paging.
type Pagination struct {
	// Total is the total number of referents.
	Total int32 `protobuf:"varint,1,opt,name=total,proto3" json:"total,omitempty"`
	// Page is current page.
	Page int32 `protobuf:"varint,2,opt,name=page,proto3" json:"page,omitempty"`
	// PageSize is the data number shown per page.
	PageSize int32 `protobuf:"varint,3,opt,name=page_size,json=pageSize,proto3" json:"page_size,omitempty"`
	// Pages is the number of pages.
	Pages int32 `protobuf:"varint,4,opt,name=pages,proto3" json:"pages,omitempty"`
}

func (option *SelectOption) Apply(do *QueryPage) {
	option.fc(do)
}

func NewPage(options []QueryPageSelect) *QueryPage {
	queryPage := new(QueryPage)
	for _, option := range options {
		option.Apply(queryPage)
	}
	return queryPage
}

func newFuncSelectOption(fc func(options *QueryPage)) *SelectOption {
	return &SelectOption{
		fc: fc,
	}
}

func WithName(names string) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		o.Name = names
	})
}

func WithLabels(labels map[string]string) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		if o.Labels == nil {
			o.Labels = labels
			return
		}

		for k, v := range labels {
			o.Labels[k] = v
		}
	})
}

func WithSelector(selector labels.Selector) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		o.Selector = selector
	})
}

func WithPhase(s string) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		phase := strings.ToUpper(s)
		if strings.Contains(phase, "UNSPECIFIED") {
			return
		}
		o.Phase = s
	})
}

func WithClusterPhase(s string) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		o.ClusterPhase = s
	})
}

func WithNodePhases(s []string) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		o.NodePhases = s
	})
}

func WithNodeIps(s string) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		o.NodeIps = s
	})
}

func WithFieldSelectorBySet(fieldSelector labels.Set) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		if o.FieldSelector == nil {
			o.FieldSelector = make(map[string][]string)
		}

		for k, v := range fieldSelector {
			o.FieldSelector[k] = []string{v}
		}
	})
}

func WithFieldSelector(fieldSelector map[string][]string) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		if o.FieldSelector == nil {
			o.FieldSelector = fieldSelector
			return
		}

		for k, v := range fieldSelector {
			o.FieldSelector[k] = v
		}
	})
}

func WithNameSearchType(searchType NameSearchType) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		o.NameSearchType = searchType
	})
}

func WithParams(paramKey SearchParam, value interface{}) QueryPageSelect {
	return newFuncSelectOption(func(o *QueryPage) {
		if o.Params == nil {
			o.Params = make(map[SearchParam]interface{})
		}
		o.Params[paramKey] = value
	})
}

func CommonPageOpts(page, size int32, sortBy, sortDir string) QueryPageSelect {
	return newFuncSelectOption(func(options *QueryPage) {
		if page < 1 {
			page = 1
		}

		if page == 1 && size == -1 {
			size = MaxPageSize
		}

		if size <= 0 {
			size = DefaultPageSize
		} else {
			if size > MaxPerPageSize && size != MaxPageSize {
				size = MaxPerPageSize
			}
		}

		options.Page = page
		options.PageSize = size

		// Field name is not supported by proto enum, therefore changes it
		// to field_name.
		if sortBy != "" {
			if sortBy == "field_name" {
				sortBy = "name"
			}
			options.SortBy = sortBy

			if sortDir != constants.OrderByDesc {
				sortDir = constants.OrderByAsc
			}
			options.SortDir = sortDir
		}
	})
}

func CalculatePagingParameters(page, pageSize, total int32) (int32, int32, int32) {
	page, pageSize = CalculatePaging(page, pageSize)
	var offset, end, pages int32
	if page > 0 && pageSize > 0 {
		limit := pageSize
		if total%limit == 0 {
			pages = total / limit
		} else {
			pages = total/limit + 1
		}
		offset = (page - 1) * limit
		end = offset + limit
		if total < end {
			end = total
		}
	} else {
		offset = 0
		end = total
	}
	return offset, end, pages
}

func CalculatePaging(page, size int32) (int32, int32) {
	if page < 1 {
		page = 1
	}

	if page == 1 && size == -1 {
		size = MaxPageSize
	}

	if size <= 0 {
		size = DefaultPageSize
	} else {
		if size > MaxPerPageSize && size != MaxPageSize {
			size = MaxPerPageSize
		}
	}
	return page, size
}

func NewPageByPageSizeAndTotal(page, size, total int32) *Pagination {
	if size <= 0 {
		return nil
	}
	pages := total / size
	if total%size != 0 {
		pages++
	}
	return &Pagination{
		Total:    total,
		Page:     page,
		PageSize: size,
		Pages:    pages,
	}
}
