/*
Copyright 2022 Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package clusterclient

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"sync"
	"time"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"
	clusterscheme "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/scheme"
	clusterv1alpha1informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions/cluster/v1alpha1"
	clusterv1alpha1listers "github.com/daocloud/dsp-appserver/api/crd/client/listers/cluster/v1alpha1"
	kubeancluster "github.com/kubean-io/kubean-api/apis/cluster/v1alpha1"
	kubeanclusterops "github.com/kubean-io/kubean-api/apis/clusteroperation/v1alpha1"
	kubeaninfomanifestv1alpha1 "github.com/kubean-io/kubean-api/apis/manifest/v1alpha1"
	volumesnapshotv1 "github.com/kubernetes-csi/external-snapshotter/client/v4/clientset/versioned/typed/volumesnapshot/v1"
	"k8s.io/apimachinery/pkg/api/equality"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	vpaclient "k8s.io/autoscaler/vertical-pod-autoscaler/pkg/client/clientset/versioned"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/kubernetes/scheme"
	corev1client "k8s.io/client-go/kubernetes/typed/core/v1"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/restmapper"
	"k8s.io/client-go/tools/cache"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/klog/v2"
	"k8s.io/metrics/pkg/client/custom_metrics"
	"sigs.k8s.io/controller-runtime/pkg/client"

	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/contextutil"
)

const (
	DefaultQPS   float32 = 50.0
	DefaultBurst int     = 100

	// defaultRetries is the number of times a cluster is added.
	defaultRetries = 10

	// defaultTimeout is the maximum amount of time per request when no timeout has been set on a RESTClient.
	// Defaults to 30s in order to have a distinguishable length of time, relative to other timeouts that exist.
	defaultTimeout = 30 * time.Second

	// default interval to reconcile the cluster.
	defaultInterval = 3 * time.Second
)

var (
	ClusterNotExistsFormat = "cluster %s not exists"
	clientSetSchemes       = runtime.NewScheme()
)

func init() {
	_ = scheme.AddToScheme(clientSetSchemes) // add Kubernetes schemes
	_ = clusterscheme.AddToScheme(clientSetSchemes)
	_ = kubeancluster.AddToScheme(clientSetSchemes)
	_ = kubeanclusterops.AddToScheme(clientSetSchemes)
	_ = kubeaninfomanifestv1alpha1.AddToScheme(clientSetSchemes) // add kubeaninfomanifest v1alpha1 schemes
}

type InnerCluster struct {
	APIEndpoint         *url.URL
	ProxyURL            *url.URL
	KubeClient          kubernetes.Interface
	RestClient          rest.Interface
	GeneratedClient     clusterclientset.Interface
	DynamicClient       dynamic.Interface
	Transport           http.RoundTripper
	SnapshotV1Client    *volumesnapshotv1.SnapshotV1Client
	ClientSet           client.Client
	CustomMetricsClient custom_metrics.CustomMetricsClient
	KubeConfig          *rest.Config

	// APIEnablements represents the list of APIs installed in the member cluster.
	APIEnablements []clusterv1alpha1.APIEnablement
}

type clusterClients struct {
	sync.RWMutex
	client            kubernetes.Interface
	listers           clusterv1alpha1listers.ClusterLister
	clusterMap        map[string]*clusterv1alpha1.Cluster
	clusterKubeConfig map[string]string

	// build a in memory cluster cache to speed things up
	innerClusters map[string]*InnerCluster
}

type ClusterClients interface {
	IsHostCluster(cluster *clusterv1alpha1.Cluster) bool
	IsClusterReady(cluster *clusterv1alpha1.Cluster) bool
	GetClusterKubeConfig(string) (*rest.Config, error)
	Get(string) (*clusterv1alpha1.Cluster, error)
	GetInnerCluster(string) *InnerCluster
	GetClient(string) (kubernetes.Interface, error)
	GetGeneratedClient(string) (clusterclientset.Interface, error)
	GetDynamicClient(string) (dynamic.Interface, error)
	GetClusterByKubeSystemID(ID string) string
	GetSnapshotClient(string) (*volumesnapshotv1.SnapshotV1Client, error)
	GetSnapshotClientWithUser(ctx context.Context, cluster string) (*volumesnapshotv1.SnapshotV1Client, error)
	GetAllClusterClient() (map[string]kubernetes.Interface, error)
	GetClientSet(string) (client.Client, error)
	GetClientSetWithUser(ctx context.Context, cluster string) (client.Client, error)
	GetCustomMetricsClient(string) (custom_metrics.CustomMetricsClient, error)
	NewKubeConfigWithUser(ctx context.Context, cluster string) (*rest.Config, error)
	NewKubernetesClientWithUser(ctx context.Context, cluster string) (kubeclient.Client, error)
	NewVPAClientWithUser(ctx context.Context, cluster string) (vpaclient.Interface, error)
	GetVPAClient(cluster string) (vpaclient.Interface, error)
}

var _ ClusterClients = &clusterClients{}

func (c *clusterClients) IsClusterReady(cluster *clusterv1alpha1.Cluster) bool {
	for _, condition := range cluster.Status.Conditions {
		if condition.Type == clusterv1alpha1.ClusterConditionRunning && condition.Status == metav1.ConditionTrue {
			return true
		}
	}
	return false
}

func (c *clusterClients) IsHostCluster(cluster *clusterv1alpha1.Cluster) bool {
	if _, ok := cluster.Labels[string(constants.ClusterRoleGlobalService)]; ok {
		return true
	}
	return false
}

func (c *clusterClients) GetInnerCluster(clusterName string) *InnerCluster {
	c.RLock()
	defer c.RUnlock()
	if cluster, ok := c.innerClusters[clusterName]; ok {
		return cluster
	}
	return nil
}

var (
	c    *clusterClients
	once sync.Once
)

func NewClusterClient(client kubernetes.Interface, clusterInformer clusterv1alpha1informers.ClusterInformer) ClusterClients {
	if c == nil {
		once.Do(
			func() {
				c = &clusterClients{
					client:            client,
					clusterMap:        map[string]*clusterv1alpha1.Cluster{},
					clusterKubeConfig: map[string]string{},
					innerClusters:     make(map[string]*InnerCluster),
					listers:           clusterInformer.Lister(),
				}
				clusterInformer.Informer().AddEventHandler(cache.ResourceEventHandlerFuncs{
					AddFunc: func(obj interface{}) {
						c.addClusterWithRetry(obj.(*clusterv1alpha1.Cluster).Name)
					},
					UpdateFunc: func(oldObj, newObj interface{}) {
						oldCluster := oldObj.(*clusterv1alpha1.Cluster)
						newCluster := newObj.(*clusterv1alpha1.Cluster)
						if oldCluster != nil {
							if oldCluster.Spec.SecretRef != nil && !equality.Semantic.DeepEqual(oldCluster.Spec.SecretRef, newCluster.Spec.SecretRef) || oldCluster.Status.KubernetesVersion != newCluster.Status.KubernetesVersion {
								c.removeCluster(oldObj)
							}
						}
						c.addClusterWithRetry(newCluster.Name)
					},
					DeleteFunc: func(obj interface{}) {
						c.removeCluster(obj)
					},
				})
			},
		)
	}

	return c
}

func (c *clusterClients) removeCluster(obj interface{}) {
	cluster := obj.(*clusterv1alpha1.Cluster)
	klog.V(4).Infof("remove cluster %s", cluster.Name)
	c.Lock()
	if _, ok := c.clusterMap[cluster.Name]; ok {
		delete(c.clusterMap, cluster.Name)
		delete(c.innerClusters, cluster.Name)
		delete(c.clusterKubeConfig, cluster.Name)
	}
	c.Unlock()
}

func (c *clusterClients) newInnerCluster(cluster *clusterv1alpha1.Cluster) (*InnerCluster, error) {
	if len(cluster.Status.APIEnablements) == 0 {
		return nil, fmt.Errorf("failed to get any apis installed in cluster %s", cluster.Name)
	}

	APIEndpoint, err := url.Parse(cluster.Spec.APIEndpoint)
	if err != nil {
		klog.V(4).ErrorS(err, "Parse kpanda apiserver endpoint", "cluster", cluster.Name, "endpoint", cluster.Spec.APIEndpoint)
		return nil, err
	}

	if cluster.Spec.SecretRef == nil {
		return nil, fmt.Errorf("the secret of cluster %s is empty", cluster.Name)
	}

	secretNamespace := cluster.Spec.SecretRef.Namespace
	secretName := cluster.Spec.SecretRef.Name
	if secretName == "" {
		return nil, fmt.Errorf("cluster name :%v, kube-system id: %s does not have a secret name", cluster.Name, cluster.Status.KubeSystemID)
	}

	secret, err := c.client.CoreV1().Secrets(secretNamespace).Get(context.TODO(), secretName, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}

	if len(secret.Data) == 0 || len(secret.Data["kubeconfig"]) == 0 {
		return nil, fmt.Errorf("secret %s data is empty", secret.Name)
	}

	clientConfig, err := clientcmd.NewClientConfigFromBytes(secret.Data["kubeconfig"])
	if err != nil {
		klog.V(4).ErrorS(err, "unable to create client config from kubeConfig bytes", "cluster", cluster.Name)
		return nil, err
	}

	clusterConfig, err := clientConfig.ClientConfig()
	if err != nil {
		klog.V(4).ErrorS(err, "failed to get client config", "cluster", cluster.Name)
		return nil, err
	}

	clusterConfig.QPS = DefaultQPS
	clusterConfig.Burst = DefaultBurst
	// clusterConfig.CAData = nil
	// clusterConfig.Insecure = true

	skipTLSVerify := false

	if util.ShouldUseEgress(cluster, clusterConfig) {
		skipTLSVerify = true
	} else {
		// use cluster.Spec.APIEndpoint access member cluster
		clusterConfig.Host = cluster.Spec.APIEndpoint
	}
	if cluster.Spec.InsecureSkipTLSVerification || skipTLSVerify {
		// the key point to use egress proxy
		// specifying a root certificates file with the insecure flag is not allowed
		util.MakeConfigSkipTLS(clusterConfig)
	}

	kubeClient, err := kubernetes.NewForConfig(clusterConfig)
	if err != nil {
		klog.Errorf("Failed to get client config, %#v", err)
		return nil, err
	}

	generatedClient, err := clusterclientset.NewForConfig(clusterConfig)
	if err != nil {
		klog.V(4).ErrorS(err, "failed get generatedClient", "cluster", cluster.Name)
		return nil, err
	}

	dynamicClient, err := dynamic.NewForConfig(clusterConfig)
	if err != nil {
		klog.V(4).ErrorS(err, "failed get dynamicClient", "cluster", cluster.Name)
		return nil, err
	}

	transport, err := rest.TransportFor(clusterConfig)
	if err != nil {
		klog.V(4).ErrorS(err, "failed to create transport", "cluster", cluster.Name)
		return nil, err
	}

	snapshotClient, err := volumesnapshotv1.NewForConfig(clusterConfig)
	if err != nil {
		klog.V(4).ErrorS(err, "failed to create snapshotClient failed", "cluster", cluster.Name)
		return nil, err
	}

	clientSet, err := client.New(clusterConfig, client.Options{
		Scheme: clientSetSchemes,
	})
	if err != nil {
		klog.V(4).ErrorS(err, "failed to create client clientSet", "cluster", cluster.Name)
		return nil, err
	}

	gr, err := restmapper.GetAPIGroupResources(kubeClient.DiscoveryClient)
	if err != nil {
		klog.V(4).ErrorS(err, "failed to create GetAPIGroupResources", "cluster", cluster.Name)
		return nil, err
	}

	mapper := restmapper.NewDiscoveryRESTMapper(gr)
	apiVersionsGetter := custom_metrics.NewAvailableAPIsGetter(kubeClient.DiscoveryClient)
	cmClient := custom_metrics.NewForConfig(clusterConfig, mapper, apiVersionsGetter)

	return &InnerCluster{
		APIEndpoint:         APIEndpoint,
		KubeClient:          kubeClient,
		GeneratedClient:     generatedClient,
		Transport:           transport,
		DynamicClient:       dynamicClient,
		SnapshotV1Client:    snapshotClient,
		ClientSet:           clientSet,
		KubeConfig:          clusterConfig,
		APIEnablements:      cluster.Status.APIEnablements,
		RestClient:          kubeClient.RESTClient(),
		CustomMetricsClient: cmClient,
	}, nil
}

func (c *clusterClients) addCluster(cluster *clusterv1alpha1.Cluster) error {
	klog.V(4).Infof("add new cluster %s", cluster.Name)
	c.RLock()
	_, exist := c.clusterMap[cluster.Name]
	c.RUnlock()
	if exist {
		return nil
	}

	innerCluster, err := c.newInnerCluster(cluster)
	if err != nil {
		klog.V(4).ErrorS(err, "failed to create newInnerCluster", "cluster", cluster.Name)
		return err
	}

	c.Lock()
	c.clusterMap[cluster.Name] = cluster
	c.clusterKubeConfig[cluster.Name] = cluster.Spec.APIEndpoint
	c.innerClusters[cluster.Name] = innerCluster
	c.Unlock()
	return nil
}

func (c *clusterClients) addClusterWithRetry(clusterName string) {
	go func() {
		_, err := util.DoWithCount(defaultRetries, defaultInterval, defaultTimeout, " new inner cluster", func() (err error) {
			cluster, err := c.listers.Get(clusterName)
			if err != nil {
				return err
			}

			if !util.IsClusterReady(&cluster.Status) {
				return nil
			}

			return c.addCluster(cluster)
		})
		if err != nil {
			klog.V(4).ErrorS(err, "failed to new inner cluster", "cluster", clusterName)
		}
	}()
}

func (c *clusterClients) GetClusterKubeConfig(cluster string) (*rest.Config, error) {
	c.RLock()
	defer c.RUnlock()
	if c, exists := c.innerClusters[cluster]; exists {
		return c.KubeConfig, nil
	}
	return nil, fmt.Errorf(ClusterNotExistsFormat, cluster)
}

func (c *clusterClients) Get(cluster string) (*clusterv1alpha1.Cluster, error) {
	c.RLock()
	defer c.RUnlock()
	if cluster, exists := c.clusterMap[cluster]; exists {
		return cluster, nil
	}
	return nil, fmt.Errorf(ClusterNotExistsFormat, cluster)
}

func (c *clusterClients) GetClient(clusterName string) (kubernetes.Interface, error) {
	cluster, err := c.Get(clusterName)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return nil, fmt.Errorf("cluster %s not found", clusterName)
		}
		return nil, err
	}

	if !c.IsClusterReady(cluster) {
		return nil, fmt.Errorf("cluster %s is not ready", cluster.Name)
	}

	innCluster := c.GetInnerCluster(cluster.Name)
	if innCluster == nil {
		return nil, fmt.Errorf("innCluster %s not found", cluster.Name)
	}
	return innCluster.KubeClient, nil
}

func (c *clusterClients) GetGeneratedClient(clusterName string) (clusterclientset.Interface, error) {
	cluster, err := c.Get(clusterName)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return nil, fmt.Errorf("cluster %s not found", clusterName)
		}
		return nil, err
	}

	if !c.IsClusterReady(cluster) {
		return nil, fmt.Errorf("cluster %s is not ready", cluster.Name)
	}

	innCluster := c.GetInnerCluster(cluster.Name)
	if innCluster == nil {
		return nil, fmt.Errorf("innCluster %s not found", cluster.Name)
	}
	return innCluster.GeneratedClient, nil
}

func (c *clusterClients) GetDynamicClient(clusterName string) (dynamic.Interface, error) {
	cluster, err := c.Get(clusterName)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return nil, fmt.Errorf("cluster %s not found", clusterName)
		}
		return nil, err
	}

	if !c.IsClusterReady(cluster) {
		return nil, fmt.Errorf("cluster %s is not ready", cluster.Name)
	}

	innCluster := c.GetInnerCluster(cluster.Name)
	if innCluster == nil {
		return nil, fmt.Errorf("innCluster %s not found", cluster.Name)
	}
	return innCluster.DynamicClient, nil
}

func (c *clusterClients) GetSnapshotClient(clusterName string) (*volumesnapshotv1.SnapshotV1Client, error) {
	cluster, err := c.Get(clusterName)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return nil, fmt.Errorf("cluster %s not found", clusterName)
		}
		return nil, err
	}

	if !c.IsClusterReady(cluster) {
		return nil, fmt.Errorf("cluster %s is not ready", cluster.Name)
	}

	innCluster := c.GetInnerCluster(cluster.Name)
	if innCluster == nil {
		return nil, fmt.Errorf("innCluster %s not found", cluster.Name)
	}

	return innCluster.SnapshotV1Client, nil
}

func (c *clusterClients) GetSnapshotClientWithUser(ctx context.Context, cluster string) (*volumesnapshotv1.SnapshotV1Client, error) {
	config, err := c.NewKubeConfigWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return volumesnapshotv1.NewForConfig(config)
}

func (c *clusterClients) GetClusterByKubeSystemID(ID string) string {
	c.RLock()
	defer c.RUnlock()

	for _, cluster := range c.clusterMap {
		if cluster != nil && cluster.Status.KubeSystemID == ID {
			return cluster.Name
		}
	}
	return ""
}

func (c *clusterClients) GetAllClusterClient() (map[string]kubernetes.Interface, error) {
	c.RLock()
	defer c.RUnlock()

	clusterMap := make(map[string]kubernetes.Interface)
	for name, cluster := range c.innerClusters {
		clusterMap[name] = cluster.KubeClient
	}
	return clusterMap, nil
}

func (c *clusterClients) GetClientSet(cluster string) (client.Client, error) {
	c.RLock()
	defer c.RUnlock()

	innCluster := c.GetInnerCluster(cluster)
	if innCluster == nil {
		return nil, fmt.Errorf("innCluster %s not found", cluster)
	}
	return innCluster.ClientSet, nil
}

func (c *clusterClients) GetClientSetWithUser(ctx context.Context, cluster string) (client.Client, error) {
	config, err := c.NewKubeConfigWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.New(config, client.Options{
		Scheme: clientSetSchemes,
	})
}

func (c *clusterClients) GetCustomMetricsClient(cluster string) (custom_metrics.CustomMetricsClient, error) {
	c.RLock()
	defer c.RUnlock()

	innCluster := c.GetInnerCluster(cluster)
	if innCluster == nil {
		return nil, fmt.Errorf("innCluster %s not found", cluster)
	}
	return innCluster.CustomMetricsClient, nil
}

func (c *clusterClients) NewKubeConfigWithUser(ctx context.Context, cluster string) (*rest.Config, error) {
	user, _ := contextutil.ParseUserInfoFromCtx(ctx)

	config, err := c.GetClusterKubeConfig(cluster)
	if err != nil {
		return nil, err
	}

	// If user exists, we add impersonate info to config.
	if user != nil && user.GetName() != "system:anonymous" {
		// Deep copy to avoid accidental modification of rest.Config
		return &rest.Config{
			Host:            config.Host,
			APIPath:         config.APIPath,
			ContentConfig:   config.ContentConfig,
			Username:        config.Username,
			Password:        config.Password,
			BearerToken:     config.BearerToken,
			BearerTokenFile: config.BearerTokenFile,
			Impersonate: rest.ImpersonationConfig{
				UserName: user.GetName(),
				Groups:   user.GetGroups(),
				UID:      user.GetUID(),
				Extra:    user.GetExtra(),
			},
			AuthProvider:        config.AuthProvider,
			AuthConfigPersister: config.AuthConfigPersister,
			ExecProvider:        config.ExecProvider,
			TLSClientConfig:     config.TLSClientConfig,
			UserAgent:           config.UserAgent,
			DisableCompression:  config.DisableCompression,
			Transport:           config.Transport,
			WrapTransport:       config.WrapTransport,
			QPS:                 config.QPS,
			Burst:               config.Burst,
			RateLimiter:         config.RateLimiter,
			WarningHandler:      config.WarningHandler,
			Timeout:             config.Timeout,
			Dial:                config.Dial,
			Proxy:               config.Proxy,
		}, nil
	}

	return config, nil
}

// NewKubernetesClientWithUser creates kubernetes client with impersonated user info, if there is.
func (c *clusterClients) NewKubernetesClientWithUser(ctx context.Context, cluster string) (kubeclient.Client, error) {
	config, err := c.NewKubeConfigWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return kubeclient.NewKubernetesClientWithConfig(&kubeclient.KubernetesOptions{QPS: DefaultQPS, Burst: DefaultBurst}, config)
}

// NewKubernetesClientWithUser creates vpa client with impersonated user info, if there is.
func (c *clusterClients) NewVPAClientWithUser(ctx context.Context, cluster string) (vpaclient.Interface, error) {
	config, err := c.NewKubeConfigWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return vpaclient.NewForConfig(config)
}

func (c *clusterClients) GetVPAClient(cluster string) (vpaclient.Interface, error) {
	config, err := c.GetClusterKubeConfig(cluster)
	if err != nil {
		return nil, err
	}

	return vpaclient.NewForConfig(config)
}

func GetKubeSystemID(ctx context.Context, namespaceInterface corev1client.NamespaceInterface) (string, error) {
	namespace, err := namespaceInterface.Get(ctx, "kube-system", metav1.GetOptions{})
	if err != nil {
		return "", err
	}
	return string(namespace.UID), nil
}
