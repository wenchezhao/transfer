package clusterclient

import (
	"context"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"
	volumesnapshotv1 "github.com/kubernetes-csi/external-snapshotter/client/v4/clientset/versioned/typed/volumesnapshot/v1"
	vpaclient "k8s.io/autoscaler/vertical-pod-autoscaler/pkg/client/clientset/versioned"
	"k8s.io/client-go/dynamic"
	dynamicfake "k8s.io/client-go/dynamic/fake"
	"k8s.io/client-go/kubernetes"
	clientsetfake "k8s.io/client-go/kubernetes/fake"
	"k8s.io/client-go/rest"
	"k8s.io/metrics/pkg/client/custom_metrics"
	"sigs.k8s.io/controller-runtime/pkg/client"

	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/util/gclient"
)

var _ ClusterClients = &FakeClusterClient{}

type FakeClusterClient struct {
	client        kubernetes.Interface
	dynamicClient dynamic.Interface
}

func NewFakeClusterClient() *FakeClusterClient {
	return &FakeClusterClient{
		client:        clientsetfake.NewSimpleClientset(),
		dynamicClient: dynamicfake.NewSimpleDynamicClient(gclient.NewSchema()),
	}
}

func (f FakeClusterClient) IsHostCluster(_ *clusterv1alpha1.Cluster) bool {
	panic("implement me")
}

func (f FakeClusterClient) IsClusterReady(_ *clusterv1alpha1.Cluster) bool {
	panic("implement me")
}

func (f FakeClusterClient) GetClusterKubeConfig(_ string) (*rest.Config, error) {
	panic("implement me")
}

func (f FakeClusterClient) Get(_ string) (*clusterv1alpha1.Cluster, error) {
	panic("implement me")
}

func (f FakeClusterClient) GetInnerCluster(_ string) *InnerCluster {
	return &InnerCluster{
		APIEnablements: []clusterv1alpha1.APIEnablement{
			{
				GroupVersion: "networking.k8s.io/v1",
				Resources: []*clusterv1alpha1.APIResource{
					{
						Name: "ingresses",
						Kind: "Ingress",
					},
				},
			},
		},
	}
}

func (f FakeClusterClient) GetClient(_ string) (kubernetes.Interface, error) {
	return f.client, nil
}

func (f FakeClusterClient) GetGeneratedClient(_ string) (clusterclientset.Interface, error) {
	panic("implement me")
}

func (f FakeClusterClient) GetDynamicClient(_ string) (dynamic.Interface, error) {
	panic("implement me")
}

func (f FakeClusterClient) GetClusterByKubeSystemID(_ string) string {
	panic("implement me")
}

func (f FakeClusterClient) GetSnapshotClient(_ string) (*volumesnapshotv1.SnapshotV1Client, error) {
	panic("implement me")
}

func (f FakeClusterClient) GetSnapshotClientWithUser(_ context.Context, _ string) (*volumesnapshotv1.SnapshotV1Client, error) {
	panic("implement me")
}

func (f FakeClusterClient) GetAllClusterClient() (map[string]kubernetes.Interface, error) {
	panic("implement me")
}

func (f FakeClusterClient) GetClientSet(_ string) (client.Client, error) {
	panic("implement me")
}

func (f FakeClusterClient) GetClientSetWithUser(_ context.Context, _ string) (client.Client, error) {
	panic("implement me")
}

func (f FakeClusterClient) GetCustomMetricsClient(_ string) (custom_metrics.CustomMetricsClient, error) {
	panic("implement me")
}

func (f FakeClusterClient) NewKubeConfigWithUser(_ context.Context, _ string) (*rest.Config, error) {
	panic("implement me")
}

func (f FakeClusterClient) NewKubernetesClientWithUser(_ context.Context, _ string) (kubeclient.Client, error) {
	return kubeclient.NewFakeClientSets(f.client, f.dynamicClient, nil, "", nil), nil
}

func (f FakeClusterClient) NewVPAClientWithUser(_ context.Context, _ string) (vpaclient.Interface, error) {
	panic("implement me")
}

func (f FakeClusterClient) GetVPAClient(_ string) (vpaclient.Interface, error) {
	panic("implement me")
}
