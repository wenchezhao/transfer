/*
Copyright 2022 Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package clusterclient

import (
	"context"
	"encoding/base64"
	"reflect"
	"sync"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"
	clusterv1alpha1listers "github.com/daocloud/dsp-appserver/api/crd/client/listers/cluster/v1alpha1"
	volumesnapshotv1 "github.com/kubernetes-csi/external-snapshotter/client/v4/clientset/versioned/typed/volumesnapshot/v1"
	"github.com/stretchr/testify/assert"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	clientsetfake "k8s.io/client-go/kubernetes/fake"
)

const (
	testConfigToken = `apiVersion: v1
clusters:
- cluster:
    certificate-authority-data:
    server: localhost:8000
  name: prod
contexts:
- context:
    cluster: prod
    namespace: default
    user: default-service-account
  name: default
current-context: default
kind: Config
preferences: {}
users:
- name: kubernetes-admin
  user:
    client-certificate-data:
    client-key-data:
`
)

var (
	clusterClient *clusterClients
	inCluster     *InnerCluster
	cluster       *clusterv1alpha1.Cluster
)

func init() {
	inCluster = &InnerCluster{}
	clusterClient = &clusterClients{innerClusters: map[string]*InnerCluster{
		"cluster-1": inCluster,
	}}
	cluster = &clusterv1alpha1.Cluster{
		ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"},
		Spec:       clusterv1alpha1.ClusterSpec{},
	}
}

func Test_clusterClients_IsClusterReady(t *testing.T) {
	tests := []struct {
		name    string
		cluster *clusterv1alpha1.Cluster
		want    bool
	}{
		{
			name: "cluster is ready",
			cluster: &clusterv1alpha1.Cluster{
				Status: clusterv1alpha1.ClusterStatus{
					Conditions: []clusterv1alpha1.ClusterCondition{
						{
							Type:   clusterv1alpha1.ClusterConditionRunning,
							Status: metav1.ConditionTrue,
						},
					},
				},
			},
			want: true,
		},
		{
			name: "cluster condition status is empty",
			cluster: &clusterv1alpha1.Cluster{
				Status: clusterv1alpha1.ClusterStatus{
					Conditions: []clusterv1alpha1.ClusterCondition{
						{
							Type: clusterv1alpha1.ClusterConditionRunning,
						},
					},
				},
			},
			want: false,
		},
	}
	for _, tt := range tests {
		if got := clusterClient.IsClusterReady(tt.cluster); got != tt.want {
			t.Errorf("clusterClients.IsClusterReady() = %v, want %v", got, tt.want)
		}
	}
}

func Test_clusterClients_IsHostCluster(t *testing.T) {
	type args struct {
		cluster *clusterv1alpha1.Cluster
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "cluster is HostCluster",
			args: args{cluster: &clusterv1alpha1.Cluster{
				TypeMeta:   metav1.TypeMeta{},
				ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{string(constants.ClusterRoleGlobalService): "true"}},
			}},
			want: true,
		},
		{
			name: "cluster is not HostCluster",
			args: args{cluster: &clusterv1alpha1.Cluster{
				TypeMeta:   metav1.TypeMeta{},
				ObjectMeta: metav1.ObjectMeta{Labels: map[string]string{}},
			}},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := clusterClient.IsHostCluster(tt.args.cluster); got != tt.want {
				t.Errorf("IsHostCluster() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_clusterClients_GetInnerCluster(t *testing.T) {
	type args struct {
		clusterName string
	}
	tests := []struct {
		name string
		args args
		want *InnerCluster
	}{
		{
			name: "cluster is innerCluster",
			args: args{clusterName: "cluster-1"},
			want: inCluster,
		},
		{
			name: "cluster is not innerCluster",
			args: args{clusterName: "cluster-2"},
			want: nil,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := clusterClient.GetInnerCluster(tt.args.clusterName); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetInnerCluster() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_clusterClients_removeCluster(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		obj interface{}
	}
	tests := []struct {
		name   string
		fields fields
		args   args
	}{
		{
			name: "remove cluster",
			fields: fields{
				client:            nil,
				clusterMap:        map[string]*clusterv1alpha1.Cluster{"cluster-1": {}},
				clusterKubeConfig: map[string]string{"cluster-1": "cluster-1 kubeConfig"},
				innerClusters:     map[string]*InnerCluster{"cluster-1": {}},
			},
			args: args{obj: &clusterv1alpha1.Cluster{
				ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"},
				Spec:       clusterv1alpha1.ClusterSpec{},
			}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			c.removeCluster(tt.args.obj)
			if c.clusterMap[tt.args.obj.(*clusterv1alpha1.Cluster).Name] != nil || c.innerClusters[tt.args.obj.(*clusterv1alpha1.Cluster).Name] != nil || c.clusterKubeConfig[tt.args.obj.(*clusterv1alpha1.Cluster).Name] != "" {
				t.Errorf("removeCluster error")
			}
		})
	}
}

func Test_clusterClients_GetClusterKubeConfig(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		cluster string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			name: "cluster exists",
			fields: fields{
				client:            nil,
				clusterMap:        map[string]*clusterv1alpha1.Cluster{"cluster-1": cluster},
				clusterKubeConfig: nil,
				innerClusters:     nil,
			},
			args:    args{cluster: "cluster-1"},
			wantErr: false,
		},
		{
			name: "cluster not exists",
			fields: fields{
				client:            nil,
				clusterMap:        nil,
				clusterKubeConfig: nil,
				innerClusters:     nil,
			},
			args:    args{cluster: "cluster-2"},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := clusterClient.GetClusterKubeConfig(tt.args.cluster)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetClusterKubeConfig() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func Test_clusterClients_Get(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		cluster string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *clusterv1alpha1.Cluster
		wantErr bool
	}{
		{
			name: "cluster exists",
			fields: fields{
				client:            nil,
				clusterMap:        map[string]*clusterv1alpha1.Cluster{"cluster-1": cluster},
				clusterKubeConfig: nil,
				innerClusters:     nil,
			},
			args:    args{cluster: "cluster-1"},
			want:    cluster,
			wantErr: false,
		},
		{
			name: "cluster not exists",
			fields: fields{
				client:            nil,
				clusterMap:        nil,
				clusterKubeConfig: nil,
				innerClusters:     nil,
			},
			args:    args{cluster: "cluster-1"},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			got, err := c.Get(tt.args.cluster)
			if (err != nil) != tt.wantErr {
				t.Errorf("Get() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Get() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_clusterClients_addCluster(t *testing.T) {
	c1 := clientsetfake.NewSimpleClientset()
	c1.CoreV1().Secrets("default").Create(context.Background(), &corev1.Secret{ObjectMeta: metav1.ObjectMeta{Name: "secret"}}, metav1.CreateOptions{})
	c2 := clientsetfake.NewSimpleClientset()
	c2.CoreV1().Secrets("default").Create(context.Background(), &corev1.Secret{ObjectMeta: metav1.ObjectMeta{Name: "secret"}, Data: map[string][]byte{"kubeconfig": []byte("kubeconfig")}}, metav1.CreateOptions{})
	decodeBytes1, _ := base64.StdEncoding.DecodeString("YXBpVmVyc2lvbjogdjEKY2x1c3RlcnM6Ci0gY2x1c3RlcjoKICAgIGNlcnRpZmljYXRlLWF1dGhvcml0eS1kYXRhOiBMUzB0TFMxQ1JVZEpUaUJEUlZKVVNVWkpRMEZVUlMwdExTMHRDazFKU1VNMWVrTkRRV01yWjBGM1NVSkJaMGxDUVVSQlRrSm5hM0ZvYTJsSE9YY3dRa0ZSYzBaQlJFRldUVkpOZDBWUldVUldVVkZFUlhkd2NtUlhTbXdLWTIwMWJHUkhWbnBOUWpSWVJGUkplRTFFYTNsUFJFRTFUa1JOZWsxc2IxaEVWRTE0VFVScmVVNXFRVFZPUkUxNlRXeHZkMFpVUlZSTlFrVkhRVEZWUlFwQmVFMUxZVE5XYVZwWVNuVmFXRkpzWTNwRFEwRlRTWGRFVVZsS1MyOWFTV2gyWTA1QlVVVkNRbEZCUkdkblJWQkJSRU5EUVZGdlEyZG5SVUpCVDJ0aUNuTk1ZMWhRTlVaamNIZ3JkVVZoYmtWRWNtUlplRXhIWTNsMFJrZ3lXR1F2Wm5Gd2VtOUxTRWRDU1NzdmFuRmtkVFp2TjA5dk56TnVURVpQTTNNeFN6QUtiRGw0ZHpKblNGbzJkRlU1WjA1dVpURnRkR2M1TTFGUk9XbFpaa0Z4U2treVoyTjVUalJGU3pJeU5XRk9kbUpHSzNab01FbDBiMlpzVTNsUFpXOXRPQXBpTVhwa2J6bGlkRWQ1VWpCcFoyZDRMMDh4VlVObWRHWTJaMWRDTUhObGRFNWxSekIwZGt4cVZ6ZFhlREZhZDB4c2EwVlRabWRqYkhORFFVWkxUMG92Q25WMk16WXJZWGR3V1dGbE5sbGlkMVphZEhkU2FrYzFlRE5zYzJsaGVuWXJRMWN2Um1WaWVFOXlkVVpDUVdOUGFIazNiM0E1YjFWMGJWQlJlbnB2U0ZJS1JXTnFNa1o2ZEd4Sk4wbFhkSEF6WWtGb0szaE1UR0ZwUW1OTGVVSkJkVFIxTDFjMFZpdGxUelkwWWtwQlZVdHJhMkpvTmxKM1dIaHFXRnAzVEcxeVJRb3lSbFpqUW1ad2FXeFBSbUpvY25FMVRpdHJRMEYzUlVGQllVNURUVVZCZDBSbldVUldVakJRUVZGSUwwSkJVVVJCWjB0clRVRTRSMEV4VldSRmQwVkNDaTkzVVVaTlFVMUNRV1k0ZDBoUldVUldVakJQUWtKWlJVWkhRVFYyYkVkM1ZuRllZekJPYW1wV2JVNHlhekY2V1V0aGFEQk5RVEJIUTFOeFIxTkpZak1LUkZGRlFrTjNWVUZCTkVsQ1FWRkJXVEZXYW5CUGJsUnhhM0pKVUUxMlVsTlpVa3hHWjJScGRFcDNkVmczZFZjM1RXMXFWM0JNV21oWk5UVldhelZVU0FvMGVqZE9PVGRwTkZwNmJrcERZelZuVTBVNFRHWkZTbmR5VW5OTE5ISnBMekZIYkVkQlkxa3piMFZrTHpsYVMyUmFSa016U0ROM1EyRlZVek5IVkdkaUNuQlJWblJRTWpGVGNrbEtjWEoxZERCa09USkhhR3BPUld0bU5HcGFXRWd3YzJGUlNHWmpUbGxGYm10cFVqazJTWGhoWkRaTloxZEJWVTkwTjBadWEzSUtVSFJUVW10dmNVb3hORkpEZWpoR1VYbEJkM1JZTUhaV09XNDVlVWh1VXpWUU4wVkVSR3MyTVdnM1QwVjVkV2x3TmpkRWVHWnZjRFJZVmpWQ1l6QnJUQXByZDAxSlpIcHlXa3BEZGtKR1EwTmhTakpsTTFsVFNrOVpUek12YzFoNFNsQnJRak5pYkRadVRrUm5kMHhhVWxsa1VUaERUakpFUm10aVQwMVViV2h2Q2t4d2VVZFhWbXBzV0hJelFsTk9TeXMwYld4aU5IRTVTbVZoY21Wck1WbDBiMlJ0ZWdvdExTMHRMVVZPUkNCRFJWSlVTVVpKUTBGVVJTMHRMUzB0Q2c9PQogICAgc2VydmVyOiBodHRwczovLzE3Mi4zMC40My4xMDA6NjQ0MwogIG5hbWU6IGNsdXN0ZXIuMTAwCmNvbnRleHRzOgotIGNvbnRleHQ6CiAgICBjbHVzdGVyOiBjbHVzdGVyLjEwMAogICAgbmFtZXNwYWNlOiBrYXJtYWRhLXN5c3RlbQogICAgdXNlcjoga3ViZXJuZXRlcy0xMDAKICBuYW1lOiBrdWJlcm5ldGVzLWFkbWluLTEwMApjdXJyZW50LWNvbnRleHQ6IGt1YmVybmV0ZXMtYWRtaW4tMTAwCmtpbmQ6IENvbmZpZwpwcmVmZXJlbmNlczoge30KdXNlcnM6Ci0gbmFtZToga3ViZXJuZXRlcy0xMDAKICB1c2VyOgogICAgY2xpZW50LWNlcnRpZmljYXRlLWRhdGE6IExTMHRMUzFDUlVkSlRpQkRSVkpVU1VaSlEwRlVSUzB0TFMwdENrMUpTVVJKVkVORFFXZHRaMEYzU1VKQlowbEpaRnBuVVRWbWVVdE5WMDEzUkZGWlNrdHZXa2xvZG1OT1FWRkZURUpSUVhkR1ZFVlVUVUpGUjBFeFZVVUtRWGhOUzJFelZtbGFXRXAxV2xoU2JHTjZRV1ZHZHpCNVRWUkJOVTFxWjNkUFZGRjZUWHBLWVVaM01IbE5ha0UxVFdwbmQwOVVVWHBOZWs1aFRVUlJlQXBHZWtGV1FtZE9Wa0pCYjFSRWJrNDFZek5TYkdKVWNIUlpXRTR3V2xoS2VrMVNhM2RHZDFsRVZsRlJSRVY0UW5Ka1YwcHNZMjAxYkdSSFZucE1WMFpyQ21KWGJIVk5TVWxDU1dwQlRrSm5hM0ZvYTJsSE9YY3dRa0ZSUlVaQlFVOURRVkU0UVUxSlNVSkRaMHREUVZGRlFYaEtlR3AzU1hCNFIyaDVaVkJJV21NS1pFZzFkRVZxUkM5bFpUTnVlbGQ0ZFhsaFoxQktOMkZvZFZWblVYTjNaRzQ1ZW5wc1QwUlNkbmRDWlcxUVpWcGlSRGtyTW5oRVIxTkdaa2cwYm5kVmJ3cFVka0UzTUZZMFFXbDNWMEZ3T0UxTGFIazFkMHRRTTIxSlZGbDRMM2xKY0V3MVdEUnhaRUpNYW5GWlQwcHZZMnBGYmsxd2JUZHNkalpSYkN0WE5qWlNDbWxYUlVSQ2JUSldRWGRoVFRneWRFY3dVVXBTYXpsT04xRk1VekowUTFJdldHbDBVV1Y1T0VKbWNHeGtaWFUwTWtOcWFYWllNa0ZtTTNseGIxZHNSV2tLVUZaT1R6bENRbUZZYTIxbVNGUXlXR0pyWm5KUGIzVnpRVU54TTBSdmVVTTFWV0p4ZVZsU2RHUlNVVVJDYm01WFNpc3pWelZLUjJOMmNEWkVPVmg2TmdwaFZHbDROV05ySzNGb1dFcFVORXhCWVVwTk1rVnJSMDlrYlM5cmQxQm5VRVppYzNCNlpESTNabWxEWlhVNU9YQm1NakpzU0hGTmMyRXdlamMxZEhSSkNpczNLMEZ3ZDBsRVFWRkJRbTh4V1hkV1JFRlBRbWRPVmtoUk9FSkJaamhGUWtGTlEwSmhRWGRGZDFsRVZsSXdiRUpCZDNkRFoxbEpTM2RaUWtKUlZVZ0tRWGRKZDBSQldVUldVakJVUVZGSUwwSkJTWGRCUkVGbVFtZE9Wa2hUVFVWSFJFRlhaMEpTWjA5aU5WSnpSbUZzTTA1RVdUUXhXbXBrY0U1ak1rTnRid3BrUkVGT1FtZHJjV2hyYVVjNWR6QkNRVkZ6UmtGQlQwTkJVVVZCUTFjcldIWmhWMlpVVVhkNmNtaHNZeXMxWTFRek1ETjJVVWc1UlV4alUwSndTMnRyQ2tkUVpqWk1TMEZGTUc5a1UyczJVbk53Y1dObGNrTmxaV2QzTjFKVWVFTTNZVWhvZEdkb056UmtRbTB5YUdOUUswZ3dWVzB6Uml0eU5qbGpVMnB4UTFBS1JrVjZiRFU1TTBOR1R6UkVTemhTUmtWR2VWZGpOR2xzSzFkbkwyRm1abXB2Wm1kVlFsRkxlbWcwZEc4eGNHdzRjMVp0ZEhKWGNubFhUR1Z5VFhFNVJnbzVVVEZTTXpWMmNYbHdSakJyYTBOUVRrVjJPR1pOYkRkalEyVmxha0pTVkdsUFlrc3daRXBUVDBWamFHd3dkMmhyVVhaNlNFVkJNR0pTY0RsRlduaEtDa3BLU204NWVsVkJSV2R0UzJGbmRDdFJTVlZCVGs1dmVWYzRXRWc1TjBwYWJEUXdNM0J6Y2tGdmIxcGxWMmh2WmpjM2JIbERTelF6VFVGWlEySlFXVElLYVZGRmFUWmpVRVJHYkU1bFJtcE1VM1YxUVhGWFMwZ3hTVzFRVUZKcU1XUlVhbkp6Y1RWUlVqWktUbVZLV0RCU1NsRTlQUW90TFMwdExVVk9SQ0JEUlZKVVNVWkpRMEZVUlMwdExTMHRDZz09CiAgICBjbGllbnQta2V5LWRhdGE6IExTMHRMUzFDUlVkSlRpQlNVMEVnVUZKSlZrRlVSU0JMUlZrdExTMHRMUXBOU1VsRmIzZEpRa0ZCUzBOQlVVVkJlRXA0YW5kSmNIaEhhSGxsVUVoYVkyUklOWFJGYWtRdlpXVXpibnBYZUhWNVlXZFFTamRoYUhWVloxRnpkMlJ1Q2psNmVteFBSRkoyZDBKbGJWQmxXbUpFT1NzeWVFUkhVMFptU0RSdWQxVnZWSFpCTnpCV05FRnBkMWRCY0RoTlMyaDVOWGRMVUROdFNWUlplQzk1U1hBS1REVllOSEZrUWt4cWNWbFBTbTlqYWtWdVRYQnROMngyTmxGc0sxYzJObEpwVjBWRVFtMHlWa0YzWVUwNE1uUkhNRkZLVW1zNVRqZFJURk15ZEVOU0x3cFlhWFJSWlhrNFFtWndiR1JsZFRReVEycHBkbGd5UVdZemVYRnZWMnhGYVZCV1RrODVRa0poV0d0dFpraFVNbGhpYTJaeVQyOTFjMEZEY1RORWIzbERDalZWWW5GNVdWSjBaRkpSUkVKdWJsZEtLek5YTlVwSFkzWndOa1E1V0hvMllWUnBlRFZqYXl0eGFGaEtWRFJNUVdGS1RUSkZhMGRQWkcwdmEzZFFaMUFLUm1KemNIcGtNamRtYVVObGRUazVjR1l5TW14SWNVMXpZVEI2TnpWMGRFa3JOeXRCY0hkSlJFRlJRVUpCYjBsQ1FVSkliRWhvYzNaUWNEUmxlbkpSTkFwSVlrRnZkR0Z4TjA1UVYxaEdjM05YZGtoeE1GSnFWR0ZLV25kcmJVRnBSR1YzTkVGNEsyY3lkRnByY0ZSbFRrTmlWRlpxY1d4SWRrcFNia1ZRVm01VUNqaFdhRVlyTVhaVFJEUkRXSHB3TnpKWVMxaDZUSGhuT0VNNE9HOUVTMHh3VEVKQ09YVlFWbFF4VW5reGRHOUpRazlOY2poSGJWSnVSekl4T1doTVpUVUthWFIxVkV4bFFrODFkMjkzWkZoSVQyRk9TM0pSUm5WU1IzZ3pTR0VyTjNwMlQwMXBLMUFyYTNCUU5HWnhaV0ZNWjNacFZUUXpUbHBTUlZoYVlVOWxhZ3BvVWxNd2NXUTRiWFV5TjBWNk1HVllMMU41TTFwaldVTldiVWxvZVhaMVMyUTRTRkU0UzB4MmQybG9UWEZvWkd0Tk5VdGliM2c1Y1ZoWWRtOUNTR1JvQ21wQ2RYVlRLMFIyT1ZkWmNqTm1VRkZZU0V4d1RXY3dNQzkzVWxsb1dWbHdLMjFRTlZWNmVGSnFlRzFSYVdJMFpIQjRlU3R6V0hwRlQyNDFVbXhNUzFJS1oyeHZWakZ2YTBObldVVkJlV3huU25rM2JHczVhSEJsTlZWVVRWSjZWeXN5VnlzMWVYaERjRFp2ZWk5WWNIQXlhRE5YUkVaTVMwRkpVMEpWZG1GUFJRcHhXV1ZDVDNSM2JrZHBOMjFyT0RZeFpteDVkMFp5UkVGemJHUjNZakp5Y0RGMU1ESnhOVVZRU0dGaVkzVnJibmhZTDNRNVRUSjBkRVp0TXpGcVJEWnlDbGhZY2tkYU5FczBWRTgyY0hJcloyWktkR3QyYjBsd1lrUlBNa1U1TVVwb00wc3dlR2xwZERneVpHczNNbmhXYW1vNU1UaExUbk5EWjFsRlFTdE1PSElLZG5saFlURkdTbTlsZWxsTFFucExTMnhOWTJseFYzQkhlamwzTUV4eVYzRkZPV0kxV0VSWlpraE1heTlMZDFOWVNIVkliVFZuY0dKVFJqTkZNVEJYWkFwVFFrdG1hMGQzUW5OMlYwVTJjMVZOSzFFMk0yTkVVM053VkVWRVpXdDViblpHTWk4clprTjNZbTlqUWs1RloxQTFXbXczZGxBeVNIbFpWVTFJTjFCVkNucHRZMHhxU0ZKNE1YbHBOSE5vU1VOTmJVUkdVV2hKUlRkQlUzZzRRVkJwTkN0NVJHMTVWVU5uV1VGeFpWaExUVGxxZWxGUlJtSmtURFpVYkRaak1VZ0tTRmRJVmpBMGFXNWxURTRyWVRGUmIwOVRNbkkwV2tKME5EZHBSMGRzV1ZaMFEwVllaSFpGY1ZkUFFVUTVUMk0yVVVWRGFXTnlXSGRsWkZKaVVIZHJXZ3BIWWtKYVRWWnJTRGd5Wm5kSWRXUjRTek40Y213NGFFNWFaMWRsVXl0V2VTdFFkU3MzVEhrNVVWaG5WRTlrYlZsTlVUQkVWMU5sYkhab1NXdFVTVWhKQ21KbU5uaE1NVWhGT1ZGdVVXZHNkbXMzYVhoTE9IZExRbWRDWkZONldWcEtNVEpEY2t4WVRFbEhWalprV2xwTldISlBPVmh6VEZsVGRuRXpWMmxPUkRrS1lXcHZNRTVQZVdKcVoyMDFhak5ZY3pGd2NXaFJMMlpuUjNaSVdXSkRkbmt5ZUZaUGJUQlpkR05VTkZkS1pWcEJaRUZFU1ZnMWRrcHZZbkpaTjNreGFBcFhVSFpXYW5GV0syTlRWakl3UlRkR0syMHdOVVpJT1ZoM01VSkNjVEpYUkVWbWEydG1abmRtY2tadEswTkphWGwyUTNjMmVHc3haa1F4VVdrclUxcElDalptYzJ4QmIwZENRVXBXYXpBNVVtbHJObXBxYkdKalIwUlFhbHBoUTBsVVMwUnpVVE5MWTJ3NUwxaEtiRFJIZVhneGFWZG1RWFJNVlUxQlFWTlhVa1lLT1dOdmRHcDBhak5NWXpCd2MwZHliVlJKWlZkUE16SXdRbXRSVFZvNGFHcHFVa3cwTW5GMVJtMDJWVFpVUTFkNFUzVnZWVzVJV2pCa1ZXaERjVGR3TkFvck1VeFRNWFp3ZG5oVlZqaFlkVlI2T0U1clkxaFlXbTlPY0doc1VVVlFaSEpRUlRSbVFYZ3JRMDlrYW1aWlZ6WmtSR1Y1Q2kwdExTMHRSVTVFSUZKVFFTQlFVa2xXUVZSRklFdEZXUzB0TFMwdENnPT0K")
	decodeBytes2, _ := base64.StdEncoding.DecodeString("YXBpVmVyc2lvbjogdjEKY2x1c3RlcnM6Ci0gY2x1c3RlcjoKICAgIGNlcnRpZmljYXRlLWF1dGhvcml0eS1kYXRhOiBMUzB0TFMxQ1JVZEpUaUJEUlZKVVNVWkpRMEZVUlMwdExTMHRDazFKU1VNMWVrTkRRV01yWjBGM1NVSkJaMGxDUVVSQlRrSm5hM0ZvYTJsSE9YY3dRa0ZSYzBaQlJFRldUVkpOZDBWUldVUldVVkZFUlhkd2NtUlhTbXdLWTIwMWJHUkhWbnBOUWpSWVJGUkplRTFFYTNsUFJFRTFUa1JOZWsxc2IxaEVWRTE0VFVScmVVNXFRVFZPUkUxNlRXeHZkMFpVUlZSTlFrVkhRVEZWUlFwQmVFMUxZVE5XYVZwWVNuVmFXRkpzWTNwRFEwRlRTWGRFVVZsS1MyOWFTV2gyWTA1QlVVVkNRbEZCUkdkblJWQkJSRU5EUVZGdlEyZG5SVUpCVDJ0aUNuTk1ZMWhRTlVaamNIZ3JkVVZoYmtWRWNtUlplRXhIWTNsMFJrZ3lXR1F2Wm5Gd2VtOUxTRWRDU1NzdmFuRmtkVFp2TjA5dk56TnVURVpQTTNNeFN6QUtiRGw0ZHpKblNGbzJkRlU1WjA1dVpURnRkR2M1TTFGUk9XbFpaa0Z4U2treVoyTjVUalJGU3pJeU5XRk9kbUpHSzNab01FbDBiMlpzVTNsUFpXOXRPQXBpTVhwa2J6bGlkRWQ1VWpCcFoyZDRMMDh4VlVObWRHWTJaMWRDTUhObGRFNWxSekIwZGt4cVZ6ZFhlREZhZDB4c2EwVlRabWRqYkhORFFVWkxUMG92Q25WMk16WXJZWGR3V1dGbE5sbGlkMVphZEhkU2FrYzFlRE5zYzJsaGVuWXJRMWN2Um1WaWVFOXlkVVpDUVdOUGFIazNiM0E1YjFWMGJWQlJlbnB2U0ZJS1JXTnFNa1o2ZEd4Sk4wbFhkSEF6WWtGb0szaE1UR0ZwUW1OTGVVSkJkVFIxTDFjMFZpdGxUelkwWWtwQlZVdHJhMkpvTmxKM1dIaHFXRnAzVEcxeVJRb3lSbFpqUW1ad2FXeFBSbUpvY25FMVRpdHJRMEYzUlVGQllVNURUVVZCZDBSbldVUldVakJRUVZGSUwwSkJVVVJCWjB0clRVRTRSMEV4VldSRmQwVkNDaTkzVVVaTlFVMUNRV1k0ZDBoUldVUldVakJQUWtKWlJVWkhRVFYyYkVkM1ZuRllZekJPYW1wV2JVNHlhekY2V1V0aGFEQk5RVEJIUTFOeFIxTkpZak1LUkZGRlFrTjNWVUZCTkVsQ1FWRkJXVEZXYW5CUGJsUnhhM0pKVUUxMlVsTlpVa3hHWjJScGRFcDNkVmczZFZjM1RXMXFWM0JNV21oWk5UVldhelZVU0FvMGVqZE9PVGRwTkZwNmJrcERZelZuVTBVNFRHWkZTbmR5VW5OTE5ISnBMekZIYkVkQlkxa3piMFZrTHpsYVMyUmFSa016U0ROM1EyRlZVek5IVkdkaUNuQlJWblJRTWpGVGNrbEtjWEoxZERCa09USkhhR3BPUld0bU5HcGFXRWd3YzJGUlNHWmpUbGxGYm10cFVqazJTWGhoWkRaTloxZEJWVTkwTjBadWEzSUtVSFJUVW10dmNVb3hORkpEZWpoR1VYbEJkM1JZTUhaV09XNDVlVWh1VXpWUU4wVkVSR3MyTVdnM1QwVjVkV2x3TmpkRWVHWnZjRFJZVmpWQ1l6QnJUQXByZDAxSlpIcHlXa3BEZGtKR1EwTmhTakpsTTFsVFNrOVpUek12YzFoNFNsQnJRak5pYkRadVRrUm5kMHhhVWxsa1VUaERUakpFUm10aVQwMVViV2h2Q2t4d2VVZFhWbXBzV0hJelFsTk9TeXMwYld4aU5IRTVTbVZoY21Wck1WbDBiMlJ0ZWdvdExTMHRMVVZPUkNCRFJWSlVTVVpKUTBGVVJTMHRMUzB0Q2c9PQogICAgc2VydmVyOiBodHRwczovLzE3Mi4zMC40My4xMDA6NjQ0MwogIG5hbWU6IGNsdXN0ZXIuMTAwCmtpbmQ6IENvbmZpZwpwcmVmZXJlbmNlczoge30KdXNlcnM6Ci0gbmFtZToga3ViZXJuZXRlcy0xMDAKICB1c2VyOgogICAgY2xpZW50LWNlcnRpZmljYXRlLWRhdGE6IExTMHRMUzFDUlVkSlRpQkRSVkpVU1VaSlEwRlVSUzB0TFMwdENrMUpTVVJKVkVORFFXZHRaMEYzU1VKQlowbEpaRnBuVVRWbWVVdE5WMDEzUkZGWlNrdHZXa2xvZG1OT1FWRkZURUpSUVhkR1ZFVlVUVUpGUjBFeFZVVUtRWGhOUzJFelZtbGFXRXAxV2xoU2JHTjZRV1ZHZHpCNVRWUkJOVTFxWjNkUFZGRjZUWHBLWVVaM01IbE5ha0UxVFdwbmQwOVVVWHBOZWs1aFRVUlJlQXBHZWtGV1FtZE9Wa0pCYjFSRWJrNDFZek5TYkdKVWNIUlpXRTR3V2xoS2VrMVNhM2RHZDFsRVZsRlJSRVY0UW5Ka1YwcHNZMjAxYkdSSFZucE1WMFpyQ21KWGJIVk5TVWxDU1dwQlRrSm5hM0ZvYTJsSE9YY3dRa0ZSUlVaQlFVOURRVkU0UVUxSlNVSkRaMHREUVZGRlFYaEtlR3AzU1hCNFIyaDVaVkJJV21NS1pFZzFkRVZxUkM5bFpUTnVlbGQ0ZFhsaFoxQktOMkZvZFZWblVYTjNaRzQ1ZW5wc1QwUlNkbmRDWlcxUVpWcGlSRGtyTW5oRVIxTkdaa2cwYm5kVmJ3cFVka0UzTUZZMFFXbDNWMEZ3T0UxTGFIazFkMHRRTTIxSlZGbDRMM2xKY0V3MVdEUnhaRUpNYW5GWlQwcHZZMnBGYmsxd2JUZHNkalpSYkN0WE5qWlNDbWxYUlVSQ2JUSldRWGRoVFRneWRFY3dVVXBTYXpsT04xRk1VekowUTFJdldHbDBVV1Y1T0VKbWNHeGtaWFUwTWtOcWFYWllNa0ZtTTNseGIxZHNSV2tLVUZaT1R6bENRbUZZYTIxbVNGUXlXR0pyWm5KUGIzVnpRVU54TTBSdmVVTTFWV0p4ZVZsU2RHUlNVVVJDYm01WFNpc3pWelZLUjJOMmNEWkVPVmg2TmdwaFZHbDROV05ySzNGb1dFcFVORXhCWVVwTk1rVnJSMDlrYlM5cmQxQm5VRVppYzNCNlpESTNabWxEWlhVNU9YQm1NakpzU0hGTmMyRXdlamMxZEhSSkNpczNLMEZ3ZDBsRVFWRkJRbTh4V1hkV1JFRlBRbWRPVmtoUk9FSkJaamhGUWtGTlEwSmhRWGRGZDFsRVZsSXdiRUpCZDNkRFoxbEpTM2RaUWtKUlZVZ0tRWGRKZDBSQldVUldVakJVUVZGSUwwSkJTWGRCUkVGbVFtZE9Wa2hUVFVWSFJFRlhaMEpTWjA5aU5WSnpSbUZzTTA1RVdUUXhXbXBrY0U1ak1rTnRid3BrUkVGT1FtZHJjV2hyYVVjNWR6QkNRVkZ6UmtGQlQwTkJVVVZCUTFjcldIWmhWMlpVVVhkNmNtaHNZeXMxWTFRek1ETjJVVWc1UlV4alUwSndTMnRyQ2tkUVpqWk1TMEZGTUc5a1UyczJVbk53Y1dObGNrTmxaV2QzTjFKVWVFTTNZVWhvZEdkb056UmtRbTB5YUdOUUswZ3dWVzB6Uml0eU5qbGpVMnB4UTFBS1JrVjZiRFU1TTBOR1R6UkVTemhTUmtWR2VWZGpOR2xzSzFkbkwyRm1abXB2Wm1kVlFsRkxlbWcwZEc4eGNHdzRjMVp0ZEhKWGNubFhUR1Z5VFhFNVJnbzVVVEZTTXpWMmNYbHdSakJyYTBOUVRrVjJPR1pOYkRkalEyVmxha0pTVkdsUFlrc3daRXBUVDBWamFHd3dkMmhyVVhaNlNFVkJNR0pTY0RsRlduaEtDa3BLU204NWVsVkJSV2R0UzJGbmRDdFJTVlZCVGs1dmVWYzRXRWc1TjBwYWJEUXdNM0J6Y2tGdmIxcGxWMmh2WmpjM2JIbERTelF6VFVGWlEySlFXVElLYVZGRmFUWmpVRVJHYkU1bFJtcE1VM1YxUVhGWFMwZ3hTVzFRVUZKcU1XUlVhbkp6Y1RWUlVqWktUbVZLV0RCU1NsRTlQUW90TFMwdExVVk9SQ0JEUlZKVVNVWkpRMEZVUlMwdExTMHRDZz09CiAgICBjbGllbnQta2V5LWRhdGE6IExTMHRMUzFDUlVkSlRpQlNVMEVnVUZKSlZrRlVSU0JMUlZrdExTMHRMUXBOU1VsRmIzZEpRa0ZCUzBOQlVVVkJlRXA0YW5kSmNIaEhhSGxsVUVoYVkyUklOWFJGYWtRdlpXVXpibnBYZUhWNVlXZFFTamRoYUhWVloxRnpkMlJ1Q2psNmVteFBSRkoyZDBKbGJWQmxXbUpFT1NzeWVFUkhVMFptU0RSdWQxVnZWSFpCTnpCV05FRnBkMWRCY0RoTlMyaDVOWGRMVUROdFNWUlplQzk1U1hBS1REVllOSEZrUWt4cWNWbFBTbTlqYWtWdVRYQnROMngyTmxGc0sxYzJObEpwVjBWRVFtMHlWa0YzWVUwNE1uUkhNRkZLVW1zNVRqZFJURk15ZEVOU0x3cFlhWFJSWlhrNFFtWndiR1JsZFRReVEycHBkbGd5UVdZemVYRnZWMnhGYVZCV1RrODVRa0poV0d0dFpraFVNbGhpYTJaeVQyOTFjMEZEY1RORWIzbERDalZWWW5GNVdWSjBaRkpSUkVKdWJsZEtLek5YTlVwSFkzWndOa1E1V0hvMllWUnBlRFZqYXl0eGFGaEtWRFJNUVdGS1RUSkZhMGRQWkcwdmEzZFFaMUFLUm1KemNIcGtNamRtYVVObGRUazVjR1l5TW14SWNVMXpZVEI2TnpWMGRFa3JOeXRCY0hkSlJFRlJRVUpCYjBsQ1FVSkliRWhvYzNaUWNEUmxlbkpSTkFwSVlrRnZkR0Z4TjA1UVYxaEdjM05YZGtoeE1GSnFWR0ZLV25kcmJVRnBSR1YzTkVGNEsyY3lkRnByY0ZSbFRrTmlWRlpxY1d4SWRrcFNia1ZRVm01VUNqaFdhRVlyTVhaVFJEUkRXSHB3TnpKWVMxaDZUSGhuT0VNNE9HOUVTMHh3VEVKQ09YVlFWbFF4VW5reGRHOUpRazlOY2poSGJWSnVSekl4T1doTVpUVUthWFIxVkV4bFFrODFkMjkzWkZoSVQyRk9TM0pSUm5WU1IzZ3pTR0VyTjNwMlQwMXBLMUFyYTNCUU5HWnhaV0ZNWjNacFZUUXpUbHBTUlZoYVlVOWxhZ3BvVWxNd2NXUTRiWFV5TjBWNk1HVllMMU41TTFwaldVTldiVWxvZVhaMVMyUTRTRkU0UzB4MmQybG9UWEZvWkd0Tk5VdGliM2c1Y1ZoWWRtOUNTR1JvQ21wQ2RYVlRLMFIyT1ZkWmNqTm1VRkZZU0V4d1RXY3dNQzkzVWxsb1dWbHdLMjFRTlZWNmVGSnFlRzFSYVdJMFpIQjRlU3R6V0hwRlQyNDFVbXhNUzFJS1oyeHZWakZ2YTBObldVVkJlV3huU25rM2JHczVhSEJsTlZWVVRWSjZWeXN5VnlzMWVYaERjRFp2ZWk5WWNIQXlhRE5YUkVaTVMwRkpVMEpWZG1GUFJRcHhXV1ZDVDNSM2JrZHBOMjFyT0RZeFpteDVkMFp5UkVGemJHUjNZakp5Y0RGMU1ESnhOVVZRU0dGaVkzVnJibmhZTDNRNVRUSjBkRVp0TXpGcVJEWnlDbGhZY2tkYU5FczBWRTgyY0hJcloyWktkR3QyYjBsd1lrUlBNa1U1TVVwb00wc3dlR2xwZERneVpHczNNbmhXYW1vNU1UaExUbk5EWjFsRlFTdE1PSElLZG5saFlURkdTbTlsZWxsTFFucExTMnhOWTJseFYzQkhlamwzTUV4eVYzRkZPV0kxV0VSWlpraE1heTlMZDFOWVNIVkliVFZuY0dKVFJqTkZNVEJYWkFwVFFrdG1hMGQzUW5OMlYwVTJjMVZOSzFFMk0yTkVVM053VkVWRVpXdDViblpHTWk4clprTjNZbTlqUWs1RloxQTFXbXczZGxBeVNIbFpWVTFJTjFCVkNucHRZMHhxU0ZKNE1YbHBOSE5vU1VOTmJVUkdVV2hKUlRkQlUzZzRRVkJwTkN0NVJHMTVWVU5uV1VGeFpWaExUVGxxZWxGUlJtSmtURFpVYkRaak1VZ0tTRmRJVmpBMGFXNWxURTRyWVRGUmIwOVRNbkkwV2tKME5EZHBSMGRzV1ZaMFEwVllaSFpGY1ZkUFFVUTVUMk0yVVVWRGFXTnlXSGRsWkZKaVVIZHJXZ3BIWWtKYVRWWnJTRGd5Wm5kSWRXUjRTek40Y213NGFFNWFaMWRsVXl0V2VTdFFkU3MzVEhrNVVWaG5WRTlrYlZsTlVUQkVWMU5sYkhab1NXdFVTVWhKQ21KbU5uaE1NVWhGT1ZGdVVXZHNkbXMzYVhoTE9IZExRbWRDWkZONldWcEtNVEpEY2t4WVRFbEhWalprV2xwTldISlBPVmh6VEZsVGRuRXpWMmxPUkRrS1lXcHZNRTVQZVdKcVoyMDFhak5ZY3pGd2NXaFJMMlpuUjNaSVdXSkRkbmt5ZUZaUGJUQlpkR05VTkZkS1pWcEJaRUZFU1ZnMWRrcHZZbkpaTjNreGFBcFhVSFpXYW5GV0syTlRWakl3UlRkR0syMHdOVVpJT1ZoM01VSkNjVEpYUkVWbWEydG1abmRtY2tadEswTkphWGwyUTNjMmVHc3haa1F4VVdrclUxcElDalptYzJ4QmIwZENRVXBXYXpBNVVtbHJObXBxYkdKalIwUlFhbHBoUTBsVVMwUnpVVE5MWTJ3NUwxaEtiRFJIZVhneGFWZG1RWFJNVlUxQlFWTlhVa1lLT1dOdmRHcDBhak5NWXpCd2MwZHliVlJKWlZkUE16SXdRbXRSVFZvNGFHcHFVa3cwTW5GMVJtMDJWVFpVUTFkNFUzVnZWVzVJV2pCa1ZXaERjVGR3TkFvck1VeFRNWFp3ZG5oVlZqaFlkVlI2T0U1clkxaFlXbTlPY0doc1VVVlFaSEpRUlRSbVFYZ3JRMDlrYW1aWlZ6WmtSR1Y1Q2kwdExTMHRSVTVFSUZKVFFTQlFVa2xXUVZSRklFdEZXUzB0TFMwdENnPT0K")

	c3 := clientsetfake.NewSimpleClientset()
	c3.CoreV1().Secrets("default").Create(context.Background(), &corev1.Secret{ObjectMeta: metav1.ObjectMeta{Name: "secret"}, Data: map[string][]byte{"kubeconfig": decodeBytes1}}, metav1.CreateOptions{})

	c4 := clientsetfake.NewSimpleClientset()
	c4.CoreV1().Secrets("default").Create(context.Background(), &corev1.Secret{ObjectMeta: metav1.ObjectMeta{Name: "secret"}, Data: map[string][]byte{"kubeconfig": decodeBytes2}}, metav1.CreateOptions{})

	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		obj     interface{}
		succeed bool
	}
	tests := []struct {
		name   string
		fields fields
		args   args
	}{
		{
			name: "add cluster endpoint is invalid",
			fields: fields{
				client:            clientsetfake.NewSimpleClientset(),
				clusterMap:        map[string]*clusterv1alpha1.Cluster{},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			args: args{obj: &clusterv1alpha1.Cluster{ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"}, Spec: clusterv1alpha1.ClusterSpec{APIEndpoint: "http://[fe80::%31]/"}}, succeed: false},
		},
		{
			name: "add cluster secret is empty",
			fields: fields{
				client:            clientsetfake.NewSimpleClientset(),
				clusterMap:        map[string]*clusterv1alpha1.Cluster{},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			args: args{obj: &clusterv1alpha1.Cluster{ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"}, Spec: clusterv1alpha1.ClusterSpec{SecretRef: nil}}, succeed: false},
		},
		{
			name: "add cluster secret name is empty",
			fields: fields{
				client:            clientsetfake.NewSimpleClientset(),
				clusterMap:        map[string]*clusterv1alpha1.Cluster{},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			args: args{obj: &clusterv1alpha1.Cluster{ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"}, Spec: clusterv1alpha1.ClusterSpec{SecretRef: &clusterv1alpha1.LocalSecretReference{Namespace: "default", Name: ""}}}, succeed: false},
		},
		{
			name: "add cluster secret not exists",
			fields: fields{
				client:            clientsetfake.NewSimpleClientset(),
				clusterMap:        map[string]*clusterv1alpha1.Cluster{},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			args: args{obj: &clusterv1alpha1.Cluster{ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"}, Spec: clusterv1alpha1.ClusterSpec{SecretRef: &clusterv1alpha1.LocalSecretReference{
				Namespace: "default",
				Name:      "secret",
			}}}, succeed: false},
		},
		{
			name: "add cluster secret exists but kubeConfig is empty",
			fields: fields{
				client:            c1,
				clusterMap:        map[string]*clusterv1alpha1.Cluster{},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			args: args{obj: &clusterv1alpha1.Cluster{ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"}, Spec: clusterv1alpha1.ClusterSpec{SecretRef: &clusterv1alpha1.LocalSecretReference{
				Namespace: "default",
				Name:      "secret",
			}}}, succeed: false},
		},
		{
			name: "add cluster secret exists but kubeConfig can't be connected",
			fields: fields{
				client:            c2,
				clusterMap:        map[string]*clusterv1alpha1.Cluster{},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			args: args{obj: &clusterv1alpha1.Cluster{ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"}, Spec: clusterv1alpha1.ClusterSpec{SecretRef: &clusterv1alpha1.LocalSecretReference{
				Namespace: "default",
				Name:      "secret",
			}}}, succeed: false},
		},
		{
			name: "add cluster succeed",
			fields: fields{
				client:            c3,
				clusterMap:        map[string]*clusterv1alpha1.Cluster{},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			args: args{obj: &clusterv1alpha1.Cluster{ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"}, Spec: clusterv1alpha1.ClusterSpec{SecretRef: &clusterv1alpha1.LocalSecretReference{
				Namespace: "default",
				Name:      "secret",
			}}}, succeed: false},
		},
		{
			name: "add cluster  but get ClientConfig failed",
			fields: fields{
				client:            c4,
				clusterMap:        map[string]*clusterv1alpha1.Cluster{},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			args: args{obj: &clusterv1alpha1.Cluster{ObjectMeta: metav1.ObjectMeta{Name: "cluster-1"}, Spec: clusterv1alpha1.ClusterSpec{SecretRef: &clusterv1alpha1.LocalSecretReference{
				Namespace: "default",
				Name:      "secret",
			}}}, succeed: false},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			c.addCluster(tt.args.obj.(*clusterv1alpha1.Cluster))
			cluster, _ := c.Get(tt.args.obj.(*clusterv1alpha1.Cluster).Name)
			if tt.args.succeed {
				if cluster == nil {
					t.Errorf("addCluster() failed, got nil, want %v", cluster)
				}
			} else {
				if cluster != nil {
					t.Errorf("addCluster() failed, got %v, want nil", cluster)
				}
			}
		})
	}
}

func Test_clusterClients_GetClient(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		clusterName string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    kubernetes.Interface
		wantErr bool
	}{
		{
			name: "get client success",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {},
				},
			},
			wantErr: false,
		},
		{
			name: "innCluster not found",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
		{
			name: "cluster not ready",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
		{
			name: "cluster not exists",
			args: args{
				clusterName: "kpanda-global-cluster000",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			_, err := c.GetClient(tt.args.clusterName)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetClient() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestGetKubeSystemID(t *testing.T) {
	fc := clientsetfake.NewSimpleClientset()
	type args struct {
		ctx context.Context
		ns  *corev1.Namespace
	}
	tests := []struct {
		name    string
		args    args
		want    string
		wantErr bool
	}{
		{
			name: "namespace not found",
			args: args{
				ctx: context.TODO(),
			},
			wantErr: true,
		},
		{
			name: "get kubeSystem ID success",
			args: args{
				ctx: context.TODO(),
				ns: &corev1.Namespace{
					ObjectMeta: metav1.ObjectMeta{
						Name: "kube-system",
						UID:  "123456",
					},
				},
			},
			want: "123456",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ns := fc.CoreV1().Namespaces()
			if tt.args.ns != nil {
				ns.Create(context.TODO(), tt.args.ns, metav1.CreateOptions{})
			}
			got, err := GetKubeSystemID(tt.args.ctx, ns)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetKubeSystemID() error = %v, wantErr %v", err, tt.wantErr)
				return
			}

			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetKubeSystemID() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_clusterClients_GetGeneratedClient(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		clusterName string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    clusterclientset.Interface
		wantErr bool
	}{
		{
			name: "get generated client success",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {},
				},
			},
			wantErr: false,
		},
		{
			name: "innCluster not found",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
		{
			name: "cluster not ready",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
		{
			name: "cluster not exists",
			args: args{
				clusterName: "kpanda-global-cluster000",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			got, err := c.GetGeneratedClient(tt.args.clusterName)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetGeneratedClient() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetGeneratedClient() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_clusterClients_GetDynamicClient(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		clusterName string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    dynamic.Interface
		wantErr bool
	}{
		{
			name: "get dynamic client success",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {},
				},
			},
			wantErr: false,
		},
		{
			name: "innCluster not found",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
		{
			name: "cluster not ready",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
		{
			name: "cluster not exists",
			args: args{
				clusterName: "kpanda-global-cluster000",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			got, err := c.GetDynamicClient(tt.args.clusterName)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetDynamicClient() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetDynamicClient() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_clusterClients_GetSnapshotClient(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		clusterName string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *volumesnapshotv1.SnapshotV1Client
		wantErr bool
	}{
		{
			name: "get snapshot client success",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {},
				},
			},
			wantErr: false,
		},
		{
			name: "innCluster not found",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
		{
			name: "cluster not ready",
			args: args{
				clusterName: "kpanda-global-cluster",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
		{
			name: "cluster not exists",
			args: args{
				clusterName: "kpanda-global-cluster000",
			},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters:     map[string]*InnerCluster{},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			got, err := c.GetSnapshotClient(tt.args.clusterName)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetSnapshotClient() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetSnapshotClient() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_clusterClients_GetClusterByKubeSystemID(t *testing.T) {
	type args struct {
		ID string
	}
	tests := []struct {
		name   string
		fields clusterClients
		args   args
		want   string
	}{
		{
			name: "get cluster by KubeSystem ID success",
			args: args{
				ID: "test-uuid",
			},
			fields: clusterClients{
				RWMutex: sync.RWMutex{},
				client:  clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
							UID:       "test-uuid",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
							KubeSystemID: "test-uuid",
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {},
				},
			},
			want: "kpanda-global-cluster",
		},
		{
			name: "cluster status not have KubeSystemID field",
			args: args{
				ID: "test-uuid",
			},
			fields: clusterClients{
				RWMutex: sync.RWMutex{},
				client:  clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
							UID:       "test-uuid",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {},
				},
			},
			want: "",
		},
	}
	for i := 0; i < len(tests); i++ {
		t.Run(tests[i].name, func(t *testing.T) {
			if got := tests[i].fields.GetClusterByKubeSystemID(tests[i].args.ID); got != tests[i].want {
				t.Errorf("GetClusterByKubeSystemID() = %v, want %v", got, tests[i].want)
			}
		})
	}
}

func Test_clusterClients_GetAllClusterClient(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	tests := []struct {
		name    string
		fields  fields
		want    map[string]kubernetes.Interface
		wantErr bool
	}{
		{
			name: "get all clientSet success",
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
							UID:       "test-uuid",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
							KubeSystemID: "test-uuid",
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {
						KubeClient: nil,
					},
				},
			},
			want: map[string]kubernetes.Interface{
				"kpanda-global-cluster": nil,
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			got, err := c.GetAllClusterClient()
			if (err != nil) != tt.wantErr {
				t.Errorf("GetAllClusterClient() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetAllClusterClient() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_clusterClients_GetClientSet(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		cluster string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			name: "innCluster not found",
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
							UID:       "test-uuid",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
							KubeSystemID: "test-uuid",
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {
						KubeClient: nil,
					},
				},
			},
			wantErr: true,
		},
		{
			name: "get clientSet success",
			args: args{cluster: "kpanda-global-cluster"},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
							UID:       "test-uuid",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
							KubeSystemID: "test-uuid",
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {
						KubeClient: clientsetfake.NewSimpleClientset(),
					},
				},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			_, err := c.GetClientSet(tt.args.cluster)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetClientSet() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func Test_clusterClients_GetCustomMetricsClient(t *testing.T) {
	type fields struct {
		client            kubernetes.Interface
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		cluster string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			name: "innCluster not found",
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
							UID:       "test-uuid",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
							KubeSystemID: "test-uuid",
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {
						KubeClient: nil,
					},
				},
			},
			wantErr: true,
		},
		{
			name: "get custom metrics client succeeded",
			args: args{cluster: "kpanda-global-cluster"},
			fields: fields{
				client: clientsetfake.NewSimpleClientset(),
				clusterMap: map[string]*clusterv1alpha1.Cluster{
					"kpanda-global-cluster": {
						ObjectMeta: metav1.ObjectMeta{
							Name:      "kpanda-global-cluster",
							Namespace: "kpanda-system",
							UID:       "test-uuid",
						},
						Status: clusterv1alpha1.ClusterStatus{
							Conditions: []clusterv1alpha1.ClusterCondition{
								{
									Type:   clusterv1alpha1.ClusterConditionRunning,
									Status: metav1.ConditionTrue,
								},
							},
							KubeSystemID: "test-uuid",
						},
					},
				},
				clusterKubeConfig: map[string]string{},
				innerClusters: map[string]*InnerCluster{
					"kpanda-global-cluster": {
						KubeClient: clientsetfake.NewSimpleClientset(),
					},
				},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				RWMutex:           sync.RWMutex{},
				client:            tt.fields.client,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			_, err := c.GetCustomMetricsClient(tt.args.cluster)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetCustomMetricsClient() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func Test_clusterClients_newInnerCluster(t *testing.T) {
	apiEnablements := []clusterv1alpha1.APIEnablement{
		{
			GroupVersion: "",
			Resources: []*clusterv1alpha1.APIResource{
				{
					Name: "pods",
					Kind: "Pod",
				},
			},
		},
	}

	client := clientsetfake.NewSimpleClientset()
	client.CoreV1().Secrets(util.GetCurrentNSOrDefault()).Create(context.Background(), &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name: "empty-secret",
		},
	}, metav1.CreateOptions{})

	client.CoreV1().Secrets(util.GetCurrentNSOrDefault()).Create(context.Background(), &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name: "invalid-secret",
		},
		Data: map[string][]byte{"kubeconfig": []byte("invalid")},
	}, metav1.CreateOptions{})

	client.CoreV1().Secrets(util.GetCurrentNSOrDefault()).Create(context.Background(), &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name: "valid-secret",
		},
		Data: map[string][]byte{"kubeconfig": []byte(testConfigToken)},
	}, metav1.CreateOptions{})

	type fields struct {
		client            kubernetes.Interface
		listers           clusterv1alpha1listers.ClusterLister
		clusterMap        map[string]*clusterv1alpha1.Cluster
		clusterKubeConfig map[string]string
		innerClusters     map[string]*InnerCluster
	}
	type args struct {
		cluster *clusterv1alpha1.Cluster
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *InnerCluster
		wantErr bool
	}{
		{
			name:   "apiEnablements is empty",
			fields: fields{},
			args: args{
				cluster: &clusterv1alpha1.Cluster{},
			},
			want:    nil,
			wantErr: true,
		},
		{
			name:   "apiEndpoint is invalid",
			fields: fields{},
			args: args{
				cluster: &clusterv1alpha1.Cluster{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec: clusterv1alpha1.ClusterSpec{
						APIEndpoint: "invalid",
					},
					Status: clusterv1alpha1.ClusterStatus{
						APIEnablements: apiEnablements,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
		{
			name:   "secret ref is nil",
			fields: fields{},
			args: args{
				cluster: &clusterv1alpha1.Cluster{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef:   nil,
						APIEndpoint: "http://foo.bar",
					},
					Status: clusterv1alpha1.ClusterStatus{
						APIEnablements: apiEnablements,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
		{
			name:   "secret name is empty",
			fields: fields{},
			args: args{
				cluster: &clusterv1alpha1.Cluster{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef:   &clusterv1alpha1.LocalSecretReference{},
						APIEndpoint: "http://foo.bar",
					},
					Status: clusterv1alpha1.ClusterStatus{
						APIEnablements: apiEnablements,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
		{
			name: "secret not found",
			fields: fields{
				client: client,
			},
			args: args{
				cluster: &clusterv1alpha1.Cluster{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace: util.GetCurrentNSOrDefault(),
							Name:      "not-found-cluster",
						},
						APIEndpoint: "http://foo.bar",
					},
					Status: clusterv1alpha1.ClusterStatus{
						APIEnablements: apiEnablements,
					},
				},
			},
			wantErr: true,
		},
		{
			name: "secret data is empty",
			fields: fields{
				client: client,
			},
			args: args{
				cluster: &clusterv1alpha1.Cluster{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace: util.GetCurrentNSOrDefault(),
							Name:      "empty-secret",
						},
						APIEndpoint: "http://foo.bar",
					},
					Status: clusterv1alpha1.ClusterStatus{
						APIEnablements: apiEnablements,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
		{
			name: "kubeconfig is invalid",
			fields: fields{
				client: client,
			},
			args: args{
				cluster: &clusterv1alpha1.Cluster{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace: util.GetCurrentNSOrDefault(),
							Name:      "invalid-secret",
						},
						APIEndpoint: "http://foo.bar",
					},
					Status: clusterv1alpha1.ClusterStatus{
						APIEnablements: apiEnablements,
					},
				},
			},
			want:    nil,
			wantErr: true,
		},
		{
			name: "kubeconfig is valid but get clientset failed",
			fields: fields{
				client: client,
			},
			args: args{
				cluster: &clusterv1alpha1.Cluster{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace: util.GetCurrentNSOrDefault(),
							Name:      "valid-secret",
						},
						APIEndpoint: "http://foo.bar",
					},
					Status: clusterv1alpha1.ClusterStatus{
						APIEnablements: apiEnablements,
					},
				},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clusterClients{
				client:            tt.fields.client,
				listers:           tt.fields.listers,
				clusterMap:        tt.fields.clusterMap,
				clusterKubeConfig: tt.fields.clusterKubeConfig,
				innerClusters:     tt.fields.innerClusters,
			}
			got, err := c.newInnerCluster(tt.args.cluster)
			if err != nil {
				if !tt.wantErr {
					t.Errorf("newInnerCluster() error = %v, wantErr %v", err, tt.wantErr)
				}
				return
			}

			assert.NotEmpty(t, got)
		})
	}
}
