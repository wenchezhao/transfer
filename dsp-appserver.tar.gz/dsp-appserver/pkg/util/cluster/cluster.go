package cluster

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

const (
	// NamespaceClusterLease is the namespace which cluster lease are stored.
	NamespaceClusterLease = "karmada-cluster"
)

var ClusterGVR = schema.GroupVersionResource{Group: "cluster.karmada.io", Version: "v1alpha1", Resource: "clusters"}

// ListClusters list all cluster of karmada cluster
func ListClusters(controlPlaneClient clientset.Interface, labelSelector string) (*ClusterList, error) {
	clusterObjs, err := controlPlaneClient.Resource(ClusterGVR).List(context.TODO(), metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		return nil, err
	}
	var clusters ClusterList
	for _, obj := range clusterObjs.Items {
		cluster, err := UnstructuredToCluster(&obj)
		if err != nil {
			return nil, err
		}
		clusters.Items = append(clusters.Items, *cluster)
	}

	clusters.APIVersion = "v1"
	clusters.Kind = "List"
	return &clusters, nil
}

// CreateClusterObject create cluster object in karmada control plane
func CreateClusterObject(controlPlaneClient clientset.Interface, cluster *Cluster) (*Cluster, error) {
	clusterObj, err := ClusterToUnstructured(cluster)
	if err != nil {
		return nil, err
	}
	obj, err := controlPlaneClient.Resource(ClusterGVR).Create(context.TODO(), clusterObj, metav1.CreateOptions{})
	if err != nil {
		return nil, err
	}

	return UnstructuredToCluster(obj)
}

func ClusterToUnstructured(cluster *Cluster) (*unstructured.Unstructured, error) {
	resBytes, err := json.Marshal(cluster)
	if err != nil {
		return nil, err
	}
	obj := &unstructured.Unstructured{}
	if err := json.Unmarshal(resBytes, obj); err != nil {
		return nil, err
	}
	return obj, nil
}

func UnstructuredToCluster(obj *unstructured.Unstructured) (*Cluster, error) {
	resBytes, err := json.Marshal(obj)
	if err != nil {
		return nil, err
	}
	cluster := &Cluster{}
	if err := json.Unmarshal(resBytes, cluster); err != nil {
		return nil, err
	}
	cluster.APIVersion = fmt.Sprintf("%s/%s", ClusterGVR.Group, ClusterGVR.Version)
	cluster.Kind = GetGroupVersionKindWithKind("Cluster").Kind
	return cluster, nil
}

func GetGroupVersionKindWithKind(kind string) schema.GroupVersionKind {
	return schema.GroupVersionKind{
		Group:   ClusterGVR.Group,
		Version: ClusterGVR.Version,
		Kind:    kind,
	}
}
