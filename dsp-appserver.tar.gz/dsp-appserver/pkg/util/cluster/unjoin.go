package cluster

import (
	"context"

	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	kubeclient "k8s.io/client-go/kubernetes"

	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
)

type UnJoinOptions struct {
	ControlPlaneKubeClient clientset.Interface
	ClusterKubeClient      clientset.Interface
	Name                   string `json:"name"`
	Namespace              string `json:"namespace"`
}

// UnJoinCluster unJoin the cluster from karmada.
func (o *UnJoinOptions) UnJoinCluster() (err error) {

	// delete the cluster object in host cluster that associates the unjoining cluster
	err = deleteClusterObject(o.ControlPlaneKubeClient, o.Name)
	if err != nil {
		//klog.Errorf("Failed to delete cluster object. cluster name: %s, error: %v", opts.ClusterName, err)
		return err
	}

	// Attempt to delete the cluster role, cluster rolebindings and service account from the unjoining cluster
	// if user provides the kubeconfig of cluster

	//klog.V(1).Infof("unjoining cluster config. endpoint: %s", clusterConfig.Host)

	// delete RBAC resource from unjoining cluster
	//err = deleteRBACResources(o.ClusterKubeClient, o.Name)
	//if err != nil {
	//	//klog.Errorf("Failed to delete RBAC resource in unjoining cluster %q: %v", opts.ClusterName, err)
	//	return err
	//}

	// delete service account from unjoining cluster
	//err = deleteServiceAccount(o.ClusterKubeClient, o.Namespace, o.Name)
	//if err != nil {
	//	//klog.Errorf("Failed to delete service account in unjoining cluster %q: %v", opts.ClusterName, err)
	//	return err
	//}

	// delete namespace from unjoining cluster
	//err = deleteNamespaceFromUnjoinCluster(o.ClusterKubeClient, o.Namespace, o.Name)
	//if err != nil {
	//	//klog.Errorf("Failed to delete namespace in unjoining cluster %q: %v", opts.ClusterName, err)
	//	return err
	//}

	return nil
}

// deleteRBACResources deletes the cluster role, cluster rolebindings from the unjoining cluster.
func deleteRBACResources(clusterKubeClient kubeclient.Interface, unjoiningClusterName string) error {

	serviceAccountName := GenerateServiceAccountName(unjoiningClusterName)
	clusterRoleName := GenerateRoleName(serviceAccountName)
	clusterRoleBindingName := clusterRoleName

	err := DeleteClusterRoleBinding(clusterKubeClient, clusterRoleBindingName)
	if err != nil {
		return err
	}

	err = DeleteClusterRole(clusterKubeClient, clusterRoleName)
	if err != nil {
		return err
	}

	return nil
}

// deleteServiceAccount deletes the service account from the unjoining cluster.
func deleteServiceAccount(clusterKubeClient kubeclient.Interface, namespace, unjoiningClusterName string) error {
	serviceAccountName := GenerateServiceAccountName(unjoiningClusterName)
	err := DeleteServiceAccount(clusterKubeClient, namespace, serviceAccountName)
	if err != nil {
		return err
	}

	return nil
}

// deleteNSFromUnjoinCluster deletes the namespace from the unjoining cluster.
func deleteNamespaceFromUnjoinCluster(clusterKubeClient clientset.Interface, namespace, unjoiningClusterName string) error {

	err := DeleteNamespace(clusterKubeClient, namespace)
	if err != nil {
		return err
	}

	return nil
}

// deleteClusterObject delete the cluster object in host cluster that associates the unjoining cluster
func deleteClusterObject(controlPlaneKarmadaClient clientset.Interface, name string) error {

	err := controlPlaneKarmadaClient.Resource(ClusterGVR).Delete(context.TODO(), name, metav1.DeleteOptions{})
	if apierrors.IsNotFound(err) {
		return nil
	}
	if err != nil {
		//klog.Errorf("Failed to delete cluster object. cluster name: %s, error: %v", opts.ClusterName, err)
		return err
	}

	return nil
}
