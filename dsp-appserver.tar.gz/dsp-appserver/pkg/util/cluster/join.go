package cluster

import (
	"fmt"
	"strings"

	corev1 "k8s.io/api/core/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	kubeclient "k8s.io/client-go/kubernetes"

	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
)

var (
	ClusterTypeLabelkey      = "ccnp.cib/cluster-type"
	ClusterNameAnnotationKey = "ccnp.cib/display-name"
	GrafanaAnnotationKey     = "ccnp.cib/grafana"
)

type JoinOptions struct {
	ControlPlaneKubeClient clientset.Interface
	ClusterKubeClient      clientset.Interface
	Namespace              string `json:"namespace,omitempty"`
	Provider               string `json:"provider,omitempty"`    // 供应商
	Region                 string `json:"region,omitempty"`      // 地域
	Zone                   string `json:"zone,omitempty"`        // 可用区
	DisplayName            string `json:"displayName,omitempty"` // 可用区名称
	Name                   string `json:"name,omitempty"`        // 可用区编码
	Type                   string `json:"type,omitempty"`        // 可用区编码
	Grafana                string `json:"grafana,omitempty"`     // grafana
	MasterUrl              string `json:"url,omitempty"`         // apiserver url
}

var (
	// Policy rules allowing full access to resources in the cluster or namespace.
	namespacedPolicyRules = []rbacv1.PolicyRule{
		{
			Verbs:     []string{rbacv1.VerbAll},
			APIGroups: []string{rbacv1.APIGroupAll},
			Resources: []string{rbacv1.ResourceAll},
		},
	}
	clusterPolicyRules = []rbacv1.PolicyRule{
		namespacedPolicyRules[0],
		{
			NonResourceURLs: []string{rbacv1.NonResourceAll},
			Verbs:           []string{"get"},
		},
	}
)

// JoinCluster join the cluster into karmada.
func (o *JoinOptions) JoinCluster() (*Cluster, error) {

	//klog.V(1).Infof("joining cluster config. endpoint: %s", clusterConfig.Host)

	// ensure namespace where the cluster object be stored exists in control plane.
	if _, err := EnsureNamespaceExist(o.ControlPlaneKubeClient, o.Namespace); err != nil {
		return nil, err
	}

	clusterSecret, impersonatorSecret, err := obtainCredentialsFromMemberCluster(o.ClusterKubeClient, o.Namespace, o.Name)
	if err != nil {
		return nil, err
	}

	cluster, err := registerClusterInControllerPlane(o, o.ControlPlaneKubeClient, clusterSecret, impersonatorSecret)
	if err != nil {
		return nil, err
	}

	fmt.Printf("cluster(%s) is joined successfully\n", o.Name)
	return cluster, nil
}

func obtainCredentialsFromMemberCluster(clusterKubeClient clientset.Interface, clusterNamespace, clusterName string) (*corev1.Secret, *corev1.Secret, error) {
	var err error

	// ensure namespace where the karmada control plane credential be stored exists in cluster.
	if _, err = EnsureNamespaceExist(clusterKubeClient, clusterNamespace); err != nil {
		return nil, nil, err
	}

	// create a ServiceAccount in cluster.
	serviceAccountObj := &corev1.ServiceAccount{}
	serviceAccountObj.Namespace = clusterNamespace
	serviceAccountObj.Name = GenerateServiceAccountName(clusterName)
	if serviceAccountObj, err = EnsureServiceAccountExist(clusterKubeClient, serviceAccountObj); err != nil {
		return nil, nil, err
	}

	// create a ServiceAccount for impersonation in cluster.
	impersonationSA := &corev1.ServiceAccount{}
	impersonationSA.Namespace = clusterNamespace
	impersonationSA.Name = GenerateServiceAccountName("impersonator")
	if impersonationSA, err = EnsureServiceAccountExist(clusterKubeClient, impersonationSA); err != nil {
		return nil, nil, err
	}

	// create a ClusterRole in cluster.
	clusterRole := &rbacv1.ClusterRole{}
	clusterRole.Name = GenerateRoleName(serviceAccountObj.Name)
	clusterRole.Rules = clusterPolicyRules
	if _, err = ensureClusterRoleExist(clusterKubeClient, clusterRole); err != nil {
		return nil, nil, err
	}

	// create a ClusterRoleBinding in cluster.
	clusterRoleBinding := &rbacv1.ClusterRoleBinding{}
	clusterRoleBinding.Name = clusterRole.Name
	clusterRoleBinding.Subjects = buildRoleBindingSubjects(serviceAccountObj.Name, serviceAccountObj.Namespace)
	clusterRoleBinding.RoleRef = buildClusterRoleReference(clusterRole.Name)
	if _, err = ensureClusterRoleBindingExist(clusterKubeClient, clusterRoleBinding); err != nil {
		return nil, nil, err
	}

	clusterSecret, err := WaitForServiceAccountSecretCreation(clusterKubeClient, serviceAccountObj)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get serviceAccount secret from cluster(%s), error: %v", clusterName, err)
	}

	impersonatorSecret, err := WaitForServiceAccountSecretCreation(clusterKubeClient, impersonationSA)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get serviceAccount secret for impersonation from cluster(%s), error: %v", clusterName, err)
	}

	return clusterSecret, impersonatorSecret, nil
}

func registerClusterInControllerPlane(opts *JoinOptions, controlPlaneKubeClient clientset.Interface, clusterSecret, clusterImpersonatorSecret *corev1.Secret) (*Cluster, error) {
	// create secret in control plane
	secret := &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: opts.Namespace,
			Name:      opts.Name,
		},
		Data: map[string][]byte{
			SecretCADataKey: clusterSecret.Data["ca.crt"],
			SecretTokenKey:  clusterSecret.Data[SecretTokenKey],
		},
	}

	secret, err := CreateSecret(controlPlaneKubeClient, secret)
	if err != nil {
		return nil, fmt.Errorf("failed to create secret in control plane. error: %v", err)
	}

	// create secret to store impersonation info in control plane
	impersonatorSecret := &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: opts.Namespace,
			Name:      GenerateImpersonationSecretName(opts.Name),
		},
		Data: map[string][]byte{
			SecretTokenKey: clusterImpersonatorSecret.Data[SecretTokenKey],
		},
	}

	impersonatorSecret, err = CreateSecret(controlPlaneKubeClient, impersonatorSecret)
	if err != nil {
		return nil, fmt.Errorf("failed to create impersonator secret in control plane. error: %v", err)
	}

	cluster, err := generateClusterInControllerPlane(controlPlaneKubeClient, opts, *secret, *impersonatorSecret)
	if err != nil {
		return nil, err
	}

	// add OwnerReference for secrets.
	patchSecretBody := &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			OwnerReferences: []metav1.OwnerReference{
				*metav1.NewControllerRef(cluster, GetGroupVersionKindWithKind("Cluster")),
			},
		},
	}

	err = PatchSecret(controlPlaneKubeClient, secret.Namespace, secret.Name, types.MergePatchType, patchSecretBody)
	if err != nil {
		return nil, fmt.Errorf("failed to patch secret %s/%s, error: %v", secret.Namespace, secret.Name, err)
	}

	err = PatchSecret(controlPlaneKubeClient, impersonatorSecret.Namespace, impersonatorSecret.Name, types.MergePatchType, patchSecretBody)
	if err != nil {
		return nil, fmt.Errorf("failed to patch impersonator secret %s/%s, error: %v", impersonatorSecret.Namespace, impersonatorSecret.Name, err)
	}

	return cluster, nil
}

func generateClusterInControllerPlane(controlPlaneKarmadaClient clientset.Interface, opts *JoinOptions, secret, impersonatorSecret corev1.Secret) (*Cluster, error) {
	clusterObj := &Cluster{}
	clusterObj.Kind = GetGroupVersionKindWithKind("Cluster").Kind
	clusterObj.APIVersion = fmt.Sprintf("%s/%s", ClusterGVR.Group, ClusterGVR.Version)
	clusterObj.Name = opts.Name
	clusterObj.Spec.SyncMode = Push
	clusterObj.Spec.APIEndpoint = opts.MasterUrl
	clusterObj.Spec.SecretRef = &LocalSecretReference{
		Namespace: secret.Namespace,
		Name:      secret.Name,
	}
	clusterObj.Spec.ImpersonatorSecretRef = &LocalSecretReference{
		Namespace: impersonatorSecret.Namespace,
		Name:      impersonatorSecret.Name,
	}
	clusterObj.Labels = map[string]string{
		ClusterTypeLabelkey: fmt.Sprintf("%s", opts.Type),
	}

	clusterObj.Annotations = map[string]string{
		ClusterNameAnnotationKey: opts.DisplayName,
		GrafanaAnnotationKey:     buildGrafanaHost(opts.Grafana),
	}

	if opts.Provider != "" {
		clusterObj.Spec.Provider = opts.Provider
	}
	if opts.Region != "" {
		clusterObj.Spec.Region = opts.Region
	}
	if opts.Zone != "" {
		clusterObj.Spec.Zone = opts.Zone
	}

	cluster, err := CreateClusterObject(controlPlaneKarmadaClient, clusterObj)
	if err != nil {
		return nil, fmt.Errorf("failed to create cluster(%s) object. error: %v", opts.Name, err)
	}

	return cluster, nil
}

// ensureClusterRoleExist makes sure that the specific cluster role exist in cluster.
// If cluster role not exit, just create it.
func ensureClusterRoleExist(client clientset.Interface, clusterRole *rbacv1.ClusterRole) (*rbacv1.ClusterRole, error) {

	exist, err := IsClusterRoleExist(client, clusterRole.Name)
	if err != nil {
		return nil, fmt.Errorf("failed to check if ClusterRole exist. ClusterRole: %s, error: %v", clusterRole.Name, err)
	}
	if exist {
		//klog.V(1).Infof("ensure ClusterRole succeed as already exist. ClusterRole: %s", clusterRole.Name)
		return clusterRole, nil
	}

	createdObj, err := CreateClusterRole(client, clusterRole)
	if err != nil {
		return nil, fmt.Errorf("ensure ClusterRole failed due to create failed. ClusterRole: %s, error: %v", clusterRole.Name, err)
	}

	return createdObj, nil
}

// ensureClusterRoleBindingExist makes sure that the specific ClusterRoleBinding exist in cluster.
// If ClusterRoleBinding not exit, just create it.
func ensureClusterRoleBindingExist(client kubeclient.Interface, clusterRoleBinding *rbacv1.ClusterRoleBinding) (*rbacv1.ClusterRoleBinding, error) {

	exist, err := IsClusterRoleBindingExist(client, clusterRoleBinding.Name)
	if err != nil {
		return nil, fmt.Errorf("failed to check if ClusterRole exist. ClusterRole: %s, error: %v", clusterRoleBinding.Name, err)
	}
	if exist {
		//klog.V(1).Infof("ensure ClusterRole succeed as already exist. ClusterRole: %s", clusterRoleBinding.Name)
		return clusterRoleBinding, nil
	}

	createdObj, err := CreateClusterRoleBinding(client, clusterRoleBinding)
	if err != nil {
		return nil, fmt.Errorf("ensure ClusterRole failed due to create failed. ClusterRole: %s, error: %v", clusterRoleBinding.Name, err)
	}

	return createdObj, nil
}

// buildRoleBindingSubjects will generate a subject as per service account.
// The subject used by RoleBinding or ClusterRoleBinding.
func buildRoleBindingSubjects(serviceAccountName, serviceAccountNamespace string) []rbacv1.Subject {
	return []rbacv1.Subject{
		{
			Kind:      rbacv1.ServiceAccountKind,
			Name:      serviceAccountName,
			Namespace: serviceAccountNamespace,
		},
	}
}

// buildClusterRoleReference will generate a ClusterRole reference.
func buildClusterRoleReference(roleName string) rbacv1.RoleRef {
	return rbacv1.RoleRef{
		APIGroup: rbacv1.GroupName,
		Kind:     "ClusterRole",
		Name:     roleName,
	}
}

//  build grafana host
func buildGrafanaHost(url string) string {
	url = strings.Replace(url, "https://", "", -1)
	url = strings.Replace(url, "http://", "", -1)
	return strings.Replace(url, "/", "", -1)
}
