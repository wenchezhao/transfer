package cluster

import "testing"

func Test_buildGrafanaHost(t *testing.T) {
	type args struct {
		url string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		// TODO: Add test cases.
		{name: "case1", args: args{url: "https://www.ccnp.cibt"}, want: "www.ccnp.cibt"},
		{name: "case2", args: args{url: "http://www.ccnp.cibt"}, want: "www.ccnp.cibt"},
		{name: "case3", args: args{url: "http://www.ccnp.cibt/"}, want: "www.ccnp.cibt"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := buildGrafanaHost(tt.args.url); got != tt.want {
				t.Errorf("buildGrafanaHost() = %v, want %v", got, tt.want)
			}
		})
	}
}
