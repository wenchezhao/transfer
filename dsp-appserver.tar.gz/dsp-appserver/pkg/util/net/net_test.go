package net

import (
	"testing"
)

func TestCheckLocalPortAvailable(t *testing.T) {
	type args struct {
		port int
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "port is available",
			args: args{
				port: 80,
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := CheckLocalPortAvailable(tt.args.port); got != tt.want {
				t.Errorf("CheckLocalPortAvailable() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestIsValidPort(t *testing.T) {
	type args struct {
		port int
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "port is invalid",
			args: args{
				port: -1,
			},
			want: false,
		},
		{
			name: "port is valid",
			args: args{
				port: 80,
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := IsValidPort(tt.args.port); got != tt.want {
				t.Errorf("IsValidPort() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestValidateIPAddress(t *testing.T) {
	if ret, err := ValidateIPAddress(`1.2.3.4`); err != nil || ret == "" {
		t.Fatalf("ValidateIPAddress(`1.2.3.4`) got %s %s", ret, err)
	}

	if ret, err := ValidateIPAddress(`127.0.0.1`); err != nil || ret == "" {
		t.Fatalf("ValidateIPAddress(`127.0.0.1`) got %s %s", ret, err)
	}

	if ret, err := ValidateIPAddress(`::1`); err != nil || ret == "" {
		t.Fatalf("ValidateIPAddress(`::1`) got %s %s", ret, err)
	}

	if ret, err := ValidateIPAddress(`127`); err == nil || ret != "" {
		t.Fatalf("ValidateIPAddress(`127`) got %s %s", ret, err)
	}

	if ret, err := ValidateIPAddress(`random invalid string`); err == nil || ret != "" {
		t.Fatalf("ValidateIPAddress(`random invalid string`) got %s %s", ret, err)
	}
}

func TestValidateDomain(t *testing.T) {
	tests := []struct {
		s  string
		ok bool
	}{
		// allow domains
		{"example.com", true},
		{"www.example.com", true},
		{"com.", true},
		{"0x0f.example.com", true},

		// disallow ports, paths, protocols, and other junk
		{"example.com:8080", false},
		{"www.example.com:8080", false},
		{"http://example.com", false},
		{"example.com/", false},
		{"example.com/123", false},
		{"example.com?a=b", false},
		{"example.com#2", false},
		{"http://http://", false},
		{"http://http://example.com", false},
		{"http://http:/example.com", false},
		{"http://ht$%$&$tp:/example.com", false},

		// disallow ips, even when weirdly formatted
		{"8.8.8.8", false},
		{"8.8.8.8.", false},
		{"8.8.8.00008", false},
		{"8.8.8.", false},
		{"8.8.8.8/24", false},
		{"8.8.8/24", false},
		{"8.", false},
		{"8", false},
		{"8.8.8", false},
		{"2001:db8:a0b:12f0::1", false},
		{"::21", false},
		{":21:", false},
		{":21:", false},
		{"2001:db8:a0b:12f0::1%eth0", false},
		{"[2001:db8:a0b:12f0::1]:21", false},
	}

	for i, test := range tests {
		ans := ValidateDomain(test.s)
		if ans != test.ok {
			t.Fatalf("%v mismatch: %v\ngot      : %v\nexpected : %v\n", i, test.s, ans, test.ok)
		}
	}
}

func TestParseImageRepo(t *testing.T) {
	type args struct {
		r string
	}
	tests := []struct {
		name    string
		args    args
		want    string
		wantErr bool
	}{
		{
			name: "url is valid",
			args: args{
				r: "10.6.109.6:9000/registry.k8s.io",
			},
			want:    "10.6.109.6:9000/registry.k8s.io",
			wantErr: false,
		},
		{
			name: "url is invalid",
			args: args{
				r: "invalid url",
			},
			want:    "",
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ParseImageRepo(tt.args.r)
			if (err != nil) != tt.wantErr {
				t.Errorf("ParseImageRepo() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("ParseImageRepo() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestParseOfflineRepo(t *testing.T) {
	type args struct {
		r      string
		scheme string
	}
	tests := []struct {
		name    string
		args    args
		want    string
		wantErr bool
	}{
		{
			name: "url is valid",
			args: args{
				r:      "http://test.io/foo/bar",
				scheme: "http",
			},
			want:    "http://test.io",
			wantErr: false,
		},
		{
			name: "no scheme in url",
			args: args{
				r:      "test.io/foo/bar",
				scheme: "https",
			},
			want:    "https://test.io",
			wantErr: false,
		},
		{
			name: "url is invalid",
			args: args{
				r:      "invalid url",
				scheme: "https",
			},
			want:    "",
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ParseOfflineRepo(tt.args.r, tt.args.scheme)
			if (err != nil) != tt.wantErr {
				t.Errorf("ParseOfflineRepo() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("ParseOfflineRepo() got = %v, want %v", got, tt.want)
			}
		})
	}
}
