/*
Copyright 2022 The Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package net

import (
	"fmt"
	netlib "net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

var hasalpha = regexp.MustCompile(`\D`)

// 0 is considered as a non valid port.
func IsValidPort(port int) bool {
	return port > 0 && port < 65535
}

func CheckLocalPortAvailable(port int) bool {
	conn, _ := netlib.DialTimeout("tcp", netlib.JoinHostPort("127.0.0.1", fmt.Sprintf("%d", port)), time.Second*5)
	if conn != nil {
		defer conn.Close()
		return false // this port is opened.
	}
	return true
}

// validateIPAddress validates an Ip address.
// for dns, ip, and ip6 flags also.
func ValidateIPAddress(val string) (string, error) {
	ip := netlib.ParseIP(strings.TrimSpace(val))
	if ip != nil {
		return ip.String(), nil
	}
	return "", fmt.Errorf("%s is not an ip address", val)
}

func ValidateDomain(s string) bool {
	// Throw a protocol in front because the parser wants one.
	proto := "http"
	u, err := url.Parse(proto + "://" + s)
	if err != nil {
		return false
	}

	// The final group must include a non-numeric character.
	// To disallow the likes of "8.8.8.8."
	dotsplit := strings.Split(strings.TrimSuffix(u.Host, "."), ".")
	if len(dotsplit) > 0 {
		group := dotsplit[len(dotsplit)-1]
		if !hasalpha.MatchString(group) {
			return false
		}
	}

	ok := (u.IsAbs()) &&
		(u.Scheme == proto) &&
		(u.User == nil) &&
		(u.Path == "") &&
		(u.RawPath == "") &&
		(u.RawQuery == "") &&
		(u.Fragment == "") &&
		// Disallow colons. So no port, and no ipv6.
		(!strings.Contains(u.Host, ":")) &&
		// Disallow any valid ip addresses.
		(netlib.ParseIP(u.Host) == nil)
	return ok
}

// ParseOfflineRepo return a image repository. Example:
// r: ghcr.io/xxx:latest, scheme: https
// return: https://ghcr.io
func ParseOfflineRepo(r, scheme string) (string, error) {
	if !strings.HasPrefix(r, "http://") && !strings.HasPrefix(r, "https://") {
		r = fmt.Sprintf("%s://%s", scheme, r)
	}

	u, err := url.Parse(r)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("%s://%s", u.Scheme, u.Host), nil
}

// ParseImageRepo returns a image url without scheme. Example:
// r: http://ghcr.xxxx/xxx:latest
// return: ghcr.xxxx/xxx:latest
func ParseImageRepo(r string) (string, error) {
	if !strings.HasPrefix(r, "http://") && !strings.HasPrefix(r, "https://") {
		r = fmt.Sprintf("http://%s", r)
	}
	u, err := url.Parse(r)
	if err != nil {
		return "", err
	}

	return fmt.Sprintf("%s%s", u.Host, u.Path), nil
}

func GetRedirectURL(URL string) string {
	c := &http.Client{
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
		Timeout: time.Second * 3,
	}
	u, err := url.Parse(URL)
	if err != nil {
		return URL
	}

	rsp, err := c.Do(&http.Request{
		Method: http.MethodGet,
		URL:    u,
		Header: map[string][]string{
			"User-Agent": {"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"},
		},
	})
	if err != nil {
		return URL
	}

	redirectURL := rsp.Header.Get("Location")
	if redirectURL != "" {
		return redirectURL
	}
	return URL
}
