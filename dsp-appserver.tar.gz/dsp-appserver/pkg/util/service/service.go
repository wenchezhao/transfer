package service

import (
	"context"
	"fmt"

	routeapi "github.com/openshift/api/route/v1"
	routeclient "github.com/openshift/client-go/route/clientset/versioned/typed/route/v1"
	extensionsv1beta1 "k8s.io/api/extensions/v1beta1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/client-go/kubernetes"

	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
)

const (
	RoutePortAnnotation = "haproxy.router.openshift.io/external-tcp-port"
)

// ListIngress return a set of ingress that its backends contain a given Service in a namespace
func ListIngress(client kubernetes.Interface, namespace, svcName string) ([]extensionsv1beta1.Ingress, error) {
	allIngs, err := client.ExtensionsV1beta1().Ingresses(namespace).List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return nil, err
	}
	filteredList := []extensionsv1beta1.Ingress{}
	for _, ing := range allIngs.Items {
		if ing.Spec.Backend != nil && ing.Spec.Backend.ServiceName == svcName {
			filteredList = append(filteredList, ing)
			continue
		}
	LOOPRULE:
		for _, rule := range ing.Spec.Rules {
			if rule.HTTP != nil {
				for _, path := range rule.HTTP.Paths {
					if path.Backend.ServiceName == svcName {
						filteredList = append(filteredList, ing)
						break LOOPRULE
					}
				}
			}
		}
	}
	for index := range filteredList {
		filteredList[index].TypeMeta = metav1.TypeMeta{
			APIVersion: "extensions/v1beta1",
			Kind:       "Ingress",
		}
	}
	return filteredList, nil
}

// ListRoute return a set of route that its backends contain a given Service in a namespace
func ListRoute(client routeclient.RouteV1Interface, namespace, svcName string) ([]routeapi.Route, error) {
	allRoutes, err := client.Routes(namespace).List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return nil, err
	}
	filteredList := []routeapi.Route{}
	for _, route := range allRoutes.Items {
		if route.Spec.To.Kind == "Service" && route.Spec.To.Name == svcName {
			filteredList = append(filteredList, route)
			continue
		}
		if len(route.Spec.AlternateBackends) > 0 {
			for _, backend := range route.Spec.AlternateBackends {
				if backend.Kind == "Service" && backend.Name == svcName {
					filteredList = append(filteredList, route)
					break
				}
			}
		}
	}
	for index := range filteredList {
		filteredList[index].TypeMeta = metav1.TypeMeta{
			APIVersion: "route.openshift.io/v1",
			Kind:       "Route",
		}
	}
	return filteredList, nil
}

// CheckServiceNodePort check service noePort
func CheckServiceNodePort(ctx context.Context, client clientset.Interface, port string) error {
	// 只需要判断是否有route使用了该端口，如果svc已经使用了kube-apiserver会报错
	version, err := client.ClusterVersion("")
	if err != nil {
		return err
	}

	if version.Type == clientset.OCP {
		routeList, err := client.OpenshiftRouteV1().Routes(metav1.NamespaceAll).List(ctx, metav1.ListOptions{})
		if err != nil {
			return err
		}
		for _, route := range routeList.Items {
			var l labels.Set
			l = route.Annotations
			if l.Get(RoutePortAnnotation) == port {
				return fmt.Errorf("nodePort %s conflict with route %s", port, route.Name)
			}
		}
	}

	return nil
}
