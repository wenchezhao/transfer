package util

import (
	"context"
	"fmt"
	"os"
	"reflect"
	"testing"
	"time"

	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util/gclient"
	"github.com/daocloud/dsp-appserver/pkg/util/maputil"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/rest"
	"sigs.k8s.io/controller-runtime/pkg/client"
	clientfake "sigs.k8s.io/controller-runtime/pkg/client/fake"
)

func TestIsClusterReady(t *testing.T) {
	type test struct {
		input *clusterv1alpha1.ClusterStatus
		want  bool
	}
	tests := []test{
		{
			input: &clusterv1alpha1.ClusterStatus{
				Conditions: []clusterv1alpha1.ClusterCondition{
					{
						Type:   clusterv1alpha1.ClusterConditionRunning,
						Status: metav1.ConditionTrue,
					},
				},
			},
			want: true,
		},
		{
			input: &clusterv1alpha1.ClusterStatus{
				Conditions: []clusterv1alpha1.ClusterCondition{
					{
						Type:   clusterv1alpha1.ClusterConditionRunning,
						Status: metav1.ConditionFalse,
					},
				},
			},
			want: false,
		},
	}
	for _, tc := range tests {
		got := IsClusterReady(tc.input)
		if got != tc.want {
			t.Errorf("expected:%v, got:%v", tc.want, got)
		}
	}
}

func TestGetCluster(t *testing.T) {
	fakeClient := newFakeClient()
	name := "cluster1"
	cluster := &clusterv1alpha1.Cluster{
		ObjectMeta: metav1.ObjectMeta{
			Name: name,
		},
	}
	type test struct {
		name    string
		args    string
		want    *clusterv1alpha1.Cluster
		wantErr bool
	}

	test0 := test{
		name:    "error",
		args:    name,
		want:    nil,
		wantErr: true,
	}
	test1 := test{
		name: "no error",
		args: name,
		want: &clusterv1alpha1.Cluster{
			TypeMeta: metav1.TypeMeta{
				Kind:       "Cluster",
				APIVersion: "cluster.kpanda.io/v1alpha1",
			},
			ObjectMeta: metav1.ObjectMeta{
				Name:            name,
				ResourceVersion: "1",
				CreationTimestamp: metav1.Time{
					Time: time.Date(1, time.January, 1, 0, 0, 0, 0, time.UTC),
				},
			},
		},
		wantErr: false,
	}

	t.Run(test0.name, func(t *testing.T) {
		got, err := GetCluster(fakeClient, test0.args)
		if (err != nil) != test0.wantErr {
			t.Errorf("GetCluster() error = %v, wantErr %v", err, test0.wantErr)
			return
		}
		if !reflect.DeepEqual(got, test0.want) {
			t.Errorf("GetCluster() got = %#v, want %#v", got, test0.want)
		}
	})

	_ = fakeClient.Create(context.TODO(), cluster)

	t.Run(test1.name, func(t *testing.T) {
		got, err := GetCluster(fakeClient, test1.args)
		if (err != nil) != test1.wantErr {
			t.Errorf("GetCluster() error = %v, wantErr %v", err, test1.wantErr)
			return
		}
		if !reflect.DeepEqual(got, test1.want) {
			t.Errorf("GetCluster() got = %#v, want %#v", got, test1.want)
		}
	})
}

func newFakeClient() client.Client {
	sch := gclient.NewSchema()
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		panic(err)
	}
	client := clientfake.NewClientBuilder().WithScheme(sch).WithRuntimeObjects(&clusterv1alpha1.Cluster{}).Build()
	return client
}

func TestLabelsConvert(t *testing.T) {
	type args struct {
		labels map[string]string
	}
	tests := []struct {
		name    string
		args    args
		want    interface{}
		wantErr bool
	}{
		{
			name: "no error",
			args: args{
				map[string]string{"test1": "test1"},
			},
			want:    []byte(`[{"op":"replace","path":"/metadata/labels","value":{"test1":"test1"}}]`),
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := LabelsConvert(tt.args.labels)
			if (err != nil) != tt.wantErr {
				t.Errorf("LabelsConvert() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("LabelsConvert() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestNodeTaintsConvert(t *testing.T) {
	type args struct {
		taints []*corev1.Taint
	}
	tests := []struct {
		name    string
		args    args
		want    interface{}
		wantErr bool
	}{
		{
			name: "no error",
			args: args{
				[]*corev1.Taint{
					{
						Key:    "node-role.kubernetes.io/master",
						Effect: corev1.TaintEffectNoSchedule,
					},
				},
			},
			want:    []byte(`[{"op":"replace","path":"/spec/taints","value":[{"key":"node-role.kubernetes.io/master","effect":"NoSchedule"}]}]`),
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := NodeTaintsConvert(tt.args.taints)
			if (err != nil) != tt.wantErr {
				t.Errorf("NodeTaintsConvert() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NodeTaintsConvert() got = %#v, want %#v", got, tt.want)
			}
		})
	}
}

func TestAnnotationsConvert(t *testing.T) {
	type args struct {
		labels map[string]string
	}
	tests := []struct {
		name    string
		args    args
		want    interface{}
		wantErr bool
	}{
		{
			name: "no error",
			args: args{
				map[string]string{"test1": "test1"},
			},
			want:    []byte(`[{"op":"replace","path":"/metadata/annotations","value":{"test1":"test1"}}]`),
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := AnnotationsConvert(tt.args.labels)
			if (err != nil) != tt.wantErr {
				t.Errorf("AnnotationsConvert() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("AnnotationsConvert() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestNodeScheduleConvert(t *testing.T) {
	type args struct {
		unschedulable bool
	}
	tests := []struct {
		name    string
		args    args
		want    interface{}
		wantErr bool
	}{
		{
			name: "no error",
			args: args{
				unschedulable: true,
			},
			want:    []byte(`[{"op":"replace","path":"/spec/unschedulable","value":true}]`),
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := NodeScheduleConvert(tt.args.unschedulable)
			if (err != nil) != tt.wantErr {
				t.Errorf("NodeScheduleConvert() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NodeScheduleConvert() got = %#v, want %#v", got, tt.want)
			}
		})
	}
}

func TestGetCurrentNS(t *testing.T) {
	env := "POD_NAMESPACE"
	type test struct {
		name    string
		want    string
		wantErr bool
	}

	test0 := test{
		name:    "env",
		want:    "gitlab",
		wantErr: false,
	}

	// Set the pod namesapce to env
	os.Setenv(env, "gitlab")

	t.Run(test0.name, func(t *testing.T) {
		got, err := GetCurrentNS()
		println("got:", got)
		if (err != nil) != test0.wantErr {
			t.Errorf("GetCurrentNS() error = %v, wantErr %v", err, test0.wantErr)
			return
		}
		if !reflect.DeepEqual(got, test0.want) {
			t.Errorf("GetCurrentNS() got = %#v, want %#v", got, test0.want)
		}
	})

	// Clear the test environment.
	os.Unsetenv(env)
}

func TestExcludeBuiltInLabels(t *testing.T) {
	type args struct {
		originLabels    map[string]string
		processedLabels map[string]string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "origin is nil",
			args: args{
				originLabels:    nil,
				processedLabels: nil,
			},
			want: true,
		},
		{
			name: "origin has kubeSystemId",
			args: args{
				originLabels:    map[string]string{"aaa": "qaz", ClusterSystemIDLabel: "qaz"},
				processedLabels: map[string]string{"aaa": "qaz"},
			},
			want: true,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if maputil.EqualMap(ExcludeBuiltInLabels(test.args.originLabels), test.args.processedLabels) != test.want {
				t.Fail()
			}
		})
	}
}

func TestExcludeBuiltInAnnotations(t *testing.T) {
	type args struct {
		originAnnotations    map[string]string
		processedAnnotations map[string]string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "origin is nil",
			args: args{
				originAnnotations:    nil,
				processedAnnotations: nil,
			},
			want: true,
		},
		{
			name: "origin has Cluster Describe Annotation",
			args: args{
				originAnnotations:    map[string]string{"qaz": "qazqwqw"},
				processedAnnotations: map[string]string{"qaz": "qazqwqw"},
			},
			want: true,
		},
		{
			name: "origin has Cluster Describe Annotation different",
			args: args{
				originAnnotations:    map[string]string{"qaz": "qazqwqw"},
				processedAnnotations: map[string]string{"qaz": "qazqwqww"},
			},
			want: false,
		},
	}
	for _, test := range tests {
		if maputil.EqualMap(ExcludeBuiltInAnnotations(test.args.originAnnotations), test.args.processedAnnotations) != test.want {
			t.Fail()
		}
	}
}

func TestMakeConfigSkipTLS(t *testing.T) {
	tests := []struct {
		name string
		args *rest.Config
		want *rest.Config
	}{
		{
			name: "nil",
			args: nil,
			want: nil,
		},
		{
			name: "not nil",
			args: &rest.Config{},
			want: &rest.Config{
				TLSClientConfig: rest.TLSClientConfig{
					CAData:   nil,
					Insecure: true,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			MakeConfigSkipTLS(tt.args)
			if !reflect.DeepEqual(tt.args, tt.want) {
				t.Errorf("NodeScheduleConvert() got = %#v, want %#v", tt.args, tt.want)
			}
		})
	}
}

func Test_ShouldUseEgress(t *testing.T) {
	tests := []struct {
		name string
		args func() bool
		want bool
	}{
		{
			name: "nil cluster",
			args: func() bool {
				return ShouldUseEgress(nil, &rest.Config{})
			},
			want: false,
		},
		{
			name: "nil config",
			args: func() bool {
				return ShouldUseEgress(&clusterv1alpha1.Cluster{}, nil)
			},
			want: false,
		},
		{
			name: "use egress",
			args: func() bool {
				cluster := &clusterv1alpha1.Cluster{}
				config := &rest.Config{}
				cluster.Status.ProxyURL = "https://a.com:11101"
				config.Host = "https://a.com:11101"
				return ShouldUseEgress(cluster, config)
			},
			want: true,
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if test.args() != test.want {
				t.Fail()
			}
		})
	}
}

func TestGenWorkClusterLabels(t *testing.T) {
	tests := []struct {
		name string
		want map[string]string
	}{
		{
			name: "GenWorkClusterLabels",
			want: map[string]string{
				fmt.Sprintf(constants.ClusterRoleLabelTemplate, constants.ClusterRoleWorker): "",
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GenWorkClusterLabels(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GenWorkClusterLabels() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGenThirdPartyLabels(t *testing.T) {
	tests := []struct {
		name string
		want map[string]string
	}{
		{
			name: "GenThirdPartyLabels",
			want: map[string]string{
				fmt.Sprintf(constants.ClusterRoleLabelTemplate, constants.ClusterRoleThirdParty): "",
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GenThirdPartyLabels(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GenThirdPartyLabels() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestFetchManagerCluster(t *testing.T) {
	type args struct {
		labels map[string]string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "constants.ManagedByLabelKey is hello",
			args: args{
				labels: map[string]string{
					constants.ManagedByLabelKey: "hello",
				},
			},
			want: "hello",
		},
		{
			name: "labels is nil",
			args: args{
				labels: nil,
			},
			want: "",
		},
		{
			name: "constants.ManagedByLabelKey is not exist",
			args: args{
				labels: map[string]string{
					"sdsf": "hello",
				},
			},
			want: "",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := FetchManagerCluster(tt.args.labels); got != tt.want {
				t.Errorf("FetchManagerCluster() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestPersistentVolumeClaimCapacityConvert(t *testing.T) {
	capacity := "hello"
	bytePatch, _ := AddJSONPatch(&JSONPatch{
		Operation: JSONPatchOperationReplace,
		Path:      "/spec/resources/requests/storage",
		Value:     capacity,
		From:      "",
	}).ToBytes()

	tests := []struct {
		name    string
		want    []byte
		wantErr bool
	}{
		{
			name:    "PersistentVolumeClaimCapacityConvert",
			want:    bytePatch,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := PersistentVolumeClaimCapacityConvert(capacity)
			if (err != nil) != tt.wantErr {
				t.Errorf("PersistentVolumeClaimCapacityConvert() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("PersistentVolumeClaimCapacityConvert() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestIsMangerCluster(t *testing.T) {
	type args struct {
		labels map[string]string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "cluster is not manger cluster",
			args: args{
				labels: nil,
			},
			want: false,
		},
		{
			name: "cluster is not manger cluster",
			args: args{
				labels: map[string]string{},
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := IsMangerCluster(tt.args.labels); got != tt.want {
				t.Errorf("IsMangerCluster() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetKubeConfigFromCluster(t *testing.T) {
	const kubeconfig = "apiVersion: v1\nclusters:\n- cluster:\n    certificate-authority-data: LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUM1ekNDQWMrZ0F3SUJBZ0lCQURBTkJna3Foa2lHOXcwQkFRc0ZBREFWTVJNd0VRWURWUVFERXdwcmRXSmwKY201bGRHVnpNQjRYRFRJeU1EWXhOakE0TlRRMU5Wb1hEVE15TURZeE16QTROVFExTlZvd0ZURVRNQkVHQTFVRQpBeE1LYTNWaVpYSnVaWFJsY3pDQ0FTSXdEUVlKS29aSWh2Y05BUUVCQlFBRGdnRVBBRENDQVFvQ2dnRUJBSmY1CjVDTlpldHhvU3E2MVBMaDVJN1NWcUR5cTRKd2dXNmV6N3dRaFc5ZUVXSHBIZ1A1WEhrSGkxeTRaQVkvS01nRUsKT0g2eDlLSmRLMTFTTFg2NTdhL1BWMWRhTmVBZlk4eXdpczRuS29TK1UrTEJ5WmZYR0dCaUUwekdUOVlteVVpVgpWYmRqWkdxck1iYzZPNVBRU0dlOGVOMXlZQmo5czcvNnhrNnBKSkV2R2tmMHh2QlJobDIyN24xZ1dLOHRyMW14CjFOTmFjbjZXYzFMd3dwMWpZZXlWczhsTEZhbXdJRXltY2VTWFRPUUcxbjh6Rk1sM0FLaG9EMWZIUDF2SGtiZk0KOU9reks4ZkJYVU5sVUtuNEpwbnV6SlVCb1JQNlpLdzNrQzcxdkpRVWd1TmdkV3FCdHFTNHh2MEFnSXgzZTJ2UwpHdDZRZTY4ckV0MVFPaE1vd1ZFQ0F3RUFBYU5DTUVBd0RnWURWUjBQQVFIL0JBUURBZ0trTUE4R0ExVWRFd0VCCi93UUZNQU1CQWY4d0hRWURWUjBPQkJZRUZFOFp5aWJIM2YzTllzR3BMNmdXVm1jUXRuR0pNQTBHQ1NxR1NJYjMKRFFFQkN3VUFBNElCQVFDUFprZktaUzNpdnZWN01NZDhqNUY4RjFsekZxeUhRcGgxSmZkUng5eW5xNStXTHRWbwpVSUtQY29uUXlseGJITjV6NWFWMWx2RHZPbjBiYmNRTTNJVE1PaUhscG5nNFZoU2JXUjlPZGdWOHhFREVlRHJICng3cTZJRzhNdUttdS9EUldHa2VjUXZWc09WMVpJcTQ3dytMcHdDNW0wditubXZtN09WVW1sTGpnbURqSlVGMDEKWSs2dEV4RXBRWnE2eU1sUE5iQlhhWVNSVFcxSDNLV0REcE9mZDBUbjlFK05JcXJyZXdDd0UyUG5uelZrQ0hYSwpoTkJJcnVuUUsyQ1RWYUdETzRkSG5JUU5PWitycWI1RW02bkJVK2JjMXBsbkQ1d2tkeU56S3NYd3kvRHM4YVpXCi8wRVpOc09tLytlVExGNWY0ckdvY1NFZVR6TDM4SzFzNzRwegotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCg==\n    server: https://192.168.121.121:65530\n  name: cluster.local\ncontexts:\n- context:\n    cluster: cluster.local\n    user: kubernetes-admin\n  name: kubernetes-admin@cluster.local\ncurrent-context: kubernetes-admin@cluster.local\nkind: Config\npreferences: {}\nusers:\n- name: kubernetes-admin\n  user:\n    client-certificate-data: LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSURFekNDQWZ1Z0F3SUJBZ0lJYm9NaUhTUUNvRjR3RFFZSktvWklodmNOQVFFTEJRQXdGVEVUTUJFR0ExVUUKQXhNS2EzVmlaWEp1WlhSbGN6QWVGdzB5TWpBMk1UWXdPRFUwTlRWYUZ3MHlNekEyTVRZd09EVTBOVGRhTURReApGekFWQmdOVkJBb1REbk41YzNSbGJUcHRZWE4wWlhKek1Sa3dGd1lEVlFRREV4QnJkV0psY201bGRHVnpMV0ZrCmJXbHVNSUlCSWpBTkJna3Foa2lHOXcwQkFRRUZBQU9DQVE4QU1JSUJDZ0tDQVFFQTdPbHFLTThhRmpTdDVuM3kKQkdPckxMS2taRVJYejJUK3RQWnBPNnhlRkQ0ZG9PWXFKVmZtL0pBYTQ5LzB0eGJnSDNndmlUanV3eDFMRmQ0YwpCRVlBcm5qZHdIK05MTStSUmdaaXFQcVZZU3FWaGNaMTQ3R0VQTUVETHFLTnVtQlhCZng5WW1OWGxpaXF3NloyCkxCbUY4WXNmS2FtRWRMdmVHcW5hU3QrcWR6aGNaSE42cUl1dnJlZjBveDJ0MnZQZDIrd2ljSmV2d1hvdjE0V3QKOEUvWW9FRUVOVVR1S1dKdkpUNnd3Z1NXUnJVbU9CWllOZkJteGxpMWtTcXdlc2UwVW1mVWUvQ1Z1VlZpcHh6dgpDalkxVytscFlHcGFJTFVtNjVmWXl6VCs4S00rZDJxajV2b3krUXZ2RjB0ZUNNM0lFdXcxNEhCMlMxeFR1a0ZuCjFoaW1Nd0lEQVFBQm8wZ3dSakFPQmdOVkhROEJBZjhFQkFNQ0JhQXdFd1lEVlIwbEJBd3dDZ1lJS3dZQkJRVUgKQXdJd0h3WURWUjBqQkJnd0ZvQVVUeG5LSnNmZC9jMWl3YWt2cUJaV1p4QzJjWWt3RFFZSktvWklodmNOQVFFTApCUUFEZ2dFQkFHTnhWU05LZk1laG1LSFgxQ1NQVzVneTBxYWx2SFJ4SWgySXRWL0p5cmppSGV4VzJQQUh5SWYzCjZvYnNoTk5QcVZkck9zRUxMa05BOHVMdXJuVkVsQVhwOTloU0VzbzhtOUhISmppY2VIbWFPNmZFNHJucDExTy8KQWFmelNrRHZKdHZqMkUxRHNUbWJvNmptODRKSzNITWw5cTd2RytWVHQrL1luSVN3WmxjM1labnlMT0EzVnlmTwpDbDZDZC9Na0Z4amFjVHpvVUwrbm5JWTJGTnp0bXpqMlk1eHlGdHlYd0ErZUtRTG5WcEI5ZndMdmlCNUJML1FECmZGUGUyZFo1VlFCOVJScDdQN2luOFZmRkI3ODFXcS96dTB1ZFNXNUVjNi8rZUJ3NU12Z0NyZ1JvU3FFZ0xVd1gKTEV4MmltZnMwQXpoUXhyd1ZWOHhEL25qandWRkx3Zz0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQo=\n    client-key-data: LS0tLS1CRUdJTiBSU0EgUFJJVkFURSBLRVktLS0tLQpNSUlFcEFJQkFBS0NBUUVBN09scUtNOGFGalN0NW4zeUJHT3JMTEtrWkVSWHoyVCt0UFpwTzZ4ZUZENGRvT1lxCkpWZm0vSkFhNDkvMHR4YmdIM2d2aVRqdXd4MUxGZDRjQkVZQXJuamR3SCtOTE0rUlJnWmlxUHFWWVNxVmhjWjEKNDdHRVBNRURMcUtOdW1CWEJmeDlZbU5YbGlpcXc2WjJMQm1GOFlzZkthbUVkTHZlR3FuYVN0K3FkemhjWkhONgpxSXV2cmVmMG94MnQydlBkMit3aWNKZXZ3WG92MTRXdDhFL1lvRUVFTlVUdUtXSnZKVDZ3d2dTV1JyVW1PQlpZCk5mQm14bGkxa1Nxd2VzZTBVbWZVZS9DVnVWVmlweHp2Q2pZMVcrbHBZR3BhSUxVbTY1Zll5elQrOEtNK2QycWoKNXZveStRdnZGMHRlQ00zSUV1dzE0SEIyUzF4VHVrRm4xaGltTXdJREFRQUJBb0lCQURiS29QL0JMaUpXbXFXRgpHVlVFakJFeFc2M0kxSm9sbkhiVHluQy9vNTZBNHk5VUxBa285RVlUT2ZUYjFlZ0dSVjFoMlhTZUV6SlM4d3VpCnE4NGROb2tqY1AzVlFoeE1BU2cxejltTzRyOXZMdGVhbDZkS1plLzdIN1pJYUFqandSeWtVWWRRdkhBQkJjVnMKR1VhSHZKK3BjbEtiWHdQMGN5Q3RpY3ZwUUs2RGk0TlMzT2pqaUx4U05ady9xald6dVlNMVQ0WHdrWjY5Tk96Swp6elFHV3VReHNFckQxVGdoa1UrNVlqd0hCVm9lWUsreTRGSSt3b0xzdWtLS1RSV0VJUUlZbU5md2ZYWDcvT3pmCjBHZDJrWW1TaDh0SjFrazhVWGkrR0pLYnoyUUNLNEdUYnFjSHBJVWxoOCtXS2lwcThNMGVrNk9ZZDFoMW5ONkEKbHlaOFltRUNnWUVBK3hVUE1TVmw4UzlseHc1QS9yRk1rM2lHYmU0cTNrS2VtS216bUxZZktJUmFabS9kbXVrVwpBT2J5QmtZanFTZ3IwRGNGSm1tQjk2akoyNG43a0JuUW1qOWxLcDl0Z3c0U2NPbGxuUzdKQm1DZU43emhnellQCi9zS1EzWFY5aG1ISjhTZkpKMzNDY2hsdVNTYjZVM0JGampvSVBoVGNDT1dmd1F5QjFDNXZKK01DZ1lFQThZMU4Kd0lvZGp4SGZxaXVpSnkwUSs5NUtoRlhWajFsN3Z3RmU5aWNZWGk4TFQwOVhXUDZNd2JtaWMwdzJCeWsvelBtbwo3dFAvSnBRbm5oa2xQRUFMRXVBWUZMYnhlYkIwdkxuZW5pazBjMHgveUdhbkdMT1M2N1hZZGpKa3VqWkpJMXhpCk9zQ1JPZ3VMcVVPWjI1MSs5M083Qit3UysvZFlVM0RuT1NRSHVYRUNnWUVBa0ZXNDEvMnhyb1lhc2VVbHc4UFUKUzJvYmpSSStubW9abFpUb1l6OCtoaUlmZlllTkVzSXZIZkdrNjZwaVVabUFKaithdkV3bXBHSHBPRVVIMGZ5bApDQ2F0VjJVeXBRWHYzK3lydDBIdjJiU3MvMG1iTWJ4Z1VZa3prYnM2bjRlVGVRZndBTDJ3aTdyR3hWS2MwRjVYCi9ieXFoRldsYjQvZzJDOENheUVPVVJVQ2dZRUFzRGpxZElGT3QwWE82eE1TSllxWFRXa0s3Q2pDdU9ZTGhYbTIKa2RaTHpNcDljY3JzYXB5cWk5cW1UWDlZR3psWXRtMmRkVDlzY2ZTOFFuY04xenJSMlY5cnNoRVZjalh0dEpIVgplNFdNSW1HNUI3YjhTT1VaVnFVLzJsdEJhU2laaXhhbkF6M2h0WHNlMU1uZ3dYdlJXUzR4VU1KRngxVFlOMmV6CkNOamtXY0VDZ1lCSm5wRlhNbUdYa2JUZGRVdldmT3NRbmVHdTBpTUx3NlVmWnBiRm93MzJGbW5pQlRSa2dvalEKclI1bExsbll0SWZSRk53eXBvNU03VElSMDRDM2hqUkdEM2k3bDdCT1RHK0NzZDRTTWlYNjErYzBmWXJkUkpscQoyT0k3OGQ0a3puSGhzek1yZ250dUZnUURFbHpEN1RxM2M4L0RtY1dZRG1objI2Z2FqQ21CaEE9PQotLS0tLUVORCBSU0EgUFJJVkFURSBLRVktLS0tLQo="
	c1 := clientfake.NewClientBuilder().Build()
	c1.Create(context.Background(), &corev1.Secret{
		TypeMeta: metav1.TypeMeta{},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "secret1",
			Namespace: "ns",
		},
	})
	c1.Create(context.Background(), &corev1.Secret{
		TypeMeta: metav1.TypeMeta{},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "secret2",
			Namespace: "ns",
		},
		Data: map[string][]byte{"kubeconfig": []byte(kubeconfig)},
	})
	type args struct {
		ctx     context.Context
		cluster *clusterv1alpha1.Cluster
		c       client.Client
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "secret ref is nil",
			args: args{
				ctx:     context.Background(),
				cluster: &clusterv1alpha1.Cluster{},
				c:       nil,
			},
			wantErr: true,
		},
		{
			name: "secret ref not exists",
			args: args{
				ctx: context.Background(),
				cluster: &clusterv1alpha1.Cluster{
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace: "ns",
							Name:      "secret",
						},
					},
				},
				c: clientfake.NewClientBuilder().Build(),
			},
			wantErr: true,
		},
		{
			name: "secret data is nil",
			args: args{
				ctx: context.Background(),
				cluster: &clusterv1alpha1.Cluster{
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace: "ns",
							Name:      "secret1",
						},
					},
				},
				c: c1,
			},
			wantErr: true,
		},
		{
			name: "secret data is valid",
			args: args{
				ctx: context.Background(),
				cluster: &clusterv1alpha1.Cluster{
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace: "ns",
							Name:      "secret2",
						},
					},
				},
				c: c1,
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := GetKubeConfigFromCluster(tt.args.ctx, tt.args.cluster, tt.args.c)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetKubeConfigFromCluster() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func Test_IsVirtualCluster(t *testing.T) {
	type args struct {
		labels map[string]string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "cluster is not virtual cluster",
			args: args{
				labels: nil,
			},
			want: false,
		},
		{
			name: "cluster is virtual cluster",
			args: args{
				labels: map[string]string{},
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := IsVirtualCluster(tt.args.labels); got != tt.want {
				t.Errorf("IsVirtualCluster() = %v, want %v", got, tt.want)
			}
		})
	}
}
