package util

import (
	"fmt"
	"os"
	"testing"
	"time"
)

func Test_WriteFile(t *testing.T) {
	tmpFile := fmt.Sprintf("/tmp/test_kps_%d", time.Now().UnixNano())
	WriteFile("a", tmpFile)
	contentBytes, _ := os.ReadFile(tmpFile)
	if string(contentBytes) != "a" {
		t.Errorf("The output is not a")
	}
	os.Remove(tmpFile)
	if os.FileMode(0o666).String() != "-rw-rw-rw-" {
		t.Errorf("This file is not readable or writable and cannot be executed")
	}
}

func Test_WriteBytesToFile(t *testing.T) {
	tmpFile := fmt.Sprintf("/tmp/test_kps_%d", time.Now().UnixNano())
	WriteBytesToFile([]byte("a"), tmpFile)
	contentBytes, _ := os.ReadFile(tmpFile)
	if string(contentBytes) != "a" {
		t.Errorf("The output is not equal to the expectation a")
	}
	os.Remove(tmpFile)
}

func Test_ExistFile(t *testing.T) {
	if !ExistFile("/tmp") {
		t.Errorf("The file is not exist /tmp")
	}
	testFile := fmt.Sprintf("/tmp/kps_test_%d", time.Now().UnixNano())
	WriteFile("a", testFile)
	if !ExistFile(testFile) {
		t.Errorf("The file is not exist")
	}
	os.Remove(testFile)
	if ExistFile(testFile) {
		t.Errorf("The file is exist")
	}
}
