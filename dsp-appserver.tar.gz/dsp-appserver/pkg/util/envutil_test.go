package util

import (
	"os"
	"testing"
)

func TestGetEnvWithDefault(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			key          string
			value        string
			defaultValue string
		}
	}{
		{
			name: "test GetEnvWithDefault when os env can be found",
			in: struct {
				key          string
				value        string
				defaultValue string
			}{key: "test1", value: "test1", defaultValue: "test1"},
		},
		{
			name: "test GetEnvWithDefault when os env can not be found",
			in: struct {
				key          string
				value        string
				defaultValue string
			}{key: "test2", value: "", defaultValue: "test1"},
		},
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			err := os.Setenv(v.in.key, v.in.value)
			if err != nil {
				t.Fatal(err)
			}
			res := GetEnvWithDefault(v.in.key, v.in.defaultValue)
			if res != v.in.defaultValue {
				t.Fatal()
			}
		})
	}
}
