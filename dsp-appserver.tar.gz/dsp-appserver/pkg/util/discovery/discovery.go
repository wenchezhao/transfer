package discovery

import (
	"fmt"
	"github.com/golang/glog"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/discovery"
	"strings"
)

// AmbiguousResourceError is returned if the RESTMapper finds multiple matches for a resource
type AmbiguousResourceError struct {
	PartialResource schema.GroupVersionKind

	MatchingResources []schema.GroupVersionResource
	MatchingKinds     []schema.GroupVersionKind
}

func (e *AmbiguousResourceError) Error() string {
	switch {
	case len(e.MatchingKinds) > 0 && len(e.MatchingResources) > 0:
		return fmt.Sprintf("%v matches multiple resources %v and kinds %v", e.PartialResource, e.MatchingResources, e.MatchingKinds)
	case len(e.MatchingKinds) > 0:
		return fmt.Sprintf("%v matches multiple kinds %v", e.PartialResource, e.MatchingKinds)
	case len(e.MatchingResources) > 0:
		return fmt.Sprintf("%v matches multiple resources %v", e.PartialResource, e.MatchingResources)
	}
	return fmt.Sprintf("%v matches multiple resources or kinds", e.PartialResource)
}

func FilterSubResources(resources []schema.GroupVersionResource) []schema.GroupVersionResource {
	var filtered []schema.GroupVersionResource
	for _, res := range resources {
		if !strings.ContainsRune(res.Resource, '/') {
			filtered = append(filtered, res)
		}
	}
	return filtered
}

func ResourceForGVK(client discovery.DiscoveryInterface, input schema.GroupVersionKind) (schema.GroupVersionResource, error) {
	resourceList, err := client.ServerResourcesForGroupVersion(input.GroupVersion().String())
	if discovery.IsGroupDiscoveryFailedError(err) {
		glog.Errorf("Skipping failed API Groups: %v", err)
	} else if err != nil {
		return schema.GroupVersionResource{}, err
	}
	var resources []schema.GroupVersionResource
	for _, resource := range resourceList.APIResources {
		if resource.Kind == input.Kind { // match kind
			resources = append(resources, input.GroupVersion().WithResource(resource.Name))
		}
	}
	resources = FilterSubResources(resources) // ignore sub-resources
	if len(resources) == 1 {
		return resources[0], nil
	}
	return schema.GroupVersionResource{}, &AmbiguousResourceError{PartialResource: input, MatchingResources: resources}
}
