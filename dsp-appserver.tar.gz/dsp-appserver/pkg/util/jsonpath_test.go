package util

import (
	"encoding/json"
	"reflect"
	"testing"
)

func TestAddJSONPatch(t *testing.T) {
	type args struct {
		jps []*JSONPatch
	}
	tests := []struct {
		name string
		args args
		want JSONPatchList
	}{
		{
			name: "convert jsonPatch success",
			args: args{
				jps: []*JSONPatch{
					{
						Operation: JSONPatchOperationReplace,
						Path:      "/metadata/annotations",
						Value:     map[string]string{"a": "b"},
					},
				},
			},
			want: JSONPatchList{{
				Operation: JSONPatchOperationReplace,
				Path:      "/metadata/annotations",
				Value:     map[string]string{"a": "b"},
			}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := AddJSONPatch(tt.args.jps...); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("AddJsonPatch() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestJSONPatchList_ToBytes(t *testing.T) {
	jp := JSONPatchList{
		{
			Operation: JSONPatchOperationReplace,
			Path:      "/metadata/annotations",
			Value:     map[string]string{"a": "b"},
		},
	}
	bytes, _ := json.Marshal(jp)
	tests := []struct {
		name    string
		jps     JSONPatchList
		want    []byte
		wantErr bool
	}{
		{
			name: "marshal jsonPatchList success",
			jps: JSONPatchList{
				{
					Operation: JSONPatchOperationReplace,
					Path:      "/metadata/annotations",
					Value:     map[string]string{"a": "b"},
				},
			},
			want:    bytes,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.jps.ToBytes()
			if (err != nil) != tt.wantErr {
				t.Errorf("ToBytes() = %v, want %v", got, tt.want)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ToBytes() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
