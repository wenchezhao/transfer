package util

import (
	"fmt"
	"testing"
	"time"
)

func Test_DoWithCount(t *testing.T) {
	sleepTime := time.Millisecond * 20
	const Attempts = 10
	info := "test retry with count"
	tests := []struct {
		name string
		args func() bool
		want bool
	}{
		{
			name: "work ok",
			args: func() bool {
				alreadyAttemptCount, err := DoWithCount(Attempts, sleepTime, time.Second, info, func() (err error) {
					return nil
				})
				return alreadyAttemptCount == 0 && err == nil
			},
			want: true,
		},
		{
			name: "attempt some times to be ok",
			args: func() bool {
				executionCount := 0
				alreadyAttemptCount, err := DoWithCount(Attempts, sleepTime, time.Second, info, func() (err error) {
					executionCount++
					if executionCount == 3 {
						// be successful at last
						return nil
					}
					return fmt.Errorf("has error")
				})
				return err == nil && alreadyAttemptCount == 2 && executionCount == 3
			},
			want: true,
		},
		{
			name: "bad Attempts",
			args: func() bool {
				_, err := DoWithCount(0, sleepTime, time.Second, info, func() (err error) {
					return nil
				})
				return err != nil && err.Error() == "retry count cannot be less than 1"
			},
			want: true,
		},
		{
			name: "failed at last",
			args: func() bool {
				alreadyAttemptCount, err := DoWithCount(Attempts, sleepTime, time.Second, info, func() (err error) {
					return fmt.Errorf("has error")
				})
				return err != nil && err.Error() == "has error" && alreadyAttemptCount == 10
			},
			want: true,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if test.want != test.args() {
				t.Fail()
			}
		})
	}
}

func Test_doWithTimeout(t *testing.T) {
	tests := []struct {
		name string
		args func() bool
		want bool
	}{
		{
			name: "work ok",
			args: func() bool {
				return doWithTimeout(time.Millisecond*500, func() (err error) {
					time.Sleep(time.Millisecond * 10)
					return nil
				}) == nil
			},
			want: true,
		},
		{
			name: "time out(1)",
			args: func() bool {
				err := doWithTimeout(time.Millisecond*500, func() (err error) {
					time.Sleep(time.Millisecond * 550)
					return nil
				})
				return err != nil && err.Error() == "timeout to invoke"
			},
			want: true,
		},
		{
			name: "time out(2)",
			args: func() bool {
				err := doWithTimeout(time.Millisecond*500, func() (err error) {
					time.Sleep(time.Millisecond * 510)
					return nil
				})
				return err != nil && err.Error() == "timeout to invoke"
			},
			want: true,
		},
		{
			name: "return error",
			args: func() bool {
				err := doWithTimeout(time.Millisecond*500, func() (err error) {
					time.Sleep(time.Millisecond * 10)
					return fmt.Errorf("new error")
				})
				return err != nil && err.Error() == "new error"
			},
			want: true,
		},
		{
			name: "error timeout",
			args: func() bool {
				err := doWithTimeout(1, func() (err error) {
					time.Sleep(time.Millisecond * 10)
					return fmt.Errorf("new error")
				})
				return err != nil && err.Error() == "time cannot be less than 1 Microsecond"
			},
			want: true,
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if test.args() != test.want {
				t.Fail()
			}
		})
	}
}
