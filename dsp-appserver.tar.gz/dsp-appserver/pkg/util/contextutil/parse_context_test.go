package contextutil

import (
	"context"
	"reflect"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apiserver/pkg/authentication/user"
)

func TestNewOutgoingContext(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name string
		args args
		want context.Context
	}{
		{
			name: "background context",
			args: args{
				ctx: context.Background(),
			},
			want: context.Background(),
		},
		{
			name: "nil context",
			args: args{
				ctx: context.Background(),
			},
			want: nil,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := NewOutgoingContext(tt.args.ctx)
			if err != nil {
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewOutgoingContext() got = %v, want %v", got, tt.want)
			}
		})
	}
}

// TestNamespaceContext validates that a namespace can be get/set on a context object.
func TestNamespaceContext(t *testing.T) {
	ctx := NewDefaultContext()
	result, ok := NamespaceFrom(ctx)
	if !ok {
		t.Fatalf("Error getting namespace")
	}
	if metav1.NamespaceDefault != result {
		t.Fatalf("Expected: %s, Actual: %s", metav1.NamespaceDefault, result)
	}

	ctx = NewContext()
	result, ok = NamespaceFrom(ctx)
	if ok {
		t.Fatalf("Should not be ok because there is no namespace on the context")
	}

	t.Log(result)
}

// TestUserContext validates that a userinfo can be get/set on a context object.
func TestUserContext(t *testing.T) {
	ctx := NewContext()
	if _, ok := UserFrom(ctx); ok {
		t.Fatalf("Should not be ok because there is no user.Info on the context")
	}
	ctx = WithUser(
		ctx,
		&user.DefaultInfo{
			Name:   "bob",
			UID:    "123",
			Groups: []string{"group1"},
			Extra:  map[string][]string{"foo": {"bar"}},
		},
	)

	result, ok := UserFrom(ctx)
	if !ok {
		t.Fatalf("Error getting user info")
	}

	if expectedName := "bob"; result.GetName() != expectedName {
		t.Fatalf("Get user name error, Expected: %s, Actual: %s", expectedName, result.GetName())
	}

	if expectedUID := "123"; result.GetUID() != expectedUID {
		t.Fatalf("Get UID error, Expected: %s, Actual: %s", expectedUID, result.GetName())
	}

	expectedGroup := "group1"
	actualGroup := result.GetGroups()
	if len(actualGroup) != 1 {
		t.Fatalf("Get user group number error, Expected: 1, Actual: %d", len(actualGroup))
	} else if actualGroup[0] != expectedGroup {
		t.Fatalf("Get user group error, Expected: %s, Actual: %s", expectedGroup, actualGroup[0])
	}

	expectedExtraKey := "foo"
	expectedExtraValue := "bar"
	actualExtra := result.GetExtra()
	if len(actualExtra[expectedExtraKey]) != 1 {
		t.Fatalf("Get user extra map number error, Expected: 1, Actual: %d", len(actualExtra[expectedExtraKey]))
	} else if actualExtra[expectedExtraKey][0] != expectedExtraValue {
		t.Fatalf("Get user extra map value error, Expected: %s, Actual: %s", expectedExtraValue, actualExtra[expectedExtraKey])
	}
}

func TestNamespaceFrom(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name  string
		args  args
		want  string
		want1 bool
	}{
		{
			name: "Test Namespace From",
			args: args{
				ctx: context.TODO(),
			},
			want:  "",
			want1: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1 := NamespaceFrom(tt.args.ctx)
			if got != tt.want {
				t.Errorf("NamespaceFrom() got = %v, want %v", got, tt.want)
			}
			if got1 != tt.want1 {
				t.Errorf("NamespaceFrom() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

func TestNewContext(t *testing.T) {
	tests := []struct {
		name string
		want bool
	}{
		{
			name: "Test New Context",
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewContext(); got == nil {
				t.Errorf("NewContext() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestNewDefaultContext(t *testing.T) {
	tests := []struct {
		name string
		want bool
	}{
		{
			name: "Test NewDefault Context",
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewDefaultContext(); got == nil {
				t.Errorf("NewDefaultContext() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestUserFrom(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name  string
		args  args
		want  user.Info
		want1 bool
	}{
		{
			name: "Test User From",
			args: args{
				ctx: context.TODO(),
			},
			want:  nil,
			want1: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1 := UserFrom(tt.args.ctx)
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("UserFrom() got = %v, want %v", got, tt.want)
			}
			if got1 != tt.want1 {
				t.Errorf("UserFrom() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

func TestWithNamespace(t *testing.T) {
	type args struct {
		parent    context.Context
		namespace string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "Test With Namespace",
			args: args{
				parent:    context.TODO(),
				namespace: "namespace",
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := WithNamespace(tt.args.parent, tt.args.namespace); got == nil {
				t.Errorf("WithNamespace() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestWithUser(t *testing.T) {
	type args struct {
		parent context.Context
		user   user.Info
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "Test With Namespace",
			args: args{
				parent: context.TODO(),
				user:   &user.DefaultInfo{},
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := WithUser(tt.args.parent, tt.args.user); got == nil {
				t.Errorf("WithUser() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestWithValue(t *testing.T) {
	type args struct {
		parent context.Context
		key    interface{}
		val    interface{}
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "Test With Namespace",
			args: args{
				parent: context.TODO(),
				key:    userKey,
				val:    namespaceKey,
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := WithValue(tt.args.parent, tt.args.key, tt.args.val)
			if got == nil {
				t.Errorf("WithValue() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestParseUserInfoFromCtx(t *testing.T) {
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		args    args
		want    user.Info
		wantErr bool
	}{
		{
			name: "ctx with nothing",
			args: args{
				ctx: context.TODO(),
			},
			wantErr: true,
		},
		{
			name: "ctx with user info",
			args: args{
				ctx: WithUser(context.Background(), &user.DefaultInfo{}),
			},
			want:    &user.DefaultInfo{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := ParseUserInfoFromCtx(tt.args.ctx)
			if (err != nil) != tt.wantErr {
				t.Errorf("ParseUserInfoFromCtx() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ParseUserInfoFromCtx() got = %v, want %v", got, tt.want)
			}
		})
	}
}
