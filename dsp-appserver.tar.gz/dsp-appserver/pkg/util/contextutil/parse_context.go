package contextutil

import (
	"context"
	"errors"

	"google.golang.org/grpc/metadata"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apiserver/pkg/authentication/user"
)

// The key type is unexported to prevent collisions.
type key int

const (
	// namespaceKey is the context key for the request namespace.
	namespaceKey key = iota

	// userKey is the context key for the request user.
	userKey
)

func NewOutgoingContext(ctx context.Context) (context.Context, error) {
	header, ok := metadata.FromIncomingContext(ctx)
	if !ok {
		return nil, errors.New("metadata does not exist")
	}

	authorization, ok := header["authorization"]
	if !ok || len(authorization) == 0 {
		return nil, errors.New("metadata does not have authorization")
	}

	return metadata.AppendToOutgoingContext(ctx, "authorization", authorization[0]), nil
}

// NewContext instantiates a base context object for request flows.
func NewContext() context.Context {
	return context.TODO()
}

// NewDefaultContext instantiates a base context object for request flows in the default namespace.
func NewDefaultContext() context.Context {
	return WithNamespace(NewContext(), metav1.NamespaceDefault)
}

// WithValue returns a copy of parent in which the value associated with key is val.
func WithValue(parent context.Context, key, val interface{}) context.Context {
	return context.WithValue(parent, key, val)
}

// WithNamespace returns a copy of parent in which the namespace value is set.
func WithNamespace(parent context.Context, namespace string) context.Context {
	return WithValue(parent, namespaceKey, namespace)
}

// NamespaceFrom returns the value of the namespace key on the ctx.
func NamespaceFrom(ctx context.Context) (string, bool) {
	namespace, ok := ctx.Value(namespaceKey).(string)
	return namespace, ok
}

// WithUser returns a copy of parent in which the user value is set.
func WithUser(parent context.Context, user user.Info) context.Context {
	return WithValue(parent, userKey, user)
}

// UserFrom returns the value of the user key on the ctx.
func UserFrom(ctx context.Context) (user.Info, bool) {
	if ctx == nil {
		return nil, false
	}

	user, ok := ctx.Value(userKey).(user.Info)
	return user, ok
}

func ParseUserInfoFromCtx(ctx context.Context) (user.Info, error) {
	useInfo, ok := UserFrom(ctx)
	if !ok {
		return nil, errors.New("user info is null")
	}
	return useInfo, nil
}
