package secret

import (
	"context"
	"encoding/json"
	"fmt"

	corev1 "k8s.io/api/core/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	corev1client "k8s.io/client-go/kubernetes/typed/core/v1"
	"k8s.io/kubernetes/pkg/credentialprovider"

	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	podutil "github.com/daocloud/dsp-appserver/pkg/util/pod"
)

// NewDockerRegistrySecret creates a secret for use with a Docker registry.
// It produces a ~/.dockercfg file that is used by subsequent 'docker push'
// and 'docker pull' commands to authenticate to the registry.
// The email address is optional.
func NewDockerRegistrySecret(
	namepace string,
	secretName string,
	server string,
	username string,
	password string,
	email string,
) (*corev1.Secret, error) {

	dockercfgAuth := credentialprovider.DockerConfigEntry{
		Username: username,
		Password: password,
	}

	dockerCfgJSON := credentialprovider.DockerConfigJSON{
		Auths: map[string]credentialprovider.DockerConfigEntry{server: dockercfgAuth},
	}

	dockercfgJSONContent, err := json.Marshal(dockerCfgJSON)
	if err != nil {
		return nil, err
	}

	secret := &corev1.Secret{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "v1",
			Kind:       "Secret",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      secretName,
			Namespace: namepace,
		},
		Data: map[string][]byte{},
	}
	secret.Data[corev1.DockerConfigJsonKey] = dockercfgJSONContent
	secret.Type = corev1.SecretTypeDockerConfigJson
	return secret, nil
}

// CreateOrUpdateSecret creates or updates a secret.
func CreateOrUpdateSecret(ctx context.Context, client corev1client.SecretsGetter, secret *corev1.Secret) error {
	if _, err := client.Secrets(secret.Namespace).Create(ctx, secret, metav1.CreateOptions{}); err != nil {
		if !apierrors.IsAlreadyExists(err) {
			return fmt.Errorf("failed to create secret: %v", err)
		}
		fetchedSecret, err := client.Secrets(secret.Namespace).Get(ctx, secret.Name, metav1.GetOptions{})
		if err != nil {
			return fmt.Errorf("failed to update secret: %v", err)
		}
		secret.ResourceVersion = fetchedSecret.ResourceVersion
		if _, err := client.Secrets(secret.Namespace).Update(ctx, secret, metav1.UpdateOptions{}); err != nil {
			return fmt.Errorf("failed to update secret: %v", err)
		}
	}
	return nil
}

// ListObjectReference returns a set of object references that use the given secret name.
func ListObjectReference(ctx context.Context, client clientset.Interface, namespace, secretName string) ([]corev1.ObjectReference, error) {
	refs := []corev1.ObjectReference{}
	allDeploys, err := client.AppsV1().Deployments(namespace).List(ctx, metav1.ListOptions{})
	if err != nil && !kapierrors.IsForbidden(err) {
		return nil, err
	}
	for _, d := range allDeploys.Items {
		podutil.VisitPodSpecSecretNames(d.Spec.Template.Spec, func(name string) bool {
			if name != secretName {
				return true
			}
			ref := corev1.ObjectReference{
				Kind:            "Deployment",
				Namespace:       d.Namespace,
				Name:            d.Name,
				UID:             d.UID,
				APIVersion:      "apps/v1",
				ResourceVersion: d.ResourceVersion,
			}
			refs = append(refs, ref)
			return false
		})
	}
	allSts, err := client.AppsV1().StatefulSets(namespace).List(ctx, metav1.ListOptions{})
	if err != nil && !kapierrors.IsForbidden(err) {
		return nil, err
	}
	for _, sts := range allSts.Items {
		podutil.VisitPodSpecSecretNames(sts.Spec.Template.Spec, func(name string) bool {
			if name != secretName {
				return true
			}
			ref := corev1.ObjectReference{
				Kind:            "StatefulSet",
				Namespace:       sts.Namespace,
				Name:            sts.Name,
				UID:             sts.UID,
				APIVersion:      "apps/v1",
				ResourceVersion: sts.ResourceVersion,
			}
			refs = append(refs, ref)
			return false
		})
	}
	allDS, err := client.AppsV1().DaemonSets(namespace).List(ctx, metav1.ListOptions{})
	if err != nil && !kapierrors.IsForbidden(err) {
		return nil, err
	}
	for _, ds := range allDS.Items {
		podutil.VisitPodSpecSecretNames(ds.Spec.Template.Spec, func(name string) bool {
			if name != secretName {
				return true
			}
			ref := corev1.ObjectReference{
				Kind:            "DaemonSet",
				Namespace:       ds.Namespace,
				Name:            ds.Name,
				UID:             ds.UID,
				APIVersion:      "apps/v1",
				ResourceVersion: ds.ResourceVersion,
			}
			refs = append(refs, ref)
			return false
		})
	}
	allCJ, err := client.BatchV1beta1().CronJobs(namespace).List(ctx, metav1.ListOptions{})
	if err != nil && !kapierrors.IsForbidden(err) {
		return nil, err
	}
	for _, cj := range allCJ.Items {
		podutil.VisitPodSpecSecretNames(cj.Spec.JobTemplate.Spec.Template.Spec, func(name string) bool {
			if name != secretName {
				return true
			}
			ref := corev1.ObjectReference{
				Kind:            "CronJob",
				Namespace:       cj.Namespace,
				Name:            cj.Name,
				UID:             cj.UID,
				APIVersion:      "batch/v1beta1",
				ResourceVersion: cj.ResourceVersion,
			}
			refs = append(refs, ref)
			return false
		})
	}
	return refs, nil
}
