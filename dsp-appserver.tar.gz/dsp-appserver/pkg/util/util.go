package util

import (
	"context"
	"encoding/json"
	"fmt"
	"net/url"
	"strconv"
	"unsafe"

	"github.com/daocloud/dsp-appserver/pkg/constants"

	"sigs.k8s.io/controller-runtime/pkg/client"
)

func BytesToString(b []byte) string {
	return *(*string)(unsafe.Pointer(&b))
}

// StringToBytes converts string to byte slice.
func StringToBytes(s string) []byte {
	return *(*[]byte)(unsafe.Pointer(
		&struct {
			string
			Cap int
		}{s, len(s)},
	))
}

func StructToString(s interface{}) string {
	data, err := json.Marshal(s)
	if err != nil {
		return err.Error()
	}
	return BytesToString(data)
}

func MarshalObj(obj client.Object) string {
	if obj == nil {
		return ""
	}
	obj.SetManagedFields(nil)
	return StructToString(obj)
}

func GetLoadResourceSchema(ctx context.Context) constants.LoadResourceSchema {
	schema, ok := ctx.Value(constants.LoadResourceSchemaKey).(constants.LoadResourceSchema)
	if !ok {
		return constants.ClusterPedia
	}

	return schema
}

func FetchReplicaSetRevision(annotations map[string]string) int64 {
	revision, _ := strconv.ParseInt(annotations[constants.WorkloadAnnotationRevision], 10, 64)
	return revision
}

func FetchDamonSetRevision(annotations map[string]string) int64 {
	revision, _ := strconv.ParseInt(annotations[constants.DaemonsetGenerationRevisionAnnation], 10, 64)
	return revision
}

func CheckURL(addr string) error {
	url, err := url.ParseRequestURI(addr)
	if err != nil {
		return fmt.Errorf("invalid 'url', got: %q, expected a valid url", addr)
	}

	if url.Scheme == "" {
		return fmt.Errorf("invalid 'url', got: %q, missing scheme", addr)
	}
	return nil
}
