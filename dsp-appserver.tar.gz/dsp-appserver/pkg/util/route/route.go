package route

import (
	"context"
	"fmt"

	routeapi "github.com/openshift/api/route/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"

	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
)

const (
	RoutePortAnnotation = "haproxy.router.openshift.io/external-tcp-port"
)

func CheckRoutePortAndHost(ctx context.Context, client clientset.Interface, route *routeapi.Route) error {

	var ol labels.Set
	ol = route.Annotations

	// 判断是否已经有route使用了该端口
	routeList, err := client.OpenshiftRouteV1().Routes(metav1.NamespaceAll).List(ctx, metav1.ListOptions{})
	if err != nil {
		return err
	}

	var l labels.Set
	found := ol.Has(RoutePortAnnotation)
	for _, r := range routeList.Items {
		// 更新时判断标准是名称，命名空间相等，这样就可以认为不需要检查
		if r.Name == route.Name && route.Namespace == r.Namespace {
			continue
		}
		l = r.Annotations
		if found {
			if l.Get(RoutePortAnnotation) == ol.Get(RoutePortAnnotation) {
				return fmt.Errorf("nodePort %s conflict with route %s/%s", ol.Get(RoutePortAnnotation), r.Namespace, r.Name)
			}
		}
		if r.Spec.Host == route.Spec.Host {
			return fmt.Errorf("host %s conflict with route %s/%s", r.Spec.Host, r.Namespace, r.Name)
		}
	}

	// 判断是否已经有svc使用了该端口
	svcList, err := client.CoreV1().Services(metav1.NamespaceAll).List(ctx, metav1.ListOptions{})
	if err != nil {
		return err
	}

	for _, svc := range svcList.Items {
		for _, port := range svc.Spec.Ports {
			if ol.Get(RoutePortAnnotation) == fmt.Sprint(port.NodePort) {
				return fmt.Errorf("nodePort %s conflic with service %s", ol.Get(RoutePortAnnotation), svc.Name)
			}
		}
	}
	return nil
}
