package route

import (
	routeapi "github.com/openshift/api/route/v1"
)

func HasIngressOwnerRef(route routeapi.Route) (string, bool) {
	for _, ref := range route.OwnerReferences {
		if ref.Kind != "Ingress" || ref.APIVersion != "extensions/v1beta1" || ref.Controller == nil || !*ref.Controller {
			continue
		}
		return ref.Name, true
	}
	return "", false
}
