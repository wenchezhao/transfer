package buildoptions

import (
	"fmt"
	"strconv"
	"strings"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util"
)

var _ BuildListOptionsInterface = &buildPGOptions{}

type buildPGOptions struct{}

// Role includes control-plane and worker.
type NodeStatus_Role int32

const (
	// This is only a meaningless placeholder, to avoid zero not return.
	NodeStatus_NODE_ROLE_UNSPECIFIED NodeStatus_Role = 0
	// The control plane manages the worker nodes and the Pods in the cluster.
	NodeStatus_CONTROL_PLANE NodeStatus_Role = 1
	// The worker node(s) host the Pods that are the components of the
	// application workload.
	NodeStatus_WORKER NodeStatus_Role = 2
)

func NewBuildPGOptions() BuildListOptionsInterface {
	return &buildPGOptions{}
}

func (b *buildPGOptions) BuildClusterListOptions(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string) {
	if listOptions == nil {
		return metav1.ListOptions{}, map[string]string{}
	}
	optBuilder := util.BuildListOptionsByQueryPage(listOptions.QueryPage)
	optBuilder.Clusters(constants.GlobalCluster)
	var sb strings.Builder
	if listOptions.Scope != nil {
		if _, ok := listOptions.Scope["*"]; !ok {
			for cluster := range listOptions.Scope {
				if cluster != "" {
					optBuilder = optBuilder.Names(string(cluster))
				}
			}
		}
		// TODO Check whether status is running when updating
		if listOptions.QueryPage != nil {
			if _, ok := getSearchParam(listOptions, util.SearchParamIsVirtualCluster); ok {
				sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
					column: "object",
					keys:   []string{"metadata", "labels", clusterv1alpha1.VirtualClusterLabelKey},
					not:    true,
				}))
				sb.WriteString(" AND ")
			}

			if fuzzyName, ok := getSearchParam(listOptions, util.SearchParamFuzzyName); ok {
				sb.WriteString(fmt.Sprintf("( ( name like '%%%s%%' )", fuzzyName))
				sb.WriteString(" OR ")
				sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
					column: "object",
					keys:   []string{"metadata", "annotations", constants.AliasNameAnnotation},
					like:   true,
					values: []string{fmt.Sprintf("%%%s%%", fuzzyName)},
				}))
				sb.WriteString(" ) ")
				sb.WriteString(" AND ")
			}

			if kubernetesVersion, ok := getSearchParam(listOptions, util.SearchParamKubernetesVersion); ok {
				sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
					column: "object",
					keys:   []string{"status", "kubernetesVersion"},
					like:   true,
					values: []string{fmt.Sprintf("%%%s%%", kubernetesVersion)},
				}))
				sb.WriteString(" AND ")
			}

			if managedBy, ok := getSearchParam(listOptions, util.SearchParamManagedBy); ok {
				sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
					column: "object",
					keys:   []string{"metadata", "labels", constants.ManagedByLabelKey},
					like:   true,
					values: []string{fmt.Sprintf("%%%s%%", managedBy)},
				}))
				sb.WriteString(" AND ")
			}
			// TODO: 这里和业务耦合在了一起，为了发生错误，跳过其中一个判断
			// listOptions.QueryPage.ClusterPhase != "" && listOptions.QueryPage.ClusterPhase != kpandaclusterv1alpha1.ClusterPhase_CLUSTER_PHASE_UNSPECIFIED.String()
			if listOptions.QueryPage.ClusterPhase != "" {
				if listOptions.QueryPage.ClusterPhase != clusterv1alpha1.ClusterConditionUnknown.String() {
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column:   "object",
						keys:     []string{"status", "conditions"},
						contains: true,
						values:   []string{fmt.Sprintf("[{\"type\": \"%s\",\"status\": \"True\"}]", listOptions.QueryPage.ClusterPhase)},
					}))
				} else {
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column:   "object",
						keys:     []string{"status", "conditions"},
						contains: true,
						values:   []string{fmt.Sprintf("[{\"type\": \"%s\",\"status\": \"False\"}]", clusterv1alpha1.ClusterConditionRunning)},
					}))
					sb.WriteString(" AND NOT ")
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column:   "object",
						keys:     []string{"status", "conditions"},
						contains: true,
						values:   []string{fmt.Sprintf("[{\"type\": \"%s\",\"status\": \"True\"}]", clusterv1alpha1.ClusterConditionFailed)},
					}))
					sb.WriteString(" AND NOT ")
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column:   "object",
						keys:     []string{"status", "conditions"},
						contains: true,
						values:   []string{fmt.Sprintf("[{\"type\": \"%s\",\"status\": \"True\"}]", clusterv1alpha1.ClusterConditionCreating)},
					}))
					sb.WriteString(" OR ")
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column:   "object",
						keys:     []string{"status", "conditions"},
						contains: true,
						values:   []string{fmt.Sprintf("[{\"type\": \"%s\",\"status\": \"True\"}]", clusterv1alpha1.ClusterConditionUnknown)},
					}))
				}
			}
		}
	}
	sql := strings.TrimRight(sb.String(), "OR ")
	sql = strings.TrimRight(sql, "AND ")
	return optBuilder.Options(), map[string]string{"whereSQL": sql}
}

func (b *buildPGOptions) BuildNodeListOptions(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string) {
	if listOptions == nil {
		return metav1.ListOptions{}, map[string]string{}
	}
	optBuilder := util.BuildListOptionsByQueryPage(listOptions.QueryPage)
	var sb strings.Builder
	if listOptions.Scope != nil && len(listOptions.Scope) <= 1 {
		if _, ok := listOptions.Scope["*"]; !ok {
			for cluster := range listOptions.Scope {
				if len(cluster) > 0 {
					optBuilder = optBuilder.Clusters(string(cluster))
				}
			}
		}
		if listOptions.QueryPage != nil {
			if listOptions.QueryPage.NodePhases != nil {
				for idx, nodephase := range listOptions.QueryPage.NodePhases {
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column:   "object",
						keys:     []string{"status", "conditions"},
						contains: true,
						values:   []string{fmt.Sprintf("[{\"type\": \"Ready\",\"status\": \"%s\"}]", nodephase)},
					}))

					if idx != len(listOptions.QueryPage.NodePhases)-1 {
						sb.WriteString(" OR ")
					} else {
						sb.WriteString(" AND ")
					}
				}
			}
			if listOptions.QueryPage.NodeIps != "" {
				sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
					column:   "object",
					keys:     []string{"status", "addresses"},
					contains: true,
					values:   []string{fmt.Sprintf("[{\"type\": \"InternalIP\",\"address\": \"%s\"}]", listOptions.QueryPage.NodeIps)},
				}))
				sb.WriteString(" AND ")
			}

			if fuzzyName, ok := getSearchParam(listOptions, util.SearchParamFuzzyName); ok {
				sb.WriteString(fmt.Sprintf("( name like '%%%s%%' )", fuzzyName))
				sb.WriteString(" AND ")
			}

			nodeRole, exist := listOptions.QueryPage.Params[util.SearchParamNodeRole]
			role, ok := nodeRole.(NodeStatus_Role)
			if ok && exist && role != NodeStatus_NODE_ROLE_UNSPECIFIED {
				sb.WriteString("( ")
				switch role {
				case NodeStatus_CONTROL_PLANE:
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column: "object",
						keys:   []string{"metadata", "labels", constants.ControllerLabelKey},
					}))
					sb.WriteString(" OR ")
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column: "object",
						keys:   []string{"metadata", "labels", constants.MasterLabelKey},
					}))
				case NodeStatus_WORKER:
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column: "object",
						keys:   []string{"metadata", "labels", constants.WorkerLabelKey},
					}))
					sb.WriteString(" OR ")
					sb.WriteString("( ")
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column: "object",
						keys:   []string{"metadata", "labels", constants.ControllerLabelKey},
						not:    true,
					}))
					sb.WriteString(" AND ")
					sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
						column: "object",
						keys:   []string{"metadata", "labels", constants.MasterLabelKey},
						not:    true,
					}))
					sb.WriteString(" )")
				}
				sb.WriteString(" )")
			}
		}
	}

	sql := strings.TrimRight(sb.String(), "OR ")
	sql = strings.TrimRight(sql, "AND ")
	return optBuilder.Options(), map[string]string{"whereSQL": sql}
}

func (b *buildPGOptions) BuildListNamespacesListOptionsAndParams(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string) {
	if listOptions == nil {
		return metav1.ListOptions{}, map[string]string{}
	}

	optBuilder := util.BuildListOptionsByQueryPage(listOptions.QueryPage)

	sb := strings.Builder{}
	if listOptions.QueryPage != nil {
		if _, unassigned := getSearchParam(listOptions, util.SearchParamWorkspaceUnassigned); unassigned {
			sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
				column: "object",
				keys:   []string{"metadata", "annotations", constants.WorkspaceAliasAnnotations},
				not:    true,
			}))
			sb.WriteString(" AND ")
		} else {
			if workspaceAlias, ok := getSearchParam(listOptions, util.SearchParamWorkspaceAlias); ok {
				sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
					column: "object",
					keys:   []string{"metadata", "annotations", constants.WorkspaceAliasAnnotations},
					like:   true,
					values: []string{fmt.Sprintf("%%%s%%", workspaceAlias)},
				}))
				sb.WriteString(" AND ")
			}
		}

		if _, excludeSystemNamespace := getSearchParam(listOptions, util.SearchParamExcludeSystem); excludeSystemNamespace {
			sb.WriteString("(name NOT IN (")
			for idx, ns := range constants.SystemNamespaces {
				sb.WriteString(fmt.Sprintf(`'%s'`, ns))
				if idx != len(constants.SystemNamespaces)-1 {
					sb.WriteString(",")
				}
			}
			sb.WriteString(")) AND ")
		}

		if fuzzyName, ok := getSearchParam(listOptions, util.SearchParamFuzzyName); ok {
			sb.WriteString(fmt.Sprintf("( name like '%%%s%%' )", fuzzyName))
			sb.WriteString(" AND ")
		}

		virtualClusterNames, exist := listOptions.QueryPage.Params[util.SearchParamNonVirtualCluster]
		virtualClusters, ok := virtualClusterNames.([]string)
		if exist && ok && len(virtualClusters) > 0 {
			sb.WriteString("cluster NOT IN (")
			for idx, cluster := range virtualClusters {
				sb.WriteString(fmt.Sprintf(`'%s'`, cluster))
				if idx != len(virtualClusters)-1 {
					sb.WriteString(",")
				}
			}
			sb.WriteString(") AND ")
		}

		if listOptions.QueryPage.Phase != "" {
			sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
				column: "object",
				keys:   []string{"status", "phase"},
				values: []string{listOptions.QueryPage.Phase},
			}))
			sb.WriteString(" AND ")
		}
	}

	if listOptions.Scope != nil {
		optBuilder = ListNamespaceScope(&sb, listOptions, optBuilder)
	}

	sql := strings.TrimRight(sb.String(), "OR ")
	sql = strings.TrimRight(sql, "AND ")
	return optBuilder.Options(), map[string]string{"whereSQL": sql}
}

func (b *buildPGOptions) BuildAcrossClustersListOptionsAndParams(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string) {
	if listOptions == nil {
		return metav1.ListOptions{}, map[string]string{}
	}
	optBuilder := util.BuildListOptionsByQueryPage(listOptions.QueryPage)

	var sb strings.Builder
	params := make(map[string]string)
	queryPage := listOptions.QueryPage
	if queryPage != nil {
		name := queryPage.Name
		if len(name) > 0 {
			switch queryPage.NameSearchType {
			case util.NameSearchTypeRoleBinding:
				sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
					column: "object",
					keys:   []string{"subjects", "0", "name"},
					values: []string{name},
				}))
				sb.WriteString(" AND ")
			}
		}

		if fuzzyName, ok := getSearchParam(listOptions, util.SearchParamFuzzyName); ok {
			sb.WriteString(fmt.Sprintf("( name like '%%%s%%' )", fuzzyName))
			sb.WriteString(" AND ")
		}

		virtualClusterNames, exist := listOptions.QueryPage.Params[util.SearchParamNonVirtualCluster]
		virtualClusters, ok := virtualClusterNames.([]string)
		if exist && ok && len(virtualClusters) > 0 {
			sb.WriteString("cluster NOT IN (")
			for idx, cluster := range virtualClusters {
				sb.WriteString(fmt.Sprintf(`'%s'`, cluster))
				if idx != len(virtualClusters)-1 {
					sb.WriteString(",")
				}
			}
			sb.WriteString(") AND ")
		}

		if roleRef, ok := getSearchParam(listOptions, util.SearchParamRoleRef); ok {
			sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
				column: "object",
				keys:   []string{"roleRef", "name"},
				values: []string{roleRef},
			}))
			sb.WriteString(" AND ")
		}

		if _, ok := getSearchParam(listOptions, util.SearchParamOnlyMetadata); ok {
			params[string(util.SearchParamOnlyMetadata)] = "true"
		}

		if secretType, ok := getSearchParam(listOptions, util.SearchParamSecretType); ok {
			sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
				column: "object",
				keys:   []string{"type"},
				like:   true,
				values: []string{fmt.Sprintf("%%%s%%", secretType)},
			}))
			sb.WriteString(" AND ")
		}

		if scProvisioner, ok := getSearchParam(listOptions, util.SearchParamSCProvisioner); ok {
			sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
				column: "object",
				keys:   []string{"provisioner"},
				like:   true,
				values: []string{fmt.Sprintf("%%%s%%", scProvisioner)},
			}))
			sb.WriteString(" AND ")
		}

		if scReclaimPolicy, ok := getSearchParam(listOptions, util.SearchParamSCReclaimPolicy); ok {
			sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
				column: "object",
				keys:   []string{"reclaimPolicy"},
				like:   true,
				values: []string{fmt.Sprintf("%%%s%%", scReclaimPolicy)},
			}))
			sb.WriteString(" AND ")
		}

		if pvcPhase, ok := getSearchParam(listOptions, util.SearchParamPVCPhase); ok {
			sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
				column: "object",
				keys:   []string{"status", "phase"},
				like:   true,
				values: []string{fmt.Sprintf("%%%s%%", pvcPhase)},
			}))
			sb.WriteString(" AND ")
		}

		if pvcAccessMode, ok := getSearchParam(listOptions, util.SearchParamPVCAccessMode); ok {
			sb.WriteString(getPostgresJSONQuery(JSONQueryExpression{
				column:   "object",
				keys:     []string{"spec", "accessModes"},
				contains: true,
				values:   []string{fmt.Sprintf("\"%s\"", pvcAccessMode)},
			}))
			sb.WriteString(" AND ")
		}
	}

	if listOptions.Scope != nil {
		optBuilder = ListAcrossClustersScope(&sb, listOptions, optBuilder)
	}

	sql := strings.TrimRight(sb.String(), "OR ")
	sql = strings.TrimRight(sql, "AND ")
	params["whereSQL"] = sql
	return optBuilder.Options(), params
}

type JSONQueryExpression struct {
	column string
	keys   []string

	like     bool
	not      bool
	contains bool
	values   []string

	// only for mysql
	unquote bool
}

func getPostgresJSONQuery(jsonQuery JSONQueryExpression) string {
	var sb strings.Builder
	jsonQuery.writePostgresJSONKey(&sb)
	switch len(jsonQuery.values) {
	case 0:
		if jsonQuery.not {
			sb.WriteString(" IS NULL")
		} else {
			sb.WriteString(" IS NOT NULL")
		}
	case 1:
		if jsonQuery.like {
			sb.WriteString(" LIKE ")
		} else if jsonQuery.contains {
			sb.WriteString(" @> ")
		} else {
			if jsonQuery.not {
				sb.WriteString(" != ")
			} else {
				sb.WriteString(" = ")
			}
		}
		sb.WriteString(writeQuoted(jsonQuery.values[0]))
	default:
		if jsonQuery.not {
			sb.WriteString(" NOT IN ")
		} else {
			sb.WriteString(" IN ")
		}
		sb.WriteString("(")
		sb.WriteString(strings.Join(jsonQuery.values, ","))
		sb.WriteString(")")
	}
	return sb.String()
}

func (jsonQuery *JSONQueryExpression) writePostgresJSONKey(sb *strings.Builder) {
	sb.WriteString(jsonQuery.column)
	for i := 0; i < len(jsonQuery.keys)-1; i++ {
		key := jsonQuery.keys[i]
		sb.WriteString("->")

		// case : getting JSON array elements. example: object->'subjects'->0 ->> 'name' = 'admin'.
		_, err := strconv.Atoi(key)
		if err == nil {
			sb.WriteString(key)
			continue
		}
		sb.WriteString(writeQuoted(key))
	}

	if jsonQuery.contains {
		sb.WriteString(" -> ")
	} else {
		sb.WriteString(" ->> ")
	}

	sb.WriteString(writeQuoted(jsonQuery.keys[len(jsonQuery.keys)-1]))
}

func writeQuoted(str string) string {
	return "'" + str + "'"
}
