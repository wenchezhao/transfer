package buildoptions

import (
	"fmt"
	"strings"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util"
)

var _ BuildListOptionsInterface = &buildDefaultOptions{}

type buildDefaultOptions struct{}

func NewDefaultOptions() BuildListOptionsInterface {
	return &buildDefaultOptions{}
}

func (d *buildDefaultOptions) BuildClusterListOptions(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string) {
	if listOptions == nil {
		return metav1.ListOptions{}, map[string]string{}
	}
	optBuilder := util.BuildListOptionsByQueryPage(listOptions.QueryPage)
	optBuilder.Clusters(constants.GlobalCluster)
	var sb strings.Builder
	if listOptions.Scope != nil {
		if _, ok := listOptions.Scope["*"]; !ok {
			for cluster := range listOptions.Scope {
				if cluster != "" {
					optBuilder = optBuilder.Names(string(cluster))
				}
			}
		}

		if listOptions.QueryPage != nil {
			if fuzzyName, ok := getSearchParam(listOptions, util.SearchParamFuzzyName); ok {
				sb.WriteString(fmt.Sprintf("( name like '%%%s%%' )", fuzzyName))
				sb.WriteString(" AND ")
			}
		}
	}
	sql := strings.TrimRight(sb.String(), "OR ")
	sql = strings.TrimRight(sql, "AND ")
	return optBuilder.Options(), map[string]string{"whereSQL": sql}
}

func (d *buildDefaultOptions) BuildNodeListOptions(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string) {
	if listOptions == nil {
		return metav1.ListOptions{}, map[string]string{}
	}
	optBuilder := util.BuildListOptionsByQueryPage(listOptions.QueryPage)
	var sb strings.Builder
	if listOptions.Scope != nil && len(listOptions.Scope) <= 1 {
		if _, ok := listOptions.Scope["*"]; !ok {
			for cluster := range listOptions.Scope {
				if len(cluster) > 0 {
					optBuilder = optBuilder.Clusters(string(cluster))
				}
			}
		}
		if listOptions.QueryPage != nil {
			if fuzzyName, ok := getSearchParam(listOptions, util.SearchParamFuzzyName); ok {
				sb.WriteString(fmt.Sprintf("( name like '%%%s%%' )", fuzzyName))
				sb.WriteString(" AND ")
			}
		}
	}

	sql := strings.TrimRight(sb.String(), "OR ")
	sql = strings.TrimRight(sql, "AND ")
	return optBuilder.Options(), map[string]string{"whereSQL": sql}
}

func (d *buildDefaultOptions) BuildListNamespacesListOptionsAndParams(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string) {
	if listOptions == nil {
		return metav1.ListOptions{}, map[string]string{}
	}

	optBuilder := util.BuildListOptionsByQueryPage(listOptions.QueryPage)

	sb := strings.Builder{}
	if listOptions.QueryPage != nil {
		if fuzzyName, ok := getSearchParam(listOptions, util.SearchParamFuzzyName); ok {
			sb.WriteString(fmt.Sprintf("( name like '%%%s%%' )", fuzzyName))
			sb.WriteString(" AND ")
		}

		virtualClusterNames, exist := listOptions.QueryPage.Params[util.SearchParamNonVirtualCluster]
		virtualClusters, ok := virtualClusterNames.([]string)
		if exist && ok && len(virtualClusters) > 0 {
			sb.WriteString("cluster NOT IN (")
			for idx, cluster := range virtualClusters {
				sb.WriteString(fmt.Sprintf(`'%s'`, cluster))
				if idx != len(virtualClusters)-1 {
					sb.WriteString(",")
				}
			}
			sb.WriteString(") AND ")
		}
	}

	if listOptions.Scope != nil {
		optBuilder = ListNamespaceScope(&sb, listOptions, optBuilder)
	}

	sql := strings.TrimRight(sb.String(), "OR ")
	sql = strings.TrimRight(sql, "AND ")
	return optBuilder.Options(), map[string]string{"whereSQL": sql}
}

func (d *buildDefaultOptions) BuildAcrossClustersListOptionsAndParams(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string) {
	if listOptions == nil {
		return metav1.ListOptions{}, map[string]string{}
	}
	optBuilder := util.BuildListOptionsByQueryPage(listOptions.QueryPage)

	var sb strings.Builder
	params := make(map[string]string)
	queryPage := listOptions.QueryPage
	if queryPage != nil {
		if fuzzyName, ok := getSearchParam(listOptions, util.SearchParamFuzzyName); ok {
			sb.WriteString(fmt.Sprintf("( name like '%%%s%%' )", fuzzyName))
			sb.WriteString(" AND ")
		}

		virtualClusterNames, exist := listOptions.QueryPage.Params[util.SearchParamNonVirtualCluster]
		virtualClusters, ok := virtualClusterNames.([]string)
		if exist && ok && len(virtualClusters) > 0 {
			sb.WriteString("cluster NOT IN (")
			for idx, cluster := range virtualClusters {
				sb.WriteString(fmt.Sprintf(`'%s'`, cluster))
				if idx != len(virtualClusters)-1 {
					sb.WriteString(",")
				}
			}
			sb.WriteString(") AND ")
		}

		if _, ok := getSearchParam(listOptions, util.SearchParamOnlyMetadata); ok {
			params[string(util.SearchParamOnlyMetadata)] = "true"
		}
	}

	if listOptions.Scope != nil {
		optBuilder = ListAcrossClustersScope(&sb, listOptions, optBuilder)
	}

	sql := strings.TrimRight(sb.String(), "OR ")
	sql = strings.TrimRight(sql, "AND ")
	params["whereSQL"] = sql
	return optBuilder.Options(), params
}
