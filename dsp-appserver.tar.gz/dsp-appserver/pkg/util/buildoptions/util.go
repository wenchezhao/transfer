package buildoptions

import (
	"strings"

	"github.com/clusterpedia-io/client-go/tools/builder"

	"github.com/daocloud/dsp-appserver/pkg/util"
)

func ListNamespaceScope(sb *strings.Builder, listOptions *util.ListOptions, optBuilder builder.ListOptionsInterface) builder.ListOptionsInterface {
	if _, ok := listOptions.Scope["*"]; ok {
		namespaces := util.FilterStrings(listOptions.Scope["*"])
		if len(namespaces) > 0 {
			optBuilder = optBuilder.Names(namespaces...)
		}
	} else {
		index := 0
		for cluster := range listOptions.Scope {
			index++
			if index == 1 {
				sb.WriteString("(")
			}
			sb.WriteString("( cluster = '")
			sb.WriteString(string(cluster))
			sb.WriteString("'")
			namespaces := util.FilterStrings(listOptions.Scope[cluster])
			switch len(namespaces) {
			case 0:
			case 1:
				sb.WriteString(" AND name = '")
				sb.WriteString(namespaces[0])
				sb.WriteString("'")
			default:
				sb.WriteString(" AND name in (")
				for i, ns := range namespaces {
					sb.WriteString("'")
					sb.WriteString(ns)
					sb.WriteString("'")
					if i != len(namespaces)-1 {
						sb.WriteString(",")
					}
				}
				sb.WriteString(")")
			}
			if index == len(listOptions.Scope) {
				sb.WriteString(" ))")
			} else {
				sb.WriteString(" ) OR ")
			}
		}
	}
	return optBuilder
}

func ListAcrossClustersScope(sb *strings.Builder, listOptions *util.ListOptions, optBuilder builder.ListOptionsInterface) builder.ListOptionsInterface {
	if _, ok := listOptions.Scope["*"]; ok {
		namespaces := util.FilterStrings(listOptions.Scope["*"])
		if len(namespaces) > 0 {
			optBuilder = optBuilder.Namespaces(namespaces...)
		}
	} else {
		index := 0
		for cluster := range listOptions.Scope {
			index++
			if index == 1 {
				sb.WriteString("(")
			}
			sb.WriteString("( cluster = '")
			sb.WriteString(string(cluster))
			sb.WriteString("'")
			namespaces := util.FilterStrings(listOptions.Scope[cluster])
			switch len(namespaces) {
			case 0:
			case 1:
				sb.WriteString(" AND namespace = '")
				sb.WriteString(namespaces[0])
				sb.WriteString("'")
			default:
				sb.WriteString(" AND namespace in (")
				for i, ns := range namespaces {
					sb.WriteString("'")
					sb.WriteString(ns)
					sb.WriteString("'")
					if i != len(namespaces)-1 {
						sb.WriteString(",")
					}
				}
				sb.WriteString(")")
			}
			if index == len(listOptions.Scope) {
				sb.WriteString(" ))")
			} else {
				sb.WriteString(" ) OR ")
			}
		}
	}

	return optBuilder
}

func getSearchParam(listOptions *util.ListOptions, param util.SearchParam) (string, bool) {
	values, exist := listOptions.QueryPage.Params[param]
	switch param {
	case util.SearchParamIsVirtualCluster:
		isVirtualClusterBool, ok := values.(bool)
		if !exist || !ok || !isVirtualClusterBool {
			return "", true
		}
	default:
		if !exist {
			return "", false
		}

		switch val := values.(type) {
		case string:
			if len(val) > 0 {
				return val, true
			}
		case bool:
			if val {
				return "", true
			}
		}
	}
	return "", false
}
