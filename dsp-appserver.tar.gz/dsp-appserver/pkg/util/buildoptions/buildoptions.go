package buildoptions

import (
	"strings"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/klog/v2"

	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util"
)

type BuildListOptionsInterface interface {
	BuildClusterListOptions(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string)
	BuildNodeListOptions(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string)
	BuildListNamespacesListOptionsAndParams(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string)
	BuildAcrossClustersListOptionsAndParams(listOptions *util.ListOptions) (metav1.ListOptions, map[string]string)
}

var buildListOptions = NewDefaultOptions()

func GetBuildListOptions() BuildListOptionsInterface {
	if buildListOptions == nil {
		klog.Exitf("failed to get list options")
	}

	return buildListOptions
}

func NewBuildListOptions(driver string) BuildListOptionsInterface {
	switch strings.ToLower(driver) {
	case constants.MYSQL:
		buildListOptions = NewBuildMYSQLOptions()
	case constants.Postgres:
		buildListOptions = NewBuildPGOptions()
	default:
		buildListOptions = NewDefaultOptions()
	}
	return buildListOptions
}
