package buildoptions

import (
	"reflect"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/util"
)

type want struct {
	opt    metav1.ListOptions
	params map[string]string
}

func Test_BuildClusterListOptions(t *testing.T) {
	tests := []struct {
		name     string
		input    *util.ListOptions
		builders map[BuildListOptionsInterface]want
	}{
		{
			name: "virtual cluster",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: false},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "(JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"labels\".\"cluster.kpanda.io/virtual\"')) IS NULL)"},
				},
			},
		},
		{
			name: "fuzzy name",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamFuzzyName: "kpanda"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "(JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"labels\".\"cluster.kpanda.io/virtual\"')) IS NULL) AND ( ( name like '%kpanda%' ) OR (JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"annotations\".\"kpanda.io/alias-name\"')) LIKE '%kpanda%') )"},
				},
			},
		},
		{
			name: "k8s version",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: true, util.SearchParamKubernetesVersion: "v1.23"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "(JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"status\".\"kubernetesVersion\"')) LIKE '%v1.23%')"},
				},
			},
		},
		{
			name: "manager by",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: true, util.SearchParamManagedBy: "kpanda"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "(JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"labels\".\"kpanda.io/managed-by\"')) LIKE '%kpanda%')"},
				},
			},
		},
		{
			name: "cluster running",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					ClusterPhase: "Running",
					Params:       map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: true},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "(JSON_CONTAINS(object,'{\"type\": \"Running\",\"status\": \"True\"}','$.status.conditions'))"},
				},
			},
		},
		{
			name: "cluster Updating",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					ClusterPhase: "Updating",
					Params:       map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: true},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "(JSON_CONTAINS(object,'{\"type\": \"Updating\",\"status\": \"True\"}','$.status.conditions'))"},
				},
			},
		},
		{
			name: "cluster Creating",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					ClusterPhase: "Creating",
					Params:       map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: true},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "(JSON_CONTAINS(object,'{\"type\": \"Creating\",\"status\": \"True\"}','$.status.conditions'))"},
				},
			},
		},
		{
			name: "cluster Deleting",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					ClusterPhase: "Deleting",
					Params:       map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: true},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "(JSON_CONTAINS(object,'{\"type\": \"Deleting\",\"status\": \"True\"}','$.status.conditions'))"},
				},
			},
		},
		{
			name: "cluster unknown",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					ClusterPhase: "Unknown",
					Params:       map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: true},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "(JSON_CONTAINS(object,'{\"type\": \"Running\",\"status\": \"False\"}','$.status.conditions')) AND NOT (JSON_CONTAINS(object,'{\"type\": \"Failed\",\"status\": \"True\"}','$.status.conditions')) AND NOT (JSON_CONTAINS(object,'{\"type\": \"Creating\",\"status\": \"True\"}','$.status.conditions')) OR (JSON_CONTAINS(object,'{\"type\": \"Unknown\",\"status\": \"True\"}','$.status.conditions'))"},
				},
			},
		},
		{
			name:  "input is nil",
			input: nil,
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{},
				},
			},
		},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			for builder, want := range tc.builders {
				_, params := builder.BuildClusterListOptions(tc.input)
				if !reflect.DeepEqual(params, want.params) {
					t.Errorf("builder %#v expected:%#v, got:%#v", builder, want.params, params)
				}
			}
		})
	}
}

func Test_BuildNodeListOptions(t *testing.T) {
	queryPageNodePhase := &util.QueryPage{
		NodePhases: []string{"True"},
	}
	queryPageNodeIP := &util.QueryPage{
		NodeIps: "12.4.53.1",
	}
	tests := []struct {
		name     string
		input    *util.ListOptions
		builders map[BuildListOptionsInterface]want
	}{
		{
			name: "fuzzy name",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamFuzzyName: "kpanda"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "( name like '%kpanda%' )"},
				},
			},
		},
		{
			name: "node Ready",
			input: &util.ListOptions{
				QueryPage: queryPageNodePhase,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPageNodePhase).Clusters("cluster").Options(),
					params: map[string]string{"whereSQL": "(JSON_CONTAINS(object,'{\"type\": \"Ready\",\"status\": \"True\"}','$.status.conditions'))"},
				},
			},
		},
		{
			name: "node InternalIP",
			input: &util.ListOptions{
				QueryPage: queryPageNodeIP,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPageNodeIP).Clusters("cluster").Options(),
					params: map[string]string{"whereSQL": "(JSON_CONTAINS(object,'{\"type\": \"InternalIP\",\"address\": \"12.4.53.1\"}','$.status.addresses'))"},
				},
			},
		},
		{
			name: "node master role",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: true, util.SearchParamNodeRole: kpandacorev1alpha1.NodeStatus_CONTROL_PLANE},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPageNodeIP).Clusters("cluster").Options(),
					params: map[string]string{"whereSQL": "( (JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"labels\".\"node-role.kubernetes.io/control-plane\"')) IS NOT NULL) OR (JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"labels\".\"node-role.kubernetes.io/master\"')) IS NOT NULL) )"},
				},
			},
		},
		{
			name: "node worker role",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamIsVirtualCluster: true, util.SearchParamNodeRole: kpandacorev1alpha1.NodeStatus_WORKER},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPageNodeIP).Clusters("cluster").Options(),
					params: map[string]string{"whereSQL": "( (JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"labels\".\"node-role.kubernetes.io/worker\"')) IS NOT NULL) OR ( (JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"labels\".\"node-role.kubernetes.io/control-plane\"')) IS NULL) AND (JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"labels\".\"node-role.kubernetes.io/master\"')) IS NULL) ) )"},
				},
			},
		},
		{
			name:  "input is nil",
			input: nil,
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{},
				},
			},
		},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			for builder, want := range tc.builders {
				_, params := builder.BuildNodeListOptions(tc.input)
				if !reflect.DeepEqual(params, want.params) {
					t.Errorf("builder %#v expected:%#v, got:%#v", builder, want.params, params)
				}
			}
		})
	}
}

func Test_BuildListNamespacesListOptionsAndParams(t *testing.T) {
	queryPage := &util.QueryPage{
		Phase: "True",
	}
	excludeSystemQueryPage := &util.QueryPage{
		Params: map[util.SearchParam]interface{}{
			util.SearchParamExcludeSystem: true,
		},
	}

	workspaceUnassignedQueryPage := &util.QueryPage{
		Params: map[util.SearchParam]interface{}{
			util.SearchParamWorkspaceUnassigned: true,
		},
	}

	workspaceQueryPage := &util.QueryPage{
		Params: map[util.SearchParam]interface{}{
			util.SearchParamWorkspaceAlias: "kpanda",
		},
	}

	tests := []struct {
		name     string
		input    *util.ListOptions
		builders map[BuildListOptionsInterface]want
	}{
		{
			name: "specified cluster and ns phase true",
			input: &util.ListOptions{
				QueryPage: queryPage,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("cluster"): []string{"default"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPage).Options(),
					params: map[string]string{"whereSQL": "(object->'$.status.phase' = 'True') AND (( cluster = 'cluster' AND name = 'default' ))"},
				},
			},
		},
		{
			name: "ns phase true",
			input: &util.ListOptions{
				QueryPage: queryPage,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("*"): []string{"default"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPage).Names("default").Options(),
					params: map[string]string{"whereSQL": "(object->'$.status.phase' = 'True')"},
				},
			},
		},
		{
			name: "specified cluster, namespace and ns phase true",
			input: &util.ListOptions{
				QueryPage: queryPage,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("cluster"): []string{"default", "namespace"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPage).Options(),
					params: map[string]string{"whereSQL": "(object->'$.status.phase' = 'True') AND (( cluster = 'cluster' AND name in ('default','namespace') ))"},
				},
			},
		},
		{
			name: "exclude system ns",
			input: &util.ListOptions{
				QueryPage: excludeSystemQueryPage,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("cluster"): []string{"default", "namespace"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(excludeSystemQueryPage).Options(),
					params: map[string]string{"whereSQL": "(name NOT IN ('default','kube-system','kube-public','kube-node-lease')) AND (( cluster = 'cluster' AND name in ('default','namespace') ))"},
				},
			},
		},
		{
			name: "search for ns  without bound to ws",
			input: &util.ListOptions{
				QueryPage: workspaceUnassignedQueryPage,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("cluster"): []string{"default", "namespace"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(workspaceUnassignedQueryPage).Options(),
					params: map[string]string{"whereSQL": "(JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"annotations\".\"workspace.ghippo.io/alias\"')) IS NULL) AND (( cluster = 'cluster' AND name in ('default','namespace') ))"},
				},
			},
		},
		{
			name: "search for ns bound to ws",
			input: &util.ListOptions{
				QueryPage: workspaceQueryPage,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("cluster"): []string{"default", "namespace"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(workspaceQueryPage).Options(),
					params: map[string]string{"whereSQL": "(JSON_UNQUOTE(JSON_EXTRACT(`object`,'$.\"metadata\".\"annotations\".\"workspace.ghippo.io/alias\"')) LIKE '%kpanda%') AND (( cluster = 'cluster' AND name in ('default','namespace') ))"},
				},
			},
		},
		{
			name: "fuzzy name",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamFuzzyName: "kpanda"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "( name like '%kpanda%' ) AND (( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name: "no virtual cluster",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamNonVirtualCluster: []string{"member1", "member2"}},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{"whereSQL": "cluster NOT IN ('member1','member2') AND (( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name:  "input is nil",
			input: nil,
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{},
				},
			},
		},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			for builder, want := range tc.builders {
				opt, params := builder.BuildListNamespacesListOptionsAndParams(tc.input)
				if !reflect.DeepEqual(opt, want.opt) {
					t.Errorf("builder %#v expected:%#v, got:%#v", builder, want.opt, opt)
				}
				if !reflect.DeepEqual(params, want.params) {
					t.Errorf("builder %#v expected:%#v, got:%#v", builder, want.params, params)
				}
			}
		})
	}
}

func Test_BuildAcrossClustersListOptionsAndParams(t *testing.T) {
	queryPage := &util.QueryPage{
		Phase: "True",
	}
	tests := []struct {
		name     string
		input    *util.ListOptions
		builders map[BuildListOptionsInterface]want
	}{
		{
			name:  "input is nil",
			input: nil,
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					params: map[string]string{},
				},
			},
		},
		{
			name: "single cluster with namespace specified",
			input: &util.ListOptions{
				QueryPage: queryPage,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("cluster"): []string{"default"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPage).Options(),
					params: map[string]string{"whereSQL": "(( cluster = 'cluster' AND namespace = 'default' ))"},
				},
			},
		},
		{
			name: "multiple clusters with namespace specified",
			input: &util.ListOptions{
				QueryPage: queryPage,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("*"): []string{"default"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPage).Namespaces("default").Options(),
					params: map[string]string{"whereSQL": ""},
				},
			},
		},
		{
			name: "multiple clusters and namespaces",
			input: &util.ListOptions{
				QueryPage: queryPage,
				Scope:     map[util.Cluster]util.Namespaces{util.Cluster("cluster"): []string{"default", "namespace"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt:    util.BuildListOptionsByQueryPage(queryPage).Options(),
					params: map[string]string{"whereSQL": "(( cluster = 'cluster' AND namespace in ('default','namespace') ))"},
				},
			},
		},
		{
			name: "search type role binding",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Name:           "kpanda",
					NameSearchType: util.NameSearchTypeRoleBinding,
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): []string{"default", "namespace"}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Name:           "kpanda",
						NameSearchType: util.NameSearchTypeRoleBinding,
					}).Options(),
					params: map[string]string{"whereSQL": "(object->'$.subjects[0].name' = 'kpanda') AND (( cluster = 'cluster' AND namespace in ('default','namespace') ))"},
				},
			},
		},
		{
			name: "fuzzy name",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamFuzzyName: "kpanda"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Params: map[util.SearchParam]interface{}{util.SearchParamFuzzyName: "kpanda"},
					}).Options(),
					params: map[string]string{"whereSQL": "( name like '%kpanda%' ) AND (( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name: "no virtual cluster",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamNonVirtualCluster: []string{"member1", "member2"}},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Params: map[util.SearchParam]interface{}{util.SearchParamNonVirtualCluster: []string{"member1", "member2"}},
					}).Options(),
					params: map[string]string{"whereSQL": "cluster NOT IN ('member1','member2') AND (( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name: "role ref",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamRoleRef: "kpanda"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Params: map[util.SearchParam]interface{}{util.SearchParamRoleRef: "kpanda"},
					}).Options(),
					params: map[string]string{"whereSQL": "(object->'$.roleRef.name' = 'kpanda') AND (( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name: "only metadata",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamOnlyMetadata: true},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Params: map[util.SearchParam]interface{}{util.SearchParamOnlyMetadata: true},
					}).Options(),
					params: map[string]string{"onlyMetadata": "true", "whereSQL": "(( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name: "secret type",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamSecretType: "Opaque"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Params: map[util.SearchParam]interface{}{util.SearchParamSecretType: "Opaque"},
					}).Options(),
					params: map[string]string{"whereSQL": "(object->'$.type' LIKE '%Opaque%') AND (( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name: "sc provisioner",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamSCProvisioner: "kpanda"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Params: map[util.SearchParam]interface{}{util.SearchParamSCProvisioner: "kpanda"},
					}).Options(),
					params: map[string]string{"whereSQL": "(object->'$.provisioner' LIKE '%kpanda%') AND (( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name: "sc reclaim policy",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamSCReclaimPolicy: "Delete"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Params: map[util.SearchParam]interface{}{util.SearchParamSCReclaimPolicy: "Delete"},
					}).Options(),
					params: map[string]string{"whereSQL": "(object->'$.reclaimPolicy' LIKE '%Delete%') AND (( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name: "pvc phase",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamPVCPhase: "Bound"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Params: map[util.SearchParam]interface{}{util.SearchParamRoleRef: "Bound"},
					}).Options(),
					params: map[string]string{"whereSQL": "(object->'$.status.phase' LIKE '%Bound%') AND (( cluster = 'cluster' ))"},
				},
			},
		},
		{
			name: "pvc access mode",
			input: &util.ListOptions{
				QueryPage: &util.QueryPage{
					Params: map[util.SearchParam]interface{}{util.SearchParamPVCAccessMode: "ReadWriteOnce"},
				},
				Scope: map[util.Cluster]util.Namespaces{util.Cluster("cluster"): {}},
			},
			builders: map[BuildListOptionsInterface]want{
				NewBuildMYSQLOptions(): {
					opt: util.BuildListOptionsByQueryPage(&util.QueryPage{
						Params: map[util.SearchParam]interface{}{util.SearchParamRoleRef: "ReadWriteOnce"},
					}).Options(),
					params: map[string]string{"whereSQL": "(JSON_CONTAINS(object,'\"ReadWriteOnce\"','$.spec.accessModes')) AND (( cluster = 'cluster' ))"},
				},
			},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			for builder, want := range tc.builders {
				opt, params := builder.BuildAcrossClustersListOptionsAndParams(tc.input)
				if !reflect.DeepEqual(opt, want.opt) {
					t.Errorf("builder %#v expected:%#v, got:%#v", builder, want.opt, opt)
				}
				if !reflect.DeepEqual(params, want.params) {
					t.Errorf("builder %#v expected:%#v, got:%#v", builder, want.params, params)
				}
			}
		})
	}
}
