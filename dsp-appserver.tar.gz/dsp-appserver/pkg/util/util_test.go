package util

import (
	"context"
	"reflect"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/constants"

	corev1 "k8s.io/api/core/v1"
	"sigs.k8s.io/controller-runtime/pkg/client"
)

func TestBytesToString(t *testing.T) {
	tests := []struct {
		args []byte
		want string
	}{
		{
			args: []byte("kpanda"),
			want: "kpanda",
		},
	}

	for _, tt := range tests {
		t.Run(tt.want, func(t *testing.T) {
			if got := BytesToString(tt.args); got != tt.want {
				t.Errorf("BytesToString() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_GetLoadResourceSchema(t *testing.T) {
	tests := []struct {
		name string
		in   context.Context
		out  constants.LoadResourceSchema
	}{
		{
			name: "test GetLoadResourceSchema normal",
			in:   context.WithValue(context.TODO(), constants.LoadResourceSchemaKey, constants.LoadResourceSchemaKey),
			out:  constants.LoadResourceSchemaKey,
		},
		{
			name: "test GetLoadResourceSchema false",
			in:   context.TODO(),
			out:  constants.ClusterPedia,
		},
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			value := GetLoadResourceSchema(v.in)
			if value != v.out {
				t.Errorf("return value %v not equal to %v", value, v.out)
			}
		})
	}
}

func Test_FetchReplicaSetRevision(t *testing.T) {
	tests := []struct {
		name string
		in   map[string]string
		out  int64
	}{
		{
			name: "test FetchReplicaSetRevision",
			in: map[string]string{
				constants.WorkloadAnnotationRevision: "100",
			},
			out: 100,
		},
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			value := FetchReplicaSetRevision(v.in)
			if value != v.out {
				t.Errorf("return value %v not equal to %v", value, v.out)
			}
		})
	}
}

func TestFetchDamonSetRevision(t *testing.T) {
	type args struct {
		annotations map[string]string
	}
	tests := []struct {
		name string
		args args
		want int64
	}{
		{
			name: "deprecated.daemonset.template.generation is 1000",
			args: args{
				annotations: map[string]string{
					constants.DaemonsetGenerationRevisionAnnation: "1000",
				},
			},
			want: 1000,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := FetchDamonSetRevision(tt.args.annotations); got != tt.want {
				t.Errorf("FetchDamonSetRevision() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestStringToBytes(t *testing.T) {
	type args struct {
		s string
	}
	tests := []struct {
		name string
		args args
		want []byte
	}{
		{
			name: "test1",
			args: args{
				"foo",
			},
			want: []byte{102, 111, 111},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := StringToBytes(tt.args.s); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("StringToBytes() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestStructToString(t *testing.T) {
	var arg interface{}
	type args struct {
		s interface{}
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "test1",
			args: args{
				arg,
			},
			want: "null",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := StructToString(tt.args.s); got != tt.want {
				t.Errorf("StructToString() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestMarshalObj(t *testing.T) {
	type args struct {
		obj client.Object
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "obj is null",
			args: args{obj: nil},
			want: "",
		},
		{
			name: "obj is valid",
			args: args{obj: &corev1.Pod{}},
			want: `{"metadata":{"creationTimestamp":null},"spec":{"containers":null},"status":{}}`,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := MarshalObj(tt.args.obj); got != tt.want {
				t.Errorf("MarshalObj() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_checkURL(t *testing.T) {
	type args struct {
		addr string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "test missing scheme",
			args: args{
				addr: "example.com",
			},
			wantErr: true,
		},
		{
			name: "test valid fqdn",
			args: args{
				addr: "http://example.com",
			},
			wantErr: false,
		},
		{
			name: "test test bad fqdn",
			args: args{
				addr: ":::::",
			},
			wantErr: true,
		},
		{
			name: "test valid fqdn with path",
			args: args{
				addr: "http://example.com/foo/bar",
			},
			wantErr: false,
		},
		{
			name: "test valid hostname",
			args: args{
				addr: "http://example",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := CheckURL(tt.args.addr)
			if (err != nil) != tt.wantErr {
				t.Errorf("checkURL() = %v ", err)
			}
		})
	}
}
