package promhttp

import (
	"bytes"
	"compress/gzip"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"

	"github.com/gin-gonic/gin"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/prometheus/common/expfmt"

	"github.com/daocloud/dsp-appserver/pkg/logi"
)

var log = logi.Log.Sugar()

const (
	contentTypeHeader     = "Content-Type"
	contentLengthHeader   = "Content-Length"
	contentEncodingHeader = "Content-Encoding"
	acceptEncodingHeader  = "Accept-Encoding"
)

var bufPool sync.Pool

func getBuf() *bytes.Buffer {
	buf := bufPool.Get()
	if buf == nil {
		return &bytes.Buffer{}
	}
	return buf.(*bytes.Buffer)
}

func giveBuf(buf *bytes.Buffer) {
	buf.Reset()
	bufPool.Put(buf)
}

func HandlerForGins(c *gin.Context) {
	opts := promhttp.HandlerOpts{}
	mfs, err := prometheus.DefaultGatherer.Gather()
	if err != nil {
		if opts.ErrorLog != nil {
			opts.ErrorLog.Println("error gathering metrics:", err)
		}
		switch opts.ErrorHandling {
		case promhttp.PanicOnError:
			panic(err)
		case promhttp.ContinueOnError:
			if len(mfs) == 0 {
				http.Error(c.Writer, "No metrics gathered, last error:\n\n"+err.Error(), http.StatusInternalServerError)
				return
			}
		case promhttp.HTTPErrorOnError:
			http.Error(c.Writer, "An error has occurred during metrics gathering:\n\n"+err.Error(), http.StatusInternalServerError)
			return
		}
	}
	contentType := expfmt.Negotiate(c.Request.Header)
	buf := getBuf()
	defer giveBuf(buf)
	writer, encoding := decorateWriter(c.Request, buf, opts.DisableCompression)
	enc := expfmt.NewEncoder(writer, contentType)
	var lastErr error
	for _, mf := range mfs {
		if err := enc.Encode(mf); err != nil {
			lastErr = err
			if opts.ErrorLog != nil {
				opts.ErrorLog.Println("error encoding metric family:", err)
			}
			switch opts.ErrorHandling {
			case promhttp.PanicOnError:
				panic(err)
			case promhttp.ContinueOnError:
				// Handled later.
			case promhttp.HTTPErrorOnError:
				http.Error(c.Writer, "An error has occurred during metrics encoding:\n\n"+err.Error(), http.StatusInternalServerError)
				return
			}
		}
	}
	if closer, ok := writer.(io.Closer); ok {
		if err := closer.Close(); err != nil {
			log.Warn("failed to close writer: %v", err)
		}
	}
	if lastErr != nil && buf.Len() == 0 {
		http.Error(c.Writer, "No metrics encoded, last error:\n\n"+lastErr.Error(), http.StatusInternalServerError)
		return
	}
	header := c.Writer.Header()
	header.Set(contentTypeHeader, string(contentType))
	header.Set(contentLengthHeader, fmt.Sprint(buf.Len()))
	if encoding != "" {
		header.Set(contentEncodingHeader, encoding)
	}

	if _, err := c.Writer.Write(buf.Bytes()); err != nil {
		log.Warn("failed to write buf: %v", err)
	}
	// TODO(beorn7): Consider streaming serving of metrics.
}

// decorateWriter wraps a writer to handle gzip compression if requested.  It
// returns the decorated writer and the appropriate "Content-Encoding" header
// (which is empty if no compression is enabled).
func decorateWriter(request *http.Request, writer io.Writer, compressionDisabled bool) (io.Writer, string) {
	if compressionDisabled {
		return writer, ""
	}
	header := request.Header.Get(acceptEncodingHeader)
	parts := strings.Split(header, ",")
	for _, part := range parts {
		part := strings.TrimSpace(part)
		if part == "gzip" || strings.HasPrefix(part, "gzip;") {
			return gzip.NewWriter(writer), "gzip"
		}
	}
	return writer, ""
}
