package caller

import (
	"time"

	errors2 "github.com/pkg/errors"
)

func TimeoutWrap(timeout time.Duration, fn func() error) error {
	result := make(chan error)
	go func() {
		result <- fn()
	}()

	// time.After is more convenient, but it potentially leaves timers
	// around much longer than necessary if we exit early.
	timer := time.NewTimer(timeout)
	defer timer.Stop()

	select {
	case err := <-result:
		return err
	case <-timer.C:
		return errors2.New("timeout")
	}
}
