/*
Copyright 2022 The Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package sliceutil

import (
	"reflect"
	"testing"
)

func TestHasString(t *testing.T) {
	type args struct {
		slice []string
		str   string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "slice contains string",
			args: args{
				slice: []string{"hello", "world"},
				str:   "hello",
			},
			want: true,
		},
		{
			name: "slice doesn't contains string",
			args: args{
				slice: []string{"hello", "world"},
				str:   "hello1",
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := HasString(tt.args.slice, tt.args.str); got != tt.want {
				t.Errorf("HasString() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestHasInt(t *testing.T) {
	type args struct {
		slice []int
		i     int
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "slice contains int",
			args: args{
				slice: []int{1, 2},
				i:     1,
			},
			want: true,
		},
		{
			name: "slice doesn't contains int",
			args: args{
				slice: []int{1, 2},
				i:     3,
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := HasInt(tt.args.slice, tt.args.i); got != tt.want {
				t.Errorf("HasInt() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRemoveString(t *testing.T) {
	type args struct {
		slice  []string
		remove func(item string) bool
	}
	tests := []struct {
		name string
		args args
		want []string
	}{
		{
			name: "remove world",
			args: args{
				slice: []string{"hello", "world"},
				remove: func(item string) bool {
					return item == "world"
				},
			},
			want: []string{"hello"},
		},
		{
			name: "remove world and again",
			args: args{
				slice: []string{"hello", "world", "again"},
				remove: func(item string) bool {
					return item == "world" || item == "again"
				},
			},
			want: []string{"hello"},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := RemoveString(tt.args.slice, tt.args.remove); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("RemoveString() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestHasPrefix(t *testing.T) {
	type args struct {
		str     string
		prefixs []string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "slice has the prefix",
			args: args{
				str:     "hello world",
				prefixs: []string{"hello", "abc"},
			},
			want: true,
		},
		{
			name: "slice doesn't has the prefix",
			args: args{
				str:     "hello world",
				prefixs: []string{"world", "ello"},
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := HasPrefix(tt.args.str, tt.args.prefixs); got != tt.want {
				t.Errorf("HasPrefix() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_Subset(t *testing.T) {
	type args struct {
		a []string
		b []string
	}
	tests := []struct {
		name string
		args args
		want []string
	}{
		{
			name: "Test_Subset-1",
			args: args{
				a: []string{"hello", "world"},
				b: []string{"hello", "hello", "hello", "word"},
			},
			want: []string{},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Subset(tt.args.a, tt.args.b); reflect.DeepEqual(got, tt.want) {
				t.Errorf("Subset() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestContains(t *testing.T) {
	type args struct {
		strs []string
		str  string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "doesn't contains str",
			args: args{
				strs: []string{"a", "b", "bdd"},
				str:  "c",
			},
			want: false,
		},
		{
			name: "contains str",
			args: args{
				strs: []string{"aaa", "bcd"},
				str:  "c",
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Contains(tt.args.strs, tt.args.str); got != tt.want {
				t.Errorf("Contains() = %v, want %v", got, tt.want)
			}
		})
	}
}
