package util

import (
	"strings"

	"github.com/daocloud/dsp-appserver/pkg/constants"

	"github.com/clusterpedia-io/client-go/tools/builder"
)

type (
	Cluster     string
	Namespaces  []string
	Scope       map[Cluster]Namespaces
	ListOptions struct {
		QueryPage *QueryPage
		// Cluster to namespace mapping.
		Scope Scope
	}
)

func BuildListOptionsByQueryPage(queryPage *QueryPage) builder.ListOptionsInterface {
	optBuilder := builder.ListOptionsBuilder()
	if queryPage != nil {
		// If the queryPage.PageSize is MaxPageSize which means that it
		// doesn't need paging.
		if queryPage.PageSize > 0 && queryPage.PageSize != MaxPageSize {
			optBuilder = optBuilder.RemainingCount()
			optBuilder = optBuilder.Limit(int(queryPage.PageSize))
			optBuilder = optBuilder.Offset(int(queryPage.PageSize * (queryPage.Page - 1)))
		}

		if len(queryPage.SortBy) > 0 {
			// default order by asc
			optBuilder = optBuilder.OrderBy(queryPage.SortBy, queryPage.SortDir == constants.OrderByDesc)
		}

		name := queryPage.Name
		if len(name) > 0 {
			switch queryPage.NameSearchType {
			case DefaultNameSearchType:
				optBuilder = optBuilder.FuzzyNames(name)
			}
		}

		if len(queryPage.Names) > 0 {
			optBuilder = optBuilder.Names(queryPage.Names...)
		}

		if queryPage.Phase != "" {
			optBuilder = optBuilder.FieldSelector("status.phase", []string{queryPage.Phase})
		}

		if len(queryPage.Labels) > 0 {
			for k, v := range queryPage.Labels {
				optBuilder = optBuilder.LabelSelector(k, []string{v})
			}
		}

		if queryPage.Selector != nil {
			optBuilder = optBuilder.Selector(queryPage.Selector)
		}

		if len(queryPage.FieldSelector) > 0 {
			for k, v := range queryPage.FieldSelector {
				if len(v) > 0 {
					optBuilder = optBuilder.FieldSelector(k, v)
				}
			}
		}
	}
	return optBuilder
}

func BuildSingleClusterListOptions(listOptions *ListOptions) builder.ListOptionsInterface {
	if listOptions == nil {
		return builder.ListOptionsBuilder()
	}
	optBuilder := BuildListOptionsByQueryPage(listOptions.QueryPage)
	if listOptions.Scope != nil && len(listOptions.Scope) <= 1 {
		if _, ok := listOptions.Scope["*"]; ok {
			namespaces := FilterStrings(listOptions.Scope["*"])
			if len(namespaces) > 0 {
				optBuilder = optBuilder.Namespaces(namespaces...)
			}
		} else {
			for cluster, namespaces := range listOptions.Scope {
				if len(cluster) > 0 {
					optBuilder = optBuilder.Clusters(string(cluster))
				}
				namespaces = FilterStrings(namespaces)
				if len(namespaces) > 0 {
					optBuilder = optBuilder.Namespaces(namespaces...)
				}
			}
		}
	}
	return optBuilder
}

func FilterStrings(strs []string) []string {
	result := make([]string, 0)
	for _, str := range strs {
		str := strings.TrimSpace(str)
		if len(str) > 0 {
			result = append(result, str)
		}
	}
	return result
}
