package pod

import (
	corev1 "k8s.io/api/core/v1"
)

// Visitor is called with each object name, and returns true if visiting should continue
type Visitor func(name string) (shouldContinue bool)

// VisitPodSecretNames invokes the visitor function with the name of every secret
// referenced by the pod spec. If visitor returns false, visiting is short-circuited.
// Transitive references (e.g. pod -> pvc -> pv -> secret) are not visited.
// Returns true if visiting completed, false if visiting was short-circuited.
func VisitPodSecretNames(pod *corev1.Pod, visitor Visitor) bool {
	return VisitPodSpecSecretNames(pod.Spec, visitor)
}

// VisitPodSpecSecretNames invokes the visitor function with the name of every secret
// referenced by the pod spec. If visitor returns false, visiting is short-circuited.
// Transitive references (e.g. pod -> pvc -> pv -> secret) are not visited.
// Returns true if visiting completed, false if visiting was short-circuited.
func VisitPodSpecSecretNames(spec corev1.PodSpec, visitor Visitor) bool {
	for _, reference := range spec.ImagePullSecrets {
		if !visitor(reference.Name) {
			return false
		}
	}
	for i := range spec.InitContainers {
		if !visitContainerSecretNames(&spec.InitContainers[i], visitor) {
			return false
		}
	}
	for i := range spec.Containers {
		if !visitContainerSecretNames(&spec.Containers[i], visitor) {
			return false
		}
	}
	var source *corev1.VolumeSource
	for i := range spec.Volumes {
		source = &spec.Volumes[i].VolumeSource
		switch {
		case source.AzureFile != nil:
			if len(source.AzureFile.SecretName) > 0 && !visitor(source.AzureFile.SecretName) {
				return false
			}
		case source.CephFS != nil:
			if source.CephFS.SecretRef != nil && !visitor(source.CephFS.SecretRef.Name) {
				return false
			}
		case source.Cinder != nil:
			if source.Cinder.SecretRef != nil && !visitor(source.Cinder.SecretRef.Name) {
				return false
			}
		case source.FlexVolume != nil:
			if source.FlexVolume.SecretRef != nil && !visitor(source.FlexVolume.SecretRef.Name) {
				return false
			}
		case source.Projected != nil:
			for j := range source.Projected.Sources {
				if source.Projected.Sources[j].Secret != nil {
					if !visitor(source.Projected.Sources[j].Secret.Name) {
						return false
					}
				}
			}
		case source.RBD != nil:
			if source.RBD.SecretRef != nil && !visitor(source.RBD.SecretRef.Name) {
				return false
			}
		case source.Secret != nil:
			if !visitor(source.Secret.SecretName) {
				return false
			}
		case source.ScaleIO != nil:
			if source.ScaleIO.SecretRef != nil && !visitor(source.ScaleIO.SecretRef.Name) {
				return false
			}
		case source.ISCSI != nil:
			if source.ISCSI.SecretRef != nil && !visitor(source.ISCSI.SecretRef.Name) {
				return false
			}
		case source.StorageOS != nil:
			if source.StorageOS.SecretRef != nil && !visitor(source.StorageOS.SecretRef.Name) {
				return false
			}
		}
	}
	return true
}

func visitContainerSecretNames(container *corev1.Container, visitor Visitor) bool {
	for _, env := range container.EnvFrom {
		if env.SecretRef != nil {
			if !visitor(env.SecretRef.Name) {
				return false
			}
		}
	}
	for _, envVar := range container.Env {
		if envVar.ValueFrom != nil && envVar.ValueFrom.SecretKeyRef != nil {
			if !visitor(envVar.ValueFrom.SecretKeyRef.Name) {
				return false
			}
		}
	}
	return true
}

// VisitPodConfigmapNames invokes the visitor function with the name of every configmap
// referenced by the pod spec. If visitor returns false, visiting is short-circuited.
// Transitive references (e.g. pod -> pvc -> pv -> secret) are not visited.
// Returns true if visiting completed, false if visiting was short-circuited.
func VisitPodConfigmapNames(pod *corev1.Pod, visitor Visitor) bool {
	return VisitPodSpecConfigMapNames(pod.Spec, visitor)
}

func VisitPodSpecConfigMapNames(spec corev1.PodSpec, visitor Visitor) bool {
	for i := range spec.InitContainers {
		if !visitContainerConfigmapNames(&spec.InitContainers[i], visitor) {
			return false
		}
	}
	for i := range spec.Containers {
		if !visitContainerConfigmapNames(&spec.Containers[i], visitor) {
			return false
		}
	}
	var source *corev1.VolumeSource
	for i := range spec.Volumes {
		source = &spec.Volumes[i].VolumeSource
		switch {
		case source.Projected != nil:
			for j := range source.Projected.Sources {
				if source.Projected.Sources[j].ConfigMap != nil {
					if !visitor(source.Projected.Sources[j].ConfigMap.Name) {
						return false
					}
				}
			}
		case source.ConfigMap != nil:
			if !visitor(source.ConfigMap.Name) {
				return false
			}
		}
	}
	return true
}

func visitContainerConfigmapNames(container *corev1.Container, visitor Visitor) bool {
	for _, env := range container.EnvFrom {
		if env.ConfigMapRef != nil {
			if !visitor(env.ConfigMapRef.Name) {
				return false
			}
		}
	}
	for _, envVar := range container.Env {
		if envVar.ValueFrom != nil && envVar.ValueFrom.ConfigMapKeyRef != nil {
			if !visitor(envVar.ValueFrom.ConfigMapKeyRef.Name) {
				return false
			}
		}
	}
	return true
}

// VisitPodPersistentVolumeClaimNames invokes the visitor function with the name of every
// pvc referenced by the pod spec. If visitor returns false, visiting is short-circuited.
// Returns true if visiting completed, false if visiting was short-circuited.
func VisitPodPersistentVolumeClaimNames(pod *corev1.Pod, visitor Visitor) bool {
	return VisitPodSpecPersistentVolumeClaimNames(pod.Spec, visitor)
}

// VisitPodSpecPersistentVolumeClaimNames invokes the visitor function with the name of every
// pvc referenced by the pod spec. If visitor returns false, visiting is short-circuited.
// Returns true if visiting completed, false if visiting was short-circuited.
func VisitPodSpecPersistentVolumeClaimNames(spec corev1.PodSpec, visitor Visitor) bool {
	for i := range spec.Volumes {
		source := spec.Volumes[i].VolumeSource
		if source.PersistentVolumeClaim != nil {
			if !visitor(source.PersistentVolumeClaim.ClaimName) {
				return false
			}
		}
	}
	return true
}
