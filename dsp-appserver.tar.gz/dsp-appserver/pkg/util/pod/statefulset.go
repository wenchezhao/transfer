package pod

import (
	"context"
	apps "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
)

// ListStatefulSetPods returns a set of pods controlled by a given statefulset.
func ListStatefulSetPods(client kubernetes.Interface, statefulSet apps.StatefulSet) ([]corev1.Pod, error) {
	selector, err := metav1.LabelSelectorAsSelector(statefulSet.Spec.Selector)
	if err != nil {
		return nil, err
	}
	allPods, err := client.CoreV1().Pods(statefulSet.Namespace).List(context.TODO(), metav1.ListOptions{
		LabelSelector: selector.String(),
	})
	if err != nil {
		return nil, err
	}
	return FilterPodsByControllerRef(&statefulSet, allPods.Items), nil
}
