package pod

import (
	"context"
	v1 "k8s.io/api/core/v1"
	extensionsv1beta1 "k8s.io/api/extensions/v1beta1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/client-go/kubernetes"
)

// ListIngressPods returns a set of pods selected by a given ingress.
func ListIngressPods(client kubernetes.Interface, ing *extensionsv1beta1.Ingress) ([]v1.Pod, error) {
	backends := sets.NewString()
	if ing.Spec.Backend != nil {
		backends.Insert(ing.Spec.Backend.ServiceName)
	}
	for _, rule := range ing.Spec.Rules {
		if rule.HTTP != nil {
			for _, path := range rule.HTTP.Paths {
				backends.Insert(path.Backend.ServiceName)
			}
		}
	}
	pods := []v1.Pod{}
	for backend := range backends {
		service, err := client.CoreV1().Services(ing.Namespace).Get(context.TODO(), backend, metav1.GetOptions{})
		if err != nil {
			if kapierrors.IsNotFound(err) {
				continue
			}
			return nil, err
		}
		servicePods, err := ListServicePods(client, service)
		if err != nil {
			return nil, err
		}
		pods = append(pods, servicePods...)
	}
	return pods, nil
}
