package pod

import (
	"context"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
)

// ListServicePods returns a set of pods selected by a given service.
func ListServicePods(client kubernetes.Interface, service *v1.Service) ([]v1.Pod, error) {

	if len(service.Spec.Selector) == 0 {
		return []v1.Pod{}, nil
	}

	selector := &metav1.LabelSelector{
		MatchLabels: service.Spec.Selector,
	}
	labelSelector, err := metav1.LabelSelectorAsSelector(selector)
	if err != nil {
		return nil, err
	}
	pods, err := client.CoreV1().Pods(service.Namespace).List(context.TODO(), metav1.ListOptions{
		LabelSelector: labelSelector.String(),
	})
	if err != nil {
		return nil, err
	}
	for index := range pods.Items {
		pods.Items[index].APIVersion = "v1"
		pods.Items[index].Kind = "Pod"
	}
	return pods.Items, nil
}
