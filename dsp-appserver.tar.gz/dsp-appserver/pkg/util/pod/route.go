package pod

import (
	"context"
	routeapi "github.com/openshift/api/route/v1"
	v1 "k8s.io/api/core/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/client-go/kubernetes"
)

// ListRoutePods returns a set of pods selected by a given route.
func ListRoutePods(client kubernetes.Interface, route *routeapi.Route) ([]v1.Pod, error) {
	backends := sets.NewString(route.Spec.To.Name)
	for _, backend := range route.Spec.AlternateBackends {
		backends.Insert(backend.Name)
	}

	pods := []v1.Pod{}
	for backend := range backends {
		service, err := client.CoreV1().Services(route.Namespace).Get(context.TODO(), backend, metav1.GetOptions{})
		if err != nil {
			if kapierrors.IsNotFound(err) {
				continue
			}
			return nil, err
		}
		servicePods, err := ListServicePods(client, service)
		if err != nil {
			return nil, err
		}
		pods = append(pods, servicePods...)
	}
	return pods, nil
}
