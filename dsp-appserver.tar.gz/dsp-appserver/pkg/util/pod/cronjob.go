package pod

import (
	"context"

	v1 "k8s.io/api/batch/v1"
	"k8s.io/client-go/kubernetes"

	"k8s.io/api/batch/v1beta1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func ListCronJobPods(client kubernetes.Interface, cj v1beta1.CronJob) ([]corev1.Pod, error) {
	jobs, err := client.BatchV1().Jobs(cj.Namespace).List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return nil, err
	}

	allPods, err := client.CoreV1().Pods(cj.Namespace).List(context.TODO(), metav1.ListOptions{})
	if err != nil {
		return nil, err
	}

	return filterCronJobPodsByOwnerReference(cj, jobs.Items, allPods.Items), nil
}

func filterCronJobPodsByOwnerReference(cj v1beta1.CronJob, jobs []v1.Job, allPods []corev1.Pod) []corev1.Pod {
	var matchingPods []corev1.Pod
	for _, job := range jobs {
		if metav1.IsControlledBy(&job, &cj) {
			matchingPods = append(matchingPods, FilterPodsByControllerRef(&job, allPods)...)
		}
	}
	return matchingPods
}
