package gclient

import (
	"reflect"
	"testing"

	"k8s.io/apimachinery/pkg/runtime"
)

func Test_NewSchema(t *testing.T) {
	tests := []struct {
		name string
		want *runtime.Scheme
	}{
		{
			name: "new schema",
			want: aggregatedScheme,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NewSchema(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("NewSchema() got = %v, want %v", got, tt.want)
			}
		})
	}
}
