package gclient

import (
	"github.com/clusterpedia-io/api/cluster/v1alpha2"
	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	kubeancluster "github.com/kubean-io/kubean-api/apis/cluster/v1alpha1"
	kubeanclusterops "github.com/kubean-io/kubean-api/apis/clusteroperation/v1alpha1"
	kubeaninfomanifestv1alpha1 "github.com/kubean-io/kubean-api/apis/manifest/v1alpha1"
	apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/client-go/kubernetes/scheme"
	clusterapiv1beta1 "sigs.k8s.io/cluster-api/api/v1beta1"
)

// aggregatedScheme aggregates Kubernetes and extended schemes.
var aggregatedScheme = runtime.NewScheme()

func init() {
	_ = scheme.AddToScheme(aggregatedScheme)                     // add Kubernetes schemes
	_ = apiextensionsv1.AddToScheme(aggregatedScheme)            // add Kubernetes CRD schemes
	_ = clusterv1alpha1.AddToScheme(aggregatedScheme)            // add cluster schemes
	_ = clusterapiv1beta1.AddToScheme(aggregatedScheme)          // add cluster-api v1beta1 schemes
	_ = v1alpha2.AddToScheme(aggregatedScheme)                   // add clusterpedia-api v1alpha2 schemes
	_ = kubeancluster.AddToScheme(aggregatedScheme)              // add kubeancluster v1alpha1 schemes
	_ = kubeanclusterops.AddToScheme(aggregatedScheme)           // add kubeanclusterops v1alpha1 schemes
	_ = kubeaninfomanifestv1alpha1.AddToScheme(aggregatedScheme) // add kubeaninfomanifestv1alpha1 v1alpha1 schemes
}

// NewSchema returns a singleton schema set which aggregated Kubernetes's schemes and extended schemes.
func NewSchema() *runtime.Scheme {
	return aggregatedScheme
}
