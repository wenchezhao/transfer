package util

import (
	"k8s.io/apimachinery/pkg/util/json"
)

type JSONPatchOperation string

const (
	JSONPatchOperationAdd     JSONPatchOperation = "add"
	JSONPatchOperationRemove  JSONPatchOperation = "remove"
	JSONPatchOperationReplace JSONPatchOperation = "replace"
	JSONPatchOperationMove    JSONPatchOperation = "move"
	JSONPatchOperationCopy    JSONPatchOperation = "copy"
	JSONPatchOperationTest    JSONPatchOperation = "test"
)

type JSONPatch struct {
	Operation JSONPatchOperation `json:"op"`
	Path      string             `json:"path,omitempty"`
	Value     interface{}        `json:"value,omitempty"`
	From      string             `json:"from,omitempty"`
}
type JSONPatchList []*JSONPatch

func AddJSONPatch(jps ...*JSONPatch) JSONPatchList {
	list := make([]*JSONPatch, 0)
	list = append(list, jps...)
	return list
}

func (jps JSONPatchList) ToBytes() ([]byte, error) {
	b, err := json.Marshal(jps)
	if err != nil {
		return nil, err
	}
	return b, nil
}
