package util

import (
	"reflect"
	"testing"

	"github.com/clusterpedia-io/client-go/tools/builder"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func Test_BuildSingleClusterListOptions(t *testing.T) {
	type args struct {
		cluster    string
		namespaces []string
		queryPage  *QueryPage
	}
	tests := []struct {
		name string
		args args
		want metav1.ListOptions
	}{
		{
			name: "param is nil",
			args: args{
				cluster:    "",
				namespaces: nil,
				queryPage:  nil,
			},
			want: builder.ListOptionsBuilder().Options(),
		},
		{
			name: "clusterNames contains blank string",
			args: args{
				cluster:    "cluster-1",
				namespaces: nil,
				queryPage:  nil,
			},
			want: builder.ListOptionsBuilder().Clusters("cluster-1").Options(),
		},
		{
			name: "clusterNames is * but namespace is nil",
			args: args{
				cluster:    "*",
				namespaces: nil,
				queryPage:  nil,
			},
			want: builder.ListOptionsBuilder().Options(),
		},
		{
			name: "clusterNames is * and namespace is not nil",
			args: args{
				cluster:    "*",
				namespaces: []string{"default"},
				queryPage:  nil,
			},
			want: builder.ListOptionsBuilder().Namespaces("default").Options(),
		},
		{
			name: "clusterNames and namespaces  contains blank string",
			args: args{
				cluster:    "cluster-1",
				namespaces: []string{"", "ns"},
				queryPage:  nil,
			},
			want: builder.ListOptionsBuilder().Clusters("cluster-1").Namespaces("ns").Options(),
		},
		{
			name: "test query page param1",
			args: args{
				cluster:    "",
				namespaces: nil,
				queryPage: &QueryPage{
					Page:     1,
					PageSize: 5,
				},
			},
			want: builder.ListOptionsBuilder().RemainingCount().Offset(0).Limit(5).Options(),
		},
		{
			name: "test query page param2",
			args: args{
				cluster:    "",
				namespaces: nil,
				queryPage: &QueryPage{
					Page:     2,
					PageSize: 5,
				},
			},
			want: builder.ListOptionsBuilder().RemainingCount().Offset(5).Limit(5).Options(),
		},
		{
			name: "test query by name",
			args: args{
				cluster:    "",
				namespaces: nil,
				queryPage: &QueryPage{
					Page:     2,
					PageSize: 5,
					Name:     "test",
				},
			},
			want: builder.ListOptionsBuilder().RemainingCount().Offset(5).Limit(5).FuzzyNames("test").Options(),
		},
		{
			name: "test query orderby1",
			args: args{
				cluster:    "",
				namespaces: nil,
				queryPage: &QueryPage{
					Page:     2,
					PageSize: 5,
					SortBy:   "name",
					SortDir:  "asc",
				},
			},
			want: builder.ListOptionsBuilder().RemainingCount().Offset(5).Limit(5).OrderBy("name", false).Options(),
		},
		{
			name: "test query orderby1",
			args: args{
				cluster:    "",
				namespaces: nil,
				queryPage: &QueryPage{
					Page:     2,
					PageSize: 5,
					SortBy:   "name",
					SortDir:  "aaa",
				},
			},
			want: builder.ListOptionsBuilder().RemainingCount().Offset(5).Limit(5).OrderBy("name", false).Options(),
		},
		{
			name: "test query orderby2",
			args: args{
				cluster:    "",
				namespaces: nil,
				queryPage: &QueryPage{
					Page:     2,
					PageSize: 5,
					SortBy:   "name",
					SortDir:  "desc",
				},
			},
			want: builder.ListOptionsBuilder().RemainingCount().Offset(5).Limit(5).OrderBy("name", true).Options(),
		},
		{
			name: "test query by fieldSelector ",
			args: args{
				cluster:    "",
				namespaces: nil,
				queryPage: &QueryPage{
					Page:          2,
					PageSize:      5,
					FieldSelector: map[string][]string{".spec.type": {"ClusterIP"}},
				},
			},
			want: builder.ListOptionsBuilder().RemainingCount().Offset(5).Limit(5).FieldSelector(".spec.type", []string{"ClusterIP"}).Options(),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// tt.args.clusterNames, tt.args.namespaces, tt.args.queryPage
			if got := BuildSingleClusterListOptions(
				&ListOptions{
					QueryPage: tt.args.queryPage,
					Scope: map[Cluster]Namespaces{
						Cluster(tt.args.cluster): tt.args.namespaces,
					},
				},
			).Options(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("buildOpts() = %v, want %v", got, tt.want)
			}
		})
	}
}
