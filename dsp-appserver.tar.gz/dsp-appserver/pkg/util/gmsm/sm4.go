package gmsm

import (
	"bytes"
	"crypto/cipher"

	"github.com/tjfoc/gmsm/sm4"
)

func SM4Encrypt(input, plainText []byte) ([]byte, error) {
	iv := make([]byte, sm4.BlockSize)
	block, err := sm4.NewCipher(input)
	if err != nil {
		return nil, err
	}
	blockSize := block.BlockSize()
	origData := pkcs5Padding(plainText, blockSize)
	blockMode := cipher.NewCBCEncrypter(block, iv)
	cryted := make([]byte, len(origData))
	blockMode.CryptBlocks(cryted, origData)
	return cryted, nil
}

func SM4Decrypt(input, cipherText []byte) ([]byte, error) {
	iv := make([]byte, sm4.BlockSize)
	block, err := sm4.NewCipher(input)
	if err != nil {
		return nil, err
	}
	blockMode := cipher.NewCBCDecrypter(block, iv)
	origData := make([]byte, len(cipherText))
	blockMode.CryptBlocks(origData, cipherText)
	origData = pkcs5UnPadding(origData)
	return origData, nil
}

func pkcs5Padding(src []byte, blockSize int) []byte {
	padding := blockSize - len(src)%blockSize
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(src, padtext...)
}

func pkcs5UnPadding(src []byte) []byte {
	length := len(src)
	if length == 0 {
		return nil
	}
	unpadding := int(src[length-1])
	return src[:(length - unpadding)]
}
