package reflectutils

import (
	"reflect"
	"testing"
)

func TestIn(t *testing.T) {
	tests := []struct {
		value interface{}
		index interface{}
		res   bool
	}{
		{
			value: []int{0, 1, 2, 3, 4, 5, 6, 7, 8},
			index: 2,
			res:   true,
		},
		{
			value: []int{0, 1, 2, 3, 4, 5, 6, 7, 8},
			index: 9,
			res:   false,
		},
		{
			value: []string{"this", "is", "a", "test", "strings", "slice"},
			index: "a",
			res:   true,
		},
		{
			value: map[string]int{"this": 159, "is": 357, "a": 789, "test": 123, "map": 852},
			index: "this",
			res:   true,
		},
		{
			value: 1,
			index: 1,
			res:   false,
		},
	}
	for i := 0; i < len(tests); i++ {
		switch reflect.TypeOf(tests[i].value).Kind() {
		case reflect.Slice, reflect.Array:
			t.Run("test:type of slice", func(t *testing.T) {
				if In(tests[i].index, tests[i].value) != tests[i].res {
					t.Fail()
				}
			})
		case reflect.Map:
			t.Run("test:type of map", func(t *testing.T) {
				if In(tests[i].index, tests[i].value) != tests[i].res {
					t.Fail()
				}
			})
		default:
			t.Run("test:type of not slice or map", func(t *testing.T) {
				if In(tests[i].index, tests[i].value) != tests[i].res {
					t.Fail()
				}
			})
		}
	}
}

func TestOverride(t *testing.T) {
	var a *string
	tests := []struct {
		name  string
		left  interface{}
		right interface{}
	}{
		{
			name:  "test nil pointer",
			left:  &struct{}{},
			right: &struct{}{},
		},
		{
			name:  "test nil pointer",
			left:  a,
			right: &struct{}{},
		},
		{
			name:  "test nil pointer diff",
			left:  []int{1, 2, 3, 4, 5},
			right: map[int]int{1: 1},
		},
		{
			name: "test same struct",
			left: &struct {
				Test1 int
				Test2 string
				Test3 bool
				Test4 float32
			}{
				Test1: 0,
				Test2: "test string",
				Test3: false,
				Test4: 3.1415926535,
			},
			right: &struct {
				Test1 int
				Test2 string
				Test3 bool
				Test4 float32
			}{
				Test1: 0,
				Test2: "test string",
				Test3: false,
				Test4: 3.1415926535,
			},
		},
		{
			name: "test same struct but tags different",
			left: &struct {
				Test1 int     `json:"test1,omitempty"`
				Test2 string  `json:"test2,omitempty"`
				Test3 bool    `json:"test3,omitempty"`
				Test4 float32 `json:"test4,omitempty"`
			}{
				Test1: 0,
				Test2: "test string",
				Test3: false,
				Test4: 3.1415926535,
			},
			right: &struct {
				Test1 int     `json:"t1,omitempty"`
				Test2 string  `json:"t2,omitempty"`
				Test3 bool    `json:"t3,omitempty"`
				Test4 float32 `json:"t4,omitempty"`
			}{
				Test1: 0,
				Test2: "test string",
				Test3: false,
				Test4: 3.1415926535,
			},
		},
	}
	for i := 0; i < len(tests); i++ {
		t.Run(tests[i].name, func(t *testing.T) {
			Override(tests[i].left, tests[i].right)
		})
	}
}
