package reflectutils

import (
	"fmt"
	"reflect"
	"testing"
)

func TestEqual(t *testing.T) {
	tests := []struct {
		name  string
		left  interface{}
		right interface{}
	}{
		{
			name:  "test nil pointer",
			left:  &struct{}{},
			right: &struct{}{},
		},
		{
			name: "test same struct",
			left: &struct {
				Test1 int
				Test2 string
				Test3 bool
				Test4 float32
			}{
				Test1: 0,
				Test2: "test string",
				Test3: false,
				Test4: 3.1415926535,
			},
			right: &struct {
				Test1 int
				Test2 string
				Test3 bool
				Test4 float32
			}{
				Test1: 0,
				Test2: "test string",
				Test3: false,
				Test4: 3.1415926535,
			},
		},
		{
			name: "test same struct but tags different",
			left: &struct {
				Test1 int     `json:"test1,omitempty"`
				Test2 string  `json:"test2,omitempty"`
				Test3 bool    `json:"test3,omitempty"`
				Test4 float32 `json:"test4,omitempty"`
			}{
				Test1: 0,
				Test2: "test string",
				Test3: false,
				Test4: 3.1415926535,
			},
			right: &struct {
				Test1 int     `json:"t1,omitempty"`
				Test2 string  `json:"t2,omitempty"`
				Test3 bool    `json:"t3,omitempty"`
				Test4 float32 `json:"t4,omitempty"`
			}{
				Test1: 0,
				Test2: "test string",
				Test3: false,
				Test4: 3.1415926535,
			},
		},
		{
			name: "nil pointer 1",
			left: nil,
			right: &struct {
				T1 int
			}{
				T1: 1,
			},
		},
		{
			name: "nil pointer 2",
			left: &struct {
				T1 int
			}{
				T1: 2,
			},
			right: nil,
		},
		{
			name:  "nil pointer 3",
			left:  nil,
			right: nil,
		},
		{
			name: "map point same",
			left: struct {
				M  map[int]int
				M1 map[int]*struct{}
			}{
				M: map[int]int{1: 1, 2: 2, 3: 3},
				M1: map[int]*struct{}{
					1: nil,
					2: nil,
				},
			},
			right: struct {
				M  map[int]int
				M1 map[int]*struct{}
			}{
				M: map[int]int{1: 1, 2: 2, 3: 3},
				M1: map[int]*struct{}{
					1: nil,
					2: nil,
				},
			},
		},
		{
			name: "map point different",
			left: struct {
				M  map[int]int
				M1 map[int]*struct{}
			}{
				M: map[int]int{1: 2, 2: 3, 3: 4},
				M1: map[int]*struct{}{
					1: nil,
					2: nil,
				},
			},
			right: struct {
				M  map[int]int
				M1 map[int]*struct{}
			}{
				M: map[int]int{1: 1, 2: 2, 3: 3},
				M1: map[int]*struct{}{
					1: nil,
					2: nil,
					3: nil,
				},
			},
		},
		{
			name: "slice point same",
			left: struct {
				S1 []int
				S2 []*struct{}
			}{
				S1: []int{1, 2, 3, 4, 5, 6, 7},
				S2: []*struct{}{nil, nil, nil, nil},
			},
			right: struct {
				S1 []int
				S2 []*struct{}
			}{
				S1: []int{1, 2, 3, 4, 5, 6, 7},
				S2: []*struct{}{nil, nil, nil, nil},
			},
		},
		{
			name: "slice point different",
			left: struct {
				S1 []int
				S2 []*struct{}
			}{
				S1: []int{1, 2, 3, 4, 5, 6, 7},
				S2: []*struct{}{nil, nil, nil, nil},
			},
			right: struct {
				S1 []int
				S2 []*struct{}
			}{
				S1: []int{7, 6, 5, 4, 3, 2, 1, 0, -1},
				S2: []*struct{}{nil},
			},
		},
	}
	for i := 0; i < len(tests); i++ {
		t.Run(tests[i].name, func(t *testing.T) {
			res := Equal(tests[i].left, tests[i].right)
			fmt.Println(res)
		})
	}
}

func TestEqual2(t *testing.T) {
	type ChildExample1 struct {
		Age   int
		Name  string
		Hobby []string
	}
	type ChildExample2 struct {
		Class string
		Level int
		M     map[string]string
		C     *ChildExample1
	}
	type TestExample struct {
		Name  string
		Child []interface{}
	}
	newChild1 := func() *ChildExample1 {
		return &ChildExample1{
			Age:   18,
			Name:  "Child example 1",
			Hobby: make([]string, 15),
		}
	}
	newChild2 := func() *ChildExample2 {
		return &ChildExample2{
			Class: "class2",
			Level: 5,
			M:     make(map[string]string),
			C:     newChild1(),
		}
	}
	newTestExample1 := func() *TestExample {
		return &TestExample{
			Name: "this is a test example",
			Child: []interface{}{
				newChild2(),
				newChild2(),
				newChild2(),
			},
		}
	}
	newTestExample2 := func() *TestExample {
		return &TestExample{}
	}
	t.Run("test Equal from nil pointer to a real pointer", func(t *testing.T) {
		dif := Equal(newTestExample2(), newTestExample1())
		fmt.Println(dif)
	})
}

func TestLogErrors(_ *testing.T) {
	LogErrors = true
	logError(&E{s: "test"})
}

type E struct {
	s string
}

func (e *E) Error() string {
	return e.s
}

func TestEqual3(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			a     reflect.Value
			b     reflect.Value
			level int
		}
		out struct {
			output string
		}
	}{
		{
			name: "test Equal3 a is nil",
			in: struct {
				a     reflect.Value
				b     reflect.Value
				level int
			}{a: reflect.ValueOf(nil), b: reflect.ValueOf([]int{1, 2, 3}), level: 0},
		},
		{
			name: "test Equal3 b is nil",
			in: struct {
				a     reflect.Value
				b     reflect.Value
				level int
			}{a: reflect.ValueOf([]int{1, 2, 3}), b: reflect.ValueOf(nil), level: 0},
		},
		{
			name: "test Equal3 error nil",
			in: struct {
				a     reflect.Value
				b     reflect.Value
				level int
			}{a: reflect.ValueOf((*error)(nil)), b: reflect.ValueOf((*error)(nil)), level: 0},
		},
		{
			name: "test Equal3 int type",
			in: struct {
				a     reflect.Value
				b     reflect.Value
				level int
			}{a: reflect.ValueOf([]interface{}{uint8(1), uint16(1), uint32(1), uint64(1)}), b: reflect.ValueOf([]interface{}{uint8(2), uint16(2), uint32(2), uint64(2)}), level: 0},
		},
		{
			name: "test Equal3 bool type",
			in: struct {
				a     reflect.Value
				b     reflect.Value
				level int
			}{a: reflect.ValueOf([]interface{}{true}), b: reflect.ValueOf([]interface{}{false}), level: 0},
		},
		{
			name: "test Equal3 float type",
			in: struct {
				a     reflect.Value
				b     reflect.Value
				level int
			}{a: reflect.ValueOf([]interface{}{float32(3.14), 3.14}), b: reflect.ValueOf([]interface{}{float32(3.1415926), 3.1415926}), level: 0},
		},
		{
			name: "test Equal3 array type  diff < maxdiff",
			in: struct {
				a     reflect.Value
				b     reflect.Value
				level int
			}{a: reflect.ValueOf([]interface{}{[5]int{1, 2, 3, 4, 5}}), b: reflect.ValueOf([]interface{}{[5]int{5, 4, 3, 2, 1}}), level: 0},
		},
		{
			name: "test Equal3 array type  diff > maxdiff",
			in: struct {
				a     reflect.Value
				b     reflect.Value
				level int
			}{a: reflect.ValueOf([]interface{}{[15]int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}}), b: reflect.ValueOf([]interface{}{[15]int{15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1}}), level: 0},
		},
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			c := &cmp{
				diff:        []string{},
				buff:        []string{},
				floatFormat: fmt.Sprintf("%%.%df", FloatPrecision),
			}
			c.equals(v.in.a, v.in.b, v.in.level)
		})
	}
}

func TestEqual4(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			MaxDepth int
			Level    int
		}
	}{
		{
			name: "test equal when maxdepth > 0 and level > maxdepth",
			in: struct {
				MaxDepth int
				Level    int
			}{MaxDepth: 10, Level: 15},
		},
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			c := &cmp{
				diff:        []string{},
				buff:        []string{},
				floatFormat: fmt.Sprintf("%%.%df", FloatPrecision),
			}
			MaxDepth = v.in.MaxDepth
			c.equals(reflect.ValueOf(nil), reflect.ValueOf(nil), v.in.Level)
		})
	}
}
