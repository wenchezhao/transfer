package certs

import (
	"crypto"
	"crypto/rsa"
	"crypto/x509"
	"testing"

	certutil "k8s.io/client-go/util/cert"
)

func TestGenX509CertificateRequestAndKey(t *testing.T) {
	type args struct {
		cfg *certutil.Config
	}
	tests := []struct {
		name    string
		args    args
		want    *x509.CertificateRequest
		want1   *rsa.PrivateKey
		wantErr bool
	}{
		{
			name:    "test",
			args:    struct{ cfg *certutil.Config }{cfg: &certutil.Config{}},
			want:    &x509.CertificateRequest{},
			want1:   &rsa.PrivateKey{},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, _, err := GenX509CertificateRequestAndKey(tt.args.cfg)
			if err != nil {
				t.Errorf("GenX509CertificateRequestAndKey() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestNewCertificateRequest(t *testing.T) {
	type args struct {
		cfg *certutil.Config
		key crypto.Signer
	}
	tests := []struct {
		name    string
		args    args
		want    *x509.CertificateRequest
		wantErr bool
	}{
		{
			name: "test11",
			args: struct {
				cfg *certutil.Config
				key crypto.Signer
			}{cfg: &certutil.Config{}},
			want:    &x509.CertificateRequest{},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, _ = NewCertificateRequest(tt.args.cfg, tt.args.key)
		})
	}
}

func TestNewPrivateKey(t *testing.T) {
	tests := []struct {
		name    string
		want    *rsa.PrivateKey
		wantErr bool
	}{
		{
			name:    "test1",
			want:    &rsa.PrivateKey{},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := NewPrivateKey()
			if err != nil {
				t.Errorf("NewPrivateKey() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
