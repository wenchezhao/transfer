package certs

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"crypto/x509/pkix"
	"fmt"

	certutil "k8s.io/client-go/util/cert"
)

const (
	rsaKeySize = 2048
)

func GenX509CertificateRequestAndKey(cfg *certutil.Config) (*x509.CertificateRequest, *rsa.PrivateKey, error) {
	key, err := NewPrivateKey()
	if err != nil {
		return nil, nil, fmt.Errorf("unable to create private key %s", err)
	}
	certificateRequest, err := NewCertificateRequest(cfg, key)
	if err != nil {
		return nil, nil, err
	}
	return certificateRequest, key, nil
}

func NewCertificateRequest(cfg *certutil.Config, key crypto.Signer) (*x509.CertificateRequest, error) {
	template := &x509.CertificateRequest{
		Subject: pkix.Name{
			CommonName:   cfg.CommonName,
			Organization: cfg.Organization,
		},
		DNSNames:    cfg.AltNames.DNSNames,
		IPAddresses: cfg.AltNames.IPs,
	}
	certificateRequestBytes, err := x509.CreateCertificateRequest(rand.Reader, template, key)
	if err != nil {
		return nil, fmt.Errorf("failed to CreateCertificateRequest %s", err)
	}
	certificateRequest, err := x509.ParseCertificateRequest(certificateRequestBytes)
	if err != nil {
		return nil, fmt.Errorf("failed to ParseCertificateRequest %s", err)
	}
	return certificateRequest, nil
}

// NewPrivateKey creates an RSA private key.
func NewPrivateKey() (*rsa.PrivateKey, error) {
	return rsa.GenerateKey(rand.Reader, rsaKeySize)
}
