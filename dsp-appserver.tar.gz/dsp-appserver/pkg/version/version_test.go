package version

import (
	"strings"
	"testing"
)

func TestString(t *testing.T) {
	tests := []struct {
		Name string
		In   string
		Out  string
	}{
		{
			Name: "nil test",
			In:   "",
			Out:  "",
		},
		{
			Name: "string test",
			In:   "test string",
			Out:  "test string",
		},
	}
	for _, v := range tests {
		t.Run(v.Name, func(t *testing.T) {
			g := Get()
			g.GitCommit = v.In
			f := g.String()
			s := strings.Split(strings.Split(f, ":")[2], ",")[0]
			s = s[1 : len(s)-1]
			if s != v.Out {
				t.Fail()
			}
		})
	}
}
