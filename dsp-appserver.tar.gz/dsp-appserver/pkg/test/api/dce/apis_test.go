package dce

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/dce/apis"
	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const ruleName = "xxyh"
const poolName = "dsptest-"
const subnetName = "dsptest"

//检查集群测试
func TestCheck(t *testing.T) {
	token := "eyJhbGciOiJSUzI1NiIsImtpZCI6ImRubm1RaEdmWmNPTGhsdzUwWDdOTUhadWJvRUdzZ05vcXNrajNsS3VUaHMifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJkZWZhdWx0Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZWNyZXQubmFtZSI6InlhbmdnYW5nLXhpbmd5ZS10b2tlbi05NnY1ciIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJ5YW5nZ2FuZy14aW5neWUiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiI3NjMwODcxMC1jY2FkLTQ5ODAtOTAyMi00OGMzMDQ0MjUwOWUiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6ZGVmYXVsdDp5YW5nZ2FuZy14aW5neWUifQ.pZZYdStCmWTq9zzw5WlxLzhgzSUNNsKLYsxkSIp6LNfCzvgYFdIxTrKfxxU26cIXFU92eOCd6c3qV6stk51n3JPXO2HoJv13y7yffbM62seTvoaf7k1lLZxr0-SQAU7_Cuu85mKAsS7g5VL8E8ZeBllxhfRakOGYvnvvAAfKReJt-I-fvKCCobJoIq1LX6kmrWP0b581lZf5zABAEiXENrafnetY-qDZGpp9g4B0qMVicA1Mg5xYRMafL8ze8cL6RZE7MB73nL7E24qnVYYCc0OJegCXV1SrFWegqaSjMKNIyC7FZ7tUFz9criKHeEdfJkRVcpTs9YSuoaj-MALj7w"
	url := "http://10.23.101.17"
	url1 := fmt.Sprintf("/v1/dce/check?token=%s&url=%s", token, url)
	api.MockApi(t, api.TestClusterDce, http.MethodGet, url1, nil)
}

//创建 ipRule 测试
func TestRuleCreate(t *testing.T) {
	appRuleInfo := apis.AppRuleInfo{
		Name:        ruleName,
		Description: "单元测试验证使用",
		PoolName:    poolName,
		Subnet:      "10.23.0.0/16",
		SubnetName:  subnetName,
	}
	appRuleInfoObj := &apis.AppAddRule{
		AppRuleInfo: appRuleInfo,
		IpList: []string{
			"10.23.6.63",
		},
	}
	url := fmt.Sprintf("/v1/dce/rules?namespace=%s", api.TestNamespace)
	api.MockApi(t, api.TestClusterDce, http.MethodPost, url, appRuleInfoObj)
}

//获取 ipRule 列表测试
func TestRulesList(t *testing.T) {
	url := fmt.Sprintf("/v1/dce/rules?namespace=%s&poolName=%s", api.TestNamespace, poolName)
	api.MockApi(t, api.TestClusterDce, http.MethodGet, url, nil)
}

//获取指定 ipRule 测试
func TestRuleOne(t *testing.T) {
	url := fmt.Sprintf("/v1/dce/rules/%s?namespace=%s&poolName=%s", ruleName, api.TestNamespace, poolName)
	api.MockApi(t, api.TestClusterDce, http.MethodGet, url, nil)
}

//更新 ipRule 测试
func TestRuleUpdate(t *testing.T) {
	appRuleInfo := apis.AppRuleInfo{
		Name:        ruleName,
		Description: "单元测试updates测试使用",
		PoolName:    poolName,
		Subnet:      "10.23.0.0/16",
		SubnetName:  subnetName,
	}
	appRuleInfoObj := &apis.AppAddRule{
		AppRuleInfo: appRuleInfo,
		IpList: []string{
			"10.23.6.64",
		},
	}

	url := fmt.Sprintf("/v1/dce/rules/%s?namespace=%s", ruleName, api.TestNamespace)
	api.MockApi(t, api.TestClusterDce, http.MethodPut, url, appRuleInfoObj)

}

//删除 指定 ipRule 测试
func TestRuleDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/dce/rules/%s?namespace=%s&poolName=%s", ruleName, api.TestNamespace, poolName)
	api.MockApi(t, api.TestClusterDce, http.MethodDelete, url, nil)
}

// 创建 ipPool 测试
func TestPoolCreate(t *testing.T) {
	poolObj := apis.AppAddPool{
		DefaultRouteV4: "10.23.0.1",
		Route:          []string{},
		V4MapV6: []string{
			"10.23.0.99>",
			"10.23.0.100>",
		},
		SubnetName: subnetName,
	}
	url := fmt.Sprintf("/v1/dce/pools?namespace=%s", api.TestNamespace)
	api.MockApi(t, api.TestClusterDce, http.MethodPost, url, poolObj)
}

//获取 ipPool 列表测试
func TestPoolsList(t *testing.T) {
	url := fmt.Sprintf("/v1/dce/pools")
	api.MockApi(t, api.TestClusterDce, http.MethodGet, url, nil)

}

//获取指定 ipPool 测试
func TestPoolOne(t *testing.T) {
	w := api.MockApi(t, api.TestClusterDce, http.MethodGet, "/v1/dce/pools", nil)
	pool := &apis.AppPoolList{}
	err := json.Unmarshal(w.Body.Bytes(), pool)
	if err != nil {
		t.Errorf("failed to unmarshal %v", err)
	}
	url := fmt.Sprintf("/v1/dce/pools/%s?namespace=%s", pool.Items[0].Name, api.TestNamespace)
	api.MockApi(t, api.TestClusterDce, http.MethodGet, url, nil)
}

//删除 ipPool 测试
func TestPoolDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/dce/pools/%s?namespace=%s", "dsptest-yorktest", api.TestNamespace)
	api.MockApi(t, api.TestClusterDce, http.MethodDelete, url, nil)
}

//获取子网列表测试
func TestSubnetsList(t *testing.T) {
	url := fmt.Sprintf("/v1/dce/subnet")
	api.MockApi(t, api.TestClusterDce, http.MethodGet, url, nil)

}

//获取子网详情测试
func TestSubnetOne(t *testing.T) {
	url := fmt.Sprintf("/v1/dce/onesubnet/%s", subnetName)
	api.MockApi(t, api.TestClusterDce, http.MethodGet, url, nil)
}
