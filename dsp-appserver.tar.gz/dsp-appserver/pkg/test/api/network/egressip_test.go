package network

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	networkapi "github.com/openshift/api/network/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//Use the NetNameSpace that already exists in the TestNameSpace，If not, please create it before testing

const TestNetNameSpace = "yorktest"

//获取 egressIps 列表测试
func TestEgressIpsList(t *testing.T) {
	url := fmt.Sprintf("/v1/network/egressip")
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取 netNamespace 列表测试
func TestNetNamespaceList(t *testing.T) {
	url := fmt.Sprintf("/v1/network/netnamespace")
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取指定 netNamespace 测试
func TestNetNamespaceGet(t *testing.T) {
	url := fmt.Sprintf("/v1/network/netnamespace/%s", TestNetNameSpace)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//更新 netNamespace 测试
func TestNetNamespaceUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/network/netnamespace/%s", TestNetNameSpace)
	w := api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, TestNetNameSpace)
	netNamespaceReq := &networkapi.NetNamespace{}
	err := json.Unmarshal(w.Body.Bytes(), netNamespaceReq)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	api.MockApi(t, api.TestClusterOcp, http.MethodPut, url, netNamespaceReq)

}
