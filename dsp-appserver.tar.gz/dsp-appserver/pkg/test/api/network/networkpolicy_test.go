package network

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	networkV1 "k8s.io/api/networking/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/intstr"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const netWorkPolicyName = "aaa"

//创建网络策略测试
func TestNetWorkPolicyCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/networkpolicy", api.TestNamespace)
	port := intstr.FromInt(80)
	podSelector := metav1.LabelSelector{
		MatchLabels: map[string]string{
			"aaa": "bbb",
		},
	}
	netWorkPolicy := &networkV1.NetworkPolicy{
		TypeMeta: metav1.TypeMeta{
			Kind:       "v1",
			APIVersion: "NetWorkPolicy",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      netWorkPolicyName,
			Namespace: api.TestNamespace,
		},
		Spec: networkV1.NetworkPolicySpec{
			PodSelector: metav1.LabelSelector{
				MatchLabels: map[string]string{
					"aaa": "bbb",
				},
			},
			Ingress: []networkV1.NetworkPolicyIngressRule{
				{
					From: []networkV1.NetworkPolicyPeer{
						{
							PodSelector: &podSelector,
						},
					},
					Ports: []networkV1.NetworkPolicyPort{
						{
							Port: &port,
						},
					},
				},
			},
		},
	}
	api.MockApi(t, api.TestClusterOcp, http.MethodPost, url, netWorkPolicy)
}

//获取网络策略列表测试
func TestNetWorPolicyList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/networkpolicy", api.TestNamespace)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取指定网络策略测试
func TestNetWorPolicyGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/networkpolicy/%s", api.TestNamespace, netWorkPolicyName)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//更新网络策略测试
func TestNetWorPolicyPut(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/networkpolicy/%s", api.TestNamespace, netWorkPolicyName)
	w := api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)

	workPolicy := &networkV1.NetworkPolicy{}
	err := json.Unmarshal(w.Body.Bytes(), &workPolicy)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	lables := map[string]string{
		"aaa": "ccc",
	}
	workPolicy.Labels = lables
	api.MockApi(t, api.TestClusterOcp, http.MethodPut, url, workPolicy)
}

//删除网络策略测试
func TestNetWorPolicyDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/networkpolicy/%s", api.TestNamespace, netWorkPolicyName)
	api.MockApi(t, api.TestClusterOcp, http.MethodDelete, url, nil)
}
