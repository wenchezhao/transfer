package network

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//获取 ports 列表测试
func TestPortsList(t *testing.T) {
	url := fmt.Sprintf("/v1/network/ports")
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}
