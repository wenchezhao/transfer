package api

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"

	"github.com/daocloud/dsp-appserver/pkg/config"
	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/server"
)

// before test:
// 1.setting database, and can connect
// 2.create a test namespace in cluster
// 3.go test package or go file, if you need more information, add option "-v"
// 4.if you run server in osx, take care database of dameng

const (
	TestClusterOcp = "ocp"      // cluster id
	TestClusterDce = "dce"      //  cluster id
	TestClusterK8s = "k8s"      //  cluster id
	TestNamespace  = "yorktest" // resource crud namespace
	BasicUsername  = "admin"    // basic username
	BasicPassword  = "admin"    // basic password
	TestName       = "test"     //already exist deployment name
)

var (
	mux http.Handler
	log = logi.Log.Sugar()
)

func init() {
	// new config
	conf, err := config.NewForEnv()
	if err != nil {
		log.Errorf("failed to new config from env: %v", err)
		return
	}

	// new server
	s, err := server.New(conf)
	if err != nil {
		log.Errorf("failed to start server: %v", err)
		return
	}
	mux = s.GetMux()
}

// MockApi is a common function to request the server mux
func MockApi(t *testing.T, cluster string, method, path string, body interface{}) *httptest.ResponseRecorder {
	var b []byte
	switch body.(type) {
	case string:
		b = []byte(body.(string))
	case []byte:
		b = body.([]byte)
	default:
		var err error
		b, err = json.Marshal(body)
		require.Nil(t, err)
	}
	fmt.Println(string(b))

	req := httptest.NewRequest(method, path, bytes.NewReader(b))
	w := httptest.NewRecorder()
	req.Header.Set("preset", "true")
	req.Header.Set("clusterID", cluster)
	req.Header.Set("Content-Type", "application/json")
	req.SetBasicAuth(BasicUsername, BasicPassword)

	log.Debugf("req url: %s", req.URL)

	gin.SetMode(gin.TestMode)

	mux.ServeHTTP(w, req)
	log.Infof("resp.code = %+v", w.Code)
	log.Infof("resp.body = %+v", w.Body.String())

	require.True(t, w.Code < 400)

	return w
}
