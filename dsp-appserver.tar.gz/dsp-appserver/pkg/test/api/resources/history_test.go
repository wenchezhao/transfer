package resources

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//Use the deployment that already exists in the TestNameSpace
//If not, please create it before testing
//deployment 历史处理测试
func TestDeploymentHistoryHandle(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/deployments/%s/replicasets", api.TestNamespace, api.TestName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}
