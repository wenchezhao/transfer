package resources

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//获取 ApiResources 列表测试
func TestApiResourcesList(t *testing.T) {
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, fmt.Sprintf("/v1/apiresources"), nil)
}
