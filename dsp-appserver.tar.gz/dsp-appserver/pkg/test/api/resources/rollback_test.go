package resources

import (
	"fmt"
	"net/http"
	url2 "net/url"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//deployment 回滚测试
//在测试之前，在集群中创建deployment，命名为test；
func TestDeploymentRollback(t *testing.T) {
	q := url2.Values{}
	q.Set("revision", "1")
	url := fmt.Sprintf("/v1/namespaces/%s/deployments/%s/rollback?%s", api.TestNamespace, api.TestName, q.Encode())
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, nil)
}
