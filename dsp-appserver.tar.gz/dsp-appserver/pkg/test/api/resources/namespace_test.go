package resources

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/handlers/resources"
	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//bindNamespace 测试
func TestNamespaceBind(t *testing.T) {
	url := fmt.Sprintf("/v1/bindnamespaces")
	request := &resources.NamespaceRequestParams{
		Namespaces: []string{api.TestNamespace},
		Clusters:   []string{api.TestClusterK8s},
		SystemCode: "100",
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, request)

}

//ListNameSpace 测试
func TestNamespaceList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces?labelSelector=%s", "aaa=bbb")
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}
