package resources

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//删除 imageStream 测试
func TestImageStreamsDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/imagestreams/%s", api.TestNamespace, "aa")
	api.MockApi(t, api.TestClusterOcp, http.MethodDelete, url, nil)
}
