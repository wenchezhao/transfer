package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	routeapi "github.com/openshift/api/route/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestRouteName = "testRoute"

//创建路由测试
func TestRouteCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/routes", api.TestNamespace)
	weight := int32(100)
	routeReq := &routeapi.Route{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Route",
			APIVersion: "route.openshift.io/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestRouteName,
			Namespace: api.TestNamespace,
			Labels: map[string]string{
				"aaa": "bbb",
			},
		},
		Spec: routeapi.RouteSpec{
			Host: "test123",
			Path: "/",
			To: routeapi.RouteTargetReference{
				Kind:   "Service",
				Name:   "aaa",
				Weight: &weight,
			},
			WildcardPolicy: routeapi.WildcardPolicyNone,
		},
	}

	api.MockApi(t, api.TestClusterOcp, http.MethodPost, url, routeReq)

}

//获取路由列表测试
func TestRouteList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/routes", api.TestNamespace)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取指定路由测试
func TestRouteGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/routes/%s", api.TestNamespace, TestRouteName)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取路由 pod 列表测试
func TestRoutePodsList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/routes/%s/pods", api.TestNamespace, TestRouteName)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//更新路由测试
func TestRouteUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/routes/%s", api.TestNamespace, TestRouteName)
	w := api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
	routeReq := &routeapi.Route{}
	err := json.Unmarshal(w.Body.Bytes(), routeReq)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}

	api.MockApi(t, api.TestClusterOcp, http.MethodPut, url, routeReq)

}

//删除路由测试
func TestRouteDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/routes/%s", api.TestNamespace, TestRouteName)
	api.MockApi(t, api.TestClusterOcp, http.MethodDelete, url, nil)
}
