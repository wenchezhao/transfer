package resources

import (
	"fmt"
	"net/http"
	url2 "net/url"
	"testing"

	appsv1 "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestStatefulSetName = "testStatefulSet"

//创建 statefulSet 测试
func TestStatefulSetCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/statefulsets", api.TestNamespace)
	replicas := int32(1)
	labels := map[string]string{
		"aaa": "ddd",
	}
	statefulset := &appsv1.StatefulSet{
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestStatefulSetName,
			Namespace: api.TestNamespace,
		},
		TypeMeta: metav1.TypeMeta{
			APIVersion: "apps/v1",
			Kind:       "StatefulSet",
		},
		Spec: appsv1.StatefulSetSpec{
			Replicas: &replicas,
			Selector: &metav1.LabelSelector{
				MatchLabels: labels,
			},
			Template: v1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: labels,
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "aaa",
							Image: "nginx:latest",
						},
					},
				},
			},
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, statefulset)
}

//获取 statefulSet 列表测试
func TestStatefulSetList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/statefulsets", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定 statefulSet 测试
func TestStatefulSetGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/statefulsets/%s", api.TestNamespace, TestStatefulSetName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 statefulSet 的Pod 测试
func TestStatefulSetPodGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/statefulsets/%s/pods", api.TestNamespace, TestStatefulSetName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 statefulSetEvent 测试
func TestStatefulSetEventGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/statefulsets/%s/events", api.TestNamespace, TestStatefulSetName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//statefulSet 重启测试
func TestStatefulSetRestart(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/statefulsets/%s/restart", api.TestNamespace, TestStatefulSetName)
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, nil)
}

//statefulSet 扩缩容测试
func TestStatefulSetScale(t *testing.T) {
	q := url2.Values{}
	q.Set("replicas", "2")
	url := fmt.Sprintf("/v1/namespaces/%s/statefulsets/%s/scale?%s", api.TestNamespace, TestStatefulSetName, q.Encode())
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, nil)
}

//更新 statefulSet 测试
//先进行lables的修改，然后提交更新
func TestStatefulSetUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/statefulsets/%s", api.TestNamespace, TestStatefulSetName)
	replicas := int32(1)
	labels := map[string]string{
		"aaa": "ddd",
	}
	statefulset := &appsv1.StatefulSet{
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestStatefulSetName,
			Namespace: api.TestNamespace,
		},
		TypeMeta: metav1.TypeMeta{
			APIVersion: "apps/v1",
			Kind:       "StatefulSet",
		},
		Spec: appsv1.StatefulSetSpec{
			Replicas: &replicas,
			Selector: &metav1.LabelSelector{
				MatchLabels: labels,
			},
			Template: v1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: labels,
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "aaa",
							Image: "nginx:1.20",
						},
					},
				},
			},
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, statefulset)
}

//删除 statefulSet 测试
func TestStatefulSetDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/statefulsets/%s", api.TestNamespace, TestStatefulSetName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
