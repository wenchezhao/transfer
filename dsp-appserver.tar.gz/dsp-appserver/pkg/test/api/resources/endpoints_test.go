package resources

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//Use the endpoint that already exists in the TestNameSpace，If not, please create it before testing
//获取 endpoints 列表测试
func TestEndpointsList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/endpoints", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)

}

//获取指定 endpoints 测试
func TestEndpointsGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/endpoints/%s", api.TestNamespace, "test")
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}
