package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestServiceName = "testService"

//创建 service 测试
func TestServiceCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/services", api.TestNamespace)
	port := int32(80)
	serviceReq := &corev1.Service{
		TypeMeta: metav1.TypeMeta{
			Kind:       "service",
			APIVersion: "core/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestServiceName,
			Namespace: api.TestNamespace,
			Labels: map[string]string{
				"app": "myapp",
			},
		},
		Spec: corev1.ServiceSpec{
			Selector: map[string]string{
				"app": "myapp",
			},
			Ports: []corev1.ServicePort{
				{
					Protocol: "TCP",
					Port:     port,
					//TargetPort: TargetPort,

				},
			},
		},
	}

	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, serviceReq)
}

//获取 service 列表测试
func TestServiceList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/services?%s", api.TestNamespace, "app")
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定 service 测试
func TestServiceGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/services/%s", api.TestNamespace, TestServiceName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)

}

//获取 serviceEvents 测试
func TestServiceEvents(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/services/%s/events", api.TestNamespace, TestServiceName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 ServiceRoute 列表
func TestServiceRouteList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/services/%s/routes", api.TestNamespace, TestServiceName)

	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 ServiceTrafficObjectList 测试
func TestServiceTrafficObjectList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/services/%s/trafficobjects", api.TestNamespace, TestServiceName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 servicePod 列表测试
func TestServicePodList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/services/%s/pods", api.TestNamespace, TestServiceName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//更新 service 测试
//先获取指定的service，然后修改其labels，最后进行更新；
func TestServiceUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/services/%s", api.TestNamespace, TestServiceName)
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)

	service := &corev1.Service{}
	err := json.Unmarshal(w.Body.Bytes(), service)
	if err != nil {
		t.Errorf("failet to unmashal : %v", err)
	}
	lables := map[string]string{
		"aaa": "bbb",
	}
	service.Labels = lables
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, service)
}

//删除 service 测试
func TestServiceDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/services/%s", api.TestNamespace, TestServiceName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
