package resources

import (
	"fmt"
	"net/http"
	"testing"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestPersistentVolumeName = "testpv"

//创建 PersistentVolume 测试
func TestPersistentVolumeCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/persistentvolumes")
	pvRequest := &corev1.PersistentVolume{
		TypeMeta: metav1.TypeMeta{
			Kind:       "persistentVolume",
			APIVersion: "core/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: TestPersistentVolumeName,
			Labels: map[string]string{
				"type": "local",
			},
		},
		Spec: corev1.PersistentVolumeSpec{
			PersistentVolumeSource: corev1.PersistentVolumeSource{
				HostPath: &corev1.HostPathVolumeSource{
					Path: "/mnt/data",
				},
			},
			AccessModes: []corev1.PersistentVolumeAccessMode{
				"ReadWriteOnce",
			},
			Capacity: map[corev1.ResourceName]resource.Quantity{
				"storage": *resource.NewQuantity(1, "Gi"),
			},
			StorageClassName: "local-storage",
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, pvRequest)
}

//获取 PersistentVolume 列表测试
func TestPersistentVolumeList(t *testing.T) {
	url := fmt.Sprintf("/v1/persistentvolumes")
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定 PersistentVolume 测试
func TestPersistentVolumeGet(t *testing.T) {
	url := fmt.Sprintf("/v1/persistentvolumes/%s", TestPersistentVolumeName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)

}

//获取 PersistentVolumeEvents 测试
func TestPersistentVolumeEventList(t *testing.T) {
	url := fmt.Sprintf("/v1/persistentvolumes/%s/events", TestPersistentVolumeName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//更新 PersistentVolume 测试
func TestPersistentVolumeUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/persistentvolumes/%s", TestPersistentVolumeName)
	pvRequest := &corev1.PersistentVolume{
		TypeMeta: metav1.TypeMeta{
			Kind:       "persistentVolume",
			APIVersion: "core/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestPersistentVolumeName,
			Namespace: api.TestNamespace,
			Labels: map[string]string{
				"type": "local",
			},
		},
		Spec: corev1.PersistentVolumeSpec{
			PersistentVolumeSource: corev1.PersistentVolumeSource{
				HostPath: &corev1.HostPathVolumeSource{
					Path: "/mnt/data",
				},
			},
			AccessModes: []corev1.PersistentVolumeAccessMode{
				"ReadWriteOnce",
			},
			Capacity: map[corev1.ResourceName]resource.Quantity{
				"storage": *resource.NewMilliQuantity(2, resource.DecimalSI),
			},
			StorageClassName: "local-storage",
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, pvRequest)
}

//删除 PersistentVolumeEvent 测试
func TestPersistentVolumeDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/persistentvolumes/%s", TestPersistentVolumeName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
