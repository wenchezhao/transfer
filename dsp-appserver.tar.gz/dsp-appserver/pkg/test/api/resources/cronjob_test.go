package resources

import (
	"fmt"
	"net/http"
	"testing"

	batchv1 "k8s.io/api/batch/v1"
	"k8s.io/api/batch/v1beta1"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestCronJobName = "testcronjob"

//创建 Cronjob 单元测试
func TestCronJobCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/cronjobs", api.TestNamespace)
	cronjob := &v1beta1.CronJob{
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestCronJobName,
			Namespace: api.TestNamespace,
		},
		TypeMeta: metav1.TypeMeta{
			APIVersion: "beta/v1",
			Kind:       "cronjob",
		},
		Spec: v1beta1.CronJobSpec{
			Schedule: "*/100 * * * *",
			JobTemplate: v1beta1.JobTemplateSpec{
				Spec: batchv1.JobSpec{
					Template: v1.PodTemplateSpec{
						Spec: v1.PodSpec{
							RestartPolicy: "OnFailure",
							Containers: []v1.Container{
								{
									Name:  "bbb",
									Image: "busybox",
									Command: []string{
										"- /bin/sh",
										"- date; echo Hello from the Kubernetes cluster",
									},
								},
							},
						},
					},
				},
			},
		},
	}
	api.MockApi(t, api.TestClusterOcp, http.MethodPost, url, cronjob)
}

//获取 cronjob 列表测试
func TestCronJobList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/cronjobs", api.TestNamespace)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取指定 cronjob 测试
func TestCronJobGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/cronjobs/%s", api.TestNamespace, TestCronJobName)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取 cronjob 事件测试
func TestCronJobEvents(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/cronjobs/%s/events", api.TestNamespace, TestCronJobName)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取 cronjob 的 job 测试
func TestJobList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/cronjobs/%s/jobs", api.TestNamespace, TestCronJobName)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//更新 cronjob 测试
func TestCornJobUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/cronjobs/%s", api.TestNamespace, TestCronJobName)
	cjrequest := &v1beta1.CronJob{
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestCronJobName,
			Namespace: api.TestNamespace,
		},
		TypeMeta: metav1.TypeMeta{
			APIVersion: "beta/v1",
			Kind:       "cronjob",
		},
		Spec: v1beta1.CronJobSpec{
			Schedule: "*/200 * * * *",
			JobTemplate: v1beta1.JobTemplateSpec{
				Spec: batchv1.JobSpec{
					Template: v1.PodTemplateSpec{
						Spec: v1.PodSpec{
							RestartPolicy: "OnFailure",
							Containers: []v1.Container{
								{
									Name:  "bbb",
									Image: "busybox",
									Command: []string{
										"- /bin/sh",
										"- date; echo Hello from the Kubernetes cluster",
									},
								},
							},
						},
					},
				},
			},
		},
	}
	api.MockApi(t, api.TestClusterOcp, http.MethodPut, url, cjrequest)
}

//删除 cronjob 测试
func TestCronJobDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/cronjobs/%s", api.TestNamespace, TestCronJobName)
	api.MockApi(t, api.TestClusterOcp, http.MethodDelete, url, nil)
}
