package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestSecretName = "testSecret"

//创建 secret 测试
func TestSecretCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/secrets", api.TestNamespace)
	secretReq := &corev1.Secret{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "core/v1",
			Kind:       "secret",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestSecretName,
			Namespace: api.TestNamespace,
		},
		Type: "kubernetes.io/basic-auth",
		StringData: map[string]string{
			"username": "admin",
			"password": "test-secret",
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, secretReq)
}

//获取 secret 列表测试
func TestSecretList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/secrets", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定 secret 测试
func TestSecretGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/secrets/%s", api.TestNamespace, TestSecretName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 secretObjrefs 列表测试
func TestSecretObjrefsList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/secrets/%s/objrefs", api.TestNamespace, TestSecretName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//更新 secret 测试
//先获取指定的secret，然后修改其labels，最后进行更新；
func TestSecretUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/secrets/%s", api.TestNamespace, TestSecretName)
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)

	secret := &corev1.Secret{}
	err := json.Unmarshal(w.Body.Bytes(), secret)
	if err != nil {
		t.Errorf("failet to unmashal : %v", err)
	}
	lables := map[string]string{
		"aaa": "bbb",
	}
	secret.Labels = lables
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, secret)
}

//删除 secret 测试
func TestSecretDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/secrets/%s", api.TestNamespace, TestSecretName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
