package resources

import (
	"fmt"
	"net/http"
	url2 "net/url"
	"testing"

	appsv1 "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestDeploymentName = "testdeployment"

//创建Deployment 接口测试；
func TestDeploymentCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/deployments", api.TestNamespace)
	replicas := int32(1)
	labels := map[string]string{
		"aaa": "ddd",
	}
	deployemnt := &appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestDeploymentName,
			Namespace: api.TestNamespace,
		},
		TypeMeta: metav1.TypeMeta{
			APIVersion: "apps/v1",
			Kind:       "Deployment",
		},
		Spec: appsv1.DeploymentSpec{
			Replicas: &replicas,
			Selector: &metav1.LabelSelector{
				MatchLabels: labels,
			},
			Template: v1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: labels,
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "aaa",
							Image: "nginx:latest",
						},
					},
				},
			},
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, deployemnt)
}

//获取Deployment 列表测试；
func TestDeploymentList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/deployments", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定Deployment 接口测试；
func TestDeploymentGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/deployments/%s", api.TestNamespace, TestDeploymentName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取Deployment pod 接口测试；
func TestDeploymentPodGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/deployments/%s/pods", api.TestNamespace, TestDeploymentName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取Deployment 事件列表测试；
func TestDeploymentEvents(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/deployments/%s/events", api.TestNamespace, TestDeploymentName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//Deployment 重启测试；
func TestDeploymentRestart(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/deployments/%s/restart", api.TestNamespace, TestDeploymentName)
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, nil)
}

//Deployment 扩缩容测试；
func TestDeploymentScale(t *testing.T) {
	q := url2.Values{}
	q.Set("replicas", "2")
	url := fmt.Sprintf("/v1/namespaces/%s/deployments/%s/scale?%s", api.TestNamespace, TestDeploymentName, q.Encode())
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, nil)
}

//Deployment 更新测试（进行的镜像更新）；
func TestDeploymentUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/deployments/%s", api.TestNamespace, TestDeploymentName)
	replicas := int32(1)
	labels := map[string]string{
		"aaa": "ddd",
	}
	resultDeployemnt := &appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestDeploymentName,
			Namespace: api.TestNamespace,
		},
		TypeMeta: metav1.TypeMeta{
			APIVersion: "apps/v1",
			Kind:       "Deployment",
		},
		Spec: appsv1.DeploymentSpec{
			Replicas: &replicas,
			Selector: &metav1.LabelSelector{
				MatchLabels: labels,
			},
			Template: v1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: labels,
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "aaa",
							Image: "nginx:1.20",
						},
					},
				},
			},
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, resultDeployemnt)
}

//Deployment 删除接口测试；
func TestDeploymentDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/deployments/%s", api.TestNamespace, TestDeploymentName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
