package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	v1 "k8s.io/api/autoscaling/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//HorizontalPodAutoScaler already exists in the namespace. If not, please create it before testing
const TestHorizontalPodAutoScalerName = "test"

//获取 hpa 列表测试
func TestHorizontalPodAutoScalerList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/horizontalpodautoscalers", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定 hpa 测试
func TestHorizontalPodAutoScalerGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/horizontalpodautoscalers/%s", api.TestNamespace, TestHorizontalPodAutoScalerName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//更新 hpa 测试
//先获取指定的hpa，修改其副本数，在进行更新
func TestHorizontalPodAutoScalerUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/horizontalpodautoscalers/%s", api.TestNamespace, TestHorizontalPodAutoScalerName)
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
	horizontalPodAutoScaler := &v1.HorizontalPodAutoscaler{}
	err := json.Unmarshal(w.Body.Bytes(), horizontalPodAutoScaler)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	horizontalPodAutoScaler.Spec.MaxReplicas = 4
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, horizontalPodAutoScaler)
}

//删除 hpa 测试
func TestHorizontalPodAutoScalerDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/horizontalpodautoscalers/%s", api.TestNamespace, TestHorizontalPodAutoScalerName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
