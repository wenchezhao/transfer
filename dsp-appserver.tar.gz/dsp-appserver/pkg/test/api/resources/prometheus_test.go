package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	monitoringv1 "github.com/prometheus-operator/prometheus-operator/pkg/apis/monitoring/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/intstr"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestPrometheusName = "prometheus"

//创建 PrometheusRule 测试
func TestPrometheusRuleCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/prometheusrules", api.TestNamespace)
	ruleRequest := &monitoringv1.PrometheusRule{
		TypeMeta: metav1.TypeMeta{
			Kind:       "prometheusRule",
			APIVersion: "monitoring.coreos.com/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestPrometheusName,
			Namespace: api.TestNamespace,
			Labels: map[string]string{
				"aaa": "bbb",
			},
		},
		Spec: monitoringv1.PrometheusRuleSpec{
			Groups: []monitoringv1.RuleGroup{
				{
					Name:     TestPrometheusName,
					Interval: "",
					Rules: []monitoringv1.Rule{
						{
							Record: "job:http_inprogress_requests:sum",
							Expr: intstr.IntOrString{
								StrVal: "sum(http_inprogress_requests) by (job)",
							},
							Labels: map[string]string{
								"aaa": "bbb",
							},
						},
					},
				},
			},
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, ruleRequest)
}

//获取 PrometheusRuleNamespaceList 测试
func TestPrometheusRulesNamespaceList(t *testing.T) {
	url := fmt.Sprintf("/v1/prometheus/rulenamespaces")
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 PrometheusRuleList 测试
func TestPrometheusRuleList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/prometheusrules", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定 PrometheusRule 测试
func TestPrometheusRuleGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/prometheusrules/%s", api.TestNamespace, TestPrometheusName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//更新 PrometheusRule 测试
//先获取需要更新的prometheusRule，进行lables修改，在进行更新
func TestPrometheusRuleUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/prometheusrules/%s", api.TestNamespace, TestPrometheusName)

	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
	PrometheusRule := &monitoringv1.PrometheusRule{}
	err := json.Unmarshal(w.Body.Bytes(), PrometheusRule)
	if err != nil {
		t.Errorf("failed to unmarshal: %v", err)
	}
	lables := map[string]string{
		"aaa": "ccc",
	}
	PrometheusRule.Labels = lables
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, PrometheusRule)

}

//删除 PrometheusRule 测试
func TestPrometheusRuleDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/prometheusrules/%s", api.TestNamespace, TestPrometheusName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
