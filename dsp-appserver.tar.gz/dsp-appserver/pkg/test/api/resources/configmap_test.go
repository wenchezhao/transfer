package resources

import (
	"fmt"
	"net/http"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestConfigMapName = "testconfigmap"

//创建 ConfigMap 测试
func TestConfigmapCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/configmaps", api.TestNamespace)
	configmap := &corev1.ConfigMap{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "core/v1",
			Kind:       "ConfigMap",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestConfigMapName,
			Namespace: api.TestNamespace,
		},
		Data: map[string]string{
			"player_initial_lives":    "3",
			"ui_properties_file_name": "user-interface.properties",
		},
	}
	api.MockApi(t, api.TestClusterOcp, http.MethodPost, url, configmap)
}

//获取 ConfigMap list测试
func TestConfigMapList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/configmaps", api.TestNamespace)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取 configmap 测试
func TestConfigmapGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/configmaps/%s", api.TestNamespace, TestConfigMapName)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//获取 configmap objrefs测试
func TestConfigMapObjrefsList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/configmaps/%s/objrefs", api.TestNamespace, TestConfigMapName)
	api.MockApi(t, api.TestClusterOcp, http.MethodGet, url, nil)
}

//更新 configmap 测试(进行的data更新测试)
func TestConfigMapUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/configmaps/%s", api.TestNamespace, TestConfigMapName)
	configmapReq := &corev1.ConfigMap{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "core/v1",
			Kind:       "ConfigMap",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestConfigMapName,
			Namespace: api.TestNamespace,
		},
		Data: map[string]string{
			"player_initial_lives":    "4",
			"ui_properties_file_name": "user-interface.properties",
		},
	}

	api.MockApi(t, api.TestClusterOcp, http.MethodPut, url, configmapReq)
}

//删除 configmap 测试
func TestConfigMapDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/configmaps/%s", api.TestNamespace, TestConfigMapName)
	api.MockApi(t, api.TestClusterOcp, http.MethodDelete, url, nil)
}
