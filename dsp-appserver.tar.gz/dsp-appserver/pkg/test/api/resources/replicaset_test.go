package resources

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//Use the ReplicaSet that already exists in the TestNameSpace
//If not, please create it before testing
const TestReplicaSetName = "test-d4df74fc9"

//获取 ReplicaSetEventList 测试
func TestReplicaSetEventList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/replicaset/%s/events", api.TestNamespace, TestReplicaSetName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}
