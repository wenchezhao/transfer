package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	appsv1 "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime/schema"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestCustomResourceName = "otherResource"

//创建 resource 测试
func TestResourcesCreate(t *testing.T) {
	gvr := schema.GroupVersionResource{
		Group:    "apps",
		Version:  "v1",
		Resource: "deployments",
	}

	resByte, err := json.Marshal(gvr)
	if err != nil {
		t.Errorf("error:%v", err)
	}

	url := fmt.Sprintf("/v1/namespaces/%s/otherresources?gvr=%s", api.TestNamespace, string(resByte))

	replicas := int32(1)
	labels := map[string]string{
		"aaa": "ddd",
	}
	deployemnt := &appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestCustomResourceName,
			Namespace: api.TestNamespace,
		},
		TypeMeta: metav1.TypeMeta{
			APIVersion: "apps/v1",
			Kind:       "Deployment",
		},
		Spec: appsv1.DeploymentSpec{
			Replicas: &replicas,
			Selector: &metav1.LabelSelector{
				MatchLabels: labels,
			},
			Template: v1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: labels,
				},
				Spec: v1.PodSpec{
					Containers: []v1.Container{
						{
							Name:  "aaaddd",
							Image: "nginx:latest",
						},
					},
				},
			},
		},
	}

	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, deployemnt)
}

//获取 resource 列表测试
func TestResourcesList(t *testing.T) {
	gvr := schema.GroupVersionResource{
		Group:    "apps",
		Version:  "v1",
		Resource: "deployments",
	}

	resByte, err := json.Marshal(gvr)
	if err != nil {
		t.Errorf("error:%v", err)
	}
	url := fmt.Sprintf("/v1/namespaces/%s/otherresources?gvr=%s", api.TestNamespace, string(resByte))
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定 resource 测试
func TestResourceGet(t *testing.T) {
	gvr := schema.GroupVersionResource{
		Group:    "apps",
		Version:  "v1",
		Resource: "deployments",
	}

	resByte, err := json.Marshal(gvr)
	if err != nil {
		t.Errorf("error:%v", err)
	}
	url := fmt.Sprintf("/v1/namespaces/%s/otherresources/%s?gvr=%s", api.TestNamespace, TestCustomResourceName, string(resByte))
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//更新 resource 测试
func TestResourceUpdate(t *testing.T) {
	gvr := schema.GroupVersionResource{
		Group:    "apps",
		Version:  "v1",
		Resource: "deployments",
	}

	resByte, err := json.Marshal(gvr)
	if err != nil {
		t.Errorf("error:%v", err)
	}

	url := fmt.Sprintf("/v1/namespaces/%s/otherresources/%s?gvr=%s", api.TestNamespace, TestCustomResourceName, string(resByte))
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
	resource := &appsv1.Deployment{}
	err = json.Unmarshal(w.Body.Bytes(), resource)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	lables := map[string]string{
		"ddd": "aaa",
	}
	resource.Labels = lables
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, resource)
}

//删除 resource 测试
func TestResourceDelete(t *testing.T) {
	gvr := schema.GroupVersionResource{
		Group:    "apps",
		Version:  "v1",
		Resource: "deployments",
	}

	resByte, err := json.Marshal(gvr)
	if err != nil {
		t.Errorf("error:%v", err)
	}
	url := fmt.Sprintf("/v1/namespaces/%s/otherresources/%s?gvr=%s", api.TestNamespace, TestCustomResourceName, string(resByte))
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
