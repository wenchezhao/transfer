package resources

import (
	"fmt"
	"net/http"
	"testing"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const GenericQuotaName = "dsp-quota-default"

//获取资源配额测试
func TestResourceQuotaGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/resourcequota?clusters=%s", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, "", http.MethodGet, url, nil)
}

//通过集群获取资源配额测试
func TestResourceQuotaByClustersGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/resourcequotamany?clusters=%s", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, "", http.MethodGet, url, nil)
}

//更新资源配额测试
func TestResourceQuotaUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/resourcequota?clusters=%s", api.TestNamespace, api.TestClusterK8s)
	resourceQuota := &corev1.ResourceQuota{
		TypeMeta: metav1.TypeMeta{
			Kind:       "ResourceQuota",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      GenericQuotaName,
			Namespace: api.TestNamespace,
		},
		Spec: corev1.ResourceQuotaSpec{
			Hard: map[corev1.ResourceName]resource.Quantity{
				"limits.cpu": *resource.NewMilliQuantity(1000, resource.DecimalSI),
			},
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, resourceQuota)
}
