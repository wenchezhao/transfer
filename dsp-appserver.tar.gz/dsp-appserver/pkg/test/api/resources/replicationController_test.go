package resources

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//Use the ReplicationController that already exists in the TestNameSpace，If not, please create it before testing
const TestReplicationControllerName = "nginx"

//获取 ReplicationControllerList 测试
func TestReplicationControllerList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/replicationcontrollers?labelSelector=%s", api.TestNamespace, "aaa=bbb")
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 ReplicationControllerEnentsList 测试
func TestReplicationControllerEnentsList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/replicationcontrollers/%s/events", api.TestNamespace, TestReplicationControllerName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}
