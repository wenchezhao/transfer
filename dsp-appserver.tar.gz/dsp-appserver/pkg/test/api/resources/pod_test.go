package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	corev1 "k8s.io/api/core/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//Pod already exists in the namespace. If not, please create it before testing
//获取 Pod 列表测试
func TestPodList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/pods", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定 pod 测试
func TestPodGet(t *testing.T) {
	url1 := fmt.Sprintf("/v1/namespaces/%s/pods", api.TestNamespace)
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url1, nil)
	Pods := corev1.PodList{}
	err := json.Unmarshal(w.Body.Bytes(), &Pods)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	PodName := Pods.Items[0].Name

	url := fmt.Sprintf("/v1/namespaces/%s/pods/%s", api.TestNamespace, PodName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 pod 事件列表测试
func TestPodEventsList(t *testing.T) {
	url1 := fmt.Sprintf("/v1/namespaces/%s/pods", api.TestNamespace)
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url1, nil)
	Pods := corev1.PodList{}
	err := json.Unmarshal(w.Body.Bytes(), &Pods)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	PodName := Pods.Items[0].Name

	url := fmt.Sprintf("/v1/namespaces/%s/pods/%s/events", api.TestNamespace, PodName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//删除 pod 列表测试
func TestPodListDelete(t *testing.T) {
	url1 := fmt.Sprintf("/v1/namespaces/%s/pods", api.TestNamespace)
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url1, nil)
	Pods := corev1.PodList{}
	err := json.Unmarshal(w.Body.Bytes(), &Pods)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	PodName := Pods.Items[0].Name

	url := fmt.Sprintf("/v1/namespaces/%s/pods?names=%s", api.TestNamespace, PodName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}

//删除指定 pod 测试
func TestPodDelete(t *testing.T) {
	url1 := fmt.Sprintf("/v1/namespaces/%s/pods", api.TestNamespace)
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url1, nil)
	Pods := corev1.PodList{}
	err := json.Unmarshal(w.Body.Bytes(), &Pods)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	PodName := Pods.Items[0].Name

	url := fmt.Sprintf("/v1/namespaces/%s/pods/%s", api.TestNamespace, PodName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
