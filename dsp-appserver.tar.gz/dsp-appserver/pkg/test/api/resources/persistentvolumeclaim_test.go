package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestPVCName = "testpvc"

//创建 PersistentVolumeClaim 测试
func TestPersistentVolumeClaimCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/persistentvolumeclaims", api.TestNamespace)
	storageClassname := "local-storage"
	pvcRequest := &corev1.PersistentVolumeClaim{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "core/v1",
			Kind:       "persistentVolumeClaim",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestPVCName,
			Namespace: api.TestNamespace,
			Labels: map[string]string{
				"type": "local",
			},
		},
		Spec: corev1.PersistentVolumeClaimSpec{
			AccessModes: []corev1.PersistentVolumeAccessMode{
				"ReadWriteOnce",
			},
			Selector: &metav1.LabelSelector{
				MatchLabels: map[string]string{
					"type": "local",
				},
			},
			Resources: corev1.ResourceRequirements{
				Requests: map[corev1.ResourceName]resource.Quantity{
					"storage": *resource.NewQuantity(1, ""),
				},
			},
			StorageClassName: &storageClassname,
			VolumeName:       "pvc-test",
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, pvcRequest)
}

//获取 PersistentVolumeClaim 测试
func TestPersistentVolumeClaimGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/persistentvolumeclaims/%s", api.TestNamespace, TestPVCName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 PersistentVolumeClaimList 测试
func TestPersistentVolumeClaimList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/persistentvolumeclaims", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 PersistentVolumeClaimObjectReference 测试
func TestPersistentVolumeClaimObjectReferenceGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/persistentvolumeclaims/%s/objrefs", api.TestNamespace, TestPVCName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 PersistentVolumeClaimEvent 测试
func TestPersistentVolumeClaimEventGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/persistentvolumeclaims/%s/events", api.TestNamespace, TestPVCName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 PersistentVolumeClaimPod 列表测试
func TestPersistentVolumeClaimPodList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/persistentvolumeclaims/%s/pods", api.TestNamespace, TestPVCName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//更新 PersistentVolumeClaim 测试
func TestPersistentVolumeClaimUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/persistentvolumeclaims/%s", api.TestNamespace, TestPVCName)
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
	pvc := &corev1.PersistentVolumeClaim{}
	err := json.Unmarshal(w.Body.Bytes(), pvc)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	lables := map[string]string{
		"type-update": "local-update",
	}
	pvc.Labels = lables
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, pvc)
}

//删除 PersistentVolumeClaim 测试
func TestPersistentVolumeClaimDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/persistentvolumeclaims/%s", api.TestNamespace, TestPVCName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
