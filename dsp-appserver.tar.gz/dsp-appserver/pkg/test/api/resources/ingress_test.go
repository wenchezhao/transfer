package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	"k8s.io/api/networking/v1beta1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/intstr"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

const TestIngressName = "testingress"

//创建 Ingress 接口测试
func TestIngressCreate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/ingresses", api.TestNamespace)
	ingressReq := &v1beta1.Ingress{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "beta1/v1",
			Kind:       "Ingress",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      TestIngressName,
			Namespace: api.TestNamespace,
		},
		Spec: v1beta1.IngressSpec{
			Rules: []v1beta1.IngressRule{
				{
					Host: "k8s01.ats",
				},
			},
			Backend: &v1beta1.IngressBackend{
				ServiceName: "test",
				ServicePort: intstr.FromInt(80),
			},
		},
	}
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, ingressReq)
}

//获取 Ingress 列表接口测试
func TestIngressList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/ingresses", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取指定 Ingress 接口测试
func TestIngressGet(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/ingresses/%s", api.TestNamespace, TestIngressName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 Ingress 的 pod 列表测试
func TestIngressPodsList(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/ingresses/%s/pods", api.TestNamespace, TestIngressName)
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//更新 Ingress 接口测试
//先获取指定的ingress，修改其lables，再进行更新
func TestIngressUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/ingresses/%s", api.TestNamespace, TestIngressName)
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)

	Ingress := &v1beta1.Ingress{}
	err := json.Unmarshal(w.Body.Bytes(), Ingress)
	if err != nil {
		t.Errorf("failet to unmashal : %v", err)
	}
	servicePort := intstr.FromInt(80)
	Ingress.Spec.Backend.ServicePort = servicePort
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, Ingress)
}

//删除 Ingress 接口测试
func TestIngressDelete(t *testing.T) {
	url := fmt.Sprintf("/v1/namespaces/%s/ingresses/%s", api.TestNamespace, TestIngressName)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, nil)
}
