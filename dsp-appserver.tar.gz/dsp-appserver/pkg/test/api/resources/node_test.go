package resources

import (
	"encoding/json"
	"fmt"
	"net/http"
	"testing"

	v1 "k8s.io/api/core/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//获取 Nodes 接口测试
func TestNodeList(t *testing.T) {
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, "/v1/nodes", nil)
}

//获取 NodeLabels 接口测试
func TestNodeLabelsList(t *testing.T) {
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, "/v1/nodelabels", nil)
}

//获取 NodeIps 接口测试
func TestNodeIpsList(t *testing.T) {
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, "/v1/nodeips", nil)
}

//获取指定 Node 测试
func TestNodeGet(t *testing.T) {
	url := fmt.Sprintf("/v1/nodes/%s", "node1")
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 Node 下 pods 测试
func TestNodePodsGet(t *testing.T) {
	url := fmt.Sprintf("/v1/nodes/%s/pods", "node1")
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//获取 NodeEvents 测试
func TestNodeEventsList(t *testing.T) {
	url := fmt.Sprintf("/v1/nodes/%s/events", "node1")
	api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
}

//更新 Node 测试
//先获取一个node，修改lables，再进行更新提交
func TestNodeUpdate(t *testing.T) {
	url := fmt.Sprintf("/v1/nodes/%s", "node1")
	w := api.MockApi(t, api.TestClusterK8s, http.MethodGet, url, nil)
	nodeUpdate := &v1.Node{}
	err := json.Unmarshal(w.Body.Bytes(), nodeUpdate)
	if err != nil {
		t.Errorf("failed to unmarshal:%v", err)
	}
	lables := map[string]string{
		"aaa": "bbb",
	}
	nodeUpdate.Labels = lables
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, nodeUpdate)
}
