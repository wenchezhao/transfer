package dashboard

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//获取集群概览测试
func TestClusterCountInfoGet(t *testing.T) {
	url := fmt.Sprintf("/v1/dashboard/clustercount?clusters=%s", "k8s")
	api.MockApi(t, "", http.MethodGet, url, nil)
}

//返回系统资源数量统计信息
func TestResourcesCountInfoGet(t *testing.T) {
	url := fmt.Sprintf("/v1/dashboard/resourcecount?namespaces=%s&clusters=%s", api.TestNamespace, "k8s")
	api.MockApi(t, "", http.MethodGet, url, nil)
}

//返回系统资源信息
func TestQuotaCountInfo(t *testing.T) {
	url := fmt.Sprintf("/v1/dashboard/quotacount?namespace=%s&clusters=%s", api.TestNamespace, "k8s")
	api.MockApi(t, "", http.MethodGet, url, nil)
}

//返回系统pod状态信息
func TestPodCountInfo(t *testing.T) {
	url := fmt.Sprintf("/v1/dashboard/podcount?namespace=%s&clusters=%s", api.TestNamespace, "k8s")
	api.MockApi(t, "", http.MethodGet, url, nil)
}
