package app

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/test/api"
)

//在同目录下创建app.yaml文件 用来进行application api接口的测试；
//check Yaml 测试
func TestCheckYaml(t *testing.T) {
	bytes, err := ioutil.ReadFile("./app.yaml")
	if err != nil {
		t.Errorf("failed to readfile")
	}
	url := fmt.Sprintf("/v1/namespaces/%s/yaml/check", api.TestNamespace)
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, bytes)
}

//获取 ApplicationWorkloads 测试
func TestApplicationWorkloadsGet(t *testing.T) {
	bytes, err := ioutil.ReadFile("./app.yaml")
	if err != nil {
		t.Errorf("failed to readfile")
	}
	url := fmt.Sprintf("/v1/namespaces/%s/applications/%s/workloads", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, bytes)
}

//获取 ApplicationDiscover 测试
func TestApplicationDiscoverGet(t *testing.T) {
	bytes, err := ioutil.ReadFile("./app.yaml")
	if err != nil {
		t.Errorf("failed to readfile")
	}
	url := fmt.Sprintf("/v1/namespaces/%s/applications/%s/discovery", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, bytes)
}

//获取 ApplicationStorage 测试
func TestApplicationStorageGet(t *testing.T) {
	bytes, err := ioutil.ReadFile("./app.yaml")
	if err != nil {
		t.Errorf("failed to readfile")
	}
	url := fmt.Sprintf("/v1/namespaces/%s/applications/%s/storage", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, bytes)
}

//获取 ApplicationOther 测试
func TestApplicationOtherGet(t *testing.T) {
	serviceAccount := &corev1.ServiceAccount{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "v1",
			Kind:       "ServiceAccount",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "testa",
			Namespace: api.TestNamespace,
		},
		Secrets: []corev1.ObjectReference{
			{
				Name: "testatoken",
			},
		},
	}

	url := fmt.Sprintf("/v1/namespaces/%s/applications/%s/other", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, serviceAccount)
}

//获取 ApplicationPods 测试
func TestApplicationPodsGet(t *testing.T) {
	bytes, err := ioutil.ReadFile("./app.yaml")
	if err != nil {
		t.Errorf("failed to readfile")
	}
	url := fmt.Sprintf("/v1/namespaces/%s/applications/%s/pods", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, bytes)
}

//获取 ApplicationStatus 测试
func TestApplicationStatusGet(t *testing.T) {
	bytes, err := ioutil.ReadFile("./app.yaml")
	if err != nil {
		t.Errorf("failed to readfile")
	}
	url := fmt.Sprintf("/v1/namespaces/%s/applications/%s/status", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, api.TestClusterK8s, http.MethodPost, url, bytes)
}

//更新 ApplicationYaml 测试
func TestApplicationYamlUpdate(t *testing.T) {
	serviceAccount := &corev1.ServiceAccount{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "v1",
			Kind:       "ServiceAccount",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "testSa",
			Namespace: api.TestNamespace,
		},
		Secrets: []corev1.ObjectReference{
			{
				Name: "testToken",
			},
		},
	}
	url := fmt.Sprintf("/v1/namespaces/%s/applications/%s/yaml", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, api.TestClusterK8s, http.MethodPut, url, serviceAccount)
}

//删除 ApplicationYaml 测试
func TestApplicationYamlDelete(t *testing.T) {
	serviceAccount := &corev1.ServiceAccount{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "v1",
			Kind:       "ServiceAccount",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "testSa",
			Namespace: api.TestNamespace,
		},
		Secrets: []corev1.ObjectReference{
			{
				Name: "testToken",
			},
		},
	}
	url := fmt.Sprintf("/v1/namespaces/%s/applications/%s/yaml", api.TestNamespace, api.TestClusterK8s)
	api.MockApi(t, api.TestClusterK8s, http.MethodDelete, url, serviceAccount)
}
