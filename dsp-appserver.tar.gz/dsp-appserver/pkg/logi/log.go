package logi

import (
	"os"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

var Log *zap.Logger

func init() {
	SetLogger(Build(GetConfig()))
}

func SetLogger(l *zap.Logger) {
	Log = l
}

func GetConfig() zap.Config {
	var zapConfig zap.Config
	level := levelFromEnv()
	switch level {
	case zap.DebugLevel:
		zapConfig = zap.NewDevelopmentConfig()
		zapConfig.EncoderConfig.EncodeLevel = zapcore.CapitalColorLevelEncoder
	default:
		zapConfig = zap.NewProductionConfig()
	}

	zapConfig.Level = zap.NewAtomicLevelAt(level)

	return zapConfig
}

func Build(zapConfig zap.Config) *zap.Logger {
	log, err := zapConfig.Build()
	if err != nil {
		panic(err)
	}
	return log
}

func IsDebug() bool {
	return Log.Core().Enabled(zap.DebugLevel)
}

func levelFromEnv() zapcore.Level {
	levelStr, ok := os.LookupEnv("LOG_LEVEL")
	if !ok {
		return zap.DebugLevel
	}

	var level zapcore.Level
	if err := level.UnmarshalText([]byte(levelStr)); err != nil {
		panic(err)
	}
	return level
}
