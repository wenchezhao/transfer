package engine

import (
	"context"
	"fmt"

	clusterpediav1beta1 "github.com/clusterpedia-io/api/clusterpedia/v1beta1"
	pediav1beta1 "github.com/clusterpedia-io/client-go/clusterpediaclient/v1beta1"
	"github.com/clusterpedia-io/client-go/tools/builder"
	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	apivolumesnapshotv1 "github.com/kubernetes-csi/external-snapshotter/client/v4/apis/volumesnapshot/v1"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	storagev1 "k8s.io/api/storage/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	"k8s.io/metrics/pkg/apis/custom_metrics/v1beta2"
	"sigs.k8s.io/controller-runtime/pkg/client"

	"github.com/daocloud/dsp-appserver/pkg/constants"
	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
	"github.com/daocloud/dsp-appserver/pkg/util/gvrutil"
	"github.com/daocloud/dsp-appserver/pkg/util/helper"
)

//go:generate mockgen -source=workload.go -destination fake_workloads.go -package engine
type Workload interface {
	GetClientSet(ctx context.Context, cluster string) (client.Client, error)
	GetAPIResourceList(ctx context.Context, cluster string) ([]*metav1.APIResourceList, error)

	GetNode(ctx context.Context, cluster, name string) (*corev1.Node, error)
	UpdateNode(ctx context.Context, cluster string, node *corev1.Node) (*corev1.Node, error)
	PatchNode(ctx context.Context, cluster, node string, loadBytes []byte) (*corev1.Node, error)
	PutNodeLabels(ctx context.Context, cluster, name string, loadBytes []byte) (map[string]string, error)
	PutNodeTaints(ctx context.Context, cluster, name string, loadBytes []byte) ([]corev1.Taint, error)
	CordonNode(ctx context.Context, cluster, node string, loadBytes []byte) (*corev1.Node, error)
	ListNamespaces(ctx context.Context, listOptions metav1.ListOptions) (*corev1.NamespaceList, error)
	GetNamespace(ctx context.Context, cluster, name string) (*corev1.Namespace, error)
	ListResourceQuotas(ctx context.Context, opts metav1.ListOptions) (*corev1.ResourceQuotaList, error)
	GetResourceQuota(ctx context.Context, cluster, namespace, name string) (*corev1.ResourceQuota, error)
	CreateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error)
	UpdateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error)
	GetLimitRange(ctx context.Context, cluster, namespace, name string) (*corev1.LimitRange, error)
	CreateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error)
	UpdateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error)
	DeleteLimitRange(ctx context.Context, cluster, namespace, name string) error

	GetPod(ctx context.Context, cluster, namespace, pod string) (*corev1.Pod, error)
	ListReplicaSets(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.ReplicaSetList, error)
	ListPods(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PodList, error)
	CreatePod(ctx context.Context, cluster, namespace string, pod *corev1.Pod) (*corev1.Pod, error)
	UpdatePod(ctx context.Context, cluster, namespace string, pod *corev1.Pod) (*corev1.Pod, error)

	GetReplicaSet(ctx context.Context, cluster, ns, name string) (*appsv1.ReplicaSet, error)
	UpdateReplicaSet(ctx context.Context, cluster, namespace string, rs *appsv1.ReplicaSet) (*appsv1.ReplicaSet, error)
	DeleteReplicaSet(ctx context.Context, cluster, namespace, name string) error

	ListPodsByFieldSelector(ctx context.Context, cluster, field string, values []string, queryPage *util.QueryPage) ([]corev1.Pod, error)
	ListCustomResources(ctx context.Context, gvr schema.GroupVersionResource, listOptions metav1.ListOptions) (*unstructured.UnstructuredList, error)
	GetCustomResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource) (*unstructured.Unstructured, error)
	CreateCustomResource(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error)
	UpdateCustomResource(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error)
	UpdateCustomResourceStatus(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error)
	PatchCustomResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource, pt types.PatchType, data []byte, subresources ...string) (*unstructured.Unstructured, error)
	DeleteCustomResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource, propagation *metav1.DeletionPropagation) error
	CreateDeployment(ctx context.Context, cluster, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error)
	GetDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error)
	UpdateDeployment(ctx context.Context, clusterName, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error)
	CreateStatefulSet(ctx context.Context, cluster, namespace string, ds *appsv1.StatefulSet) (*appsv1.StatefulSet, error)
	GetStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error)
	UpdateStatefulSet(ctx context.Context, cluster, namespace string, sts *appsv1.StatefulSet) (*appsv1.StatefulSet, error)
	CreateDaemonSet(ctx context.Context, cluster, namespace string, ds *appsv1.DaemonSet) (*appsv1.DaemonSet, error)
	GetDaemonSet(ctx context.Context, cluster, namespace, name string) (*appsv1.DaemonSet, error)
	UpdateDaemonSet(ctx context.Context, cluster, namespace string, ds *appsv1.DaemonSet) (*appsv1.DaemonSet, error)
	DeleteDeployment(ctx context.Context, cluster, namespace, name string) error
	PatchDeployment(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.Deployment, error)
	DeleteStatefulSet(ctx context.Context, cluster, namespace, name string) error
	PatchStatefulSet(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.StatefulSet, error)
	PatchDaemonSet(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.DaemonSet, error)
	ListControllerRevisions(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.ControllerRevisionList, error)
	ListEvents(ctx context.Context, listOptions metav1.ListOptions) (*corev1.EventList, error)
	ListServices(ctx context.Context, listOptions metav1.ListOptions) (*corev1.ServiceList, error)
	GetService(ctx context.Context, cluster, namespace, name string) (*corev1.Service, error)
	CreateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error)
	UpdateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error)
	DeleteService(ctx context.Context, cluster, namespace, name string) error
	ListIngresses(ctx context.Context, listOptions metav1.ListOptions) (*networkingv1.IngressList, error)
	GetIngress(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error)
	CreateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error)
	UpdateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error)
	PatchIngress(ctx context.Context, cluster, namespace, name string) (*networkingv1.Ingress, error)
	DeleteIngress(ctx context.Context, cluster, namespace, name string) error
	GetNetworkPolicy(ctx context.Context, cluster, namespace, name string) (*networkingv1.NetworkPolicy, error)
	CreateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error)
	UpdateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error)
	DeleteNetworkPolicy(ctx context.Context, cluster, namespace, name string) error
	ListIngressClasses(ctx context.Context, listOptions metav1.ListOptions) (*networkingv1.IngressClassList, error)
	ListPersistentVolumeClaims(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PersistentVolumeClaimList, error)
	GetPersistentVolumeClaim(ctx context.Context, cluster, namespace, name string) (*corev1.PersistentVolumeClaim, error)
	UpdateSecret(ctx context.Context, cluster string, secret *corev1.Secret) (*corev1.Secret, error)
	GetSecret(ctx context.Context, cluster, namespace, name string) (*corev1.Secret, error)
	DeleteSecret(ctx context.Context, cluster, namespace, name string) error
	CreateSecret(ctx context.Context, cluster, namespace string, secret *corev1.Secret) (*corev1.Secret, error)
	GetConfigMap(ctx context.Context, cluster, namespace, name string) (*corev1.ConfigMap, error)
	CreateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error)
	UpdateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error)
	PatchConfigMap(ctx context.Context, cluster, namespace, name string) (*corev1.ConfigMap, error)
	DeleteConfigMap(ctx context.Context, cluster, namespace, name string) error
	DeleteJob(ctx context.Context, cluster, namespace, name string) error
	DeleteCronJob(ctx context.Context, cluster, namespace, name string) error
	ListJobs(ctx context.Context, listOptions metav1.ListOptions) (*batchv1.JobList, error)
	DeletePod(ctx context.Context, cluster, namespace, name string) error
	DeleteDaemonSet(ctx context.Context, cluster, namespace, name string) error
	CreateCronJob(ctx context.Context, cluster, namespace string, cronJob *unstructured.Unstructured) (*unstructured.Unstructured, error)
	GetCronJob(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error)
	UpdateCronJob(ctx context.Context, cluster, namespace string, cronJob *unstructured.Unstructured) (*unstructured.Unstructured, error)
	PatchCronJob(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*unstructured.Unstructured, error)
	CreateJob(ctx context.Context, cluster, namespace string, job *batchv1.Job) (*batchv1.Job, error)
	GetJob(ctx context.Context, cluster, namespace, name string) (*batchv1.Job, error)
	UpdateJob(ctx context.Context, cluster, namespace string, job *batchv1.Job) (*batchv1.Job, error)
	DeleteNamespace(ctx context.Context, cluster, namespace string) error
	CreateNamespace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error)
	WatchNamespace(ctx context.Context, cluster, namespace string) (*corev1.Namespace, error)
	UpdateNameSpace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error)
	PatchNameSpace(ctx context.Context, cluster, name string, patchType types.PatchType, patchData []byte) (*corev1.Namespace, error)
	CreatePersistentVolumeClaim(ctx context.Context, cluster, namespace string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error)
	DeletePersistentVolumeClaim(ctx context.Context, cluster, name, namespaces string) error
	PatchPersistentVolumeClaim(ctx context.Context, cluster, name, namespaces string, loadBytes []byte, jsonType types.PatchType) (*corev1.PersistentVolumeClaim, error)
	ListPersistentVolumes(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PersistentVolumeList, error)
	GetPersistentVolume(ctx context.Context, cluster, name string) (*corev1.PersistentVolume, error)
	CreatePersistentVolume(ctx context.Context, cluster string, persistentvolume *corev1.PersistentVolume) (*corev1.PersistentVolume, error)
	UpdatePersistentVolume(ctx context.Context, cluster string, persistentvolume *corev1.PersistentVolume) (*corev1.PersistentVolume, error)
	DeletePersistentVolume(ctx context.Context, cluster, name string) error
	UpdatePersistentVolumeClaim(ctx context.Context, cluster, namespace string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error)
	CreateVolumeSnapshot(ctx context.Context, cluster, namespace string, snapshot *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error)
	DeletePersistentVolumeClaimSnapshot(ctx context.Context, cluster, name, namespaces string) error

	GetHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error)
	CreateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error)
	UpdateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error)
	DeleteHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) error
	RESTGetInto(ctx context.Context, cluster, absPath string, params map[string]string, obj runtime.Object) error
	ListMetricValues(ctx context.Context, cluster, namespace string, groupKind schema.GroupKind, selector labels.Selector, metricName string, metricSelector labels.Selector) (*v1beta2.MetricValueList, error)

	ListStorageClass(ctx context.Context, listOptions metav1.ListOptions) (*storagev1.StorageClassList, error)
	DeleteStorageClass(ctx context.Context, cluster, name string) error
	GetStorageClass(ctx context.Context, cluster, name string) (*storagev1.StorageClass, error)
	CreateStorageClass(ctx context.Context, cluster string, storageClass *storagev1.StorageClass) (*storagev1.StorageClass, error)
	UpdateStorageClass(ctx context.Context, cluster string, storageClass *storagev1.StorageClass) (*storagev1.StorageClass, error)
	UpdateVolumeSnapshot(ctx context.Context, cluster, namespace string, volumeSnapshot *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error)

	CreateServiceAccount(ctx context.Context, cluster, namespace string, sa *corev1.ServiceAccount) (*corev1.ServiceAccount, error)
	GetServiceAccount(ctx context.Context, cluster, namespace, name string) (*corev1.ServiceAccount, error)
	WatchServiceAccount(ctx context.Context, cluster, namespace string, opts metav1.ListOptions) (watch.Interface, error)
	ListServiceAccounts(ctx context.Context, listOptions metav1.ListOptions) (*corev1.ServiceAccountList, error)
	UpdateServiceAccount(ctx context.Context, cluster, namespace string, service *corev1.ServiceAccount) (*corev1.ServiceAccount, error)
	DeleteServiceAccount(ctx context.Context, cluster, namespace, name string) error

	WatchPod(ctx context.Context, cluster, namespace string, opts metav1.ListOptions) (watch.Interface, error)

	FetchCollectionResource(ctx context.Context, name string, opts metav1.ListOptions, params map[string]string) (*clusterpediav1beta1.CollectionResource, error)
}

var (
	_       Workload = new(WorkloadEngine)
	timeout          = int64(30)
)

type WorkloadEngine struct {
	kpandaFactory      informers.SharedInformerFactory
	clientFactory      pedia.Clients
	multiClient        kubernetes.Interface
	clusterClient      clusterclient.ClusterClients
	dynamicClient      dynamic.Interface
	clusterpediaClient pediav1beta1.ClusterPediaV1beta1
}

func (we *WorkloadEngine) ListMetricValues(_ context.Context, cluster, namespace string, groupKind schema.GroupKind, selector labels.Selector, metricName string, metricSelector labels.Selector) (*v1beta2.MetricValueList, error) {
	cmClient, err := we.clusterClient.GetCustomMetricsClient(cluster)
	if err != nil {
		return nil, err
	}

	return cmClient.NamespacedMetrics(namespace).GetForObjects(groupKind, selector, metricName, metricSelector)
}

func (we *WorkloadEngine) RESTGetInto(ctx context.Context, cluster, absPath string, params map[string]string, obj runtime.Object) error {
	innerCluster := we.clusterClient.GetInnerCluster(cluster)
	if innerCluster == nil {
		return status.Errorf(codes.FailedPrecondition, "cluster %s is not ready", cluster)
	}
	req := innerCluster.RestClient.Get().AbsPath(absPath)
	for param, value := range params {
		if len(param) > 0 && len(value) > 0 {
			req = req.Param(param, value)
		}
	}
	return req.Do(ctx).Into(obj)
}

func NewWorkloadEngine(kpandaFactory informers.SharedInformerFactory, clientFactory pedia.Clients, clusterClient clusterclient.ClusterClients) (*WorkloadEngine, error) {
	multiClient, err := clientFactory.Get()
	if multiClient == nil || err != nil {
		return nil, err
	}
	dynamicClient, err := clientFactory.Dynamic()
	if dynamicClient == nil || err != nil {
		return nil, err
	}
	clusterpediaClient, err := clientFactory.GetClusterpediaClient()
	if clusterpediaClient == nil || err != nil {
		return nil, err
	}
	return &WorkloadEngine{clientFactory: clientFactory, multiClient: multiClient, kpandaFactory: kpandaFactory, clusterClient: clusterClient, dynamicClient: dynamicClient, clusterpediaClient: clusterpediaClient}, nil
}

func (we *WorkloadEngine) SetClientSet(c clusterclient.ClusterClients) {
	we.clusterClient = c
}

func (we *WorkloadEngine) GetClientSet(ctx context.Context, cluster string) (client.Client, error) {
	return we.clusterClient.GetClientSetWithUser(ctx, cluster)
}

func (we *WorkloadEngine) GetAPIResourceList(_ context.Context, cluster string) ([]*metav1.APIResourceList, error) {
	client, err := we.clusterClient.GetClient(cluster)
	if err != nil {
		return nil, err
	}

	_, apiResourceList, err := client.Discovery().ServerGroupsAndResources()
	if len(apiResourceList) == 0 {
		return nil, err
	}

	return apiResourceList, nil
}

func (we *WorkloadEngine) GetNode(ctx context.Context, cluster, name string) (*corev1.Node, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}

		node, err := client.CoreV1().Nodes().Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			return nil, err
		}
		return node, nil
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	node, err := client.CoreV1().Nodes().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return node, nil
}

func (we *WorkloadEngine) UpdateNode(ctx context.Context, cluster string, node *corev1.Node) (*corev1.Node, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}
	return client.Kubernetes().CoreV1().Nodes().Update(ctx, node, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) PatchNode(ctx context.Context, cluster, node string, loadBytes []byte) (*corev1.Node, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}
	return client.Kubernetes().CoreV1().Nodes().Patch(ctx, node, types.JSONPatchType, loadBytes, metav1.PatchOptions{})
}

func (we *WorkloadEngine) PutNodeLabels(ctx context.Context, cluster, name string, loadBytes []byte) (map[string]string, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	node, err := client.Kubernetes().CoreV1().Nodes().Patch(ctx, name, types.JSONPatchType, loadBytes, metav1.PatchOptions{})
	if err != nil {
		return nil, err
	}

	return node.GetLabels(), nil
}

func (we *WorkloadEngine) PutNodeTaints(ctx context.Context, cluster, name string, loadBytes []byte) ([]corev1.Taint, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	node, err := client.Kubernetes().CoreV1().Nodes().Patch(ctx, name, types.JSONPatchType, loadBytes, metav1.PatchOptions{})
	if err != nil {
		return nil, err
	}

	return node.Spec.Taints, nil
}

func (we *WorkloadEngine) CordonNode(ctx context.Context, cluster, node string, loadBytes []byte) (*corev1.Node, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().Nodes().Patch(ctx, node, types.JSONPatchType, loadBytes, metav1.PatchOptions{})
}

func (we *WorkloadEngine) DeleteNamespace(ctx context.Context, cluster, namespace string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().CoreV1().Namespaces().Delete(ctx, namespace, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) CreateNamespace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().Namespaces().Create(ctx, namespace, metav1.CreateOptions{})
}

func (we *WorkloadEngine) WatchNamespace(ctx context.Context, cluster, namespace string) (*corev1.Namespace, error) {
	client, err := we.clusterClient.GetClient(cluster)
	if err != nil {
		return nil, err
	}
	w, err := client.CoreV1().Namespaces().Watch(ctx, metav1.ListOptions{
		FieldSelector:  "metadata.name=" + namespace,
		TimeoutSeconds: &timeout,
	})
	if err != nil {
		return nil, err
	}

	for event := range w.ResultChan() {
		if ns, ok := event.Object.(*corev1.Namespace); ok {
			return ns, nil
		}
	}
	return nil, fmt.Errorf("failed to wait for namespace %s to be ready", namespace)
}

func (we *WorkloadEngine) UpdateNameSpace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().Namespaces().Update(ctx, namespace, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) PatchNameSpace(ctx context.Context, cluster, name string, patchType types.PatchType, patchData []byte) (*corev1.Namespace, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().Namespaces().Patch(ctx, name, patchType, patchData, metav1.PatchOptions{})
}

func (we *WorkloadEngine) DeleteJob(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().BatchV1().Jobs(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) DeleteCronJob(ctx context.Context, cluster, namespace, name string) error {
	originalClient := we.clusterClient.GetInnerCluster(cluster)
	if originalClient == nil {
		return fmt.Errorf("cluster %s is not ready", cluster)
	}

	gvr, err := gvrutil.GetSupportsCronJobGVR(originalClient.APIEnablements)
	if err != nil {
		return err
	}

	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) CreateCronJob(ctx context.Context, cluster, namespace string, cronJob *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	originalClient := we.clusterClient.GetInnerCluster(cluster)
	if originalClient == nil {
		return nil, fmt.Errorf("cluster %s is not ready", cluster)
	}

	gvr, err := gvrutil.GetSupportsCronJobGVR(originalClient.APIEnablements)
	if err != nil {
		return nil, err
	}

	cronJob, err = gvrutil.ConvertToVersion(cronJob, gvr)
	if err != nil {
		return nil, err
	}

	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Create(ctx, cronJob, metav1.CreateOptions{})
}

func (we *WorkloadEngine) PatchCronJob(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*unstructured.Unstructured, error) {
	originalClient := we.clusterClient.GetInnerCluster(cluster)
	if originalClient == nil {
		return nil, fmt.Errorf("cluster %s is not ready", cluster)
	}
	gvr, err := gvrutil.GetSupportsCronJobGVR(originalClient.APIEnablements)
	if err != nil {
		return nil, err
	}

	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Patch(ctx, name, patchType, patchData, metav1.PatchOptions{})
}

func (we *WorkloadEngine) GetCronJob(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client := we.clusterClient.GetInnerCluster(cluster)
		if client == nil {
			return nil, fmt.Errorf("cluster %s is not ready", cluster)
		}

		gvr, err := gvrutil.GetSupportsCronJobGVR(client.APIEnablements)
		if err != nil {
			return nil, err
		}

		return client.DynamicClient.Resource(gvr).Namespace(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}

	cj, err := client.BatchV1().CronJobs(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}

	return helper.ConvertToUnstructured(cj)
}

func (we *WorkloadEngine) UpdateCronJob(ctx context.Context, cluster, namespace string, cronJob *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	originalClient := we.clusterClient.GetInnerCluster(cluster)
	if originalClient == nil {
		return nil, fmt.Errorf("cluster %s is not ready", cluster)
	}

	gvr, err := gvrutil.GetSupportsCronJobGVR(originalClient.APIEnablements)
	if err != nil {
		return nil, err
	}

	cronJob, err = gvrutil.ConvertToVersion(cronJob, gvr)
	if err != nil {
		return nil, err
	}

	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Update(ctx, cronJob, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) CreateJob(ctx context.Context, cluster, namespace string, job *batchv1.Job) (*batchv1.Job, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}
	return client.Kubernetes().BatchV1().Jobs(namespace).Create(ctx, job, metav1.CreateOptions{})
}

func (we *WorkloadEngine) GetJob(ctx context.Context, cluster, namespace, name string) (*batchv1.Job, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		return client.BatchV1().Jobs(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	job, err := client.BatchV1().Jobs(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return job, err
}

func (we *WorkloadEngine) UpdateJob(ctx context.Context, cluster, namespace string, job *batchv1.Job) (*batchv1.Job, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}
	return client.Kubernetes().BatchV1().Jobs(namespace).Update(ctx, job, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) ListJobs(ctx context.Context, listOptions metav1.ListOptions) (*batchv1.JobList, error) {
	return we.multiClient.BatchV1().Jobs("").List(ctx, listOptions)
}

func (we *WorkloadEngine) GetConfigMap(ctx context.Context, cluster, namespace, name string) (*corev1.ConfigMap, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		return client.CoreV1().ConfigMaps(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	// default query by clusterpedia
	subClient, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	return subClient.CoreV1().ConfigMaps(namespace).Get(ctx, name, metav1.GetOptions{})
}

func (we *WorkloadEngine) CreateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().ConfigMaps(namespace).Create(ctx, configmap, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().ConfigMaps(namespace).Update(ctx, configmap, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) PatchConfigMap(_ context.Context, _, _, _ string) (*corev1.ConfigMap, error) {
	//  TODO implement me.
	panic("implement me")
}

func (we *WorkloadEngine) DeleteConfigMap(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}
	return client.Kubernetes().CoreV1().ConfigMaps(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) ListNamespaces(ctx context.Context, listOptions metav1.ListOptions) (*corev1.NamespaceList, error) {
	return we.multiClient.CoreV1().Namespaces().List(ctx, listOptions)
}

func (we *WorkloadEngine) GetNamespace(ctx context.Context, cluster, name string) (*corev1.Namespace, error) {
	schema := util.GetLoadResourceSchema(ctx)
	if schema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return &corev1.Namespace{}, err
		}
		return client.CoreV1().Namespaces().Get(ctx, name, metav1.GetOptions{})
	}

	// default query by clusterpedia
	subClient, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return &corev1.Namespace{}, err
	}
	return subClient.CoreV1().Namespaces().Get(ctx, name, metav1.GetOptions{})
}

func (we *WorkloadEngine) ListResourceQuotas(ctx context.Context, opts metav1.ListOptions) (*corev1.ResourceQuotaList, error) {
	return we.multiClient.CoreV1().ResourceQuotas("").List(ctx, opts)
}

func (we *WorkloadEngine) GetResourceQuota(ctx context.Context, cluster, namespace, name string) (*corev1.ResourceQuota, error) {
	schema := util.GetLoadResourceSchema(ctx)
	if schema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		return client.CoreV1().ResourceQuotas(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	// default query by clusterpedia
	subClient, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	return subClient.CoreV1().ResourceQuotas(namespace).Get(ctx, name, metav1.GetOptions{})
}

func (we *WorkloadEngine) CreateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}
	return client.Kubernetes().CoreV1().ResourceQuotas(namespace).Create(ctx, quota, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}
	return client.Kubernetes().CoreV1().ResourceQuotas(namespace).Update(ctx, quota, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) GetLimitRange(ctx context.Context, cluster, namespace, name string) (*corev1.LimitRange, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		return client.CoreV1().LimitRanges(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	// default query by clusterpedia
	subClient, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	return subClient.CoreV1().LimitRanges(namespace).Get(ctx, name, metav1.GetOptions{})
}

func (we *WorkloadEngine) CreateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().LimitRanges(namespace).Create(ctx, limitrange, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().LimitRanges(namespace).Update(ctx, limitrange, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) DeleteLimitRange(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().CoreV1().LimitRanges(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) GetPod(ctx context.Context, cluster, namespaceName, podName string) (*corev1.Pod, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		pod, err := client.CoreV1().Pods(namespaceName).Get(ctx, podName, metav1.GetOptions{})
		if err != nil {
			return nil, err
		}
		return pod, nil
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	pod, err := client.CoreV1().Pods(namespaceName).Get(ctx, podName, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return pod, nil
}

func (we *WorkloadEngine) GetReplicaSet(ctx context.Context, cluster, ns, name string) (*appsv1.ReplicaSet, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		rs, err := client.AppsV1().ReplicaSets(ns).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			return nil, err
		}
		return rs, nil
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	rs, err := client.AppsV1().ReplicaSets(ns).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return rs, nil
}

func (we *WorkloadEngine) ListReplicaSets(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.ReplicaSetList, error) {
	return we.multiClient.AppsV1().ReplicaSets("").List(ctx, listOptions)
}

func (we *WorkloadEngine) UpdateReplicaSet(ctx context.Context, cluster, namespace string, rs *appsv1.ReplicaSet) (*appsv1.ReplicaSet, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().ReplicaSets(namespace).Update(ctx, rs, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) DeleteReplicaSet(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().AppsV1().ReplicaSets(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) ListPods(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PodList, error) {
	return we.multiClient.CoreV1().Pods("").List(ctx, listOptions)
}

func (we *WorkloadEngine) ListServiceAccounts(ctx context.Context, listOptions metav1.ListOptions) (*corev1.ServiceAccountList, error) {
	return we.multiClient.CoreV1().ServiceAccounts("").List(ctx, listOptions)
}

func (we *WorkloadEngine) CreatePod(ctx context.Context, cluster, namespace string, pod *corev1.Pod) (*corev1.Pod, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().Pods(namespace).Create(ctx, pod, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdatePod(ctx context.Context, cluster, namespace string, pod *corev1.Pod) (*corev1.Pod, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}
	return client.Kubernetes().CoreV1().Pods(namespace).Update(ctx, pod, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) ListPodsByFieldSelector(ctx context.Context, cluster, field string, values []string, queryPage *util.QueryPage) ([]corev1.Pod, error) {
	name := queryPage.Name
	opts := builder.ListOptionsBuilder().Clusters(cluster).FieldSelector(field, values).FuzzyNames(name).RemainingCount().Limit(int(queryPage.PageSize)).Offset(int(queryPage.PageSize * (queryPage.Page - 1))).Options()
	podList, err := we.multiClient.CoreV1().Pods("").List(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(podList.Items)), podList.GetListMeta().GetRemainingItemCount())
	return podList.Items, nil
}

func (we *WorkloadEngine) ListCustomResources(ctx context.Context, gvr schema.GroupVersionResource, listOptions metav1.ListOptions) (*unstructured.UnstructuredList, error) {
	return we.dynamicClient.Resource(gvr).Namespace("").List(ctx, listOptions)
}

func (we *WorkloadEngine) GetCustomResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource) (*unstructured.Unstructured, error) {
	// TODO: Get from clusterpedia.
	client, err := we.clusterClient.GetDynamicClient(cluster)
	if err != nil {
		return nil, err
	}
	unStructObj, err := client.Resource(gvr).Namespace(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return unStructObj, nil
}

func (we *WorkloadEngine) CreateCustomResource(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Create(ctx, obj, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdateCustomResource(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Update(ctx, obj, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) UpdateCustomResourceStatus(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).UpdateStatus(ctx, obj, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) PatchCustomResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource, pt types.PatchType, data []byte, subresources ...string) (*unstructured.Unstructured, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Patch(ctx, name, pt, data, metav1.PatchOptions{}, subresources...)
}

func (we *WorkloadEngine) DeleteCustomResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource, propagation *metav1.DeletionPropagation) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Delete(ctx, name, metav1.DeleteOptions{PropagationPolicy: propagation})
}

func (we *WorkloadEngine) CreateDeployment(ctx context.Context, cluster, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().Deployments(namespace).Create(ctx, deploy, metav1.CreateOptions{})
}

func (we *WorkloadEngine) GetDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		deploy, err := client.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			return nil, err
		}
		return deploy, nil
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	deploy, err := client.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return deploy, err
}

func (we *WorkloadEngine) UpdateDeployment(ctx context.Context, cluster, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().Deployments(namespace).Update(ctx, deploy, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) CreateSecret(ctx context.Context, cluster, namespace string, secret *corev1.Secret) (*corev1.Secret, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().Secrets(namespace).Create(ctx, secret, metav1.CreateOptions{})
}

func (we *WorkloadEngine) GetSecret(ctx context.Context, cluster, namespace, name string) (*corev1.Secret, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}

		secret, err := client.CoreV1().Secrets(namespace).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			return nil, err
		}
		return secret, nil
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	secret, err := client.CoreV1().Secrets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return secret, nil
}

func (we *WorkloadEngine) UpdateSecret(ctx context.Context, cluster string, secret *corev1.Secret) (*corev1.Secret, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().Secrets(secret.Namespace).Update(ctx, secret, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) DeleteSecret(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().CoreV1().Secrets(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) DeleteDeployment(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().AppsV1().Deployments(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) PatchDeployment(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.Deployment, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().Deployments(namespace).Patch(ctx, name, patchType, patchData, metav1.PatchOptions{})
}

func (we *WorkloadEngine) DeleteStatefulSet(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().AppsV1().StatefulSets(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) PatchStatefulSet(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.StatefulSet, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().StatefulSets(namespace).Patch(ctx, name, patchType, patchData, metav1.PatchOptions{})
}

func (we *WorkloadEngine) PatchDaemonSet(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.DaemonSet, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().DaemonSets(namespace).Patch(ctx, name, patchType, patchData, metav1.PatchOptions{})
}

func (we *WorkloadEngine) CreateStatefulSet(ctx context.Context, cluster, namespace string, sts *appsv1.StatefulSet) (*appsv1.StatefulSet, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().StatefulSets(namespace).Create(ctx, sts, metav1.CreateOptions{})
}

func (we *WorkloadEngine) GetStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		sts, err := client.AppsV1().StatefulSets(namespace).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			return nil, err
		}
		return sts, nil
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	statefulSet, err := client.AppsV1().StatefulSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return statefulSet, err
}

func (we *WorkloadEngine) UpdateStatefulSet(ctx context.Context, cluster, namespace string, sts *appsv1.StatefulSet) (*appsv1.StatefulSet, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().StatefulSets(namespace).Update(ctx, sts, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) CreateDaemonSet(ctx context.Context, cluster, namespace string, ds *appsv1.DaemonSet) (*appsv1.DaemonSet, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().DaemonSets(namespace).Create(ctx, ds, metav1.CreateOptions{})
}

func (we *WorkloadEngine) GetDaemonSet(ctx context.Context, cluster, namespace, name string) (*appsv1.DaemonSet, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		ds, err := client.AppsV1().DaemonSets(namespace).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			return nil, err
		}
		return ds, nil
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return &appsv1.DaemonSet{}, err
	}
	daemonSet, err := client.AppsV1().DaemonSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return &appsv1.DaemonSet{}, err
	}
	return daemonSet, err
}

func (we *WorkloadEngine) UpdateDaemonSet(ctx context.Context, cluster, namespace string, ds *appsv1.DaemonSet) (*appsv1.DaemonSet, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().AppsV1().DaemonSets(namespace).Update(ctx, ds, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) ListServices(ctx context.Context, listOptions metav1.ListOptions) (*corev1.ServiceList, error) {
	list, err := we.multiClient.CoreV1().Services("").List(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	return list, nil
}

func (we *WorkloadEngine) GetService(ctx context.Context, cluster, namespace, name string) (*corev1.Service, error) {
	schema := util.GetLoadResourceSchema(ctx)
	if schema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		return client.CoreV1().Services(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	// default query by clusterpedia
	subClient, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	return subClient.CoreV1().Services(namespace).Get(ctx, name, metav1.GetOptions{})
}

func (we *WorkloadEngine) CreateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().Services(namespace).Create(ctx, service, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().Services(namespace).Update(ctx, service, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) UpdateServiceAccount(ctx context.Context, cluster, namespace string, service *corev1.ServiceAccount) (*corev1.ServiceAccount, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().ServiceAccounts(namespace).Update(ctx, service, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) DeleteService(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().CoreV1().Services(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) ListPersistentVolumes(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PersistentVolumeList, error) {
	list, err := we.multiClient.CoreV1().PersistentVolumes().List(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	return list, nil
}

func (we *WorkloadEngine) GetPersistentVolume(ctx context.Context, cluster, name string) (*corev1.PersistentVolume, error) {
	schema := util.GetLoadResourceSchema(ctx)
	if schema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		return client.CoreV1().PersistentVolumes().Get(ctx, name, metav1.GetOptions{})
	}

	// default query by clusterpedia
	subClient, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	return subClient.CoreV1().PersistentVolumes().Get(ctx, name, metav1.GetOptions{})
}

func (we *WorkloadEngine) CreatePersistentVolume(ctx context.Context, cluster string, persistentvolume *corev1.PersistentVolume) (*corev1.PersistentVolume, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().PersistentVolumes().Create(ctx, persistentvolume, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdatePersistentVolume(ctx context.Context, cluster string, persistentvolume *corev1.PersistentVolume) (*corev1.PersistentVolume, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().PersistentVolumes().Update(ctx, persistentvolume, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) DeletePersistentVolume(ctx context.Context, cluster, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().CoreV1().PersistentVolumes().Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) ListIngresses(ctx context.Context, listOptions metav1.ListOptions) (*networkingv1.IngressList, error) {
	return we.multiClient.NetworkingV1().Ingresses("").List(ctx, listOptions)
}

func (we *WorkloadEngine) GetIngress(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client := we.clusterClient.GetInnerCluster(cluster)
		if client == nil {
			return nil, status.Errorf(codes.Internal, "cluster %s is not ready", cluster)
		}
		ingressGVR, err := gvrutil.GetSupportsIngressGVR(client.APIEnablements)
		if err != nil {
			return nil, err
		}
		return client.DynamicClient.Resource(ingressGVR).Namespace(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	// default query by clusterpedia
	subClient, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}

	ingress, err := subClient.NetworkingV1().Ingresses(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return helper.ConvertToUnstructured(ingress)
}

func (we *WorkloadEngine) CreateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	originalClient := we.clusterClient.GetInnerCluster(cluster)
	if originalClient == nil {
		return nil, status.Errorf(codes.Internal, "cluster %s is not ready", cluster)
	}

	gvr, err := gvrutil.GetSupportsIngressGVR(originalClient.APIEnablements)
	if err != nil {
		return nil, err
	}

	ingress, err = gvrutil.ConvertToVersion(ingress, gvr)
	if err != nil {
		return nil, err
	}

	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Create(ctx, ingress, metav1.CreateOptions{})
}

func (we *WorkloadEngine) DeleteIngress(ctx context.Context, cluster, namespace, name string) error {
	originalClient := we.clusterClient.GetInnerCluster(cluster)
	if originalClient == nil {
		return status.Errorf(codes.Internal, "cluster %s is not ready", cluster)
	}

	gvr, err := gvrutil.GetSupportsIngressGVR(originalClient.APIEnablements)
	if err != nil {
		return err
	}

	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) UpdateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	originalClient := we.clusterClient.GetInnerCluster(cluster)
	if originalClient == nil {
		return nil, status.Errorf(codes.Internal, "cluster %s is not ready", cluster)
	}

	gvr, err := gvrutil.GetSupportsIngressGVR(originalClient.APIEnablements)
	if err != nil {
		return nil, err
	}

	ingress, err = gvrutil.ConvertToVersion(ingress, gvr)
	if err != nil {
		return nil, err
	}

	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Dynamic().Resource(gvr).Namespace(namespace).Update(ctx, ingress, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) PatchIngress(_ context.Context, _, _, _ string) (*networkingv1.Ingress, error) {
	// TODO:
	panic("implement me")
}

func (we *WorkloadEngine) GetNetworkPolicy(ctx context.Context, cluster, namespace, name string) (*networkingv1.NetworkPolicy, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		return client.NetworkingV1().NetworkPolicies(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	// default query by clusterpedia
	subClient, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	return subClient.NetworkingV1().NetworkPolicies(namespace).Get(ctx, name, metav1.GetOptions{})
}

func (we *WorkloadEngine) CreateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().NetworkingV1().NetworkPolicies(namespace).Create(ctx, networkpolicy, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().NetworkingV1().NetworkPolicies(namespace).Update(ctx, networkpolicy, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) DeleteNetworkPolicy(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().NetworkingV1().NetworkPolicies(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) ListIngressClasses(ctx context.Context, listOptions metav1.ListOptions) (*networkingv1.IngressClassList, error) {
	return we.multiClient.NetworkingV1().IngressClasses().List(ctx, listOptions)
}

func (we *WorkloadEngine) ListControllerRevisions(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.ControllerRevisionList, error) {
	return we.multiClient.AppsV1().ControllerRevisions("").List(ctx, listOptions)
}

func (we *WorkloadEngine) ListPersistentVolumeClaims(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PersistentVolumeClaimList, error) {
	return we.multiClient.CoreV1().PersistentVolumeClaims("").List(ctx, listOptions)
}

func (we *WorkloadEngine) GetPersistentVolumeClaim(ctx context.Context, cluster, namespace, name string) (*corev1.PersistentVolumeClaim, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}

		pvc, err := client.CoreV1().PersistentVolumeClaims(namespace).Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			return nil, err
		}
		return pvc, nil
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	pvc, err := client.CoreV1().PersistentVolumeClaims(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return pvc, nil
}

func (we *WorkloadEngine) ListEvents(ctx context.Context, listOptions metav1.ListOptions) (*corev1.EventList, error) {
	return we.multiClient.CoreV1().Events("").List(ctx, listOptions)
}

func (we *WorkloadEngine) DeletePod(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().CoreV1().Pods(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) DeleteServiceAccount(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().CoreV1().ServiceAccounts(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) DeleteDaemonSet(ctx context.Context, cluster, namespace, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().AppsV1().DaemonSets(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) CreatePersistentVolumeClaim(ctx context.Context, cluster, namespace string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().PersistentVolumeClaims(namespace).Create(ctx, pvc, metav1.CreateOptions{})
}

func (we *WorkloadEngine) CreateVolumeSnapshot(ctx context.Context, cluster, namespace string, snapshot *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error) {
	client, err := we.clusterClient.GetSnapshotClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}
	return client.VolumeSnapshots(namespace).Create(ctx, snapshot, metav1.CreateOptions{})
}

func (we *WorkloadEngine) DeletePersistentVolumeClaim(ctx context.Context, cluster, name, namespaces string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().CoreV1().PersistentVolumeClaims(namespaces).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) DeletePersistentVolumeClaimSnapshot(ctx context.Context, cluster, namespaces, name string) error {
	client, err := we.clusterClient.GetSnapshotClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}
	return client.VolumeSnapshots(namespaces).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) UpdateVolumeSnapshot(ctx context.Context, cluster, namespace string, volumeSnapshot *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error) {
	client, err := we.clusterClient.GetSnapshotClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}
	return client.VolumeSnapshots(namespace).Update(ctx, volumeSnapshot, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) PatchPersistentVolumeClaim(ctx context.Context, cluster, name, namespaces string, loadBytes []byte, jsonType types.PatchType) (*corev1.PersistentVolumeClaim, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().PersistentVolumeClaims(namespaces).Patch(ctx, name, jsonType, loadBytes, metav1.PatchOptions{})
}

func (we *WorkloadEngine) ListStorageClass(ctx context.Context, listOptions metav1.ListOptions) (*storagev1.StorageClassList, error) {
	return we.multiClient.StorageV1().StorageClasses().List(ctx, listOptions)
}

func (we *WorkloadEngine) DeleteStorageClass(ctx context.Context, cluster, name string) error {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().StorageV1().StorageClasses().Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) GetStorageClass(ctx context.Context, cluster, name string) (*storagev1.StorageClass, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}

		storageClass, err := client.StorageV1().StorageClasses().Get(ctx, name, metav1.GetOptions{})
		if err != nil {
			return nil, err
		}
		return storageClass, nil
	}

	subClient, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	storageClass, err := subClient.StorageV1().StorageClasses().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	return storageClass, nil
}

func (we *WorkloadEngine) CreateStorageClass(ctx context.Context, cluster string, storageClass *storagev1.StorageClass) (*storagev1.StorageClass, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().StorageV1().StorageClasses().Create(ctx, storageClass, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdateStorageClass(ctx context.Context, cluster string, storageClass *storagev1.StorageClass) (*storagev1.StorageClass, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().StorageV1().StorageClasses().Update(ctx, storageClass, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) UpdatePersistentVolumeClaim(ctx context.Context, cluster, namespace string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().PersistentVolumeClaims(namespace).Update(ctx, pvc, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) GetHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client := we.clusterClient.GetInnerCluster(cluster)
		if client == nil {
			return nil, fmt.Errorf("cluster %s is not ready", cluster)
		}

		gvr, err := gvrutil.GetSupportsHPAGVR(client.APIEnablements)
		if err != nil {
			return nil, err
		}

		return client.DynamicClient.Resource(gvr).Namespace(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}

	hpa, err := client.AutoscalingV1().HorizontalPodAutoscalers(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}

	return helper.ConvertToUnstructured(hpa)
}

func (we *WorkloadEngine) CreateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	client := we.clusterClient.GetInnerCluster(cluster)
	if client == nil {
		return nil, fmt.Errorf("cluster %s is not ready", cluster)
	}

	gvr, err := gvrutil.GetSupportsHPAGVR(client.APIEnablements)
	if err != nil {
		return nil, err
	}

	hpa, err = gvrutil.ConvertToVersion(hpa, gvr)
	if err != nil {
		return nil, err
	}

	return client.DynamicClient.Resource(gvr).Namespace(namespace).Create(ctx, hpa, metav1.CreateOptions{})
}

func (we *WorkloadEngine) UpdateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	client := we.clusterClient.GetInnerCluster(cluster)
	if client == nil {
		return nil, fmt.Errorf("cluster %s is not ready", cluster)
	}

	gvr, err := gvrutil.GetSupportsHPAGVR(client.APIEnablements)
	if err != nil {
		return nil, err
	}

	hpa, err = gvrutil.ConvertToVersion(hpa, gvr)
	if err != nil {
		return nil, err
	}

	return client.DynamicClient.Resource(gvr).Namespace(namespace).Update(ctx, hpa, metav1.UpdateOptions{})
}

func (we *WorkloadEngine) DeleteHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) error {
	client := we.clusterClient.GetInnerCluster(cluster)
	if client == nil {
		return fmt.Errorf("cluster %s is not ready", cluster)
	}
	gvr, err := gvrutil.GetSupportsHPAGVR(client.APIEnablements)
	if err != nil {
		return err
	}

	return client.DynamicClient.Resource(gvr).Namespace(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (we *WorkloadEngine) CreateServiceAccount(ctx context.Context, cluster, namespace string, sa *corev1.ServiceAccount) (*corev1.ServiceAccount, error) {
	client, err := we.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().CoreV1().ServiceAccounts(namespace).Create(ctx, sa, metav1.CreateOptions{})
}

func (we *WorkloadEngine) GetServiceAccount(ctx context.Context, cluster, namespace, name string) (*corev1.ServiceAccount, error) {
	resourceSchema := util.GetLoadResourceSchema(ctx)
	if resourceSchema == constants.MemberCluster {
		client, err := we.clusterClient.GetClient(cluster)
		if err != nil {
			return nil, err
		}
		return client.CoreV1().ServiceAccounts(namespace).Get(ctx, name, metav1.GetOptions{})
	}

	client, err := we.clientFactory.GetSubClient(cluster)
	if err != nil {
		return nil, err
	}
	return client.CoreV1().ServiceAccounts(namespace).Get(ctx, name, metav1.GetOptions{})
}

func (we *WorkloadEngine) WatchServiceAccount(ctx context.Context, cluster, namespace string, opts metav1.ListOptions) (watch.Interface, error) {
	client, err := we.clusterClient.GetClient(cluster)
	if err != nil {
		return nil, err
	}
	return client.CoreV1().ServiceAccounts(namespace).Watch(ctx, opts)
}

func (we *WorkloadEngine) WatchPod(ctx context.Context, cluster, namespace string, opts metav1.ListOptions) (watch.Interface, error) {
	client, err := we.clusterClient.GetClient(cluster)
	if err != nil {
		return nil, err
	}
	return client.CoreV1().Pods(namespace).Watch(ctx, opts)
}

func (we *WorkloadEngine) FetchCollectionResource(ctx context.Context, name string, opts metav1.ListOptions, params map[string]string) (*clusterpediav1beta1.CollectionResource, error) {
	return we.clusterpediaClient.CollectionResource().Fetch(ctx, name, opts, params)
}
