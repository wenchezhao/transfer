package engine

import (
	"context"

	"github.com/clusterpedia-io/client-go/customclient"
	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
)

type Storage struct {
	namespace *string
	nsList    []string
	DB        DB
}

type DB struct {
	deploylist             appsv1.DeploymentList
	statefulsetlist        appsv1.StatefulSetList
	daemonsetlist          appsv1.DaemonSetList
	podlist                corev1.PodList
	joblist                batchv1.JobList
	cronjoblist            batchv1.CronJobList
	rolebindinglist        rbacv1.RoleBindingList
	clusterrolebindinglist rbacv1.ClusterRoleBindingList
	namespacelist          corev1.NamespaceList
	nodelist               corev1.NodeList
	clusterlist            clusterv1alpha1.ClusterList
}

type FakeResource struct {
	m map[schema.GroupVersionResource]*Storage
}

func newFakeResource() *FakeResource {
	return &FakeResource{
		m: make(map[schema.GroupVersionResource]*Storage),
	}
}

func (r *FakeResource) Resource(re schema.GroupVersionResource) customclient.NamespaceableResourceInterface {
	return r.m[re]
}

func (s *Storage) Namespace(strs string) customclient.ResourceInterface {
	s.namespace = &strs
	return s
}

func (s *Storage) List(_ context.Context, _ metav1.ListOptions, _ map[string]string, _ runtime.Object) error {
	return nil
}

func (s *Storage) initLz() {
	s.nsList = []string{"test1", "test2", "test3", "test4", "test5"}
	s.DB.deploylist = appsv1.DeploymentList{
		Items: make([]appsv1.Deployment, 0),
	}
	s.DB.statefulsetlist = appsv1.StatefulSetList{
		Items: make([]appsv1.StatefulSet, 0),
	}
	s.DB.daemonsetlist = appsv1.DaemonSetList{
		Items: make([]appsv1.DaemonSet, 0),
	}
	s.DB.joblist = batchv1.JobList{
		Items: make([]batchv1.Job, 0),
	}
	s.DB.cronjoblist = batchv1.CronJobList{
		Items: make([]batchv1.CronJob, 0),
	}
	s.DB.podlist = corev1.PodList{
		Items: make([]corev1.Pod, 0),
	}
	s.DB.rolebindinglist = rbacv1.RoleBindingList{
		Items: make([]rbacv1.RoleBinding, 0),
	}
	s.DB.clusterrolebindinglist = rbacv1.ClusterRoleBindingList{
		Items: make([]rbacv1.ClusterRoleBinding, 0),
	}
	s.DB.namespacelist = corev1.NamespaceList{
		Items: make([]corev1.Namespace, 0),
	}
	s.DB.nodelist = corev1.NodeList{
		Items: make([]corev1.Node, 0),
	}
	s.DB.clusterlist = clusterv1alpha1.ClusterList{
		Items: make([]clusterv1alpha1.Cluster, 0),
	}
}
