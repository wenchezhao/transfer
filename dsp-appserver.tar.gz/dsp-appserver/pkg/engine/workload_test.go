package engine

import (
	"context"
	"reflect"
	"testing"

	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"

	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	storagev1 "k8s.io/api/storage/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	clientsetfake "k8s.io/client-go/kubernetes/fake"
)

func TestWorkloadEngine_ListNamespaces(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.NamespaceList
		wantErr bool
	}{
		{
			name: "test list namespaces",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListNamespaces(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListNamespaces() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestWorkloadEngine_ListReplicaSets(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *appsv1.ReplicaSetList
		wantErr bool
	}{
		{
			name: "test ListReplicaSets",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListReplicaSets(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListReplicaSets() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestWorkloadEngine_ListPods(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.PodList
		wantErr bool
	}{
		{
			name: "test ListPods",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListPods(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListPods() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestWorkloadEngine_ListPodsByFieldSelector(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx       context.Context
		cluster   string
		field     string
		values    []string
		queryPage *util.QueryPage
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    []corev1.Pod
		wantErr bool
	}{
		{
			name: "test ListPodsByFieldSelector",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:       context.Background(),
				cluster:   "cluster",
				field:     "",
				values:    []string{},
				queryPage: &util.QueryPage{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			got, err := we.ListPodsByFieldSelector(tt.args.ctx, tt.args.cluster, tt.args.field, tt.args.values, tt.args.queryPage)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListPodsByFieldSelector() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("WorkloadEngine.ListPodsByFieldSelector() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestWorkloadEngine_ListJobs(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *batchv1.JobList
		wantErr bool
	}{
		{
			name: "test ListJobs",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			want:    &batchv1.JobList{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListJobs(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListJobs() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestWorkloadEngine_ListStorageClass(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *storagev1.StorageClassList
		wantErr bool
	}{
		{
			name: "test ListStorageClass",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			want:    &storagev1.StorageClassList{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListStorageClass(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListStorageClass() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestWorkloadEngine_ListEvents(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.EventList
		wantErr bool
	}{
		{
			name: "test ListEvents",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			want:    &corev1.EventList{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListEvents(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListEvents() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestWorkloadEngine_ListPersistentVolumeClaims(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.PersistentVolumeClaimList
		wantErr bool
	}{
		{
			name: "test ListPersistentVolumeClaims",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			want:    &corev1.PersistentVolumeClaimList{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListPersistentVolumeClaims(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListPersistentVolumeClaims() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestWorkloadEngine_ListControllerRevisions(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *appsv1.ControllerRevisionList
		wantErr bool
	}{
		{
			name: "test ListControllerRevisions",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			want:    &appsv1.ControllerRevisionList{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListControllerRevisions(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListControllerRevisions() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestWorkloadEngine_ListIngresses(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *networkingv1.IngressList
		wantErr bool
	}{
		{
			name: "test ListIngresses",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			want:    &networkingv1.IngressList{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListIngresses(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListIngresses() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func TestWorkloadEngine_ListServices(t *testing.T) {
	type fields struct {
		kpandaFactory informers.SharedInformerFactory
		clientFactory pedia.Clients
		multiClient   kubernetes.Interface
		clusterClient clusterclient.ClusterClients
		dynamicClient dynamic.Interface
	}
	type args struct {
		ctx         context.Context
		listOptions metav1.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.ServiceList
		wantErr bool
	}{
		{
			name: "test ListServices",
			fields: fields{
				kpandaFactory: nil,
				clientFactory: nil,
				multiClient:   clientsetfake.NewSimpleClientset(),
				clusterClient: nil,
				dynamicClient: nil,
			},
			args: args{
				ctx:         context.Background(),
				listOptions: metav1.ListOptions{},
			},
			want:    &corev1.ServiceList{},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			we := &WorkloadEngine{
				kpandaFactory: tt.fields.kpandaFactory,
				clientFactory: tt.fields.clientFactory,
				multiClient:   tt.fields.multiClient,
				clusterClient: tt.fields.clusterClient,
				dynamicClient: tt.fields.dynamicClient,
			}
			_, err := we.ListServices(tt.args.ctx, tt.args.listOptions)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadEngine.ListServices() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
