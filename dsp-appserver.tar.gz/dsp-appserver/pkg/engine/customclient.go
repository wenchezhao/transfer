package engine

import (
	"context"

	"github.com/clusterpedia-io/client-go/customclient"
	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	helmv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/helm/v1alpha1"
	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	storagev1 "k8s.io/api/storage/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"

	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/buildoptions"
)

type CustomClient interface {
	ListDeployments(ctx context.Context, options *util.ListOptions) (*appsv1.DeploymentList, error)
	ListStatefulSets(ctx context.Context, options *util.ListOptions) (*appsv1.StatefulSetList, error)
	ListDaemonSets(ctx context.Context, options *util.ListOptions) (*appsv1.DaemonSetList, error)
	ListPods(ctx context.Context, options *util.ListOptions) (*corev1.PodList, error)
	ListJobs(ctx context.Context, options *util.ListOptions) (*batchv1.JobList, error)
	ListCronJobs(ctx context.Context, options *util.ListOptions) (*batchv1.CronJobList, error)
	ListRoleBindings(ctx context.Context, options *util.ListOptions) (*rbacv1.RoleBindingList, error)
	ListClusterRoleBindings(ctx context.Context, options *util.ListOptions) (*rbacv1.ClusterRoleBindingList, error)
	ListNamespaces(ctx context.Context, options *util.ListOptions) (*corev1.NamespaceList, error)
	ListNodes(ctx context.Context, options *util.ListOptions) (*corev1.NodeList, error)
	ListLimitRanges(ctx context.Context, options *util.ListOptions) (*corev1.LimitRangeList, error)
	ListClusters(ctx context.Context, options *util.ListOptions) (*clusterv1alpha1.ClusterList, error)
	ListReplicaSets(ctx context.Context, options *util.ListOptions) (*appsv1.ReplicaSetList, error)
	ListConfigMaps(ctx context.Context, options *util.ListOptions) (*corev1.ConfigMapList, error)
	ListSecrets(ctx context.Context, options *util.ListOptions) (*corev1.SecretList, error)
	ListNetworkPolicies(ctx context.Context, options *util.ListOptions) (*networkingv1.NetworkPolicyList, error)

	ListHelmReleases(ctx context.Context, options *util.ListOptions) (*helmv1alpha1.HelmReleaseList, error)

	ListServices(ctx context.Context, options *util.ListOptions) (*corev1.ServiceList, error)
	ListIngresses(ctx context.Context, options *util.ListOptions) (*networkingv1.IngressList, error)

	ListPersistentVolumeClaims(ctx context.Context, options *util.ListOptions) (*corev1.PersistentVolumeClaimList, error)
	ListStorageClass(ctx context.Context, options *util.ListOptions) (*storagev1.StorageClassList, error)

	ListCustomResources(ctx context.Context, gvr schema.GroupVersionResource, options *util.ListOptions) (*unstructured.UnstructuredList, error)
}

type CustomClientEngine struct {
	customclient.Interface
	buildoptions.BuildListOptionsInterface
}

var _ CustomClient = &CustomClientEngine{}

func NewCustomEngine(clientFactory pedia.Clients) (*CustomClientEngine, error) {
	customclient, err := clientFactory.GetCustomClient()
	if err != nil {
		return nil, err
	}
	return &CustomClientEngine{Interface: customclient, BuildListOptionsInterface: buildoptions.GetBuildListOptions()}, nil
}

func (ce *CustomClientEngine) ListDeployments(ctx context.Context, options *util.ListOptions) (*appsv1.DeploymentList, error) {
	list := &appsv1.DeploymentList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "deployments"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListStatefulSets(ctx context.Context, options *util.ListOptions) (*appsv1.StatefulSetList, error) {
	list := &appsv1.StatefulSetList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "statefulsets"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListDaemonSets(ctx context.Context, options *util.ListOptions) (*appsv1.DaemonSetList, error) {
	list := &appsv1.DaemonSetList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "daemonsets"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListReplicaSets(ctx context.Context, options *util.ListOptions) (*appsv1.ReplicaSetList, error) {
	list := &appsv1.ReplicaSetList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "replicasets"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListJobs(ctx context.Context, options *util.ListOptions) (*batchv1.JobList, error) {
	list := &batchv1.JobList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "batch", Version: "v1", Resource: "jobs"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListCronJobs(ctx context.Context, options *util.ListOptions) (*batchv1.CronJobList, error) {
	list := &batchv1.CronJobList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "batch", Version: "v1", Resource: "cronjobs"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListPods(ctx context.Context, options *util.ListOptions) (*corev1.PodList, error) {
	list := &corev1.PodList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "", Version: "v1", Resource: "pods"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListRoleBindings(ctx context.Context, options *util.ListOptions) (*rbacv1.RoleBindingList, error) {
	list := &rbacv1.RoleBindingList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "rbac.authorization.k8s.io", Version: "v1", Resource: "rolebindings"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListClusterRoleBindings(ctx context.Context, options *util.ListOptions) (*rbacv1.ClusterRoleBindingList, error) {
	list := &rbacv1.ClusterRoleBindingList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "rbac.authorization.k8s.io", Version: "v1", Resource: "clusterrolebindings"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListNamespaces(ctx context.Context, options *util.ListOptions) (*corev1.NamespaceList, error) {
	list := &corev1.NamespaceList{}
	opt, params := ce.BuildListNamespacesListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "", Version: "v1", Resource: "namespaces"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListNodes(ctx context.Context, options *util.ListOptions) (*corev1.NodeList, error) {
	list := &corev1.NodeList{}
	opt, params := ce.BuildNodeListOptions(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "", Version: "v1", Resource: "nodes"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListLimitRanges(ctx context.Context, options *util.ListOptions) (*corev1.LimitRangeList, error) {
	list := &corev1.LimitRangeList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "", Version: "v1", Resource: "limitranges"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListClusters(ctx context.Context, options *util.ListOptions) (*clusterv1alpha1.ClusterList, error) {
	list := &clusterv1alpha1.ClusterList{}
	opt, params := ce.BuildClusterListOptions(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "cluster.kpanda.io", Version: "v1alpha1", Resource: "clusters"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListConfigMaps(ctx context.Context, options *util.ListOptions) (*corev1.ConfigMapList, error) {
	list := &corev1.ConfigMapList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "", Version: "v1", Resource: "configmaps"}).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListSecrets(ctx context.Context, options *util.ListOptions) (*corev1.SecretList, error) {
	list := &corev1.SecretList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(corev1.SchemeGroupVersion.WithResource("secrets")).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListHelmReleases(ctx context.Context, options *util.ListOptions) (*helmv1alpha1.HelmReleaseList, error) {
	list := &helmv1alpha1.HelmReleaseList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(helmv1alpha1.SchemeGroupVersion.WithResource("helmreleases")).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListServices(ctx context.Context, options *util.ListOptions) (*corev1.ServiceList, error) {
	list := &corev1.ServiceList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(corev1.SchemeGroupVersion.WithResource("services")).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListIngresses(ctx context.Context, options *util.ListOptions) (*networkingv1.IngressList, error) {
	list := &networkingv1.IngressList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(networkingv1.SchemeGroupVersion.WithResource("ingresses")).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListPersistentVolumeClaims(ctx context.Context, options *util.ListOptions) (*corev1.PersistentVolumeClaimList, error) {
	list := &corev1.PersistentVolumeClaimList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(corev1.SchemeGroupVersion.WithResource("persistentvolumeclaims")).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListStorageClass(ctx context.Context, options *util.ListOptions) (*storagev1.StorageClassList, error) {
	list := &storagev1.StorageClassList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(storagev1.SchemeGroupVersion.WithResource("storageclasses")).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListCustomResources(ctx context.Context, gvr schema.GroupVersionResource, options *util.ListOptions) (*unstructured.UnstructuredList, error) {
	list := &unstructured.UnstructuredList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(gvr).List(ctx, opt, params, list)
	return list, err
}

func (ce *CustomClientEngine) ListNetworkPolicies(ctx context.Context, options *util.ListOptions) (*networkingv1.NetworkPolicyList, error) {
	list := &networkingv1.NetworkPolicyList{}
	opt, params := ce.BuildAcrossClustersListOptionsAndParams(options)
	err := ce.Resource(schema.GroupVersionResource{Group: "networking.k8s.io", Version: "v1", Resource: "networkpolicies"}).List(ctx, opt, params, list)
	return list, err
}
