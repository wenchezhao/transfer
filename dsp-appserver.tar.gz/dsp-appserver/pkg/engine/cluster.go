package engine

import (
	"context"
	"fmt"
	"time"

	certificatesv1 "k8s.io/api/certificates/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
	"k8s.io/klog/v2"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/constants"
	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
	"github.com/daocloud/dsp-appserver/pkg/util/gvrutil"
	"github.com/daocloud/dsp-appserver/pkg/util/helper"
)

type Cluster interface {
	ListClusters(ctx context.Context, listOptions metav1.ListOptions) (*clusterv1alpha1.ClusterList, error)
	GetCluster(ctx context.Context, clusterName string) (*clusterv1alpha1.Cluster, error)
	CreateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster) (*clusterv1alpha1.Cluster, error)
	ExistCluster(ctx context.Context, name string) (exist bool)
	UpdateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster) (*clusterv1alpha1.Cluster, error)
	EditClusterLabels(ctx context.Context, clusterName string, LoadBytes []byte) (map[string]string, error)
	DeleteCluster(ctx context.Context, clusterName string) error
	GetClusterByKubeSystemID(ctx context.Context, kubeSystemID string) (*clusterv1alpha1.Cluster, error)
	GetClusterCerts(ctx context.Context, clusterName string, ignoreTLS bool) (*rest.Config, *clientcmdapi.Config, error)
	CreateCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error)
	ApproveCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error
	DeleteCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error
	GetCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error)
	GetGlobalClusterKubeSystemID(ctx context.Context) (string, error)
}

var _ Cluster = &ClusterEngine{}

type ClusterEngine struct {
	client        kubeclient.Client
	pclient       pedia.Clients
	factory       informers.SharedInformerFactory
	clusterClient clusterclient.ClusterClients
}

func NewClusterEngine(client kubeclient.Client, pclient pedia.Clients, factory informers.SharedInformerFactory, clusterClient clusterclient.ClusterClients) *ClusterEngine {
	return &ClusterEngine{
		client:        client,
		pclient:       pclient,
		factory:       factory,
		clusterClient: clusterClient,
	}
}

func (c *ClusterEngine) ListClusters(ctx context.Context, listOptions metav1.ListOptions) (*clusterv1alpha1.ClusterList, error) {
	client, err := c.pclient.Generated()
	if err != nil {
		klog.Error(err)
		return nil, err
	}
	return client.ClusterV1alpha1().Clusters().List(ctx, listOptions)
}

func (c *ClusterEngine) GetCluster(ctx context.Context, clusterName string) (*clusterv1alpha1.Cluster, error) {
	client, err := c.pclient.Generated()
	if err != nil {
		return &clusterv1alpha1.Cluster{}, err
	}
	cluster, err := client.ClusterV1alpha1().Clusters().Get(ctx, clusterName, metav1.GetOptions{})
	if err != nil {
		return &clusterv1alpha1.Cluster{}, err
	}

	return cluster, nil
}

func (c *ClusterEngine) GetClusterCerts(ctx context.Context, clusterName string, ignoreTLS bool) (*rest.Config, *clientcmdapi.Config, error) {
	targetCluster, err := c.factory.Cluster().V1alpha1().Clusters().Lister().Get(clusterName)
	if err != nil {
		return nil, nil, err
	}
	if targetCluster.Spec.SecretRef == nil {
		return nil, nil, fmt.Errorf("cluster %s secret is nil", clusterName)
	}
	secret, err := c.client.Kubernetes().CoreV1().Secrets(targetCluster.Spec.SecretRef.Namespace).
		Get(ctx, targetCluster.Spec.SecretRef.Name, metav1.GetOptions{})
	if err != nil {
		return nil, nil, err
	}
	kubeConfigData, ok := secret.Data["kubeconfig"]
	if !ok {
		return nil, nil, fmt.Errorf("cluster %s no kubeConfig data in secret", clusterName)
	}
	clientConfig, err := clientcmd.NewClientConfigFromBytes(kubeConfigData)
	if err != nil {
		return nil, nil, fmt.Errorf("cluster %s newClientConfigFromBytes but %s", clusterName, err)
	}
	// return config
	config, err := clientConfig.ClientConfig()
	if err != nil {
		return nil, nil, fmt.Errorf("cluster %s getClientConfig but %s", clusterName, err)
	}

	rawconfig, err := clientConfig.RawConfig()
	if err != nil {
		return nil, nil, fmt.Errorf("cluster %s getRawConfig but %s", clusterName, err)
	}

	if ignoreTLS {
		util.MakeConfigSkipTLS(config)
	}
	return config, &rawconfig, nil
}

func (c *ClusterEngine) ExistCluster(ctx context.Context, name string) bool {
	result, err := c.client.Generated().ClusterV1alpha1().Clusters().Get(ctx, name, metav1.GetOptions{})
	if err == nil && result.Name == name {
		return true
	}
	return false
}

func (c *ClusterEngine) CreateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster) (*clusterv1alpha1.Cluster, error) {
	client, err := c.clusterClient.NewKubernetesClientWithUser(ctx, constants.GlobalCluster)
	if err != nil {
		return nil, err
	}

	return client.Generated().ClusterV1alpha1().Clusters().Create(ctx, targetCluster, metav1.CreateOptions{})
}

func (c *ClusterEngine) UpdateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster) (*clusterv1alpha1.Cluster, error) {
	oldTarget, err := c.client.Generated().ClusterV1alpha1().Clusters().Get(ctx, targetCluster.Name, metav1.GetOptions{})
	if err != nil {
		return nil, err
	}
	targetCluster.SetResourceVersion(oldTarget.GetResourceVersion())

	client, err := c.clusterClient.NewKubernetesClientWithUser(ctx, constants.GlobalCluster)
	if err != nil {
		return nil, err
	}

	return client.Generated().ClusterV1alpha1().Clusters().Update(ctx, targetCluster, metav1.UpdateOptions{})
}

func (c *ClusterEngine) EditClusterLabels(ctx context.Context, clusterName string, LoadBytes []byte) (map[string]string, error) {
	client, err := c.clusterClient.NewKubernetesClientWithUser(ctx, constants.GlobalCluster)
	if err != nil {
		return nil, err
	}

	cluster, err := client.Generated().ClusterV1alpha1().Clusters().Patch(ctx, clusterName, types.JSONPatchType, LoadBytes, metav1.PatchOptions{})
	if err != nil {
		klog.Error(err)
		return nil, err
	}
	clusterLabels := cluster.GetLabels()
	return clusterLabels, nil
}

func (c *ClusterEngine) DeleteCluster(ctx context.Context, clusterName string) error {
	client, err := c.clusterClient.NewKubernetesClientWithUser(ctx, constants.GlobalCluster)
	if err != nil {
		return err
	}

	return client.Generated().ClusterV1alpha1().Clusters().Delete(ctx, clusterName, metav1.DeleteOptions{})
}

func (c *ClusterEngine) GetClusterByKubeSystemID(ctx context.Context, kubeSystemID string) (*clusterv1alpha1.Cluster, error) {
	// Get cluster instance according to the ClusterSystemIDLabel
	targetLabels := map[string]string{util.ClusterSystemIDLabel: kubeSystemID}
	resultList, err := c.client.Generated().ClusterV1alpha1().Clusters().List(ctx, metav1.ListOptions{LabelSelector: labels.Set(targetLabels).String(), Limit: 1})
	if err != nil {
		return nil, err
	}
	if len(resultList.Items) == 0 {
		return nil, fmt.Errorf("not fount cluster by label %s", kubeSystemID)
	}
	return &resultList.Items[0], nil
}

func (c *ClusterEngine) CreateCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error) {
	client := c.clusterClient.GetInnerCluster(cluster.Name)
	if client == nil {
		return nil, fmt.Errorf("cluster %s is not ready", cluster.Name)
	}

	gvr, err := gvrutil.GetSupportsCsrGVR(client.APIEnablements)
	if err != nil {
		return nil, fmt.Errorf("failed to get csr gvr: %v", err)
	}

	csr, err := helper.ConvertToUnstructured(request)
	if err != nil {
		return nil, fmt.Errorf("failed to convertToUnstruct: %v", err)
	}

	csr, err = gvrutil.ConvertToVersion(csr, gvr)
	if err != nil {
		return nil, fmt.Errorf("failed to convert csr: %v", err)
	}

	csr, err = client.DynamicClient.Resource(gvr).Create(ctx, csr, metav1.CreateOptions{})
	if err != nil {
		return nil, fmt.Errorf("failed to create CertificateSigningRequest :%s", err)
	}

	return helper.ConvertToCSR(csr)
}

func (c *ClusterEngine) ApproveCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
	client := c.clusterClient.GetInnerCluster(cluster.Name)
	if client == nil {
		return fmt.Errorf("cluster %s is not ready", cluster.Name)
	}

	if len(request.Status.Certificate) > 0 {
		return fmt.Errorf("CertificateSigningRequest %s has been apporved", request.Name)
	}

	request.Status = certificatesv1.CertificateSigningRequestStatus{
		Conditions: []certificatesv1.CertificateSigningRequestCondition{{
			Status:  corev1.ConditionTrue,
			Type:    util.CSRApproved,
			Reason:  "KpandaApprove",
			Message: "This CSR was approved by Kpanda",
			LastUpdateTime: metav1.Time{
				Time: time.Now(),
			},
		}},
	}

	gvr, err := gvrutil.GetSupportsCsrGVR(client.APIEnablements)
	if err != nil {
		return fmt.Errorf("failed to get csr gvr: %v", err)
	}

	csr, err := helper.ConvertToUnstructured(request)
	if err != nil {
		return fmt.Errorf("failed to convertToUnstruct: %v", err)
	}

	csr, err = gvrutil.ConvertToVersion(csr, gvr)
	if err != nil {
		return fmt.Errorf("failed to convert csr: %v", err)
	}

	_, err = client.DynamicClient.Resource(gvr).Update(ctx, csr, metav1.UpdateOptions{}, "approval")
	return err
}

func (c *ClusterEngine) GetCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error) {
	client := c.clusterClient.GetInnerCluster(cluster.Name)
	if client == nil {
		return nil, fmt.Errorf("cluster %s is not ready", cluster.Name)
	}

	gvr, err := gvrutil.GetSupportsCsrGVR(client.APIEnablements)
	if err != nil {
		return nil, fmt.Errorf("failed to get csr gvr: %v", err)
	}

	csr, err := client.DynamicClient.Resource(gvr).Get(ctx, csrName, metav1.GetOptions{})
	if err != nil {
		return nil, fmt.Errorf("get CertificateSigningRequest %s but %s", csrName, err)
	}
	return helper.ConvertToCSR(csr)
}

func (c *ClusterEngine) DeleteCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
	client := c.clusterClient.GetInnerCluster(cluster.Name)
	if client == nil {
		return fmt.Errorf("cluster %s is not ready", cluster.Name)
	}

	gvr, err := gvrutil.GetSupportsCsrGVR(client.APIEnablements)
	if err != nil {
		return fmt.Errorf("failed to get csr gvr: %v", err)
	}

	return client.DynamicClient.Resource(gvr).Delete(ctx, request.Name, metav1.DeleteOptions{})
}

func (c *ClusterEngine) GetGlobalClusterKubeSystemID(ctx context.Context) (string, error) {
	client, err := c.pclient.Generated()
	if err != nil {
		return "", err
	}
	cluster, err := client.ClusterV1alpha1().Clusters().Get(ctx, constants.GlobalCluster, metav1.GetOptions{})
	if err != nil {
		return "", err
	}
	return cluster.Status.KubeSystemID, nil
}
