/*
Copyright 2022 Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package engine

import (
	"context"
	"reflect"
	"testing"
	"time"

	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/util/gclient"

	cloudshellv1alpha1 "github.com/cloudtty/cloudtty/pkg/apis/cloudshell/v1alpha1"
	cloudshellclient "github.com/cloudtty/cloudtty/pkg/generated/clientset/versioned"
	cloudttyfake "github.com/cloudtty/cloudtty/pkg/generated/clientset/versioned/fake"
	"github.com/onsi/gomega"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/client-go/dynamic/fake"
	clientsetfake "k8s.io/client-go/kubernetes/fake"
	"k8s.io/client-go/rest"
)

func Test_CloudshellEngine(t *testing.T) {
	client := cloudttyfake.NewSimpleClientset()
	options := &kubeclient.KubernetesOptions{}
	options.QPS, options.Burst, options.Master = 10, 10, "master"
	config := &rest.Config{}
	kubeclient, _ := kubeclient.NewKubernetesClientWithConfig(options, config)

	fakeEngine := NewCloudshellEngine(client, kubeclient)

	g := gomega.NewGomegaWithT(t)

	// create cloudshell
	cloudshell, err := fakeEngine.CreateCloudshell(context.TODO(), NewCloudshell())
	g.Expect(err).NotTo(gomega.HaveOccurred())

	// get cloudshell
	cloudshell2, err := fakeEngine.GetCloudshell(context.TODO(), cloudshell.Namespace, cloudshell.Name)
	g.Expect(err).NotTo(gomega.HaveOccurred())
	g.Expect(reflect.DeepEqual(cloudshell, cloudshell2)).To(gomega.BeTrue())

	cloudshell3, err := fakeEngine.UpdateCloudshell(context.TODO(), cloudshell2)
	g.Expect(err).NotTo(gomega.HaveOccurred())
	g.Expect(reflect.DeepEqual(cloudshell2, cloudshell3)).To(gomega.BeTrue())

	cloudshell3.Status.Phase = "Ready"
	cloudshell4, err := fakeEngine.UpdateCloudshellStatus(context.TODO(), cloudshell3)
	g.Expect(err).NotTo(gomega.HaveOccurred())
	g.Expect(reflect.DeepEqual(cloudshell3, cloudshell4)).To(gomega.BeTrue())

	_, err = fakeEngine.GetCompletedCloudshell(context.TODO(), "cloudshell-system", "cloudshell-sample", "", time.Second*1)
	g.Expect(err).To(gomega.HaveOccurred())

	// delete cloudshell
	err = fakeEngine.DeleteCloudshell(context.TODO(), cloudshell.Namespace, cloudshell.Name)
	g.Expect(err).NotTo(gomega.HaveOccurred())
}

func NewCloudshell() *cloudshellv1alpha1.CloudShell {
	return &cloudshellv1alpha1.CloudShell{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "cloudshell-sample",
			Namespace: "cloudshell-system",
		},
		Spec: cloudshellv1alpha1.CloudShellSpec{
			RunAsUser:     "root",
			CommandAction: "bash",
			Ttl:           500,
		},
	}
}

func Test_cloudshellEngine_GetKpandaGProductProxy(t *testing.T) {
	kube := kubeclient.NewFakeClientSets(clientsetfake.NewSimpleClientset(), fake.NewSimpleDynamicClient(gclient.NewSchema()), nil, "", nil)
	type fields struct {
		kubeclient kubeclient.Client
		client     cloudshellclient.Interface
	}
	type args struct {
		ctx context.Context
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *unstructured.Unstructured
		wantErr bool
	}{
		{
			name: "test GetKpandaGProductProxy",
			fields: fields{
				kubeclient: kube,
				client:     nil,
			},
			args: args{
				ctx: context.Background(),
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &cloudshellEngine{
				kubeclient: tt.fields.kubeclient,
				client:     tt.fields.client,
			}
			_, err := c.GetKpandaGProductProxy(tt.args.ctx)
			if (err != nil) != tt.wantErr {
				t.Errorf("cloudshellEngine.GetKpandaGProductProxy() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func Test_cloudshellEngine_UpdateKpandaGProductProxy(t *testing.T) {
	kube := kubeclient.NewFakeClientSets(clientsetfake.NewSimpleClientset(), fake.NewSimpleDynamicClient(gclient.NewSchema()), nil, "", nil)
	type fields struct {
		kubeclient kubeclient.Client
		client     cloudshellclient.Interface
	}
	type args struct {
		ctx context.Context
		obj *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *unstructured.Unstructured
		wantErr bool
	}{
		{
			name: "test UpdateKpandaGProductProxy",
			fields: fields{
				kubeclient: kube,
				client:     nil,
			},
			args: args{
				ctx: context.Background(),
				obj: &unstructured.Unstructured{},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &cloudshellEngine{
				kubeclient: tt.fields.kubeclient,
				client:     tt.fields.client,
			}
			_, err := c.UpdateKpandaGProductProxy(tt.args.ctx, tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("cloudshellEngine.UpdateKpandaGProductProxy() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
