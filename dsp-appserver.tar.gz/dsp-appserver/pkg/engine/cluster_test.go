package engine

import (
	"context"
	"fmt"
	"reflect"
	"testing"

	fake "github.com/clusterpedia-io/fake-apiserver/apiserver"
	"github.com/clusterpedia-io/fake-apiserver/storage/memory"
	"github.com/onsi/gomega"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	clientsetfake "k8s.io/client-go/kubernetes/fake"
	"k8s.io/client-go/kubernetes/scheme"
	"sigs.k8s.io/controller-runtime/pkg/client"
	runtimeclientfake "sigs.k8s.io/controller-runtime/pkg/client/fake"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	clusterclientsetfake "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/fake"
	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
)

func NewMockClusterEngineData(processClusterInterface func(clusterInterface *FakeClusterInterface), processClusterLister func(*FakeClusterLister)) Cluster {
	storage := memory.NewFakeStorageFactory()
	server, _ := fake.NewFakeApiserver(storage)
	return &FakeClusterEngine{
		ClusterEngine: ClusterEngine{
			client: &FakeKubeClient{
				FakeClient: kubeclient.FakeClient{
					KubeClient:    nil,
					DynamicClient: nil,
					GeneratedClient: &FakeGeneratedClientSetInterface{
						processClusterInterface: processClusterInterface,
					},
					MasterURL:  "",
					KubeConfig: nil,
				},
			},
			factory: &FakeSharedInformerFactory{
				processClusterLister: processClusterLister,
			},
			clusterClient: NewFakeClusterClient(server, false),
		},
	}
}

func newCluster(name string) *clusterv1alpha1.Cluster {
	return &clusterv1alpha1.Cluster{
		TypeMeta: metav1.TypeMeta{Kind: clusterv1alpha1.ResourceKindCluster, APIVersion: clusterv1alpha1.GroupVersion.String()},
		ObjectMeta: metav1.ObjectMeta{
			Name: name,
		},
		Spec: clusterv1alpha1.ClusterSpec{
			Provider: "k8s",
		},
	}
}

func NewFakeClient() client.Client {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		panic(err)
	}
	client := runtimeclientfake.NewClientBuilder().WithScheme(sch).WithRuntimeObjects(&clusterv1alpha1.Cluster{}).Build()
	return client
}

func TestClusterOperation(t *testing.T) {
	// client
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}

	client := runtimeclientfake.NewClientBuilder().WithScheme(sch).WithRuntimeObjects(&clusterv1alpha1.Cluster{}).Build()

	// resource
	key := types.NamespacedName{
		Name: "test",
	}

	g := gomega.NewGomegaWithT(t)

	// Test Create
	created := newCluster("test")
	g.Expect(client.Create(context.TODO(), created)).NotTo(gomega.HaveOccurred())

	// Test Get
	fetched := &clusterv1alpha1.Cluster{}
	g.Expect(client.Get(context.TODO(), key, fetched)).NotTo(gomega.HaveOccurred())
	t.Logf("get cluster %+v\n", fetched)

	// Test Updating the Labels
	updated := fetched.DeepCopy()
	updated.Labels = map[string]string{"cluster.kpanda.io/name": "kpanda"}
	g.Expect(client.Update(context.TODO(), updated)).NotTo(gomega.HaveOccurred())

	g.Expect(client.Get(context.TODO(), key, fetched)).NotTo(gomega.HaveOccurred())
	t.Logf("get cluster %+v\n", fetched)

	// Test Delete
	g.Expect(client.Delete(context.TODO(), fetched)).NotTo(gomega.HaveOccurred())
	g.Expect(client.Get(context.TODO(), key, fetched)).To(gomega.HaveOccurred())
}

func Test_MakeStaticCheckHappy(_ *testing.T) {
	FakeInformerClusterInterface{processClusterLister: func(lister *FakeClusterLister) {
		fmt.Println(lister)
	}}.processClusterLister(nil)
	FakeInformerv1alpha1Interface{processClusterLister: func(lister *FakeClusterLister) {
		fmt.Println(lister)
	}}.processClusterLister(nil)
}

func Test_ExistCluster(t *testing.T) {
	clusterEngine := NewMockClusterEngineData(func(clusterInterface *FakeClusterInterface) {
		clusterInterface._Get = func(ctx context.Context, name string, opts metav1.GetOptions) (*clusterv1alpha1.Cluster, error) {
			return nil, fmt.Errorf("not found")
		}
	}, func(lister *FakeClusterLister) {})

	if clusterEngine.ExistCluster(context.Background(), "false") { // should not exist
		t.Fail()
	}

	clusterEngine = NewMockClusterEngineData(func(clusterInterface *FakeClusterInterface) {
		clusterInterface._Get = func(ctx context.Context, name string, opts metav1.GetOptions) (*clusterv1alpha1.Cluster, error) {
			return &clusterv1alpha1.Cluster{
				ObjectMeta: metav1.ObjectMeta{Name: name},
			}, nil
		}
	}, func(lister *FakeClusterLister) {})

	if !clusterEngine.ExistCluster(context.Background(), "insight") { // should exist
		t.Fail()
	}
}

func Test_CreateClusters(t *testing.T) {
	fakeClient := NewFakeClient()
	clusterEngine := NewMockClusterEngineData(func(clusterInterface *FakeClusterInterface) {
		clusterInterface._Create = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, opts metav1.CreateOptions) (*clusterv1alpha1.Cluster, error) {
			err := fakeClient.Create(ctx, cluster)
			return cluster, err
		}
	}, func(lister *FakeClusterLister) {})

	targetCluster := clusterv1alpha1.Cluster{
		TypeMeta:   metav1.TypeMeta{Kind: clusterv1alpha1.ResourceKindCluster, APIVersion: clusterv1alpha1.GroupVersion.String()},
		ObjectMeta: metav1.ObjectMeta{Name: "test-cluster"},
		Spec:       clusterv1alpha1.ClusterSpec{Provider: "k8s"},
	}

	result, _ := clusterEngine.CreateClusters(context.Background(), &targetCluster)
	if result.Spec.Provider != "k8s" {
		t.Fail()
	}
}

func Test_UpdateClusters(t *testing.T) {
	fakeClient := NewFakeClient()
	clusterEngine := NewMockClusterEngineData(func(clusterInterface *FakeClusterInterface) {
		clusterInterface._Get = func(ctx context.Context, name string, opts metav1.GetOptions) (*clusterv1alpha1.Cluster, error) {
			key := client.ObjectKey{Name: name}
			result := clusterv1alpha1.Cluster{
				Status: clusterv1alpha1.ClusterStatus{KubeSystemID: "TEST"},
			}
			err := fakeClient.Get(context.Background(), key, &result)
			return &result, err
		}
		clusterInterface._Update = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, opts metav1.UpdateOptions) (*clusterv1alpha1.Cluster, error) {
			err := fakeClient.Update(ctx, cluster)
			return cluster, err
		}
		clusterInterface._Create = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, opts metav1.CreateOptions) (*clusterv1alpha1.Cluster, error) {
			err := fakeClient.Create(ctx, cluster)
			return cluster, err
		}
	}, func(lister *FakeClusterLister) {})

	targetCluster := clusterv1alpha1.Cluster{
		TypeMeta:   metav1.TypeMeta{Kind: clusterv1alpha1.ResourceKindCluster, APIVersion: clusterv1alpha1.GroupVersion.String()},
		ObjectMeta: metav1.ObjectMeta{Name: "test-cluster"},
		Spec:       clusterv1alpha1.ClusterSpec{Provider: "k8s"},
	}

	clusterEngine.CreateClusters(context.Background(), &targetCluster)

	updateCluster := clusterv1alpha1.Cluster{
		TypeMeta: metav1.TypeMeta{Kind: clusterv1alpha1.ResourceKindCluster, APIVersion: clusterv1alpha1.GroupVersion.String()},
		ObjectMeta: metav1.ObjectMeta{
			Name:   "test-cluster",
			Labels: map[string]string{"labelKey": "labelValue"},
		},
		Spec: clusterv1alpha1.ClusterSpec{Provider: "k8s-------1"},
	}

	result, _ := clusterEngine.UpdateClusters(context.Background(), &updateCluster)
	if !reflect.DeepEqual(result.Labels, map[string]string{"labelKey": "labelValue"}) {
		t.Fail()
	}
}

func TestClusterEngine_DeleteCluster(t *testing.T) {
	storage := memory.NewFakeStorageFactory()
	server, _ := fake.NewFakeApiserver(storage)
	type fields struct {
		client        kubeclient.Client
		pclient       pedia.Clients
		factory       informers.SharedInformerFactory
		clusterClient clusterclient.ClusterClients
	}
	type args struct {
		ctx         context.Context
		clusterName string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			name: "test delete cluster",
			fields: fields{
				client:        kubeclient.NewFakeClientSets(clientsetfake.NewSimpleClientset(), nil, clusterclientsetfake.NewSimpleClientset(), "", nil),
				pclient:       nil,
				factory:       nil,
				clusterClient: NewFakeClusterClient(server, false),
			},
			args: args{
				ctx:         context.Background(),
				clusterName: "cluster1",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &ClusterEngine{
				client:        tt.fields.client,
				pclient:       tt.fields.pclient,
				factory:       tt.fields.factory,
				clusterClient: tt.fields.clusterClient,
			}
			if err := c.DeleteCluster(tt.args.ctx, tt.args.clusterName); (err != nil) != tt.wantErr {
				t.Errorf("ClusterEngine.DeleteCluster() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func TestClusterEngine_GetClusterByKubeSystemID(t *testing.T) {
	c := kubeclient.NewFakeClientSets(clientsetfake.NewSimpleClientset(), nil, clusterclientsetfake.NewSimpleClientset(), "", nil)
	c.Generated().ClusterV1alpha1().Clusters().Create(context.Background(), &clusterv1alpha1.Cluster{
		ObjectMeta: metav1.ObjectMeta{
			Name:   "abc",
			Labels: map[string]string{util.ClusterSystemIDLabel: "abc"},
		},
	}, metav1.CreateOptions{})
	type fields struct {
		client        kubeclient.Client
		pclient       pedia.Clients
		factory       informers.SharedInformerFactory
		clusterClient clusterclient.ClusterClients
	}
	type args struct {
		ctx          context.Context
		kubeSystemID string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *clusterv1alpha1.Cluster
		wantErr bool
	}{
		{
			name: "kube system not exists",
			fields: fields{
				client:        c,
				pclient:       nil,
				factory:       nil,
				clusterClient: nil,
			},
			args: args{
				ctx:          context.Background(),
				kubeSystemID: "bcd",
			},
			want:    nil,
			wantErr: true,
		},
		{
			name: "kube system not exists",
			fields: fields{
				client:        c,
				pclient:       nil,
				factory:       nil,
				clusterClient: nil,
			},
			args: args{
				ctx:          context.Background(),
				kubeSystemID: "abc",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &ClusterEngine{
				client:        tt.fields.client,
				pclient:       tt.fields.pclient,
				factory:       tt.fields.factory,
				clusterClient: tt.fields.clusterClient,
			}
			_, err := c.GetClusterByKubeSystemID(tt.args.ctx, tt.args.kubeSystemID)
			if (err != nil) != tt.wantErr {
				t.Errorf("ClusterEngine.GetClusterByKubeSystemID() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
