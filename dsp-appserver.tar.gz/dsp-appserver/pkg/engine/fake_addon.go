package engine

import (
	"context"
	"fmt"
	"net/http/httptest"
	"sync"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	helmv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/helm/v1alpha1"
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"
	clusterclientsetfake "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/fake"
	clusterv1alpha11 "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/typed/cluster/v1alpha1"
	helmversionedv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/typed/helm/v1alpha1"
	v1 "github.com/kubernetes-csi/external-snapshotter/client/v4/clientset/versioned/typed/volumesnapshot/v1"
	vpaclient "k8s.io/autoscaler/vertical-pod-autoscaler/pkg/client/clientset/versioned"
	"k8s.io/client-go/discovery"
	"k8s.io/client-go/dynamic"
	dynamicfake "k8s.io/client-go/dynamic/fake"
	"k8s.io/client-go/kubernetes"
	clientsetfake "k8s.io/client-go/kubernetes/fake"
	"k8s.io/client-go/rest"
	"k8s.io/metrics/pkg/client/custom_metrics"
	"sigs.k8s.io/controller-runtime/pkg/client"
	clientfake "sigs.k8s.io/controller-runtime/pkg/client/fake"

	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
	"github.com/daocloud/dsp-appserver/pkg/util/gclient"
)

type FakeAddonClusterClient struct {
	sync.RWMutex
	FakeServer       map[string]*httptest.Server
	GeneratedClient  map[string]*FakeVersionedInterface
	k8sClientMap     map[string]kubernetes.Interface
	clientMap        map[string]client.Client
	dynamicClientMap map[string]dynamic.Interface
}

func NewFakeAddonClusterClient() *FakeAddonClusterClient {
	return &FakeAddonClusterClient{
		FakeServer:       map[string]*httptest.Server{},
		GeneratedClient:  map[string]*FakeVersionedInterface{},
		k8sClientMap:     map[string]kubernetes.Interface{},
		clientMap:        map[string]client.Client{},
		dynamicClientMap: map[string]dynamic.Interface{},
	}
}

var _ clusterclient.ClusterClients = new(FakeAddonClusterClient)

func (f *FakeAddonClusterClient) IsHostCluster(_ *clusterv1alpha1.Cluster) bool {
	panic("implement me")
}

func (f *FakeAddonClusterClient) IsClusterReady(_ *clusterv1alpha1.Cluster) bool {
	panic("implement me")
}

func (f *FakeAddonClusterClient) GetClusterKubeConfig(_ string) (*rest.Config, error) {
	return &rest.Config{}, nil
}

func (f *FakeAddonClusterClient) Get(_ string) (*clusterv1alpha1.Cluster, error) {
	panic("implement me")
}

func (f *FakeAddonClusterClient) GetInnerCluster(_ string) *clusterclient.InnerCluster {
	panic("implement me")
}

func (f *FakeAddonClusterClient) GetClient(cluster string) (kubernetes.Interface, error) {
	f.RWMutex.RLock()
	c, exist := f.k8sClientMap[cluster]
	f.RUnlock()
	if exist {
		return c, nil
	}
	f.RWMutex.Lock()
	defer f.RWMutex.Unlock()
	c = clientsetfake.NewSimpleClientset()
	f.k8sClientMap[cluster] = c
	return c, nil
}

func (f *FakeAddonClusterClient) GetGeneratedClient(_ string) (clusterclientset.Interface, error) {
	return nil, fmt.Errorf("not found")
}

func (f *FakeAddonClusterClient) GetDynamicClient(cluster string) (dynamic.Interface, error) {
	f.RWMutex.RLock()
	c, exist := f.dynamicClientMap[cluster]
	f.RUnlock()
	if exist {
		return c, nil
	}
	f.RWMutex.Lock()
	defer f.RWMutex.Unlock()
	c = dynamicfake.NewSimpleDynamicClient(gclient.NewSchema())
	f.dynamicClientMap[cluster] = c
	return c, nil
}

func (f *FakeAddonClusterClient) GetClusterByKubeSystemID(_ string) string {
	panic("implement me")
}

func (f *FakeAddonClusterClient) GetSnapshotClient(_ string) (*v1.SnapshotV1Client, error) {
	panic("implement me")
}

func (f *FakeAddonClusterClient) GetSnapshotClientWithUser(_ context.Context, _ string) (*v1.SnapshotV1Client, error) {
	panic("implement me")
}

func (f *FakeAddonClusterClient) GetAllClusterClient() (map[string]kubernetes.Interface, error) {
	panic("implement me")
}

func (f *FakeAddonClusterClient) GetClientSet(cluster string) (client.Client, error) {
	f.RWMutex.RLock()
	c, exist := f.clientMap[cluster]
	f.RUnlock()
	if exist {
		return c, nil
	}
	f.RWMutex.Lock()
	defer f.RWMutex.Unlock()
	c = clientfake.NewClientBuilder().WithScheme(gclient.NewSchema()).Build()
	f.clientMap[cluster] = c
	return c, nil
}

func (f *FakeAddonClusterClient) GetClientSetWithUser(_ context.Context, cluster string) (client.Client, error) {
	f.RWMutex.RLock()
	c, exist := f.clientMap[cluster]
	f.RUnlock()
	if exist {
		return c, nil
	}
	f.RWMutex.Lock()
	defer f.RWMutex.Unlock()
	schema := gclient.NewSchema()
	err := helmv1alpha1.AddToScheme(schema)
	if err != nil {
		return nil, err
	}
	c = clientfake.NewClientBuilder().WithScheme(schema).Build()
	f.clientMap[cluster] = c
	return c, nil
}

func (f *FakeAddonClusterClient) AddCluster(_ interface{}) {
	panic("implement me")
}

func (f *FakeAddonClusterClient) GetCustomMetricsClient(_ string) (custom_metrics.CustomMetricsClient, error) {
	panic("implement me")
}

func (f *FakeAddonClusterClient) NewKubeConfigWithUser(_ context.Context, _ string) (*rest.Config, error) {
	panic("implement me")
}

func (f *FakeAddonClusterClient) NewKubernetesClientWithUser(_ context.Context, cluster string) (kubeclient.Client, error) {
	kubeClient, _ := f.GetClient(cluster)
	dynamicClient, _ := f.GetDynamicClient(cluster)
	return kubeclient.NewFakeClientSets(kubeClient, dynamicClient, NewFakeVersionedInterface(), "", nil), nil
}

func (f *FakeAddonClusterClient) NewVPAClientWithUser(_ context.Context, _ string) (vpaclient.Interface, error) {
	panic("implement me")
}

func (f *FakeAddonClusterClient) GetVPAClient(_ string) (vpaclient.Interface, error) {
	panic("implement me")
}

type FakeVersionedInterface struct {
	helm helmversionedv1alpha1.HelmV1alpha1Interface
}

func NewFakeVersionedInterface() *FakeVersionedInterface {
	return &FakeVersionedInterface{
		helm: clusterclientsetfake.NewSimpleClientset(&helmv1alpha1.HelmRelease{},
			&helmv1alpha1.HelmReleaseList{}, &helmv1alpha1.HelmRepo{}, &helmv1alpha1.HelmRepoList{},
			&helmv1alpha1.HelmOperation{}, &helmv1alpha1.HelmOperationList{}).HelmV1alpha1(),
	}
}

func (f *FakeVersionedInterface) Discovery() discovery.DiscoveryInterface {
	panic("implement me")
}

func (f *FakeVersionedInterface) ClusterV1alpha1() clusterv1alpha11.ClusterV1alpha1Interface {
	return &FakeClusterV1alpha1Client{}
}

func (f *FakeVersionedInterface) HelmV1alpha1() helmversionedv1alpha1.HelmV1alpha1Interface {
	return f.helm
}
