/*
Copyright 2021 The Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package clusterpedia

import (
	"context"
	"testing"

	pediaclient "github.com/clusterpedia-io/client-go/client"
	"github.com/clusterpedia-io/client-go/tools/builder"
	fake "github.com/clusterpedia-io/fake-apiserver/apiserver"
	"github.com/clusterpedia-io/fake-apiserver/storage/memory"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/rest"
)

func TestFakeApiserver(t *testing.T) {
	// build fake memory storage
	storage := memory.NewFakeStorageFactory()
	server, err := fake.NewFakeApiserver(storage)
	if err != nil {
		t.Error(err)
	}
	defer server.Close()

	cs, err := pediaclient.NewForConfig(&rest.Config{Host: server.URL})
	if err != nil {
		t.Error(err)
	}

	// generic pod data
	podDates := []struct {
		name        string
		clusterNmae string
		namespace   string
	}{
		{"pod01", "cluster01", "default"},
		{"pod02", "cluster01", "default"},
		{"pod03", "cluster01", "default"},
		{"pod04", "cluster01", "default"},
		{"pod05", "cluster01", "kube-system"},
		{"pod06", "cluster01", "kube-system"},
		{"pod07", "cluster01", "kube-system"},
		{"pod08", "cluster02", "default"},
		{"pod09", "cluster02", "default"},
		{"pod10", "cluster02", "kube-system"},
		{"pod11", "cluster03", "kube-system"},
		{"pod12", "cluster03", "kube-system"},
	}
	for _, pod := range podDates {
		err := storage.Create(context.TODO(), pod.clusterNmae, newPod(pod.name, pod.namespace, pod.clusterNmae))
		if err != nil {
			t.Error(err)
		}
	}

	testCase := []struct {
		opt         metav1.ListOptions
		expectCount int
	}{
		{
			builder.ListOptionsBuilder().Clusters("cluster01").
				Namespaces("default").Options(), 4,
		},
		{
			builder.ListOptionsBuilder().Clusters("cluster01").
				Namespaces("kube-system").Options(), 3,
		},
		{
			builder.ListOptionsBuilder().Clusters("cluster01", "cluster02").
				Namespaces("kube-system").Options(), 4,
		},
		{
			builder.ListOptionsBuilder().Clusters("cluster01", "cluster02").
				Namespaces("kube-system", "default").Options(), 10,
		},
	}

	for _, test := range testCase {
		t.Run("", func(t *testing.T) {
			pods, err := cs.CoreV1().Pods("").List(context.TODO(), test.opt)
			if err != nil {
				t.Error(err)
			}
			if len(pods.Items) != test.expectCount {
				t.Errorf("Unexpect label selector: %s", test.opt.LabelSelector)
			}
		})
	}
}

// newPod return a pod obejct.
func newPod(name, namespace, clusterName string) *corev1.Pod {
	b := true
	return &corev1.Pod{
		TypeMeta: metav1.TypeMeta{Kind: "Pod", APIVersion: "v1"},
		ObjectMeta: metav1.ObjectMeta{
			Name:      name,
			Namespace: namespace,
			Labels: map[string]string{
				"name":      name,
				"namespace": namespace,
				"cluster":   clusterName,
			},
			OwnerReferences: []metav1.OwnerReference{
				{
					UID:        types.UID(name),
					Controller: &b,
				},
			},
		},
	}
}
