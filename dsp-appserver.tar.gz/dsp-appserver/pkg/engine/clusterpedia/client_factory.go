package clusterpedia

import (
	"context"
	"fmt"
	"sync"

	pediaclient "github.com/clusterpedia-io/client-go/client"
	pediav1beta1 "github.com/clusterpedia-io/client-go/clusterpediaclient/v1beta1"
	"github.com/clusterpedia-io/client-go/customclient"
	pediadynamic "github.com/clusterpedia-io/client-go/dynamic"
	version "github.com/clusterpedia-io/client-go/pkg/generated/clientset/versioned"
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	vpaclient "k8s.io/autoscaler/vertical-pod-autoscaler/pkg/client/clientset/versioned"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"

	"github.com/daocloud/dsp-appserver/pkg/constants"
)

var ClientNotExistsFormat = "client %s not exists"

type clients struct {
	sync.RWMutex
	globalClient kubernetes.Interface
	// generated clientset
	clusterclientset clusterclientset.Interface

	// dynamic client
	dynamic             dynamic.Interface
	subClients          map[string]kubernetes.Interface
	subClusterClientSet map[string]clusterclientset.Interface
	customClient        customclient.Interface
	subDynamic          map[string]dynamic.Interface
	clusterpediaClient  pediav1beta1.ClusterPediaV1beta1
	subVPA              map[string]vpaclient.Interface
}

type Clients interface {
	Get() (kubernetes.Interface, error)
	GetSubClient(clusterName string) (kubernetes.Interface, error)
	Dynamic() (dynamic.Interface, error)
	Generated() (clusterclientset.Interface, error)
	GetSubGenerated(clusterName string) (clusterclientset.Interface, error)
	GetCustomClient() (customclient.Interface, error)
	GetSubDynamic(clusterName string) (dynamic.Interface, error)
	GetClusterpediaClient() (pediav1beta1.ClusterPediaV1beta1, error)
	GetSubVPAClient(cluster string) (vpaclient.Interface, error)
}

// Get get globalClient.
func (c *clients) Get() (kubernetes.Interface, error) {
	if c.globalClient == nil {
		return nil, fmt.Errorf("failed to init globalClient")
	}
	return c.globalClient, nil
}

// GetSubClient get client for a specific cluster.
func (c *clients) GetSubClient(clusterName string) (kubernetes.Interface, error) {
	cluster := func() kubernetes.Interface {
		c.RLock()
		defer c.RUnlock()
		if cluster, exists := c.subClients[clusterName]; exists {
			return cluster
		}
		return nil
	}()
	if cluster != nil {
		return cluster, nil
	}

	c.Lock()
	defer c.Unlock()
	if cluster, exists := c.subClients[clusterName]; exists {
		return cluster, nil
	}
	// if subClient is nil, create and add to clientsmap
	sc, err := initSubClient(clusterName)
	if err != nil {
		return nil, fmt.Errorf(ClientNotExistsFormat, clusterName)
	}
	c.subClients[clusterName] = sc

	return sc, nil
}

func (c *clients) Dynamic() (dynamic.Interface, error) {
	if c.dynamic == nil {
		return nil, fmt.Errorf("failed to init dynamic client")
	}
	return c.dynamic, nil
}

func (c *clients) GetSubDynamic(clusterName string) (dynamic.Interface, error) {
	cluster := func() dynamic.Interface {
		c.RLock()
		defer c.RUnlock()
		if cluster, exists := c.subDynamic[clusterName]; exists {
			return cluster
		}
		return nil
	}()
	if cluster != nil {
		return cluster, nil
	}

	c.Lock()
	defer c.Unlock()
	if cluster, exists := c.subDynamic[clusterName]; exists {
		return cluster, nil
	}
	// if subDynamic is nil, create and add to clientsmap
	sc, err := initSubDynamic(clusterName)
	if err != nil {
		return nil, fmt.Errorf(ClientNotExistsFormat, clusterName)
	}
	c.subDynamic[clusterName] = sc

	return sc, nil
}

func (c *clients) Generated() (clusterclientset.Interface, error) {
	if c.clusterclientset == nil {
		return nil, fmt.Errorf("failed to init generated client")
	}
	return c.clusterclientset, nil
}

func (c *clients) GetSubGenerated(clusterName string) (clusterclientset.Interface, error) {
	cluster := func() clusterclientset.Interface {
		c.RLock()
		defer c.RUnlock()
		if cluster, exists := c.subClusterClientSet[clusterName]; exists {
			return cluster
		}
		return nil
	}()
	if cluster != nil {
		return cluster, nil
	}

	c.Lock()
	defer c.Unlock()
	if cluster, exists := c.subClusterClientSet[clusterName]; exists {
		return cluster, nil
	}

	// if sub Cluster Client Set is nil, create and add to subClusterClientSet
	sg, err := initGenerated(clusterName)
	if err != nil {
		return nil, fmt.Errorf(ClientNotExistsFormat, clusterName)
	}
	c.subClusterClientSet[clusterName] = sg
	return sg, nil
}

func (c *clients) GetCustomClient() (customclient.Interface, error) {
	if c.customClient == nil {
		return nil, fmt.Errorf("failed to init custom client")
	}
	return c.customClient, nil
}

func (c *clients) GetClusterpediaClient() (pediav1beta1.ClusterPediaV1beta1, error) {
	if c.clusterpediaClient == nil {
		return nil, fmt.Errorf("failed to init pediaclusterClient")
	}
	return c.clusterpediaClient, nil
}

func (c *clients) GetSubVPAClient(cluster string) (vpaclient.Interface, error) {
	client := func() vpaclient.Interface {
		c.RLock()
		defer c.RUnlock()
		if cluster, exists := c.subVPA[cluster]; exists {
			return cluster
		}
		return nil
	}()
	if client != nil {
		return client, nil
	}

	c.Lock()
	defer c.Unlock()
	if client, exists := c.subVPA[cluster]; exists {
		return client, nil
	}
	// if subVPA is nil, create and add to client's map
	vc, err := initSubVPAClient(cluster)
	if err != nil {
		return nil, fmt.Errorf(ClientNotExistsFormat, cluster)
	}
	c.subVPA[cluster] = vc

	return vc, nil
}

var (
	client *clients
	once   sync.Once
)

func NewClients() Clients {
	if client == nil {
		once.Do(func() {
			c, _ := initGlobalClient()
			gc, _ := initGenerated(constants.GlobalCluster)
			dc, _ := initDynamic()
			cc, _ := initCustomClient()
			pc, _ := initClusterpediaClient()
			client = &clients{
				clusterclientset:    gc,
				dynamic:             dc,
				globalClient:        c,
				subClients:          make(map[string]kubernetes.Interface),
				subClusterClientSet: map[string]clusterclientset.Interface{},
				customClient:        cc,
				clusterpediaClient:  pc,
				subVPA:              map[string]vpaclient.Interface{},
			}
		})
		go SyncSubClients()
	}

	return client
}

// SyncClients sync clusterpedia client to maps.
func SyncSubClients() error {
	client.Lock()
	defer client.Unlock()
	// set sub client
	config, err := BuildConfig()
	if err != nil {
		return err
	}
	if version, err := version.NewForConfig(config); err == nil {
		pediaclusters, err := version.ClusterV1alpha2().PediaClusters().List(context.TODO(), metav1.ListOptions{})
		if err != nil {
			return err
		}

		for _, pc := range pediaclusters.Items {
			cluster, err := pediaclient.NewClusterForConfig(config, pc.Name)
			if err != nil {
				return err
			}
			client.subClients[pc.Name] = cluster

			pediaConfig, err := pediaclient.ClusterConfigFor(config, pc.Name)
			if err != nil {
				return err
			}

			gc, err := clusterclientset.NewForConfig(pediaConfig)
			if err != nil {
				return err
			}
			client.subClusterClientSet[pc.Name] = gc
		}
	}

	return nil
}

func initGlobalClient() (kubernetes.Interface, error) {
	config, err := BuildConfig()
	if err != nil {
		return nil, err
	}

	// set multiClient
	c, err := pediaclient.NewForConfig(config)
	if err != nil {
		return nil, err
	}
	return c, nil
}

func initCustomClient() (customclient.Interface, error) {
	config, err := BuildConfig()
	if err != nil {
		return nil, err
	}
	return customclient.NewForConfig(config)
}

func initSubClient(clusterName string) (kubernetes.Interface, error) {
	if clusterName == "" {
		return nil, fmt.Errorf("cluster name cannot be empty")
	}

	config, err := BuildConfig()
	if err != nil {
		return nil, err
	}

	// create subClient
	sc, err := pediaclient.NewClusterForConfig(config, clusterName)
	if err != nil {
		return nil, err
	}

	return sc, nil
}

func initSubDynamic(clusterName string) (dynamic.Interface, error) {
	if clusterName == "" {
		return nil, fmt.Errorf("cluster name cannot be empty")
	}

	config, err := BuildConfig()
	if err != nil {
		return nil, err
	}

	// create subClient
	sc, err := pediadynamic.NewClusterForConfig(config, clusterName)
	if err != nil {
		return nil, err
	}

	return sc, nil
}

func initDynamic() (dynamic.Interface, error) {
	config, err := BuildConfig()
	if err != nil {
		return nil, err
	}

	dc, err := pediadynamic.NewForConfig(config)
	if err != nil {
		return nil, err
	}

	return dc, nil
}

func initGenerated(clusterName string) (clusterclientset.Interface, error) {
	config, err := BuildConfig()
	if err != nil {
		return nil, err
	}

	pediaConfig, err := pediaclient.ClusterConfigFor(config, clusterName)
	if err != nil {
		return nil, err
	}

	gc, err := clusterclientset.NewForConfig(pediaConfig)
	if err != nil {
		return nil, err
	}

	return gc, nil
}

func initClusterpediaClient() (pediav1beta1.ClusterPediaV1beta1, error) {
	config, err := BuildConfig()
	if err != nil {
		return nil, err
	}

	pc, err := pediav1beta1.NewForConfig(config)
	if err != nil {
		return nil, err
	}

	return pc, nil
}

func initSubVPAClient(cluster string) (vpaclient.Interface, error) {
	if cluster == "" {
		return nil, fmt.Errorf("cluster name cannot be empty")
	}

	globalConfig, err := BuildConfig()
	if err != nil {
		return nil, err
	}

	config, err := pediaclient.ClusterConfigFor(globalConfig, cluster)
	if err != nil {
		return nil, err
	}

	return vpaclient.NewForConfig(config)
}
