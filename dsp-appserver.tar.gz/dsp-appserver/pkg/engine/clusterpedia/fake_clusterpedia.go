package clusterpedia

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"sync"
	"time"

	pediaclusterv1alpha2 "github.com/clusterpedia-io/api/cluster/v1alpha2"
	internal "github.com/clusterpedia-io/api/clusterpedia"
	"github.com/clusterpedia-io/api/clusterpedia/install"
	pediaclient "github.com/clusterpedia-io/client-go/client"
	pediav1beta1 "github.com/clusterpedia-io/client-go/clusterpediaclient/v1beta1"
	"github.com/clusterpedia-io/client-go/customclient"
	pediadynamic "github.com/clusterpedia-io/client-go/dynamic"
	"github.com/clusterpedia-io/clusterpedia/pkg/apiserver/registry/clusterpedia/resources"
	fakepediaclient "github.com/clusterpedia-io/clusterpedia/pkg/generated/clientset/versioned/fake"
	informers "github.com/clusterpedia-io/clusterpedia/pkg/generated/informers/externalversions"
	"github.com/clusterpedia-io/clusterpedia/pkg/kubeapiserver"
	"github.com/clusterpedia-io/clusterpedia/pkg/scheme"
	"github.com/clusterpedia-io/clusterpedia/pkg/storage"
	cache "github.com/clusterpedia-io/clusterpedia/pkg/storage/internalstorage"
	"github.com/clusterpedia-io/clusterpedia/pkg/storageconfig"
	"github.com/clusterpedia-io/clusterpedia/pkg/utils/filters"
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"
	metallbv1beta1 "go.universe.tf/metallb/api/v1beta1"
	"gopkg.in/yaml.v3"
	metainternal "k8s.io/apimachinery/pkg/apis/meta/internalversion"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/runtime/serializer"
	"k8s.io/apimachinery/pkg/version"
	"k8s.io/apiserver/pkg/authorization/authorizerfactory"
	registryrest "k8s.io/apiserver/pkg/registry/rest"
	genericapiserver "k8s.io/apiserver/pkg/server"
	"k8s.io/apiserver/pkg/server/healthz"
	vpaclient "k8s.io/autoscaler/vertical-pod-autoscaler/pkg/client/clientset/versioned"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"

	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/gclient"
)

func init() {
	scheme := gclient.NewSchema()
	_ = metallbv1beta1.AddToScheme(Scheme)
	install.Install(scheme)

	// we need to add the options to empty v1
	// TODO fix the server code to avoid this
	metav1.AddToGroupVersion(Scheme, schema.GroupVersion{Version: "v1"})
	_ = metainternal.AddToScheme(Scheme)

	// TODO: keep the generic API server from wanting this
	unversioned := schema.GroupVersion{Group: "", Version: "v1"}
	Scheme.AddUnversionedTypes(unversioned,
		&metav1.Status{},
		&metav1.APIVersions{},
		&metav1.APIGroupList{},
		&metav1.APIGroup{},
		&metav1.APIResourceList{},
	)
}

func getStorageConfigFile() (string, error) {
	db := "kpanda.db"
	if util.ExistFile(db) {
		_ = os.Remove(db)
	}

	config := cache.Config{
		Type: "sqlite3",
		DSN:  db,
	}

	data, err := yaml.Marshal(&config)
	if err != nil {
		return "", err
	}

	configFile := "config.yaml"
	err = os.WriteFile(configFile, data, os.ModePerm)
	if err != nil {
		return "", err
	}

	return configFile, err
}

func getClusterPediaServer(ctx context.Context, client *fakepediaclient.Clientset) (*httptest.Server, storage.StorageFactory, error) {
	file, err := getStorageConfigFile()
	if err != nil {
		return nil, nil, err
	}

	defer func() {
		_ = os.Remove(file)
	}()

	factory, err := cache.NewStorageFactory(file)
	if err != nil {
		return nil, nil, err
	}

	server, err := newFakeApiserver(ctx, factory, informers.NewSharedInformerFactory(client, 0))
	if err != nil {
		return nil, nil, err
	}
	return server, factory, err
}

var (
	// Scheme defines methods for serializing and deserializing API objects.
	Scheme = gclient.NewSchema()

	// Codecs provides methods for retrieving codecs and serializers for specific
	// versions and content types.
	Codecs = serializer.NewCodecFactory(Scheme)

	// ParameterCodec handles versioning of objects that are converted to query parameters.
	ParameterCodec = runtime.NewParameterCodec(Scheme)
)

func newFakeApiserver(ctx context.Context, storageFactory storage.StorageFactory, sharedInformers informers.SharedInformerFactory) (*httptest.Server, error) {
	genericConfig := genericapiserver.NewRecommendedConfig(Codecs)
	genericConfig.SecureServing = &genericapiserver.SecureServingInfo{Listener: fakeLocalhost443Listener{}}
	genericConfig.Authorization.Authorizer = authorizerfactory.NewAlwaysAllowAuthorizer()
	genericConfig.LoopbackClientConfig = &rest.Config{
		ContentConfig: rest.ContentConfig{NegotiatedSerializer: Codecs},
	}
	genericConfig.Version = &version.Info{
		Major: "1",
		Minor: "0",
	}
	completedConfig := genericConfig.Complete()
	resourceServerConfig := kubeapiserver.NewDefaultConfig()
	resourceServerConfig.GenericConfig.ExternalAddress = completedConfig.ExternalAddress
	resourceServerConfig.GenericConfig.LoopbackClientConfig = completedConfig.LoopbackClientConfig
	resourceServerConfig.ExtraConfig = kubeapiserver.ExtraConfig{
		StorageFactory:  storageFactory,
		InformerFactory: sharedInformers,
	}
	kubeResourceAPIServer, err := resourceServerConfig.Complete().New(genericapiserver.NewEmptyDelegate())
	if err != nil {
		return nil, err
	}

	handlerChainFunc := genericConfig.BuildHandlerChainFunc
	genericConfig.BuildHandlerChainFunc = func(apiHandler http.Handler, c *genericapiserver.Config) http.Handler {
		handler := handlerChainFunc(apiHandler, c)
		handler = filters.WithRequestQuery(handler)
		return handler
	}

	genericServer, err := completedConfig.New("clusterpedia", hooksDelegate{kubeResourceAPIServer})
	if err != nil {
		return nil, err
	}

	v1beta1storage := map[string]registryrest.Storage{}
	v1beta1storage["resources"] = resources.NewREST(kubeResourceAPIServer.Handler)

	apiGroupInfo := genericapiserver.NewDefaultAPIGroupInfo(internal.GroupName, Scheme, ParameterCodec, Codecs)
	apiGroupInfo.VersionedResourcesStorageMap["v1beta1"] = v1beta1storage
	if err := genericServer.InstallAPIGroup(&apiGroupInfo); err != nil {
		return nil, err
	}

	sharedInformers.Start(ctx.Done())
	sharedInformers.WaitForCacheSync(ctx.Done())

	return httptest.NewServer(genericServer.Handler), nil
}

type fakeLocalhost443Listener struct{}

func (fakeLocalhost443Listener) Accept() (net.Conn, error) {
	return nil, nil
}

func (fakeLocalhost443Listener) Close() error {
	return nil
}

func (fakeLocalhost443Listener) Addr() net.Addr {
	return &net.TCPAddr{
		IP:   net.IPv4(127, 0, 0, 1),
		Port: 443,
	}
}

type hooksDelegate struct {
	genericapiserver.DelegationTarget
}

func (s hooksDelegate) UnprotectedHandler() http.Handler {
	return nil
}

func (s hooksDelegate) HealthzChecks() []healthz.HealthChecker {
	return []healthz.HealthChecker{}
}

func (s hooksDelegate) ListedPaths() []string {
	return []string{}
}

func (s hooksDelegate) NextDelegate() genericapiserver.DelegationTarget {
	return nil
}

type fakeResources struct {
	Namespaced bool
	gvr        schema.GroupVersionResource
}

type FakeClientFactory struct {
	server    *httptest.Server
	cfg       *rest.Config
	factory   storage.StorageFactory
	resources map[string]*fakeResources
}

var (
	onceDo                   sync.Once
	defaultFakeClientFactory *FakeClientFactory
)

func GetDefaultFakeClientFactory() (*FakeClientFactory, error) {
	if defaultFakeClientFactory != nil {
		return defaultFakeClientFactory, nil
	}
	var err error
	onceDo.Do(func() {
		defaultFakeClientFactory, err = NewFakeClientFactory()
		if err != nil {
			return
		}
		err = defaultFakeClientFactory.CreatePediaCluster(context.TODO(), DefaultGlobalClient, constants.GlobalCluster)
		if err != nil {
			return
		}

		err = defaultFakeClientFactory.CreatePediaCluster(context.TODO(), DefaultGlobalClient, "member1")
		if err != nil {
			return
		}

		err = defaultFakeClientFactory.CreatePediaCluster(context.TODO(), DefaultGlobalClient, "member2")
		if err != nil {
			return
		}
	})
	return defaultFakeClientFactory, err
}

func NewFakeClientFactory() (*FakeClientFactory, error) {
	server, factory, err := getClusterPediaServer(context.TODO(), DefaultGlobalClient)
	if err != nil {
		return nil, err
	}
	return &FakeClientFactory{
		server: server, cfg: &rest.Config{Host: server.URL, Timeout: time.Minute},
		factory: factory, resources: map[string]*fakeResources{},
	}, nil
}

func (f *FakeClientFactory) Create(ctx context.Context, clusterName string, obj runtime.Object) error {
	cf := storageconfig.NewStorageConfigFactory()
	gvk := schema.GroupVersionKind{
		Group:   obj.GetObjectKind().GroupVersionKind().Group,
		Kind:    obj.GetObjectKind().GroupVersionKind().Kind,
		Version: obj.GetObjectKind().GroupVersionKind().Version,
	}
	fr, ok := f.resources[gvk.String()]
	if !ok {
		return fmt.Errorf("gvk: %s not support,please add this resource in apiGroupResources", gvk.String())
	}

	rc, err := cf.NewConfig(fr.gvr, fr.Namespaced)
	if err != nil {
		return err
	}

	if !scheme.LegacyResourceScheme.IsGroupRegistered(gvk.Group) {
		rc.Codec = Codecs.LegacyCodec(gvk.GroupVersion())
	}

	resourceStorage, err := f.factory.NewResourceStorage(rc)
	if err != nil {
		return err
	}
	return resourceStorage.Create(ctx, clusterName, obj)
}

func (f *FakeClientFactory) Get() (kubernetes.Interface, error) {
	return pediaclient.NewForConfig(f.cfg)
}

func (f *FakeClientFactory) GetSubClient(clusterName string) (kubernetes.Interface, error) {
	return pediaclient.NewClusterForConfig(f.cfg, clusterName)
}

func (f *FakeClientFactory) Dynamic() (dynamic.Interface, error) {
	return pediadynamic.NewForConfig(f.cfg)
}

func (f *FakeClientFactory) Generated() (clusterclientset.Interface, error) {
	return clusterclientset.NewForConfig(f.cfg)
}

func (f *FakeClientFactory) GetSubGenerated(clusterName string) (clusterclientset.Interface, error) {
	pediaConfig, err := pediaclient.ClusterConfigFor(f.cfg, clusterName)
	if err != nil {
		return nil, err
	}
	return clusterclientset.NewForConfig(pediaConfig)
}

func (f *FakeClientFactory) GetCustomClient() (customclient.Interface, error) {
	return customclient.NewForConfig(f.cfg)
}

func (f *FakeClientFactory) GetSubDynamic(clusterName string) (dynamic.Interface, error) {
	return pediadynamic.NewClusterForConfig(f.cfg, clusterName)
}

func (f *FakeClientFactory) GetClusterpediaClient() (pediav1beta1.ClusterPediaV1beta1, error) {
	return pediav1beta1.NewForConfig(f.cfg)
}

func (f *FakeClientFactory) GetSubVPAClient(cluster string) (vpaclient.Interface, error) {
	config, err := pediaclient.ClusterConfigFor(f.cfg, cluster)
	if err != nil {
		return nil, err
	}

	return vpaclient.NewForConfig(config)
}

func (f *FakeClientFactory) Close() {
	f.server.Close()
	_ = os.Remove("kpanda.db")
}

var DefaultGlobalClient = fakepediaclient.NewSimpleClientset()

func createCluster(ctx context.Context, client *fakepediaclient.Clientset, cluster *pediaclusterv1alpha2.PediaCluster) error {
	_, err := client.ClusterV1alpha2().PediaClusters().Create(ctx, cluster, metav1.CreateOptions{})
	if err != nil {
		return err
	}
	return nil
}

func (f *FakeClientFactory) CreatePediaCluster(ctx context.Context, client *fakepediaclient.Clientset, clusterName string, resources ...pediaclusterv1alpha2.ClusterGroupResourcesStatus) error {
	cluster := pediaclusterv1alpha2.PediaCluster{}
	if len(resources) == 0 {
		err := json.Unmarshal(util.StringToBytes(apiGroupResources), &cluster)
		if err != nil {
			return err
		}
	} else {
		cluster.Status = pediaclusterv1alpha2.ClusterStatus{
			SyncResources: []pediaclusterv1alpha2.ClusterGroupResourcesStatus{},
		}
		cluster.Status.SyncResources = append(cluster.Status.SyncResources, resources...)
	}

	cluster.Name = clusterName
	for _, syncResource := range cluster.Status.SyncResources {
		for _, resource := range syncResource.Resources {
			for _, r := range resource.SyncConditions {
				f.resources[schema.GroupVersionKind{
					Group:   syncResource.Group,
					Version: r.Version,
					Kind:    resource.Kind,
				}.String()] = &fakeResources{
					Namespaced: resource.Namespaced,
					gvr: schema.GroupVersionResource{
						Group:    syncResource.Group,
						Version:  r.Version,
						Resource: resource.Name,
					},
				}
			}
		}
	}

	err := createCluster(ctx, client, &cluster)

	// 等待 informer 获取到此 cluster 并加入到 cache 中
	time.Sleep(2 * time.Second)

	return err
}
