package clusterpedia

import (
	"reflect"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util/gclient"

	pediav1beta1 "github.com/clusterpedia-io/client-go/clusterpediaclient/v1beta1"
	"github.com/clusterpedia-io/client-go/customclient"
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"
	"k8s.io/client-go/dynamic"
	dynamicfake "k8s.io/client-go/dynamic/fake"
	clientset "k8s.io/client-go/kubernetes"
	rest "k8s.io/client-go/rest"
)

func Test_clients_GetSubClient(t *testing.T) {
	type fields struct {
		multiClient clientset.Interface
		subClients  map[string]clientset.Interface
	}
	type args struct {
		clusterID string
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   bool
	}{
		{
			name: "test cluster name already exists",
			fields: fields{
				multiClient: clientset.New(nil),
				subClients: map[string]clientset.Interface{
					"demo": clientset.New(nil),
				},
			},
			args: args{
				clusterID: "demo",
			},
			want: true,
		},
		{
			name: "test cluster name is not exist",
			fields: fields{
				multiClient: clientset.New(nil),
				subClients: map[string]clientset.Interface{
					"demo": clientset.New(nil),
				},
			},
			args: args{
				clusterID: "demo1",
			},
			want: false,
		},
		{
			name: "test cluster name is empty",
			fields: fields{
				multiClient: clientset.New(nil),
				subClients: map[string]clientset.Interface{
					"demo": clientset.New(nil),
				},
			},
			args: args{
				clusterID: "",
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clients{
				globalClient: tt.fields.multiClient,
				subClients:   tt.fields.subClients,
			}

			sc, err := c.GetSubClient(tt.args.clusterID)
			if reflect.DeepEqual(sc, tt.fields.subClients["demo"]) != tt.want {
				t.Errorf("clients.GetSubClient() clusterName = %v, err = %v, want %v", tt.args.clusterID, err, tt.want)
				return
			}
		})
	}
}

func Test_clients_Get(t *testing.T) {
	type fields struct {
		globalClient clientset.Interface
	}
	tests := []struct {
		name   string
		fields fields
		want   clientset.Interface
	}{
		{
			name: "test global client is not empty",
			fields: fields{
				globalClient: clientset.New(nil),
			},
			want: clientset.New(nil),
		},
		{
			name: "test global client is empty",
			fields: fields{
				globalClient: nil,
			},
			want: nil,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clients{
				globalClient: tt.fields.globalClient,
			}
			cli, err := c.Get()
			if !reflect.DeepEqual(cli, tt.want) {
				t.Errorf("clients.Get() error = %v", err)
				return
			}
		})
	}
}

func Test_clients_Dynamic(t *testing.T) {
	type fields struct {
		dynamic dynamic.Interface
	}
	dyn, _ := dynamic.NewForConfig(&rest.Config{})
	tests := []struct {
		name   string
		fields fields
		want   dynamic.Interface
	}{
		{
			name: "test dynamic is not empty",
			fields: fields{
				dynamic: dyn,
			},
			want: dyn,
		},
		{
			name: "test dynamic is empty",
			fields: fields{
				dynamic: nil,
			},
			want: nil,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clients{
				dynamic: tt.fields.dynamic,
			}
			dynamic, err := c.Dynamic()
			if !reflect.DeepEqual(dynamic, tt.want) {
				t.Errorf("clients.Dynamic() error = %v", err)
				return
			}
		})
	}
}

func Test_clients_Generated(t *testing.T) {
	type fields struct {
		clusterclientset clusterclientset.Interface
	}
	tests := []struct {
		name   string
		fields fields
		want   clusterclientset.Interface
	}{
		{
			name: "test generated is not empty",
			fields: fields{
				clusterclientset: clusterclientset.New(nil),
			},
			want: clusterclientset.New(nil),
		},
		{
			name: "test generated is empty",
			fields: fields{
				clusterclientset: nil,
			},
			want: nil,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clients{
				clusterclientset: tt.fields.clusterclientset,
			}
			gen, err := c.Generated()
			if !reflect.DeepEqual(gen, tt.want) {
				t.Errorf("clients.Generated() error = %v", err)
				return
			}
		})
	}
}

func Test_NewClients(t *testing.T) {
	t.Run("test NewClients", func(t *testing.T) {
		clients := NewClients()
		if clients == nil {
			t.Error("NewClients() return nil")
			return
		}
	})
}

func Test_initGlobalClient(t *testing.T) {
	t.Run("test initGlobalClient", func(t *testing.T) {
		_, err := initGlobalClient()
		if err != nil {
			t.Errorf("initGlobalClient() err = %v", err)
			return
		}
	})
}

func Test_initSubClient(t *testing.T) {
	type args struct {
		clusterName string
	}
	tests := []struct {
		name    string
		args    args
		wantErr bool
	}{
		{
			name: "test cluster name is not empty",
			args: args{
				clusterName: "test_cluster_01",
			},
			wantErr: false,
		},
		{
			name: "test cluster name is empty",
			args: args{
				clusterName: "",
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := initSubClient(tt.args.clusterName)
			if (err != nil) != tt.wantErr {
				t.Errorf("initSubClient() err = %v", err)
				return
			}
		})
	}
}

func Test_initDynamic(t *testing.T) {
	t.Run("test initDynamic", func(t *testing.T) {
		_, err := initDynamic()
		if err != nil {
			t.Errorf("initDynamic() err = %v", err)
			return
		}
	})
}

func Test_initGenerated(t *testing.T) {
	t.Run("test initGenerated", func(t *testing.T) {
		_, err := initGenerated(constants.GlobalCluster)
		if err != nil {
			t.Errorf("initGenerated() err = %v", err)
			return
		}
	})
}

func Test_BuildConfig(t *testing.T) {
	t.Run("test buildConfig", func(t *testing.T) {
		_, err := BuildConfig()
		if err != nil {
			t.Errorf("buildConfig() err = %v", err)
			return
		}
	})
}

func Test_clients_GetSubDynamic(t *testing.T) {
	type fields struct {
		globalClient        clientset.Interface
		clusterclientset    clusterclientset.Interface
		dynamic             dynamic.Interface
		subClients          map[string]clientset.Interface
		subClusterClientSet map[string]clusterclientset.Interface
		customClient        customclient.Interface
		subDynamic          map[string]dynamic.Interface
		clusterpediaClient  pediav1beta1.ClusterPediaV1beta1
	}
	type args struct {
		clusterName string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			name: "subclient exists",
			fields: fields{
				subDynamic: map[string]dynamic.Interface{"abc": dynamicfake.NewSimpleDynamicClient(gclient.NewSchema())},
			},
			args: args{
				clusterName: "abc",
			},
			wantErr: false,
		},
		{
			name: "subclient not exists",
			fields: fields{
				subDynamic: map[string]dynamic.Interface{"abc": dynamicfake.NewSimpleDynamicClient(gclient.NewSchema())},
			},
			args: args{
				clusterName: "bcd",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clients{
				globalClient:        tt.fields.globalClient,
				clusterclientset:    tt.fields.clusterclientset,
				dynamic:             tt.fields.dynamic,
				subClients:          tt.fields.subClients,
				subClusterClientSet: tt.fields.subClusterClientSet,
				customClient:        tt.fields.customClient,
				subDynamic:          tt.fields.subDynamic,
				clusterpediaClient:  tt.fields.clusterpediaClient,
			}
			_, err := c.GetSubDynamic(tt.args.clusterName)
			if (err != nil) != tt.wantErr {
				t.Errorf("clients.GetSubDynamic() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func Test_clients_GetSubGenerated(t *testing.T) {
	type fields struct {
		globalClient        clientset.Interface
		clusterclientset    clusterclientset.Interface
		dynamic             dynamic.Interface
		subClients          map[string]clientset.Interface
		subClusterClientSet map[string]clusterclientset.Interface
		customClient        customclient.Interface
		subDynamic          map[string]dynamic.Interface
		clusterpediaClient  pediav1beta1.ClusterPediaV1beta1
	}
	type args struct {
		clusterName string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			name: "subclient exists",
			fields: fields{
				subClusterClientSet: map[string]clusterclientset.Interface{"abc": clusterclientset.New(nil)},
			},
			args: args{
				clusterName: "abc",
			},
			wantErr: false,
		},
		{
			name: "subclient not exists",
			fields: fields{
				subClusterClientSet: map[string]clusterclientset.Interface{"bcd": clusterclientset.New(nil)},
			},
			args: args{
				clusterName: "abc",
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clients{
				globalClient:        tt.fields.globalClient,
				clusterclientset:    tt.fields.clusterclientset,
				dynamic:             tt.fields.dynamic,
				subClients:          tt.fields.subClients,
				subClusterClientSet: tt.fields.subClusterClientSet,
				customClient:        tt.fields.customClient,
				subDynamic:          tt.fields.subDynamic,
				clusterpediaClient:  tt.fields.clusterpediaClient,
			}
			_, err := c.GetSubGenerated(tt.args.clusterName)
			if (err != nil) != tt.wantErr {
				t.Errorf("clients.GetSubGenerated() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func Test_clients_GetCustomClient(t *testing.T) {
	type fields struct {
		globalClient        clientset.Interface
		clusterclientset    clusterclientset.Interface
		dynamic             dynamic.Interface
		subClients          map[string]clientset.Interface
		subClusterClientSet map[string]clusterclientset.Interface
		customClient        customclient.Interface
		subDynamic          map[string]dynamic.Interface
		clusterpediaClient  pediav1beta1.ClusterPediaV1beta1
	}
	tests := []struct {
		name    string
		fields  fields
		want    customclient.Interface
		wantErr bool
	}{
		{
			name:    "CustomClient is nil",
			fields:  fields{},
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &clients{
				globalClient:        tt.fields.globalClient,
				clusterclientset:    tt.fields.clusterclientset,
				dynamic:             tt.fields.dynamic,
				subClients:          tt.fields.subClients,
				subClusterClientSet: tt.fields.subClusterClientSet,
				customClient:        tt.fields.customClient,
				subDynamic:          tt.fields.subDynamic,
				clusterpediaClient:  tt.fields.clusterpediaClient,
			}
			got, err := c.GetCustomClient()
			if (err != nil) != tt.wantErr {
				t.Errorf("clients.GetCustomClient() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("clients.GetCustomClient() = %v, want %v", got, tt.want)
			}
		})
	}
}
