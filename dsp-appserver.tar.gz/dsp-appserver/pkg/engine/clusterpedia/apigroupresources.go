package clusterpedia

var apiGroupResources = `
{
    "apiVersion": "cluster.clusterpedia.io/v1alpha2",
    "kind": "PediaCluster",
    "metadata": {
        "name": "kpanda-global-cluster"
    },
    "spec": {
        "syncAllCustomResources": true,
        "syncResources": [],
        "syncResourcesRefName": "kpanda-sync-resources"
    },
    "status": {
        "syncResources": [
            {
                "group": "",
                "resources": [
                    {
                        "kind": "Pod",
                        "name": "pods",
                        "namespaced": true,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "Node",
                        "name": "nodes",
                        "namespaced": false,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "Namespace",
                        "name": "namespaces",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "ConfigMap",
                        "name": "configmaps",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "Service",
                        "name": "services",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "Event",
                        "name": "events",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "Secret",
                        "name": "secrets",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "PersistentVolumeClaim",
                        "name": "persistentvolumeclaims",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "PersistentVolume",
                        "name": "persistentvolumes",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "ResourceQuota",
                        "name": "resourcequotas",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "Endpoints",
                        "name": "endpoints",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "LimitRange",
                        "name": "limitranges",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "ServiceAccount",
                        "name": "serviceaccounts",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "apps",
                "resources": [
                    {
                        "kind": "Deployment",
                        "name": "deployments",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "StatefulSet",
                        "name": "statefulsets",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "ReplicaSet",
                        "name": "replicasets",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "DaemonSet",
                        "name": "daemonsets",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "ControllerRevision",
                        "name": "controllerrevisions",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "batch",
                "resources": [
                    {
                        "kind": "Job",
                        "name": "jobs",
                        "namespaced": true,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1alpha1",
                                "version": "v1alpha1"
                            }
                        ]
                    },
                    {
                        "kind": "CronJob",
                        "name": "cronjobs",
                        "namespaced": true,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1alpha1",
                                "version": "v1alpha1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "rbac.authorization.k8s.io",
                "resources": [
                    {
                        "kind": "ClusterRoleBinding",
                        "name": "clusterrolebindings",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "RoleBinding",
                        "name": "rolebindings",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "ClusterRole",
                        "name": "clusterroles",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "Role",
                        "name": "roles",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "networking.k8s.io",
                "resources": [
                    {
                        "kind": "Ingress",
                        "name": "ingresses",
                        "namespaced": true,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "IngressClass",
                        "name": "ingressclasses",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    },
                    {
                        "kind": "NetworkPolicy",
                        "name": "networkpolicies",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "apiextensions.k8s.io",
                "resources": [
                    {
                        "kind": "CustomResourceDefinition",
                        "name": "customresourcedefinitions",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "autoscaling",
                "resources": [
                    {
                        "kind": "HorizontalPodAutoscaler",
                        "name": "horizontalpodautoscalers",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v2"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "storage.k8s.io",
                "resources": [
                    {
                        "kind": "StorageClass",
                        "name": "storageclasses",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "apiregistration.k8s.io",
                "resources": [
                    {
                        "kind": "APIService",
                        "name": "apiservices",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "autoscaling.k8s.io",
                "resources": [
                    {
                        "kind": "VerticalPodAutoscalerCheckpoint",
                        "name": "verticalpodautoscalercheckpoints",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            },
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1beta2",
                                "version": "v1beta2"
                            }
                        ]
                    },
                    {
                        "kind": "VerticalPodAutoscaler",
                        "name": "verticalpodautoscalers",
                        "namespaced": true,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1",
                                "version": "v1"
                            },
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1beta2",
                                "version": "v1beta2"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "cloudshell.cloudtty.io",
                "resources": [
                    {
                        "kind": "CloudShell",
                        "name": "cloudshells",
                        "namespaced": true,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1alpha1",
                                "version": "v1alpha1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "cluster.clusterpedia.io",
                "resources": [
                    {
                        "kind": "ClusterSyncResources",
                        "name": "clustersyncresources",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1alpha2",
                                "version": "v1alpha2"
                            }
                        ]
                    },
                    {
                        "kind": "PediaCluster",
                        "name": "pediaclusters",
                        "namespaced": false,
                        "syncConditions": [
                            { 
                                "status": "Syncing",
                                "storageVersion": "v1alpha2",
                                "version": "v1alpha2"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "cluster.kpanda.io",
                "resources": [
                    {
                        "kind": "Cluster",
                        "name": "clusters",
                        "namespaced": false,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1alpha1",
                                "version": "v1alpha1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "helm.kpanda.io",
                "resources": [
                    {
                        "kind": "HelmOperation",
                        "name": "helmoperations",
                        "namespaced": true,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1alpha1",
                                "version": "v1alpha1"
                            }
                        ]
                    },
                    {
                        "kind": "HelmRelease",
                        "name": "helmreleases",
                        "namespaced": true,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1alpha1",
                                "version": "v1alpha1"
                            }
                        ]
                    },
                    {
                        "kind": "HelmRepo",
                        "name": "helmrepos",
                        "namespaced": false,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1alpha1",
                                "version": "v1alpha1"
                            }
                        ]
                    }
                ]
            },
            {
                "group": "metallb.io",
                "resources": [
                    {
                        "kind": "IPAddressPool",
                        "name": "ipaddresspools",
                        "namespaced": true,
                        "syncConditions": [
                            {
                                "status": "Syncing",
                                "storageVersion": "v1beta1",
                                "version": "v1beta1"
                            }
                        ]
                    }
                ]
            }
        ]
    }
}
`
