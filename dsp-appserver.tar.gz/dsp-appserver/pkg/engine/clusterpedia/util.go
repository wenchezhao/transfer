package clusterpedia

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"

	pediaclient "github.com/clusterpedia-io/client-go/client"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/klog/v2"

	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/version"
)

const (
	DefaultClusterPediaServiceName = "kpanda-clusterpedia-apiserver"
	ClusterperiaHostKey            = "CLUSTERPERIA_HOST_IP"
)

func getClusterPediaServerHost() string {
	return util.GetEnvWithDefault(ClusterperiaHostKey, DefaultClusterPediaServiceName)
}

func getClusterPeidaService() (*rest.Config, error) {
	clusterPediaHost := getClusterPediaServerHost()
	klog.InfoS("clusterpedia host server", "clusterpedia host", clusterPediaHost)
	host := fmt.Sprintf("https://%s", clusterPediaHost)

	return &rest.Config{
		Host:            host,
		BearerTokenFile: "/var/run/secrets/kubernetes.io/serviceaccount/token",
		TLSClientConfig: rest.TLSClientConfig{
			Insecure: true,
		},
	}, nil
}

func BuildConfig() (*rest.Config, error) {
	config, err := getClusterPeidaService()

	defer func() {
		if err == nil && config != nil {
			config.UserAgent = buildUserAgent(adjustCommand(os.Args[0]), version.Get().GitVersion, runtime.GOOS, runtime.GOARCH, version.Get().GitCommit)
		}
	}()

	if err == nil {
		_, err := pediaclient.NewForConfig(config)
		if err == nil {
			return config, nil
		}
	}

	// get default kubeConfig path
	config, err = rest.InClusterConfig()
	if err != nil {
		// to test outside the cluster, need to specify kubeconfig path
		config, err = clientcmd.BuildConfigFromFlags("", kubeclient.NewKubernetesOptions().KubeConfig)
		if err != nil {
			return nil, err
		}
	}

	return config, nil
}

// buildUserAgent builds a User-Agent string from given args.
func buildUserAgent(command, version, os, arch, commit string) string {
	return fmt.Sprintf(
		"%s/%s (%s/%s) kpanda/%s", command, version, os, arch, commit)
}

// adjustCommand returns the last component of the
// OS-specific command path for use in User-Agent.
func adjustCommand(p string) string {
	// Unlikely, but better than returning "".
	if len(p) == 0 {
		return "unknown"
	}
	return filepath.Base(p)
}
