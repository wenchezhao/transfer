package clusterpedia

import (
	"testing"

	"k8s.io/client-go/rest"
)

func TestBuildConfig(t *testing.T) {
	tests := []struct {
		name    string
		want    *rest.Config
		wantErr bool
	}{
		{
			name:    "test",
			want:    &rest.Config{},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := BuildConfig()
			if err != nil {
				t.Errorf("BuildConfig() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}

func Test_getClusterPediaServerHost(t *testing.T) {
	tests := []struct {
		name string
		want string
	}{
		{
			name: "test1",
			want: "kpanda-clusterpedia-apiserver",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := getClusterPediaServerHost(); got != tt.want {
				t.Errorf("getClusterPediaServerHost() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_getClusterPeidaService(t *testing.T) {
	tests := []struct {
		name    string
		want    *rest.Config
		wantErr bool
	}{
		{
			name:    "test2",
			want:    nil,
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			_, err := getClusterPeidaService()
			if err != nil {
				t.Errorf("getClusterPeidaService() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
