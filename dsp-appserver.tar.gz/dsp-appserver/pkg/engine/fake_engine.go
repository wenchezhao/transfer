package engine

import (
	"context"
	"net/http/httptest"
	"reflect"

	pediaclient "github.com/clusterpedia-io/client-go/client"
	pediav1beta1 "github.com/clusterpedia-io/client-go/clusterpediaclient/v1beta1"
	"github.com/clusterpedia-io/client-go/customclient"
	"github.com/clusterpedia-io/fake-apiserver/storage/memory"
	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	helmv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/helm/v1alpha1"
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"
	clusterclientsetfake "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/fake"
	"github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/typed/cluster/v1alpha1"
	helmversionedv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/typed/helm/v1alpha1"
	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	generatedcluster "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions/cluster"
	clusterv1alpha1informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions/cluster/v1alpha1"
	"github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions/helm"
	"github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions/internalinterfaces"
	clusterv1alpha1listers "github.com/daocloud/dsp-appserver/api/crd/client/listers/cluster/v1alpha1"
	volumesnapshotv1 "github.com/kubernetes-csi/external-snapshotter/client/v4/clientset/versioned/typed/volumesnapshot/v1"
	appsv1 "k8s.io/api/apps/v1"
	autoscalingv1 "k8s.io/api/autoscaling/v1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	storagev1 "k8s.io/api/storage/v1"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/watch"
	vpaclient "k8s.io/autoscaler/vertical-pod-autoscaler/pkg/client/clientset/versioned"
	"k8s.io/client-go/discovery"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/dynamic/fake"
	"k8s.io/client-go/kubernetes"
	clientsetfake "k8s.io/client-go/kubernetes/fake"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/cache"
	"k8s.io/metrics/pkg/client/custom_metrics"
	"sigs.k8s.io/controller-runtime/pkg/client"
	clientfake "sigs.k8s.io/controller-runtime/pkg/client/fake"

	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
)

type FakeKpandaFactory struct {
	KpandaFactory *memory.FakeStorageFactory
}

func (f *FakeKpandaFactory) Start(_ <-chan struct{}) {
	panic("implement me")
}

func (f *FakeKpandaFactory) InformerFor(_ runtime.Object, _ internalinterfaces.NewInformerFunc) cache.SharedIndexInformer {
	panic("implement me")
}

func (f *FakeKpandaFactory) ForResource(_ schema.GroupVersionResource) (informers.GenericInformer, error) {
	panic("implement me")
}

func (f *FakeKpandaFactory) WaitForCacheSync(_ <-chan struct{}) map[reflect.Type]bool {
	panic("implement me")
}

func (f *FakeKpandaFactory) Cluster() generatedcluster.Interface {
	panic("implement me")
}

type FakeClientFactory struct {
	FakeClusterPeida *memory.FakeStorageFactory
	FakeServer       *httptest.Server
	FakePediaClient  kubernetes.Interface
	FakeSubClient    kubernetes.Interface
	FakeDynamic      dynamic.Interface
	FakeCustomClient customclient.Interface
}

func (f *FakeClientFactory) GetSubGenerated(_ string) (clusterclientset.Interface, error) {
	return clusterclientsetfake.NewSimpleClientset(&helmv1alpha1.HelmRelease{}), nil
}

func (f *FakeClientFactory) GetSubDynamic(_ string) (dynamic.Interface, error) {
	panic("implement me")
}

func (f *FakeClientFactory) GetClusterpediaClient() (pediav1beta1.ClusterPediaV1beta1, error) {
	return &pediav1beta1.ClusterPediaV1beta1Client{}, nil
}

func NewFakeClientFactory(f *memory.FakeStorageFactory, h *httptest.Server, inter kubernetes.Interface, d dynamic.Interface) *FakeClientFactory {
	return &FakeClientFactory{
		FakeClusterPeida: f,
		FakeServer:       h,
		FakePediaClient:  inter,
		FakeDynamic:      d,
	}
}

func (f *FakeClientFactory) Get() (kubernetes.Interface, error) {
	return f.FakePediaClient, nil
}

func (f *FakeClientFactory) GetSubClient(clusterName string) (kubernetes.Interface, error) {
	return pediaclient.NewClusterForConfig(&rest.Config{Host: f.FakeServer.URL}, clusterName)
}

func (f *FakeClientFactory) Dynamic() (dynamic.Interface, error) {
	return f.FakeDynamic, nil
}

func (f *FakeClientFactory) GetCustomClient() (customclient.Interface, error) {
	f.FakeCustomClient = newFakeResource()
	return f.FakeCustomClient, nil
}

func (f *FakeClientFactory) Generated() (clusterclientset.Interface, error) {
	return &FakeGeneratedClientSetInterface{}, nil
}

func (f *FakeClientFactory) GetSubVPAClient(_ string) (vpaclient.Interface, error) {
	panic("implement me")
}

func (f *FakeClusterClient) GetResultClient(_ string) (rest.Interface, error) {
	panic("implement me")
}

type FakeClusterClient struct {
	FakeClientServer *httptest.Server
	Transmission     bool
}

func (f *FakeClusterClient) GetGeneratedClient(_ string) (clusterclientset.Interface, error) {
	panic("implement me")
}

func (f *FakeClusterClient) AddCluster(_ interface{}) {
	panic("implement me")
}

func (f *FakeClusterClient) GetClientSet(string) (client.Client, error) {
	return clientfake.NewClientBuilder().Build(), nil
}

func (f *FakeClusterClient) GetClientSetWithUser(_ context.Context, _ string) (client.Client, error) {
	return clientfake.NewClientBuilder().Build(), nil
}

func (f *FakeClusterClient) GetCustomMetricsClient(string) (custom_metrics.CustomMetricsClient, error) {
	panic("implement me")
}

func (f *FakeClusterClient) GetSnapshotClient(_ string) (*volumesnapshotv1.SnapshotV1Client, error) {
	return nil, nil
}

func (f *FakeClusterClient) GetSnapshotClientWithUser(_ context.Context, _ string) (*volumesnapshotv1.SnapshotV1Client, error) {
	return nil, nil
}

func (f *FakeClusterClient) GetAllClusterClient() (map[string]kubernetes.Interface, error) {
	return nil, nil
}

func (f *FakeClusterClient) NewKubeConfigWithUser(_ context.Context, _ string) (*rest.Config, error) {
	panic("implement me")
}

func (f *FakeClusterClient) NewKubernetesClientWithUser(_ context.Context, cluster string) (kubeclient.Client, error) {
	kubeClient, _ := f.GetClient(cluster)
	dynamicClient, _ := f.GetDynamicClient(cluster)
	return kubeclient.NewFakeClientSets(kubeClient, dynamicClient, NewFakeVersionedInterface(), "", nil), nil
}

func (f *FakeClusterClient) NewVPAClientWithUser(_ context.Context, _ string) (vpaclient.Interface, error) {
	panic("implement me")
}

func (f *FakeClusterClient) GetVPAClient(_ string) (vpaclient.Interface, error) {
	panic("implement me")
}

var _ clusterclient.ClusterClients = &FakeClusterClient{}

func NewFakeClusterClient(h *httptest.Server, transmission bool) *FakeClusterClient {
	return &FakeClusterClient{
		FakeClientServer: h,
		Transmission:     transmission,
	}
}

func getTestPod() *corev1.Pod {
	return &corev1.Pod{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Pod",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "name1",
			Namespace: "namespaces1",
		},
	}
}

func getTestNode() *corev1.Node {
	return &corev1.Node{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Node",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: "name1",
		},
	}
}

func getTestPersistentVolumeClaims() *corev1.PersistentVolumeClaim {
	return &corev1.PersistentVolumeClaim{
		TypeMeta: metav1.TypeMeta{
			Kind:       "PersistentVolumeClaim",
			APIVersion: "core/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "name1",
			Namespace: "namespaces",
		},
		Spec: corev1.PersistentVolumeClaimSpec{
			Resources: corev1.ResourceRequirements{
				Requests: corev1.ResourceList{
					corev1.ResourceStorage: resource.Quantity{},
				},
			},
		},
	}
}

func getPersistentVolume() *corev1.PersistentVolume {
	return &corev1.PersistentVolume{
		TypeMeta: metav1.TypeMeta{
			Kind:       "PersistentVolume",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: "pv",
		},
		Spec: corev1.PersistentVolumeSpec{},
	}
}

func getTestStorageClass() *storagev1.StorageClass {
	return &storagev1.StorageClass{
		TypeMeta: metav1.TypeMeta{
			Kind:       "StorageClass",
			APIVersion: "storage.k8s.io/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: "name1",
		},
		Provisioner: "fask",
	}
}

func getTestDaemonSets() *appsv1.DaemonSet {
	Annontaiton := map[string]string{"key": "value"}
	return &appsv1.DaemonSet{
		TypeMeta: metav1.TypeMeta{
			Kind:       "DaemonSet",
			APIVersion: "apps/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:        "name1",
			Namespace:   "namespaces1",
			Annotations: Annontaiton,
		},
	}
}

func getTestDeployment() *appsv1.Deployment {
	Annontaiton := map[string]string{"deployment.kubernetes.io/revision": "1", "kubernetes.io/change-cause": "1"}
	return &appsv1.Deployment{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Deployment",
			APIVersion: "apps/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:        "name1",
			Namespace:   "namespaces1",
			Annotations: Annontaiton,
			UID:         "123456",
		},
	}
}

func getTestDeploymentStopped() *appsv1.Deployment {
	replicas := int32(1)
	return &appsv1.Deployment{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Deployment",
			APIVersion: "apps/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:        "stop",
			Namespace:   "namespace",
			Annotations: map[string]string{constants.WorkloadLastReplicasAnnoKey: "1"},
		},
		Spec: appsv1.DeploymentSpec{
			Replicas: &replicas,
		},
	}
}

func getTestDeploymentPaused() *appsv1.Deployment {
	Annontaiton := map[string]string{"deployment.kubernetes.io/revision": "1", "kubernetes.io/change-cause": "1"}
	return &appsv1.Deployment{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Deployment",
			APIVersion: "apps/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:        "namePaused",
			Namespace:   "namespaces1",
			Annotations: Annontaiton,
			UID:         "123456",
		},
		Spec: appsv1.DeploymentSpec{
			Paused: true,
		},
	}
}

func getReplicaSet() *appsv1.ReplicaSet {
	Annontaiton := map[string]string{"deployment.kubernetes.io/revision": "1", "kubernetes.io/change-cause": "1"}
	return &appsv1.ReplicaSet{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Deployment",
			APIVersion: "apps/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:        "name1",
			Namespace:   "namespaces1",
			Annotations: Annontaiton,
			OwnerReferences: []metav1.OwnerReference{
				{
					UID: "123456",
				},
			},
		},
	}
}

func getTestCronJob() *batchv1.CronJob {
	return &batchv1.CronJob{
		TypeMeta: metav1.TypeMeta{
			Kind:       "CronJob",
			APIVersion: "batch/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "name1",
			Namespace: "namespaces1",
		},
	}
}

func getTestJob() *batchv1.Job {
	return &batchv1.Job{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Job",
			APIVersion: "batch/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "name1",
			Namespace: "namespaces1",
		},
	}
}

func getTestStatefulsets() *appsv1.StatefulSet {
	Annontaiton := map[string]string{"key": "value"}
	return &appsv1.StatefulSet{
		TypeMeta: metav1.TypeMeta{
			Kind:       "StatefulSet",
			APIVersion: "apps/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:        "name1",
			Namespace:   "namespaces1",
			Annotations: Annontaiton,
		},
	}
}

func getTestConfigMap() *corev1.ConfigMap {
	return &corev1.ConfigMap{
		TypeMeta: metav1.TypeMeta{
			Kind:       "ConfigMap",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "configmap1",
			Namespace: "namespace",
		},
	}
}

func getTestService() *corev1.Service {
	return &corev1.Service{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Service",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "service2",
			Namespace: "namespace1",
		},
	}
}

func getTestSecret() *corev1.Secret {
	return &corev1.Secret{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Secret",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "secret1",
			Namespace: "namespace1",
		},
	}
}

func getTestNamespace() *corev1.Namespace {
	return &corev1.Namespace{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Namespace",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: "name1",
		},
	}
}

func getTestIngress() *networkingv1.Ingress {
	return &networkingv1.Ingress{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Ingress",
			APIVersion: "networking.k8s.io/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "name1",
			Namespace: "namespace1",
		},
	}
}

func getTestHorizontalPodAutoscaler() *autoscalingv1.HorizontalPodAutoscaler {
	return &autoscalingv1.HorizontalPodAutoscaler{
		TypeMeta: metav1.TypeMeta{
			Kind:       "HorizontalPodAutoscaler",
			APIVersion: "autoscaling/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "name1",
			Namespace: "namespace1",
		},
	}
}

func getRoleBinding() *rbacv1.RoleBinding {
	return &rbacv1.RoleBinding{
		TypeMeta: metav1.TypeMeta{
			Kind:       "RoleBinding",
			APIVersion: "rbac.authorization.k8s.io/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "binding",
			Namespace: "kube-system",
		},
		Subjects: []rbacv1.Subject{
			{
				Kind: "User",
				Name: "admin",
			},
		},
		RoleRef: rbacv1.RoleRef{
			APIGroup: "rbac.authorization.k8s.io",
			Kind:     "ClusterRole",
			Name:     "role-template-cluster-admin",
		},
	}
}

func getClusterRoleBinding() *rbacv1.ClusterRoleBinding {
	return &rbacv1.ClusterRoleBinding{
		TypeMeta: metav1.TypeMeta{
			Kind:       "ClusterRoleBinding",
			APIVersion: "rbac.authorization.k8s.io/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: "binding",
		},
		Subjects: []rbacv1.Subject{
			{
				Kind: "User",
				Name: "admin",
			},
		},
		RoleRef: rbacv1.RoleRef{
			APIGroup: "rbac.authorization.k8s.io",
			Kind:     "ClusterRole",
			Name:     "role-template-cluster-admin",
		},
	}
}

func getResourceQuota() *corev1.ResourceQuota {
	return &corev1.ResourceQuota{
		TypeMeta: metav1.TypeMeta{
			Kind:       "ResourceQuota",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "quota",
			Namespace: "namespace",
		},
	}
}

func getLimitRange() *corev1.LimitRange {
	return &corev1.LimitRange{
		TypeMeta: metav1.TypeMeta{
			Kind:       "LimitRange",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "limits",
			Namespace: "namespace",
		},
	}
}

func getNetworkPolicy() *networkingv1.NetworkPolicy {
	return &networkingv1.NetworkPolicy{
		TypeMeta: metav1.TypeMeta{
			Kind:       "NetworkPolicy",
			APIVersion: "networking.k8s.io/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "netpol",
			Namespace: "namespace",
		},
	}
}

func (f *FakeClusterClient) IsHostCluster(_ *clusterv1alpha1.Cluster) bool {
	panic("implement me")
}

func (f *FakeClusterClient) IsClusterReady(_ *clusterv1alpha1.Cluster) bool {
	panic("implement me")
}

func (f *FakeClusterClient) GetClusterKubeConfig(_ string) (*rest.Config, error) {
	return &rest.Config{Host: f.FakeClientServer.URL}, nil
}

func (f *FakeClusterClient) Get(_ string) (*clusterv1alpha1.Cluster, error) {
	return &clusterv1alpha1.Cluster{}, nil
}

func (f *FakeClusterClient) GetInnerCluster(_ string) *clusterclient.InnerCluster {
	panic("implement me")
}

func (f *FakeClusterClient) GetClient(s string) (kubernetes.Interface, error) {
	deployemnts := getTestDeployment()
	deployemntsStopped := getTestDeploymentStopped()
	deployemntsPaused := getTestDeploymentPaused()
	daemonSets := getTestDaemonSets()
	pods := getTestPod()
	jobs := getTestJob()
	cronJobs := getTestCronJob()
	statefulsets := getTestStatefulsets()
	configmap := getTestConfigMap()
	namespace := getTestNamespace()
	service := getTestService()
	secret := getTestSecret()
	ingress := getTestIngress()
	pvc := getTestPersistentVolumeClaims()
	pv := getPersistentVolume()
	storageClass := getTestStorageClass()
	replicaSet := getReplicaSet()
	nodes := getTestNode()
	hpa := getTestHorizontalPodAutoscaler()
	roleBinding := getRoleBinding()
	clusterRoleBinding := getClusterRoleBinding()
	resourceQuota := getResourceQuota()
	limitRange := getLimitRange()
	networkPolicy := getNetworkPolicy()
	c := clientsetfake.NewSimpleClientset(deployemnts, deployemntsStopped, deployemntsPaused, daemonSets, pods, jobs, cronJobs, statefulsets, configmap, namespace, service, secret, ingress, pv, pvc, storageClass, replicaSet, nodes, hpa, roleBinding, clusterRoleBinding, resourceQuota, limitRange, networkPolicy)
	if f.Transmission {
		return c, nil
	}
	sub, err := pediaclient.NewClusterForConfig(&rest.Config{Host: f.FakeClientServer.URL}, s)
	return sub, err
}

func (f *FakeClusterClient) GetDynamicClient(_ string) (dynamic.Interface, error) {
	scheme := runtime.NewScheme()
	customResourceDefinitionGVR := constants.CustomResourceDefinitionGVR
	customResourceDefinitionGVK := customResourceDefinitionGVR.GroupVersion().WithKind("CustomreSourceDefinition")
	customResourceDefinition := unstructured.Unstructured{}
	customResourceDefinition.SetGroupVersionKind(customResourceDefinitionGVK)
	customResourceDefinition.SetName("name")
	client := fake.NewSimpleDynamicClient(scheme, &customResourceDefinition)

	return client, nil
}

func (f *FakeClusterClient) GetClusterByKubeSystemID(_ string) string {
	return "kpanda-cluster"
}

type FakeClusterEngine struct {
	ClusterEngine // implements (pseudo) inheritance
}

type FakeKubeClient struct {
	kubeclient.FakeClient
}

var _ clusterclientset.Interface = new(FakeGeneratedClientSetInterface)

type FakeGeneratedClientSetInterface struct {
	processClusterInterface func(clusterInterface *FakeClusterInterface)
}

func (f *FakeGeneratedClientSetInterface) Discovery() discovery.DiscoveryInterface {
	panic("not implemented")
}

func (f *FakeGeneratedClientSetInterface) ClusterV1alpha1() v1alpha1.ClusterV1alpha1Interface {
	return &FakeClusterV1alpha1Client{}
}

func (f *FakeGeneratedClientSetInterface) HelmV1alpha1() helmversionedv1alpha1.HelmV1alpha1Interface {
	panic("implement me")
}

type FakeClusterV1alpha1Client struct {
	placeholder string
}

func (f *FakeClusterV1alpha1Client) RESTClient() rest.Interface {
	panic(f.placeholder)
}

func (f *FakeClusterV1alpha1Client) Clusters() v1alpha1.ClusterInterface {
	clusterInterface := FakeClusterInterface{}
	return &clusterInterface
}

type FakeClusterInterface struct {
	_Create func(ctx context.Context, cluster *clusterv1alpha1.Cluster, opts metav1.CreateOptions) (*clusterv1alpha1.Cluster, error)
	_Update func(ctx context.Context, cluster *clusterv1alpha1.Cluster, opts metav1.UpdateOptions) (*clusterv1alpha1.Cluster, error)
	_Get    func(ctx context.Context, name string, opts metav1.GetOptions) (*clusterv1alpha1.Cluster, error)
	_List   func(ctx context.Context, opts metav1.ListOptions) (*clusterv1alpha1.ClusterList, error)
	_Watch  func(ctx context.Context, opts metav1.ListOptions) (watch.Interface, error)
	_Patch  func(ctx context.Context, name string, pt types.PatchType, data []byte, opts metav1.PatchOptions, subresources ...string) (result *clusterv1alpha1.Cluster, err error)
}

func (f *FakeClusterInterface) Create(_ context.Context, cluster *clusterv1alpha1.Cluster, _ metav1.CreateOptions) (*clusterv1alpha1.Cluster, error) {
	return cluster, nil
}

func (f *FakeClusterInterface) Update(_ context.Context, cluster *clusterv1alpha1.Cluster, _ metav1.UpdateOptions) (*clusterv1alpha1.Cluster, error) {
	return cluster, nil
}

func (f *FakeClusterInterface) UpdateStatus(_ context.Context, cluster *clusterv1alpha1.Cluster, _ metav1.UpdateOptions) (*clusterv1alpha1.Cluster, error) {
	return cluster, nil
}

func (f *FakeClusterInterface) Delete(_ context.Context, _ string, _ metav1.DeleteOptions) error {
	return nil
}

func (f *FakeClusterInterface) DeleteCollection(_ context.Context, _ metav1.DeleteOptions, _ metav1.ListOptions) error {
	return nil
}

func (f *FakeClusterInterface) Get(_ context.Context, name string, _ metav1.GetOptions) (*clusterv1alpha1.Cluster, error) {
	if name == "false" {
		return nil, apierrors.NewNotFound(clusterv1alpha1.Resource("clusters"), "false")
	}
	return &clusterv1alpha1.Cluster{
		ObjectMeta: metav1.ObjectMeta{Name: name, Labels: map[string]string{constants.ManagedByLabelKey: constants.GlobalCluster}},
		Status:     clusterv1alpha1.ClusterStatus{KubeSystemID: name},
	}, nil
}

func (f *FakeClusterInterface) List(ctx context.Context, opts metav1.ListOptions) (*clusterv1alpha1.ClusterList, error) {
	return f._List(ctx, opts)
}

func (f *FakeClusterInterface) Watch(ctx context.Context, opts metav1.ListOptions) (watch.Interface, error) {
	return f._Watch(ctx, opts)
}

func (f *FakeClusterInterface) Patch(ctx context.Context, name string, pt types.PatchType, data []byte, opts metav1.PatchOptions, _ ...string) (result *clusterv1alpha1.Cluster, err error) {
	return f._Patch(ctx, name, pt, data, opts)
}

var _ informers.SharedInformerFactory = new(FakeSharedInformerFactory)

type FakeSharedInformerFactory struct {
	processClusterLister func(*FakeClusterLister)
}

func (f FakeSharedInformerFactory) Helm() helm.Interface {
	panic("implement me")
}

func (f FakeSharedInformerFactory) Start(_ <-chan struct{}) {
	panic("not implemented")
}

func (f FakeSharedInformerFactory) InformerFor(_ runtime.Object, _ internalinterfaces.NewInformerFunc) cache.SharedIndexInformer {
	panic("not implemented")
}

func (f FakeSharedInformerFactory) ForResource(_ schema.GroupVersionResource) (informers.GenericInformer, error) {
	panic("not implemented")
}

func (f FakeSharedInformerFactory) WaitForCacheSync(_ <-chan struct{}) map[reflect.Type]bool {
	panic("not implemented")
}

func (f FakeSharedInformerFactory) Cluster() generatedcluster.Interface {
	return FakeInformerClusterInterface(f)
}

type FakeInformerClusterInterface struct {
	processClusterLister func(*FakeClusterLister)
}

func (f FakeInformerClusterInterface) V1alpha1() clusterv1alpha1informers.Interface {
	return FakeInformerv1alpha1Interface(f)
}

type FakeInformerv1alpha1Interface struct {
	processClusterLister func(*FakeClusterLister)
}

func (f FakeInformerv1alpha1Interface) Clusters() clusterv1alpha1informers.ClusterInformer {
	return FakeClusterInformer(f)
}

type FakeClusterInformer struct {
	processClusterLister func(*FakeClusterLister)
}

func (f FakeClusterInformer) Informer() cache.SharedIndexInformer {
	panic("not implemented")
}

func (f FakeClusterInformer) Lister() clusterv1alpha1listers.ClusterLister {
	lister := FakeClusterLister{}
	f.processClusterLister(&lister)
	return lister
}

type FakeClusterLister struct {
	_List func(selector labels.Selector) (ret []*clusterv1alpha1.Cluster, err error)
	_Get  func(name string) (*clusterv1alpha1.Cluster, error)
}

func (f FakeClusterLister) List(selector labels.Selector) (ret []*clusterv1alpha1.Cluster, err error) {
	return f._List(selector)
}

func (f FakeClusterLister) Get(name string) (*clusterv1alpha1.Cluster, error) {
	return f._Get(name)
}

func NewFakeWorkloadEngine(clusterClient clusterclient.ClusterClients) *WorkloadEngine {
	return &WorkloadEngine{clusterClient: clusterClient}
}
