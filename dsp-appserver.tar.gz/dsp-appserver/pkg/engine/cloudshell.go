/*
Copyright 2022 Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package engine

import (
	"context"
	"errors"
	"time"

	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"

	cloudshellv1alpha1 "github.com/cloudtty/cloudtty/pkg/apis/cloudshell/v1alpha1"
	cloudshellclient "github.com/cloudtty/cloudtty/pkg/generated/clientset/versioned"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/watch"
)

type Cloudshell interface {
	CreateCloudshell(ctx context.Context, couldshell *cloudshellv1alpha1.CloudShell) (*cloudshellv1alpha1.CloudShell, error)
	GetCloudshell(ctx context.Context, namespace, name string) (*cloudshellv1alpha1.CloudShell, error)
	GetCompletedCloudshell(ctx context.Context, namespace, name, startResourceVersion string, timeout time.Duration) (*cloudshellv1alpha1.CloudShell, error)
	UpdateCloudshell(ctx context.Context, couldshell *cloudshellv1alpha1.CloudShell) (*cloudshellv1alpha1.CloudShell, error)
	UpdateCloudshellStatus(ctx context.Context, couldshell *cloudshellv1alpha1.CloudShell) (*cloudshellv1alpha1.CloudShell, error)
	DeleteCloudshell(ctx context.Context, namespace, name string) error
	GetKpandaGProductProxy(ctx context.Context) (*unstructured.Unstructured, error)
	UpdateKpandaGProductProxy(ctx context.Context, obj *unstructured.Unstructured) (*unstructured.Unstructured, error)
}

var GProductProxyGVR = schema.GroupVersionResource{Group: "ghippo.io", Version: "v1alpha1", Resource: "gproductproxies"}

type cloudshellEngine struct {
	kubeclient kubeclient.Client
	client     cloudshellclient.Interface
}

func NewCloudshellEngine(client cloudshellclient.Interface, kubeclient kubeclient.Client) Cloudshell {
	return &cloudshellEngine{
		kubeclient: kubeclient,
		client:     client,
	}
}

func (c *cloudshellEngine) CreateCloudshell(ctx context.Context, couldshell *cloudshellv1alpha1.CloudShell) (*cloudshellv1alpha1.CloudShell, error) {
	return c.client.CloudshellV1alpha1().CloudShells(couldshell.Namespace).Create(ctx, couldshell, metav1.CreateOptions{})
}

func (c *cloudshellEngine) UpdateCloudshell(ctx context.Context, couldshell *cloudshellv1alpha1.CloudShell) (*cloudshellv1alpha1.CloudShell, error) {
	return c.client.CloudshellV1alpha1().CloudShells(couldshell.Namespace).Update(ctx, couldshell, metav1.UpdateOptions{})
}

func (c *cloudshellEngine) UpdateCloudshellStatus(ctx context.Context, couldshell *cloudshellv1alpha1.CloudShell) (*cloudshellv1alpha1.CloudShell, error) {
	return c.client.CloudshellV1alpha1().CloudShells(couldshell.Namespace).UpdateStatus(ctx, couldshell, metav1.UpdateOptions{})
}

func (c *cloudshellEngine) GetCloudshell(ctx context.Context, namespace, name string) (*cloudshellv1alpha1.CloudShell, error) {
	return c.client.CloudshellV1alpha1().CloudShells(namespace).Get(ctx, name, metav1.GetOptions{})
}

func (c *cloudshellEngine) DeleteCloudshell(ctx context.Context, namespace, name string) error {
	return c.client.CloudshellV1alpha1().CloudShells(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}

func (c *cloudshellEngine) GetCompletedCloudshell(ctx context.Context, namespace, name, startResourceVersion string, timeout time.Duration) (*cloudshellv1alpha1.CloudShell, error) {
	watchChan, err := c.client.CloudshellV1alpha1().CloudShells(namespace).Watch(ctx, metav1.ListOptions{ResourceVersion: startResourceVersion})
	if err != nil {
		return nil, err
	}
	for {
		select {
		case event := <-watchChan.ResultChan():
			if event.Type != watch.Modified {
				continue
			}
			cloudshell := event.Object.(*cloudshellv1alpha1.CloudShell)
			if cloudshell != nil && cloudshell.Status.Phase == "Ready" &&
				cloudshell.Name == name && cloudshell.Namespace == namespace {
				return cloudshell, nil
			}
		case <-time.After(timeout):
			return nil, errors.New("timed out waiting for watch cloudshell event")
		}
	}
}

func (c *cloudshellEngine) GetKpandaGProductProxy(ctx context.Context) (*unstructured.Unstructured, error) {
	return c.kubeclient.Dynamic().Resource(GProductProxyGVR).Get(ctx, "kpanda", metav1.GetOptions{})
}

func (c *cloudshellEngine) UpdateKpandaGProductProxy(ctx context.Context, obj *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return c.kubeclient.Dynamic().Resource(GProductProxyGVR).Update(ctx, obj, metav1.UpdateOptions{})
}
