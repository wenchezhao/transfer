package engine

import (
	"context"

	rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
)

type RBAC interface {
	CreateClusterRoleBinding(ctx context.Context, cluster string, clusterRolebinding *rbacv1.ClusterRoleBinding) (*rbacv1.ClusterRoleBinding, error)
	CreateClusterRole(ctx context.Context, cluster string, clusterRole *rbacv1.ClusterRole) (*rbacv1.ClusterRole, error)
	DeleteClusterRole(ctx context.Context, cluster, name string) error
	UpdateClusterRoleBinding(ctx context.Context, cluster string, clusterRoleBinding *rbacv1.ClusterRoleBinding) (*rbacv1.ClusterRoleBinding, error)
	DeleteClusterRoleBinding(ctx context.Context, cluster, name string) error
	GetClusterRole(ctx context.Context, cluster, name string) (*rbacv1.ClusterRole, error)
	GetClusterRoleBinding(ctx context.Context, cluster, name string) (*rbacv1.ClusterRoleBinding, error)
	CreateRole(ctx context.Context, cluster, namespace string, role *rbacv1.Role) (*rbacv1.Role, error)
	CreateRoleBinding(ctx context.Context, cluster, namespace string, roleBinding *rbacv1.RoleBinding) (*rbacv1.RoleBinding, error)
	DeleteRoleBinding(ctx context.Context, cluster, namespace, name string) error
}

type RBACEngine struct {
	clusterClient clusterclient.ClusterClients
}

var _ RBAC = new(RBACEngine)

func NewRBACEngine(clusterClient clusterclient.ClusterClients) RBAC {
	return &RBACEngine{clusterClient: clusterClient}
}

func (r *RBACEngine) CreateClusterRole(ctx context.Context, cluster string, clusterRole *rbacv1.ClusterRole) (*rbacv1.ClusterRole, error) {
	client, err := r.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().RbacV1().ClusterRoles().Create(ctx, clusterRole, metav1.CreateOptions{})
}

func (r *RBACEngine) DeleteClusterRole(ctx context.Context, cluster, name string) error {
	client, err := r.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().RbacV1().ClusterRoles().Delete(ctx, name, metav1.DeleteOptions{})
}

func (r *RBACEngine) GetClusterRole(ctx context.Context, cluster, name string) (*rbacv1.ClusterRole, error) {
	client, err := r.clusterClient.GetClient(cluster)
	if err != nil {
		return nil, err
	}
	return client.RbacV1().ClusterRoles().Get(ctx, name, metav1.GetOptions{})
}

func (r *RBACEngine) GetClusterRoleBinding(ctx context.Context, cluster, name string) (*rbacv1.ClusterRoleBinding, error) {
	client, err := r.clusterClient.GetClient(cluster)
	if err != nil {
		return nil, err
	}
	return client.RbacV1().ClusterRoleBindings().Get(ctx, name, metav1.GetOptions{})
}

func (r *RBACEngine) CreateClusterRoleBinding(ctx context.Context, cluster string, clusterRolebinding *rbacv1.ClusterRoleBinding) (*rbacv1.ClusterRoleBinding, error) {
	client, err := r.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().RbacV1().ClusterRoleBindings().Create(ctx, clusterRolebinding, metav1.CreateOptions{})
}

func (r *RBACEngine) DeleteClusterRoleBinding(ctx context.Context, cluster, name string) error {
	client, err := r.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().RbacV1().ClusterRoleBindings().Delete(ctx, name, metav1.DeleteOptions{})
}

func (r *RBACEngine) UpdateClusterRoleBinding(ctx context.Context, cluster string, clusterRoleBinding *rbacv1.ClusterRoleBinding) (*rbacv1.ClusterRoleBinding, error) {
	client, err := r.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().RbacV1().ClusterRoleBindings().Update(ctx, clusterRoleBinding, metav1.UpdateOptions{})
}

func (r *RBACEngine) CreateRole(ctx context.Context, cluster, namespace string, role *rbacv1.Role) (*rbacv1.Role, error) {
	client, err := r.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().RbacV1().Roles(namespace).Create(ctx, role, metav1.CreateOptions{})
}

func (r *RBACEngine) CreateRoleBinding(ctx context.Context, cluster, namespace string, roleBinding *rbacv1.RoleBinding) (*rbacv1.RoleBinding, error) {
	client, err := r.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return nil, err
	}

	return client.Kubernetes().RbacV1().RoleBindings(namespace).Create(ctx, roleBinding, metav1.CreateOptions{})
}

func (r *RBACEngine) DeleteRoleBinding(ctx context.Context, cluster, namespace, name string) error {
	client, err := r.clusterClient.NewKubernetesClientWithUser(ctx, cluster)
	if err != nil {
		return err
	}

	return client.Kubernetes().RbacV1().RoleBindings(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}
