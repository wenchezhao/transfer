package engine

import (
	"context"
	"reflect"
	"testing"

	"github.com/clusterpedia-io/client-go/customclient"
	helmv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/helm/v1alpha1"
	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	storagev1 "k8s.io/api/storage/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"

	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/buildoptions"
)

func newFakeCustomEngine(r *FakeResource) CustomClientEngine {
	return CustomClientEngine{Interface: CustomClientEngine{Interface: r}, BuildListOptionsInterface: buildoptions.GetBuildListOptions()}
}

func TestListDeploymet(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "deployments"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListDeployments(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestListStatefiSets(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "statefulsets"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListStatefulSets(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestListDaemonSets(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "daemonsets"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListDaemonSets(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestListJobs(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "batch", Version: "v1", Resource: "jobs"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListJobs(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestListCronJobs(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "batch", Version: "v1", Resource: "cronjobs"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListCronJobs(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestListPods(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "", Version: "v1", Resource: "pods"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListPods(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestListRoleBindings(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "rbac.authorization.k8s.io", Version: "v1", Resource: "rolebindings"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListRoleBindings(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestListClusterRoleBindings(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "rbac.authorization.k8s.io", Version: "v1", Resource: "clusterrolebindings"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListClusterRoleBindings(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestListNamespaces(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "", Version: "v1", Resource: "namespaces"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListNamespaces(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestListNodes(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "", Version: "v1", Resource: "namespaces"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListNodes(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestCustomClientEngine_ListClusters(t *testing.T) {
	r := newFakeResource()
	e := newFakeCustomEngine(r)
	depgvk := schema.GroupVersionResource{Group: "cluster.kpanda.io", Version: "v1alpha1", Resource: "clusters"}
	r.m[depgvk] = &Storage{}
	r.m[depgvk].initLz()
	list, err := e.ListClusters(context.TODO(), nil)
	if list == nil || err != nil {
		t.Errorf("the return value is not as expected")
	}
}

func TestCustomClientEngine_ListConfigMaps(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.ConfigMapList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List ConfigMaps",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &corev1.ConfigMapList{
				TypeMeta: metav1.TypeMeta{
					Kind:       "configmap",
					APIVersion: "v1",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []corev1.ConfigMap{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListConfigMaps(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListConfigMaps() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListConfigMaps() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListCustomResources(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		gvr     schema.GroupVersionResource
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *unstructured.UnstructuredList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List UnstructuredList",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &unstructured.UnstructuredList{
				Items: []unstructured.Unstructured{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListCustomResources(tt.args.ctx, tt.args.gvr, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListCustomResources() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListCustomResources() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListDaemonSets(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *appsv1.DaemonSetList
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface: tt.fields.Interface,
			}
			got, err := ce.ListDaemonSets(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListDaemonSets() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ListDaemonSets() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListHelmReleases(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *helmv1alpha1.HelmReleaseList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List ConfigMaps",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &helmv1alpha1.HelmReleaseList{
				TypeMeta: metav1.TypeMeta{
					Kind: "HelmRelease",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []helmv1alpha1.HelmRelease{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListHelmReleases(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListHelmReleases() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListHelmReleases() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListIngresses(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *networkingv1.IngressList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List Ingress",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &networkingv1.IngressList{
				TypeMeta: metav1.TypeMeta{
					Kind: "ingress",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []networkingv1.Ingress{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListIngresses(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListIngresses() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListIngresses() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListLimitRanges(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.LimitRangeList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List LimitRange",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &corev1.LimitRangeList{
				TypeMeta: metav1.TypeMeta{
					Kind: "limitRange",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []corev1.LimitRange{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListLimitRanges(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListLimitRanges() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListLimitRanges() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListNetworkPolicies(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *networkingv1.NetworkPolicyList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List Network",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &networkingv1.NetworkPolicyList{
				TypeMeta: metav1.TypeMeta{
					Kind: "network",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []networkingv1.NetworkPolicy{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListNetworkPolicies(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListNetworkPolicies() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListNetworkPolicies() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListPersistentVolumeClaims(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.PersistentVolumeClaimList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List Pvc",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &corev1.PersistentVolumeClaimList{
				TypeMeta: metav1.TypeMeta{
					Kind: "pvc",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []corev1.PersistentVolumeClaim{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListPersistentVolumeClaims(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListPersistentVolumeClaims() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListPersistentVolumeClaims() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListReplicaSet(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *appsv1.ReplicaSetList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List Replicaset",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &appsv1.ReplicaSetList{
				TypeMeta: metav1.TypeMeta{
					Kind: "replicaset",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []appsv1.ReplicaSet{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListReplicaSets(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListReplicaSet() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListReplicaSet() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListSecrets(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.SecretList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List Secrets",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &corev1.SecretList{
				TypeMeta: metav1.TypeMeta{
					Kind:       "secret",
					APIVersion: "v1",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []corev1.Secret{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListSecrets(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListSecrets() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListSecrets() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListServices(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.ServiceList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List Service",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &corev1.ServiceList{
				TypeMeta: metav1.TypeMeta{
					Kind: "service",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []corev1.Service{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListServices(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListServices() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListServices() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListStatefulSets(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *appsv1.StatefulSetList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List StatefulSet",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &appsv1.StatefulSetList{
				TypeMeta: metav1.TypeMeta{
					Kind: "statefulset",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []appsv1.StatefulSet{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListStatefulSets(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListStatefulSets() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListStatefulSets() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestCustomClientEngine_ListStorageClass(t *testing.T) {
	type fields struct {
		Interface customclient.Interface
		buildoptions.BuildListOptionsInterface
	}
	type args struct {
		ctx     context.Context
		options *util.ListOptions
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *storagev1.StorageClassList
		wantErr bool
	}{
		{
			name: "Test CustomClientEngine List Storge",
			fields: fields{
				Interface:                 newFakeCustomEngine(newFakeResource()),
				BuildListOptionsInterface: buildoptions.GetBuildListOptions(),
			},
			args: args{
				ctx: context.TODO(),
				options: &util.ListOptions{
					Scope: map[util.Cluster]util.Namespaces{},
				},
			},
			want: &storagev1.StorageClassList{
				TypeMeta: metav1.TypeMeta{
					Kind: "storge",
				},
				ListMeta: metav1.ListMeta{},
				Items:    []storagev1.StorageClass{},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ce := &CustomClientEngine{
				Interface:                 tt.fields.Interface,
				BuildListOptionsInterface: tt.fields.BuildListOptionsInterface,
			}
			got, err := ce.ListStorageClass(tt.args.ctx, tt.args.options)
			if (err != nil) != tt.wantErr {
				t.Errorf("ListStorageClass() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if (err == nil) && len(got.Items) != len(tt.want.Items) {
				t.Errorf("ListStorageClass() got = %v, want %v", got, tt.want)
			}
		})
	}
}

//
//func TestNewCustomEngine(t *testing.T) {
//	type args struct {
//		clientFactory clusterpedia.Clients
//	}
//	tests := []struct {
//		name    string
//		args    args
//		want    *CustomClientEngine
//		wantErr bool
//	}{
//		{
//			name: "Test New CustomEngine",
//			args: args{
//				clientFactory:
//			},
//			wantErr: false,
//			want:    nil,
//		},
//	}
//	for _, tt := range tests {
//		t.Run(tt.name, func(t *testing.T) {
//			got, err := NewCustomEngine(tt.args.clientFactory)
//			if (err != nil) != tt.wantErr {
//				t.Errorf("NewCustomEngine() error = %v, wantErr %v", err, tt.wantErr)
//				return
//			}
//			if !reflect.DeepEqual(got, tt.want) {
//				t.Errorf("NewCustomEngine() got = %v, want %v", got, tt.want)
//			}
//		})
//	}
//}
