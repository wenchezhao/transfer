package config

import (
	"encoding/hex"
	"os"
	"strings"

	"github.com/opentracing/opentracing-go"

	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/util/gmsm"
)

const (
	// SM4DefaultKey is used to decrypt sm4 secret data
	SM4DefaultKey = "3l5butlj26hvv313"
	DbDMType      = "DM"
	DbMysqlType   = "MYSQL"
)

type DBConfig struct {
	Type     string //数据库类型 MYSQL ｜ DM
	Host     string //数据库host
	Port     string //数据库端口
	User     string //数据库连接用户
	Password string //数据库连接密码
	Name     string //数据库名
}

// resources-counter-controller用于统计集群的资源数量信息
// 统计结果存储在被纳管集群的特定configmap下，所以需要controller在所有被纳管的集群上部署
// 并且统计的cm目标需要appserver知道，该结构用于配置读取的configmap源
type ResourcesCounter struct {
	Name      string //资源统计configmap名称
	Namespace string //资源统计configmap所在命名空间
}

type Config struct {
	Debug bool
	Port  string

	CertPath string
	KeyPath  string

	BasicAuthUser     string
	BasicAuthPassword string
	StorageURL        string
	StorageUser       string
	StoragePass       string

	DBConfig *DBConfig

	ResourcesC *ResourcesCounter

	/*
		根据环境变量配置jaeger，参考https://github.com/jaegertracing/jaeger-client-go#environment-variables

		以下配置二选一

		option1[推荐]：使用jaeger-agent，udp端口
		JAEGER_AGENT_HOST
		JAEGER_AGENT_PORT

		option2：直接发往jaeger-collector，http端点
		JAEGER_ENDPOINT
	*/
	Tracer opentracing.Tracer
}

func getEnvOrDefault(key string, def string) string {
	if val, ok := os.LookupEnv(key); ok {
		return val
	}
	return def
}
func decrypt(data string) (string, error) {
	if !strings.HasPrefix(data, "{SMS4}") {
		return data, nil
	}
	cipherBytes, err := hex.DecodeString(strings.TrimPrefix(data, "{SMS4}"))
	if err != nil {
		return "", err
	}
	plainBytes, err := gmsm.SM4Decrypt([]byte(SM4DefaultKey), cipherBytes)
	if err != nil {
		return "", err
	}
	return string(plainBytes), nil
}

func NewForEnv() (*Config, error) {
	dbPassword, err := decrypt(getEnvOrDefault("DB_PASSWORD", "dangerous"))
	if err != nil {
		return nil, err
	}

	return &Config{
		Debug:             logi.IsDebug(),
		Port:              getEnvOrDefault("PORT", "8989"),
		CertPath:          getEnvOrDefault("CERT_PATH", ""),
		KeyPath:           getEnvOrDefault("KEY_PATH", ""),
		BasicAuthUser:     getEnvOrDefault("BASIC_AUTH_USER", "admin"),
		BasicAuthPassword: getEnvOrDefault("BASIC_AUTH_PASSWORD", "admin"),
		ResourcesC: &ResourcesCounter{
			Name:      getEnvOrDefault("COUNTER_CM_NAME", "resources-counter"),
			Namespace: getEnvOrDefault("COUNTER_CM_NAMESPACE", "ccnp-system"),
		},
		DBConfig: &DBConfig{
			Type:     getEnvOrDefault("DB_TYPE", "MYSQL"),
			Host:     getEnvOrDefault("DB_HOST", "127.0.0.1"),
			Port:     getEnvOrDefault("DB_PORT", "3306"),
			User:     getEnvOrDefault("DB_USER", "root"),
			Password: dbPassword,
			Name:     getEnvOrDefault("DB_NAME", "edip"),
		},
	}, nil
}
