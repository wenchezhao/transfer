package websocket

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	"github.com/gin-gonic/gin"
	"gopkg.in/igm/sockjs-go.v2/sockjs"
	v1 "k8s.io/api/core/v1"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/tools/remotecommand"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
)

const (
	END_OF_TRANSMISSION = "\u0004"
	JWTSecret           = "admin"
)

// PtyHandler is what remotecommand expects from a pty
type PtyHandler interface {
	io.Reader
	io.Writer
	remotecommand.TerminalSizeQueue
	Done()
}

// TerminalSession implements PtyHandler (using a SockJS connection)
type TerminalSession struct {
	terminalReqCtx *terminalReqCtx
	sockJSSession  sockjs.Session
	sizeChan       chan remotecommand.TerminalSize
	doneChan       chan struct{}
}

// TerminalMessage is the messaging protocol between ShellController and TerminalSession.
//
// OP      DIRECTION  FIELD(S) USED  DESCRIPTION
// ---------------------------------------------------------------------
// bind    fe->be     SessionID      Id sent back from TerminalResponse
// stdin   fe->be     Data           Keystrokes/paste buffer
// resize  fe->be     Rows, Cols     New terminal size
// stdout  be->fe     Data           Output from the process
// toast   be->fe     Data           OOB message to be shown to the user
type TerminalMessage struct {
	Op, Data, SessionID string
	Rows, Cols          uint16
}

// TerminalSize handles pty->process resize events
// Called in a loop from remotecommand as long as the process is running
func (t TerminalSession) Next() *remotecommand.TerminalSize {
	select {
	case size := <-t.sizeChan:
		return &size
	case <-t.doneChan:
		return nil
	}
}

// Read handles pty->process messages (stdin, resize)
// Called in a loop from remotecommand as long as the process is running
func (t TerminalSession) Read(p []byte) (int, error) {
	m, err := t.sockJSSession.Recv()
	if err != nil {
		// Send terminated signal to process to avoid resource leak
		return copy(p, END_OF_TRANSMISSION), err
	}
	var msg TerminalMessage
	if err := json.Unmarshal([]byte(m), &msg); err != nil {
		return copy(p, END_OF_TRANSMISSION), err
	}

	switch msg.Op {
	case "stdin":
		return copy(p, msg.Data), nil
	case "resize":
		t.sizeChan <- remotecommand.TerminalSize{Width: msg.Cols, Height: msg.Rows}
		return 0, nil
	default:
		return copy(p, END_OF_TRANSMISSION), fmt.Errorf("unknown message type '%s'", msg.Op)
	}
}

// Write handles process->pty stdout
// Called from remotecommand whenever there is any output
func (t TerminalSession) Write(p []byte) (int, error) {
	msg, err := json.Marshal(TerminalMessage{
		Op:   "stdout",
		Data: string(p),
	})
	if err != nil {
		return 0, err
	}

	if err = t.sockJSSession.Send(string(msg)); err != nil {
		return 0, err
	}
	return len(p), nil
}

// Toast can be used to send the user any OOB messages
// hterm puts these in the center of the terminal
func (t TerminalSession) Toast(p string) error {
	msg, err := json.Marshal(TerminalMessage{
		Op:   "toast",
		Data: p,
	})
	if err != nil {
		return err
	}

	if err = t.sockJSSession.Send(string(msg)); err != nil {
		return err
	}
	return nil
}

// Done done, must call Done() before connection close, or next() would not exists.
func (t TerminalSession) Done() {
	if channelIsClosed(t.doneChan) {
		log.Info("channel is closed no need close")
		return
	}
	log.Info("before connection close call Done")
	close(t.doneChan)
}

func (t TerminalSession) Close() {
	// bugfix panic: close of closed channel
	if channelIsClosed(t.doneChan) {
		log.Info("channel is closed no need close")
		return
	}
	close(t.doneChan)
}

// judge channel whether is closed
func channelIsClosed(ch chan struct{}) bool {
	select {
	case <-ch:
		return true
	default:
	}
	return false
}

type terminalReqCtx struct {
	Cluster   string `json:"clusterID"`
	Namespace string `json:"namespace"`
	Pod       string `json:"pod"`
	Container string `json:"container"`
	Shell     string `json:"shell"`
}

// Handles execute shell API call
func httpHandleTerminal(c *gin.Context) {
	//判断传入的shell类型
	shell := c.Query("shell")
	if shell == "sh" {
		shell = "bash"
	}

	terminalReqCtx := terminalReqCtx{
		Cluster:   c.GetHeader("clusterID"),
		Namespace: c.Param("namespace"),
		Pod:       c.Param("name"),
		Container: c.Param("container"),
		Shell:     shell,
	}

	tokenString, err := buildJwt(terminalReqCtx)
	if err != nil {
		common.HandleError(c, http.StatusInternalServerError, err)
		return
	}

	c.JSON(http.StatusOK, WsResponse{Id: tokenString})
	return
}

// HandleTerminalSession is Called by net/http for any new sockjs connections
func (h *handler) wsHandleTerminal(session sockjs.Session) {
	ctxStr, err := validJwtAndGetCtx(session)
	if err != nil {
		closeSession(session, 401, err.Error())
		return
	}

	terminalReqCtx := new(terminalReqCtx)
	if err := json.Unmarshal([]byte(ctxStr), terminalReqCtx); err != nil {
		log.Errorf("wsHandleTerminal Unmarshal data err: %+v", err)
		closeSession(session, 401, "invalid token")
		return
	}

	ts := &TerminalSession{
		terminalReqCtx: terminalReqCtx,
		sizeChan:       make(chan remotecommand.TerminalSize),
		sockJSSession:  session,
		doneChan:       make(chan struct{}),
	}

	ts.sockJSSession = session

	processTerminal(h.clusterClientManager, ts)
}

func processTerminal(mgr *multicluster.ClusterClientManager, ts *TerminalSession) {

	client, err := mgr.GetClientFromCache(ts.terminalReqCtx.Cluster)
	if err != nil {
		log.Errorf("processTerminal: get k8s client err: %+v", err)
		closeSession(ts.sockJSSession, 3, "can not get zone config,please check SessionId")
		return
	}

	shell := ts.terminalReqCtx.Shell

	validShells := []string{"bash", "sh", "powershell", "cmd"}

	if isValidShell(validShells, shell) {
		//首先test是否有/bin/bash文件，如果有切换bash没有切换sh
		cmd := []string{shell}
		err = startProcess(client, ts.terminalReqCtx, cmd, ts)
		//当连接流返回错误的时候
		if err != nil {
			return
		}
	} else {
		// No shell given or it was not valid: try some shells until one succeeds or all fail
		// FIXME: if the first shell fails then the first keyboard event is lost
		for _, testShell := range validShells {
			cmd := []string{testShell}
			if err = startProcess(client, ts.terminalReqCtx, cmd, ts); err == nil {
				break
			}
		}
	}

	session := ts.sockJSSession
	ts.Close()
	if err != nil {
		closeSession(session, 2, err.Error())
		return
	}
	closeSession(session, 1, "Process exited")
}

// startProcess is called by handleAttach
// Executed cmd in the container specified in request and connects it up with the ptyHandler (a session)
func startProcess(cli clientset.Interface, ctx *terminalReqCtx, cmd []string, ptyHandler PtyHandler) error {
	defer func() {
		ptyHandler.Done()
	}()
	namespace := ctx.Namespace
	podName := ctx.Pod
	containerName := ctx.Container

	req := cli.CoreV1().RESTClient().Post().
		Resource("pods").
		Name(podName).
		Namespace(namespace).
		SubResource("exec")

	req.VersionedParams(&v1.PodExecOptions{
		Container: containerName,
		Command:   cmd,
		Stdin:     true,
		Stdout:    true,
		Stderr:    true,
		TTY:       true,
	}, scheme.ParameterCodec)

	exec, err := remotecommand.NewSPDYExecutor(cli.ClientConfig(), "POST", req.URL())
	if err != nil {
		return err
	}

	err = exec.Stream(remotecommand.StreamOptions{
		Stdin:             ptyHandler,
		Stdout:            ptyHandler,
		Stderr:            ptyHandler,
		TerminalSizeQueue: ptyHandler,
		Tty:               true,
	})
	if err != nil {
		return err
	}

	return nil
}

// isValidShell checks if the shell is an allowed one
func isValidShell(validShells []string, shell string) bool {
	for _, validShell := range validShells {
		if validShell == shell {
			return true
		}
	}
	return false
}
