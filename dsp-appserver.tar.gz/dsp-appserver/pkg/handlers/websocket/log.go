package websocket

import (
	"bufio"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	errors2 "github.com/pkg/errors"
	"gopkg.in/igm/sockjs-go.v2/sockjs"
	v1 "k8s.io/api/core/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
)

type logReqCtx struct {
	Cluster   string
	Namespace string
	Pod       string
	Container string
	Follow    bool
}

func (h *handler) httpHandleLog(c *gin.Context) {
	var follow bool
	if value, exist := c.GetQuery("follow"); exist {
		boolean, err := strconv.ParseBool(value)
		if err != nil {
			log.Errorf("failed to parse the query parameter follow into a bool: %v", err)
			common.HandleError(c, 400, err)
			return
		}
		follow = boolean
	}

	logReqCtx := &logReqCtx{
		Cluster:   c.GetHeader("clusterID"),
		Namespace: c.Param("namespace"),
		Pod:       c.Param("name"),
		Container: c.Param("container"),
		Follow:    follow,
	}

	if !follow {
		readCloser, err := getLogReadCloser(c.Request.Context(), h.clusterClientManager, logReqCtx)
		if err != nil {
			common.HandleError(c, 500, err)
			return
		}
		defer readCloser.Close()
		c.DataFromReader(200, -1, "application/json", readCloser, map[string]string{})
		return
	}

	// return jwt
	tokenString, err := buildJwt(logReqCtx)
	if err != nil {
		common.HandleError(c, http.StatusInternalServerError, err)
		return
	}

	c.JSON(http.StatusOK, WsResponse{Id: tokenString})
	return
}

func (h *handler) wsHandleLog(session sockjs.Session) {
	ctxStr, err := validJwtAndGetCtx(session)
	if err != nil {
		closeSession(session, 401, err.Error())
		return
	}

	logReqCtx := new(logReqCtx)
	if err := json.Unmarshal([]byte(ctxStr), logReqCtx); err != nil {
		log.Errorf("err: %+v", err)
		closeSession(session, 401, "invalid token")
		return
	}

	readCloser, err := getLogReadCloser(context.Background(), h.clusterClientManager, logReqCtx)
	if err != nil {
		closeSession(session, 500, err.Error())
		return
	}
	defer readCloser.Close()

	reader := bufio.NewReader(readCloser)
	msgChan := make(chan []byte, 2048)

	go recieveMessage(reader, msgChan)
	sendMessage(session, msgChan)
}

func getLogReadCloser(ctext context.Context, mgr *multicluster.ClusterClientManager, ctx *logReqCtx) (io.ReadCloser, error) {
	// log stream
	client, err := mgr.Client(ctx.Cluster)
	if err != nil {
		return nil, errors2.Wrap(err, "")
	}

	var tailLines int64 = 1000
	readCloser, err := client.CoreV1().Pods(ctx.Namespace).GetLogs(ctx.Pod, &v1.PodLogOptions{
		Container: ctx.Container,
		Follow:    ctx.Follow,
		TailLines: &tailLines,
	}).Stream(ctext)
	if err != nil {
		return nil, errors2.Wrap(err, "")
	}
	return readCloser, nil
}

// recieveMessage read message from a reader, then send the message to a channel.
func recieveMessage(reader *bufio.Reader, msgChan chan<- []byte) {
	for {
		bytes, err := reader.ReadBytes('\n')
		if err != nil && err != io.EOF {
			log.Errorf("failed to read message: %v", err)
			return
		}

		if err == io.EOF {
			return
		}
		msgChan <- bytes
	}
}

// sendMessage copy messages from message channel to remote client.
// if didn't receive messages from channel in 5 * time.Second, it will be timeout and send hearbeat to client
// if err nil that mean websocket is connecting, continue to next loop
func sendMessage(conn sockjs.Session, msgChan <-chan []byte) {
	for {
		select {
		case bytes := <-msgChan:
			err := conn.Send(string(bytes))
			if err != nil {
				log.Errorf("unable to send message to remote client: %v", err)
				return
			}
		case <-time.After(5 * time.Second):
			log.Info("receive message timeout")
			err := conn.Send("")
			if err != nil {
				return
			}
		}
	}
}
