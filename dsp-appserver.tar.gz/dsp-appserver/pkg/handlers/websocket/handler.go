package websocket

import (
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/gin"
	errors2 "github.com/pkg/errors"
	"gopkg.in/igm/sockjs-go.v2/sockjs"

	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
)

var log = logi.Log.Sugar()

const (
	ws_prefix   = "/ws/v1"
	ws_terminal = ws_prefix + "/container/terminal"
	ws_log      = ws_prefix + "/container/log"

	jwt_ctx = "ctx"
)

type handler struct {
	clusterClientManager *multicluster.ClusterClientManager
}

type SessionMessage struct {
	Op, SessionID string
}

type WsResponse struct {
	Id string `json:"id"`
}

func InstallHandlers(routerGroup *gin.RouterGroup, clusterClientManager *multicluster.ClusterClientManager) {
	h := &handler{
		clusterClientManager: clusterClientManager,
	}

	// 容器终端exec
	routerGroup.GET("/v1/namespaces/:namespace/pods/:name/shell/:container", httpHandleTerminal)
	// 查询容器的实时日志
	routerGroup.GET("/v1/namespaces/:namespace/pods/:name/log/:container", h.httpHandleLog)

	http.Handle(ws_terminal+"/", sockjs.NewHandler(ws_terminal, sockjs.DefaultOptions, h.wsHandleTerminal))
	http.Handle(ws_log+"/", sockjs.NewHandler(ws_log, sockjs.DefaultOptions, h.wsHandleLog))
}

func closeSession(session sockjs.Session, stauts uint32, reason string) {
	log.Debugf("close session, reason: %s", reason)
	err := session.Close(stauts, reason)
	if err != nil {
		log.Errorf("err: %+v", err)
	}
}

func buildJwt(ctx interface{}) (string, error) {
	buf, err := json.Marshal(ctx)
	if err != nil {
		return "", errors2.Wrap(err, "")
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		jwt_ctx: string(buf),
		"exp":   time.Now().Add(5 * time.Minute).Unix(),
	})

	// Sign and get the complete encoded token as a string using the secret
	tokenString, err := token.SignedString([]byte(JWTSecret))
	if err != nil {
		return "", errors2.Wrap(err, "")
	}

	return tokenString, nil
}

func validJwtAndGetCtx(session sockjs.Session) (string, error) {
	var (
		buf string
		err error
		msg SessionMessage
	)

	if buf, err = session.Recv(); err != nil {
		log.Infof("handleTerminalSession: can't Recv: %v", err)
		return "", err
	}

	if err = json.Unmarshal([]byte(buf), &msg); err != nil {
		log.Infof("handleTerminalSession: can't UnMarshal (%v): %s", err, buf)
		return "", err
	}

	if msg.Op != "bind" {
		log.Infof("handleTerminalSession: expected 'bind' message, got: %s", buf)
		return "", errors2.New("invalid token")
	}

	token, err := jwt.Parse(msg.SessionID, func(token *jwt.Token) (interface{}, error) {
		// Don't forget to validate the alg is what you expect:
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}

		// hmacSampleSecret is a []byte containing your secret, e.g. []byte("my_secret_key")
		return []byte(JWTSecret), nil
	})
	if err != nil || !token.Valid {
		log.Errorf("err: %+v", err)
		return "", errors2.New("invalid token")
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok {
		return "", errors2.New("invalid token")
	}

	str, ok := claims[jwt_ctx].(string)
	if !ok {
		return "", errors2.New("invalid token")
	}

	log.Debugf("ws connected, jwt: %s, ctx: %s", msg.SessionID, str)

	return str, nil
}
