package app

import (
	"github.com/gin-gonic/gin"

	"github.com/daocloud/dsp-appserver/pkg/informermanager"
	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
)

var log = logi.Log.Sugar()

type handler struct {
	clusterClientManager *multicluster.ClusterClientManager
	informerManager      informermanager.InformerManager
}

// InstallHandlers install Handlers
func InstallHandlers(routerGroup *gin.RouterGroup,
	clusterClientManager *multicluster.ClusterClientManager,
	informerManager informermanager.InformerManager) {

	h := &handler{
		clusterClientManager: clusterClientManager,
		informerManager:      informerManager,
	}

	routerGroup.POST("/v1/namespaces/:namespace/yaml/check", h.handleCheckYAML)

	routerGroup.POST("/v1/namespaces/:namespace/applications/:id/all", h.handleGetApplicationAll)
	routerGroup.POST("/v1/namespaces/:namespace/applications/:id/workloads", h.handleGetApplicationWorkloads)
	routerGroup.POST("/v1/namespaces/:namespace/applications/:id/discovery", h.handleGetApplicationDiscovery)
	routerGroup.POST("/v1/namespaces/:namespace/applications/:id/storage", h.handleGetApplicationStorage)
	routerGroup.POST("/v1/namespaces/:namespace/applications/:id/other", h.handleGetApplicationOther)
	routerGroup.POST("/v1/namespaces/:namespace/applications/:id/vpa", h.handlerGetApplicationVPA)
	routerGroup.POST("/v1/namespaces/:namespace/applications/:id/hpa", h.handlerGetApplicationHPA)
	routerGroup.POST("/v1/namespaces/:namespace/applications/:id/pods", h.handleGetApplicationPods)

	routerGroup.POST("/v1/namespaces/:namespace/applications/:id/status", h.handleGetApplicationStatus)

	routerGroup.PUT("/v1/namespaces/:namespace/applications/:id/yaml", h.handleUpdateApplicationYAML)
	routerGroup.DELETE("/v1/namespaces/:namespace/applications/:id/yaml", h.handleDeleteApplicationYAML)
}
