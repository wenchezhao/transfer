package app

import (
	"io/ioutil"

	"github.com/gin-gonic/gin"

	"github.com/daocloud/dsp-appserver/pkg/app"
	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

// ApplicationStatus define the application status
type ApplicationStatus struct {
	Code    int    `json:"code"`    // 用于返回定义的状态：1 应用正常 2 应用异常
	Status  string `json:"status"`  // 用于返回可明确展示的信息
	Message string `json:"message"` // 用于返回错误的信息
}

// UpdateRequest define the update struct
type UpdateRequest struct {
	OldYamls []string `json:"old"`
	NewYaml  string   `json:"new"`
}

func (h *handler) handleGetApplicationAll(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get application all")
	defer span.Finish()

	namespace := c.Param("namespace")
	kinds := c.QueryArray("kinds")

	defer c.Request.Body.Close()
	manifests, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		log.Errorf("failed to read request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	resources, err := app.ListAll(ctx, namespace, kinds, manifests, client, informer)
	if err != nil {
		log.Errorf("failed to get all resources: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resources)
}

func (h *handler) handleGetApplicationWorkloads(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get application workloads")
	defer span.Finish()

	namespace := c.Param("namespace")

	defer c.Request.Body.Close()
	manifests, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		log.Errorf("failed to read request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	resources, err := app.ListWorkloads(ctx, namespace, manifests, client, informer)
	if err != nil {
		log.Errorf("failed to get workloads: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resources)
}

func (h *handler) handleGetApplicationPods(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get application workloads")
	defer span.Finish()

	namespace := c.Param("namespace")

	defer c.Request.Body.Close()
	manifests, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		log.Errorf("failed to read request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	resources, err := app.ListApplicationPods(ctx, namespace, manifests, client)
	if err != nil {
		log.Errorf("failed to get pod list: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resources)
}

func (h *handler) handleGetApplicationDiscovery(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get application service discover")
	defer span.Finish()

	namespace := c.Param("namespace")

	defer c.Request.Body.Close()
	manifests, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		log.Errorf("failed to read request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	resources, err := app.ListDiscovery(ctx, namespace, manifests, client, informer)
	if err != nil {
		log.Errorf("failed to get service discovery: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resources)
}

func (h *handler) handleGetApplicationStorage(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get application storage")
	defer span.Finish()

	namespace := c.Param("namespace")

	defer c.Request.Body.Close()
	manifests, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		log.Errorf("failed to read request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	resources, err := app.ListStorage(ctx, namespace, manifests, client, informer)
	if err != nil {
		log.Errorf("failed to get storage: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resources)
}

func (h *handler) handleGetApplicationOther(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get application other")
	defer span.Finish()

	namespace := c.Param("namespace")

	defer c.Request.Body.Close()
	manifests, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		log.Errorf("failed to read request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	resources, err := app.ListOther(ctx, namespace, manifests, client)
	if err != nil {
		log.Errorf("failed to get other resources: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resources)
}

func (h *handler) handlerGetApplicationVPA(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get application vpa")
	defer span.Finish()

	namespace := c.Param("namespace")

	defer c.Request.Body.Close()
	manifests, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		log.Errorf("failed to read request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	resources, err := app.ListVPA(ctx, namespace, manifests, client)
	if err != nil {
		log.Errorf("failed to get vpa: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resources)
	return
}

func (h *handler) handlerGetApplicationHPA(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get application hpa")
	defer span.Finish()

	namespace := c.Param("namespace")

	defer c.Request.Body.Close()
	manifests, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		log.Errorf("failed to read request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	resources, err := app.ListHPA(ctx, namespace, manifests, client)
	if err != nil {
		log.Errorf("failed to list hpa: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resources)
}

func (h *handler) handleUpdateApplicationYAML(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update application with yaml")
	defer span.Finish()

	namespace := c.Param("namespace")

	updateRequest := UpdateRequest{}
	err := c.Bind(&updateRequest)
	if err != nil {
		log.Errorf("failed to get update request bodyt: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	appStatus := app.ApplyApplication(ctx, namespace, updateRequest.OldYamls, updateRequest.NewYaml, client)
	c.JSON(200, appStatus)
}

func (h *handler) handleDeleteApplicationYAML(c *gin.Context) {

	span, ctx := utiltrace.StartSpanFromGin(c, "delete application yaml")
	defer span.Finish()

	namespace := c.Param("namespace")

	updateRequest := UpdateRequest{}
	err := c.Bind(&updateRequest)
	if err != nil {
		log.Errorf("failed to get update request bodyt: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	if err := app.DeleteApplication(ctx, namespace, append(updateRequest.OldYamls, updateRequest.NewYaml), client); err != nil {
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, struct{}{})
}

// 对于应用状态定义，如果一个应用所包含的资源都存在，则应用正常
func (h *handler) handleGetApplicationStatus(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get application status")
	defer span.Finish()

	namespace := c.Param("namespace")

	defer c.Request.Body.Close()
	manifests, err := ioutil.ReadAll(c.Request.Body)
	if err != nil {
		log.Errorf("failed to read request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	appStatus, err := app.GetApplicationStatus(ctx, namespace, manifests, client, informer)
	if err != nil {
		log.Errorf("unable to compute application status: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, appStatus)
}

func (h *handler) handleCheckYAML(c *gin.Context) {

	span, ctx := utiltrace.StartSpanFromGin(c, "check yaml")
	defer span.Finish()

	namespace := c.Param("namespace")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	if err = app.CheckApplicationYAML(ctx, client, namespace, c.Request.Body); err != nil {
		log.Errorf("yaml has some err: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	c.JSON(200, struct{}{})
}
