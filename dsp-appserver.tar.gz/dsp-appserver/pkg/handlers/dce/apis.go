package dce

import (
	"crypto/tls"
	"errors"
	"net/http"
	"sort"
	"strings"
	"time"

	"github.com/daocloud/dsp-appserver/pkg/dce"
	"github.com/daocloud/dsp-appserver/pkg/dce/apis"
	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	"github.com/gin-gonic/gin"
)

// check集群
func (h *handler) check(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "check")
	defer span.Finish()

	token := c.Query("token")
	url := c.Query("url")
	log.Infof("token is %v, url  is %v", token, url)

	if token == "" || url == "" {
		common.HandleError(c, 500, errors.New("token or url is null"))
		return
	}

	req, err := http.NewRequest(http.MethodGet, url+"/apis/parcel.dce.daocloud.io/v1beta1/ovs/subnet?Namespace=", nil)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	req.Header.Add("Authorization", "Bearer "+token)
	client := &http.Client{
		Timeout: 15 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				InsecureSkipVerify: true,
			},
		},
	}
	resp, err := client.Do(req)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		common.HandleError(c, 500, errors.New("token can not be valid by server"))
		return
	}

	c.JSON(200, "check success")
}

// 规则列表
func (h *handler) listRules(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "listRules")
	defer span.Finish()

	namespace := c.Query("namespace")
	poolName := c.Query("poolName")
	log.Infof("namespace is %v", namespace, ", poolName is %v", poolName)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	rules, ise := dce.AppRuleList(h.DceNetworkApi(), z.Authenticationinformation, z.Interfaceurl, namespace, poolName)
	if ise != nil {
		log.Infof("failed to get AppRuleList: %v", ise)
		handleError(c, 500, ise)
		return
	}
	c.JSON(200, rules)
}

// 删除规则
func (h *handler) deleteRule(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "deleteRule")
	defer span.Finish()

	namespace := c.Query("namespace")
	rule := c.Param("rule")
	poolName := c.Query("poolName")
	log.Infof("namespace is %v , rule is %v ,poolName is %v", namespace, rule, poolName)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	resp, ise := h.DceNetworkApi().DeleteRuleOne(z.Authenticationinformation, z.Interfaceurl, namespace, poolName, rule)

	var retJ apis.AppResponse
	if ise != nil {
		retJ.Code = 500
		retJ.Message = ise.Error()
		c.JSON(500, retJ)
	} else {
		retJ.Code = resp.Code
		retJ.Message = resp.Msg + " " + resp.Details
		c.JSON(resp.Code, retJ)
	}
}

// 创建规则
func (h *handler) createRule(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "createRule")
	defer span.Finish()

	ruleObj := &apis.AppAddRule{}
	if err := c.BindJSON(ruleObj); err != nil {
		handleError(c, 400, err)
		return
	}
	if ruleObj.PoolName == "" {
		handleError(c, 400, errors.New("need poolName"))
		return
	}

	namespace := c.Query("namespace")
	log.Infof("namespace is %v , ruleObj is %v ", namespace, ruleObj)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	rule := apis.AddOvsRule{
		ApiVersion: apis.ApiVersion,
		Kind:       apis.KindRule,
		Metadata: apis.Metadata{
			Name:      ruleObj.Name,
			Namespace: namespace,
		},
		Description: ruleObj.Description,
		IpList:      ruleObj.IpList,
		PoolName:    ruleObj.PoolName,
		Subnet:      ruleObj.Subnet,
		SubnetName:  ruleObj.SubnetName,
	}

	resp, ise := h.DceNetworkApi().AddRule(z.Authenticationinformation, z.Interfaceurl, namespace, ruleObj.PoolName, rule)

	var retJ apis.AppResponse
	if ise != nil {
		retJ.Code = 500
		retJ.Message = ise.Error()
		c.JSON(500, retJ)
	} else {
		retJ.Code = resp.Code
		retJ.Message = resp.Msg + " " + resp.Details
		c.JSON(resp.Code, retJ)
	}
}

// 修改规则
func (h *handler) updateRule(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "updateRule")
	defer span.Finish()

	ruleObj := &apis.AppAddRule{}
	if err := c.BindJSON(ruleObj); err != nil {
		handleError(c, 400, err)
		return
	}
	if ruleObj.PoolName == "" {
		handleError(c, 400, errors.New("need poolName"))
		return
	}

	namespace := c.Query("namespace")
	ruleParam := c.Param("rule")

	log.Infof("namespace is %v , ruleObj is %v , rule is %v ", namespace, ruleObj, ruleParam)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	rule := apis.AddOvsRule{
		ApiVersion: apis.ApiVersion,
		Kind:       apis.KindRule,
		Metadata: apis.Metadata{
			Name:      ruleObj.Name,
			Namespace: namespace,
		},
		Description: ruleObj.Description,
		IpList:      ruleObj.IpList,
		PoolName:    ruleObj.PoolName,
		Subnet:      ruleObj.Subnet,
		SubnetName:  ruleObj.SubnetName,
	}

	resp, ise := h.DceNetworkApi().UpdateRule(z.Authenticationinformation, z.Interfaceurl, namespace, ruleObj.PoolName, ruleParam, rule)

	var retJ apis.AppResponse
	if ise != nil {
		retJ.Code = 500
		retJ.Message = ise.Error()
		c.JSON(500, retJ)
	} else {
		retJ.Code = resp.Code
		retJ.Message = resp.Msg + " " + resp.Details
		c.JSON(resp.Code, retJ)
	}
}

// 规则详情
func (h *handler) oneRule(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "oneRule")
	defer span.Finish()

	namespace := c.Query("namespace")
	rule := c.Param("rule")
	poolName := c.Query("poolName")
	log.Infof("namespace is %v , rule is %v,poolName is %v ", namespace, rule, poolName)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	ruleObj, ise := h.DceNetworkApi().GetRuleOne(z.Authenticationinformation, z.Interfaceurl, namespace, poolName, rule)
	if ise != nil {
		log.Infof("failed to get GetRuleOne: %v", ise)
		// rule不存在返回404及message：RULE_IS_EMPTY
		if ise.Error() == dce.RULE_IS_EMPTY {
			handleError(c, 404, ise)
			return
		}
		handleError(c, 500, ise)
		return
	}
	appRuleInfo := apis.AppRuleInfo{
		Name:        ruleObj.Metadata.Name,
		Description: ruleObj.Description,
		Subnet:      ruleObj.Subnet,
		SubnetName:  ruleObj.SubnetName,
		PoolName:    ruleObj.PoolName,
	}
	appRuleDetailMore := apis.AppRuleDetailMore{
		AppRuleInfo: appRuleInfo,
	}
	var ruleObj_ apis.AppRuleDetail
	for key, v := range ruleObj.Ips {
		statusS := ""
		if v.PodName == "" {

			V4ConflictB := false
			switch v.V4Conflict.(type) {
			case string:
			case bool:
				if v.V4Conflict.(bool) {
					V4ConflictB = true
				}
			}
			V6ConflictB := false
			switch v.V6Conflict.(type) {
			case string:
			case bool:
				if v.V6Conflict.(bool) {
					V6ConflictB = true
				}
			}

			if V4ConflictB || V6ConflictB {
				statusS = statusConflict
			} else {
				statusS = statusUnUsed
			}
		} else {
			statusS = statusUsed
		}
		ruleObj_.Items = append(ruleObj_.Items, struct {
			Ip     string "json:\"ip\""
			Status string "json:\"status\""
		}{key, statusS})
	}
	appRuleDetailMore.AppRuleDetail = ruleObj_
	c.JSON(200, appRuleDetailMore)
}

// ip池列表
func (h *handler) listPolls(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "listPolls")
	defer span.Finish()

	// namespace := c.Query("namespace")
	// log.Infof("namespace is %v  ", namespace)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	rules, ise := dce.AppPoolList(h.DceNetworkApi(), z.Authenticationinformation, z.Interfaceurl, "")

	if ise != nil {
		log.Infof("failed to get AppPoolList: %v", ise)
		handleError(c, 500, ise)
		return
	}
	c.JSON(200, rules)
}

// ip池详情
func (h *handler) onePool(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "onePool")
	defer span.Finish()

	namespace := c.Query("namespace")
	poolName := c.Param("pool")
	log.Infof("namespace is %v ,poolName is %v ", namespace, poolName)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	rules_, ise := h.DceNetworkApi().GetPoolOne(z.Authenticationinformation, z.Interfaceurl, namespace, poolName)
	if ise != nil {
		log.Errorf("failed to GetPoolOne: %v", ise)
		handleError(c, 500, err)
		return
	}

	var rules apis.AppPoolDetail
	rules.DefaultRouteV4 = rules_.DefaultRouteV4
	rules.DisplayVlan = rules_.DisplayVlan
	rules.Name = rules_.Metadata.Name
	rules.SubnetName = rules_.SubnetName
	rules.Subnet = rules_.Subnet
	for kk, vv := range rules_.Ips {
		// if vv.OwnerNamespace != "" && vv.OwnerNamespace != namespace {
		// 	log.Warnf("onePool filter other ns's ippool detail, OwnerNamespace=%v,namespace=%v", vv.OwnerNamespace, namespace)
		// 	continue
		// }
		statusS := ""
		if vv.PodName == "" {

			V4ConflictB := false
			switch vv.V4Conflict.(type) {
			case string:
			case bool:
				if vv.V4Conflict.(bool) {
					V4ConflictB = true
				}
			}
			V6ConflictB := false
			switch vv.V6Conflict.(type) {
			case string:
			case bool:
				if vv.V6Conflict.(bool) {
					V6ConflictB = true
				}
			}

			if V4ConflictB || V6ConflictB {
				statusS = statusConflict
			} else {
				statusS = statusUnUsed
			}
		} else {
			statusS = statusUsed
		}

		var ipDetail apis.IpDetail
		ipDetail.Ip = kk
		ipDetail.Mac = vv.Mac
		ipDetail.RuleName = vv.RuleName
		ipDetail.Status = statusS
		ipDetail.Pod = vv.PodName
		rules.Items = append(rules.Items, ipDetail)
	}

	sort.Sort(rules.Items)

	c.JSON(200, rules)
}

// 创建ip池
func (h *handler) createPool(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "createPool")
	defer span.Finish()

	poolObj := &apis.AppAddPool{}
	if err := c.BindJSON(poolObj); err != nil {
		handleError(c, 400, err)
		return
	}

	namespace := c.Query("namespace")
	log.Infof("namespace is %v , poolObj is %v ", namespace, poolObj)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	rule := apis.AddOvsPool{
		ApiVersion: apis.ApiVersion,
		Kind:       apis.KindOvsPoolRequest,
		Metadata: struct {
			Namespace string "json:\"namespace\""
		}{
			Namespace: namespace,
		},
		DefaultRouteV4: poolObj.DefaultRouteV4,
		DefaultRouteV6: poolObj.DefaultRouteV6,
		SubnetName:     poolObj.SubnetName,
		Route:          poolObj.Route,
		V4MapV6:        poolObj.V4MapV6,
	}

	resp, ise := h.DceNetworkApi().AddPoolOne(z.Authenticationinformation, z.Interfaceurl, namespace, poolObj.SubnetName, rule)

	var retJ apis.AppResponse
	if ise != nil {
		retJ.Code = 500
		retJ.Message = ise.Error()
		c.JSON(500, retJ)
	} else {
		retJ.Code = resp.Code
		retJ.Message = resp.Msg + " " + resp.Details
		c.JSON(resp.Code, retJ)
	}
}

// 删除ip池
func (h *handler) deletePool(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "deletePool")
	defer span.Finish()

	namespace := c.Query("namespace")
	pool := c.Param("pool")
	log.Infof("namespace is %v , poolName is %v", namespace, pool)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	resp, ise := h.DceNetworkApi().DeletePoolOne(z.Authenticationinformation, z.Interfaceurl, namespace, pool)

	var retJ apis.AppResponse
	if ise != nil {
		retJ.Code = 500
		retJ.Message = ise.Error()
		c.JSON(500, retJ)
	} else {
		retJ.Code = resp.Code
		retJ.Message = resp.Msg + " " + resp.Details
		c.JSON(resp.Code, retJ)
	}
}

// 子网详情
func (h *handler) oneSubnet(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "oneSubnet")
	defer span.Finish()

	subnetName := c.Param("subnetName")
	subnetName = strings.TrimSpace(subnetName)
	log.Infof("subnetName is %v ", subnetName)
	if subnetName == "" {
		log.Infof("subnetName can not be null")
		handleError(c, 500, errors.New("subnetName can not be null"))
		return
	}

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	subnets, ise := h.DceNetworkApi().GetSubnetOne(z.Authenticationinformation, z.Interfaceurl, subnetName)
	if ise != nil {
		log.Infof("failed to get oneSubnet %v", ise)
		handleError(c, 500, ise)
		return
	}

	if len(subnets.Items) == 0 {
		log.Infof("subnet detail must have one subnet")
		handleError(c, 500, errors.New("subnet detail must have one subnet"))
		return
	}

	var subnet apis.AppOvsSubnet
	subnet.DefaultRouteV4 = subnets.Items[0].DefaultRouteV4
	subnet.DefaultRouteV6 = subnets.Items[0].DefaultRouteV6
	subnet.DisplayVlan = subnets.Items[0].DisplayVlan
	subnet.Subnet = subnets.Items[0].Subnet
	subnet.SubnetName = subnets.Items[0].Metadata.Name

	c.JSON(200, subnet)
}

// 子网列表
func (h *handler) listSubnets(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "listSubnets")
	defer span.Finish()

	namespace := c.Query("namespace")
	name := c.Query("name")

	log.Infof("namespace is %v , name is %v", namespace, name)

	z, err := common.GetZoneByClusterInfo(h.clusterClientManager, c)
	//log.Infof("get zone info %v", z)
	if err != nil {
		log.Infof("failed to get zone by zone id: %v", err)
		handleError(c, 500, err)
		return
	}

	subnets, ise := h.DceNetworkApi().GetSubnets(z.Authenticationinformation, z.Interfaceurl, dce.SubnetNamespace, namespace)
	if ise != nil {
		log.Infof("failed to get GetSubnets %v", ise)
		handleError(c, 500, err)
		return
	}

	for inx, subnet := range subnets.Items {
		var ovsPools []apis.OvsPool
		for _, pool := range subnet.Pools {
			if pool.Namespace != namespace {
				log.Warnf("filter public pools:%v , my namespace is :%v", pool.Namespace, namespace)
				continue
			}
			ovsPools = append(ovsPools, pool)
		}
		subnets.Items[inx].Pools = ovsPools
	}
	for inx, subnet := range subnets.Items {
		for inx2, pool := range subnet.Pools {
			subnets.Items[inx].Pools[inx2].IpList = nil
			poolObj, ise := h.DceNetworkApi().GetPoolOne(z.Authenticationinformation, z.Interfaceurl, namespace, pool.PoolName)
			if ise != nil {
				log.Infof("failed to get GetPoolOne %v", ise)
			} else {
				subnets.Items[inx].Pools[inx2].Ips = poolObj.Ips
			}
		}
	}

	c.JSON(200, subnets)
}
