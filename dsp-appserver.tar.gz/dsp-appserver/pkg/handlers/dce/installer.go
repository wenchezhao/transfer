package dce

import (
	"github.com/daocloud/dsp-appserver/pkg/dce"
	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
	"github.com/gin-gonic/gin"
)

var log = logi.Log.Sugar()

const (
	statusUsed     = "已连接"
	statusUnUsed   = "未连接"
	statusConflict = "IP冲突"
)

type handler struct {
	clusterClientManager *multicluster.ClusterClientManager
	dceNetworkApi        dce.DceNetworkApi
}

func (h *handler) DceNetworkApi() dce.DceNetworkApi {
	return h.dceNetworkApi
}

func InstallHandlers(routerGroup *gin.RouterGroup,
	clusterClientManager *multicluster.ClusterClientManager) {
	h := &handler{
		clusterClientManager: clusterClientManager,
		dceNetworkApi:        dce.New(),
	}

	//集群dce验证
	routerGroup.GET("/check", h.check)
	//ip规则的CRUD
	routerGroup.GET("/rules", h.listRules)
	routerGroup.GET("/rules/:rule", h.oneRule)
	routerGroup.PUT("/rules/:rule", h.updateRule)
	routerGroup.POST("/rules", h.createRule)
	routerGroup.DELETE("/rules/:rule", h.deleteRule)
	//ip池的CRUD
	routerGroup.GET("/pools", h.listPolls)
	routerGroup.GET("/pools/:pool", h.onePool)
	routerGroup.POST("/pools", h.createPool)
	routerGroup.DELETE("/pools/:pool", h.deletePool)
	//子网列表
	routerGroup.GET("/subnet", h.listSubnets)
	//子网详情
	routerGroup.GET("/onesubnet/:subnetName", h.oneSubnet)
}

func handleError(c *gin.Context, code int, err error) {
	common.HandleError(c, code, err)
}
