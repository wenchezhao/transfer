package dashboard

import (
	"encoding/json"

	"github.com/gin-gonic/gin"
	"github.com/tidwall/gjson"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/sets"

	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

// 获取集群概览,支持多集群
func (h *handler) getClusterCountInfo(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get pod status information")
	defer span.Finish()

	clusters := c.QueryArray("clusters")
	resMap := make(map[string]interface{})
	for _, cluster := range clusters {
		resMap[cluster] = make(map[string]interface{})
		client, err := h.clusterClientManager.GetClientFromCache(cluster)
		if err != nil {
			log.Errorf("failed to get cluster client: %v", err)
			continue
		}

		cm, err := client.CoreV1().ConfigMaps(h.ResourcesC.Namespace).Get(ctx, h.ResourcesC.Name, metav1.GetOptions{})
		if err != nil {
			log.Errorf("failed to get configmap %s/%s error: %v", h.ResourcesC.Namespace, h.ResourcesC.Name, err)
			continue
		}

		vData := make(map[string]interface{})
		if vStr, ok := cm.Data["node"]; ok {
			if err := json.Unmarshal([]byte(vStr), &vData); err != nil {
				log.Errorf("failed to json unmashal %s error: %v", vStr, err)
				continue
			}
		}
		resMap[cluster] = vData
	}

	c.JSON(200, resMap)
	return
}

// 根据集群ID和命名空间列表获取资源统计信息
func (h *handler) getResourcesCountInfo(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get resources count information")
	defer span.Finish()

	namespaces := c.QueryArray("namespaces")
	clusters := c.QueryArray("clusters")

	resMap := make(map[string]interface{})
	for _, cluster := range clusters {
		resMap[cluster] = make(map[string]interface{})
		client, err := h.clusterClientManager.GetClientFromCache(cluster)
		if err != nil {
			log.Errorf("failed to get cluster client: %v", err)
			continue
		}

		cm, err := client.CoreV1().ConfigMaps(h.ResourcesC.Namespace).Get(ctx, h.ResourcesC.Name, metav1.GetOptions{})
		if err != nil {
			log.Errorf("failed to get configmap %s/%s error: %v", h.ResourcesC.Namespace, h.ResourcesC.Name, err)
			continue
		}

		nsSet := sets.NewString(namespaces...)
		nsResMap := make(map[string]interface{})
		if vStr, ok := cm.Data["resourcescounter"]; ok {
			nsMap := make(map[string]interface{})
			if err := json.Unmarshal([]byte(vStr), &nsMap); err != nil {
				log.Errorf("failed to json unmashal %s error: %v", vStr, err)
				continue
			}
			for n, v := range nsMap {
				if !nsSet.Has(n) {
					continue
				}
				nsResMap[n] = v
			}
		}
		resMap[cluster] = nsResMap
	}

	c.JSON(200, resMap)
	return
}

// 根据集群ID和命名空间列表获取资源配额信息
func (h *handler) getQuotaCountInfo(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get resource quota information")
	defer span.Finish()

	namespaces := c.QueryArray("namespaces")
	clusters := c.QueryArray("clusters")

	resMap := make(map[string]interface{})
	for _, cluster := range clusters {
		resMap[cluster] = make(map[string]interface{})
		client, err := h.clusterClientManager.GetClientFromCache(cluster)
		if err != nil {
			log.Errorf("failed to get cluster client: %v", err)
			continue
		}

		cm, err := client.CoreV1().ConfigMaps(h.ResourcesC.Namespace).Get(ctx, h.ResourcesC.Name, metav1.GetOptions{})
		if err != nil {
			log.Errorf("failed to get configmap %s/%s error: %v", h.ResourcesC.Namespace, h.ResourcesC.Name, err)
			continue
		}
		nsMap := make(map[string]interface{})
		if vStr, ok := cm.Data["quota"]; ok {
			r := gjson.Parse(vStr)
			for _, namespace := range namespaces {
				if r.Get(namespace).Value() != nil {
					nsMap[namespace] = r.Get(namespace).Value()
				}
			}
		}
		resMap[cluster] = nsMap
	}

	c.JSON(200, resMap)
	return
}
