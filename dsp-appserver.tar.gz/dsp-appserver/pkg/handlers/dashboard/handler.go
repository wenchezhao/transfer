package dashboard

import (
	"github.com/gin-gonic/gin"

	"github.com/daocloud/dsp-appserver/pkg/config"
	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
)

var log = logi.Log.Sugar()

type handler struct {
	ResourcesC           *config.ResourcesCounter
	clusterClientManager *multicluster.ClusterClientManager
}

func InstallHandlers(routerGroup *gin.RouterGroup, clusterClientManager *multicluster.ClusterClientManager, resourceC *config.ResourcesCounter) {
	h := &handler{
		clusterClientManager: clusterClientManager,
		ResourcesC:           resourceC,
	}

	routerGroup.GET("/v1/dashboard/clustercount", h.getClusterCountInfo)    // 获取集群概览
	routerGroup.GET("/v1/dashboard/resourcecount", h.getResourcesCountInfo) // 返回系统资源数量统计信息
	routerGroup.GET("/v1/dashboard/quotacount", h.getQuotaCountInfo)        // 返回系统资源信息
}
