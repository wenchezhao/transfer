package cloudshell

import "github.com/gin-gonic/gin"

func (h *CloudshellImp) GetCloudshell(c *gin.Context) {
	c.JSON(200, "OK")
}

func (h *CloudshellImp) CreateCloudshell(c *gin.Context) {
	c.JSON(200, "ok")
}
