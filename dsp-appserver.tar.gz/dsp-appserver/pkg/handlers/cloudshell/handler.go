package cloudshell

import (
	cloudshellclient "github.com/cloudtty/cloudtty/pkg/generated/clientset/versioned"
	"github.com/gin-gonic/gin"

	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/services/cloudshell"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
)

var log = logi.Log.Sugar()

type CloudshellHandler interface {
	GetCloudshell(c *gin.Context)
	CreateCloudshell(c *gin.Context)
}

type CloudshellImp struct {
	Service cloudshell.Services
}

func NewCloudShellHandler(kubeclient kubeclient.Client, pclient pedia.Clients, factory informers.SharedInformerFactory, clusterClient clusterclient.ClusterClients) (CloudshellHandler, error) {
	cloudshellclient, err := cloudshellclient.NewForConfig(kubeclient.Config())
	if err != nil {
		return nil, err
	}

	service, err := cloudshell.NewCloudshellServices(cloudshellclient, kubeclient, pclient, factory, clusterClient)
	if err != nil {
		return nil, err
	}
	return &CloudshellImp{Service: service}, nil
}
