package cluster

import (
	"github.com/gin-gonic/gin"

	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"

	"github.com/daocloud/dsp-appserver/pkg/config"
)

var log = logi.Log.Sugar()

type handler struct {
	clusterClientManager *multicluster.ClusterClientManager
	ResourcesC           *config.ResourcesCounter
}

func InstallHandlers(routerGroup *gin.RouterGroup, clusterClientManager *multicluster.ClusterClientManager, resourceC *config.ResourcesCounter) {

	h := &handler{
		clusterClientManager: clusterClientManager,
		ResourcesC:           resourceC,
	}

	routerGroup.POST("/v1/cluster/version", h.zoneVersion)                       // 获取集群版本信息
	routerGroup.GET("/v1/cluster/resptime", h.getClusterRespTime)                // 获取集群响应时间
	routerGroup.GET("/v1/cluster/componentstatus", h.getClusterComponentsStatus) // 获取集群组件状态
	routerGroup.POST("/v1/cluster/join", h.joinCluster)                          // 将集群注册到karmada
	routerGroup.POST("/v1/cluster/unjoin", h.unJoinCluster)                      // 将集群从karmada移除
	routerGroup.GET("/v1/cluster/workloadcluster", h.workloadClusters)           // 获取karmada成员集群
	routerGroup.GET("/v1/cluster/moreinformation", h.clusterMoreInformation)     // 获取集群更多详细信息
}
