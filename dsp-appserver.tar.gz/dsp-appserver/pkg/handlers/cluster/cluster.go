package cluster

import (
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/sets"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	apputil "github.com/daocloud/dsp-appserver/pkg/util/app"
	clusterutil "github.com/daocloud/dsp-appserver/pkg/util/cluster"
)

//DefaultKarmadaClusterNamespace defines the default namespace where the member cluster secrets are stored.
const (
	DefaultKarmadaClusterNamespace = "karmada-cluster"
	DceKeepAlivedLabel             = "loadbalancer.dce.daocloud.io/adapter=keepalived"
)

// 接口提交的集群信息
type Cluster struct {
	ClusterURL               string `json:"clusterUrl"`               // 集群地址
	CertificateAuthorityData []byte `json:"certificateAuthorityData"` // 集群证书
	ClientCertificateData    []byte `json:"clientCertificateData"`    // 用户证书
	ClientKeyData            []byte `json:"clientKeyData"`            // 用户私钥
}

type JoinRequest struct {
	ControlPlaneClusterCode string `json:"karmadaClusterCode,omitempty"` // karmada 集群编码
	ClusterCode             string `json:"clusterCode,omitempty"`        // 注册集群编码
	Provider                string `json:"provider,omitempty"`           // 供应商
	Region                  string `json:"region,omitempty"`             // 地域
	Zone                    string `json:"zone,omitempty"`               // 可用区
}

type ClusterMoreInformation struct {
	Name        string            `json:"name,omitempty"`
	Code        string            `json:"code,omitempty"`
	Type        string            `json:"type,omitempty"`
	RouteIps    []string          `json:"routeIps,omitempty"`
	LoadBalance []*LoadBalance    `json:"loadBalance,omitempty"`
	NotesNameIp map[string]string `json:"notesNameIP,omitempty"`
}

type LoadBalance struct {
	L4VIP     string `json:"l4VIP,omitempty"`
	L7VIP     string `json:"l7VIP,omitempty"`
	HttpPort  string `json:"httpPort,omitempty"`
	HttpsPort string `json:"httpsPort,omitempty"`
}

// 获取集群版本handler,返回{type:"DCE/K8S/OCP",info{}}
func (h *handler) zoneVersion(c *gin.Context) {
	cluster := new(Cluster)

	err := c.BindJSON(cluster)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, fmt.Errorf("failed to get cluster client"))
		return
	}

	version, err := h.getClusterVersion(cluster)
	if err != nil {
		log.Errorf("failed to get cluster version: %v", err)
		common.HandleError(c, 400, fmt.Errorf("failed to get version"))
		return
	}

	// FIXME 目前的情况是只会存在dce ocp 和karmada，如果集群类型探测为k8s，则为karmada
	// 如果集群类型是DCE，直接转换为k8s,这样不破坏底层检测集群类型逻辑
	if version.Type == clientset.DCE {
		version.Type = clientset.K8S
	} else if version.Type == clientset.K8S {
		version.Type = clientset.KARMADA
	}

	c.JSON(http.StatusOK, version)
	return
}

// 根据集群信息获取集群版本
func (h *handler) getClusterVersion(cluster *Cluster) (*clientset.Version, error) {

	clientConfig, err := clientset.NewRestConfig(
		cluster.ClusterURL,
		cluster.CertificateAuthorityData,
		cluster.ClientCertificateData,
		cluster.ClientKeyData,
	)
	if err != nil {
		return nil, err
	}

	client, err := clientset.NewForConfig(clientConfig)
	if err != nil {
		return nil, err
	}

	version, err := client.ClusterVersion("")
	if err != nil {
		return nil, err
	}

	return version, nil
}

//根据集群信息获取集群响应时间
func (h *handler) getClusterRespTime(c *gin.Context) {
	clusters := c.QueryArray("clusters")

	respMap := make(map[string]interface{})

	for _, cluster := range clusters {
		client, err := h.clusterClientManager.GetClientFromCache(cluster)
		if err != nil {
			log.Errorf("failed to get cluster client:%v", err)
			continue
		}
		startTime := time.Now().UnixNano()
		_, err = client.Discovery().ServerVersion()
		if err != nil {
			log.Errorf("failed to get cluster server:%v", err)
			continue
		}
		endTime := time.Now().UnixNano()
		respMap[cluster] = endTime - startTime
	}

	c.JSON(http.StatusOK, respMap)
}

//获取集群组件部署状态
func (h *handler) getClusterComponentsStatus(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get clientComponents status")
	defer span.Finish()

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err.Error())
		common.HandleError(c, 500, err)
		return
	}

	deploySet := sets.NewString("ccnp-cluster-controller", "grafana", "alertmanager-fingerprint-webhook")

	gvr := schema.GroupVersionResource{
		Group:    "apps",
		Version:  "v1",
		Resource: "deployments",
	}
	deployList, err := client.Resource(gvr).Namespace(h.ResourcesC.Namespace).List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to list deployment:%v", err.Error())
	}

	resMap := make(map[string]string)
	for _, deploy := range deployList.Items {
		if !deploySet.Has(deploy.GetName()) {
			continue
		}
		status, err := apputil.Status(&deploy)
		if err != nil {
			continue
		}
		resMap[deploy.GetName()] = status
	}

	c.JSON(200, resMap)
}

// 将集群注册到karmada
func (h *handler) joinCluster(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "join cluster to karmada control")
	defer span.Finish()

	// get join information from body
	joinRequest := JoinRequest{}
	if err := c.BindJSON(&joinRequest); err != nil {
		log.Errorf("failed to bind json: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	// fetch the member cluster information from database
	clusterInfo, err := h.clusterClientManager.FetchTiZone(joinRequest.ClusterCode)
	if err != nil {
		log.Errorf("failed to query cluster %s information: %v", joinRequest.ClusterCode, err)
		common.HandleError(c, 500, err)
		return
	}

	// fetch the controlPlane cluster information from database
	controlPlaneClusterInfo, err := h.clusterClientManager.FetchTiZone(joinRequest.ControlPlaneClusterCode)
	if err != nil {
		log.Errorf("failed to query cluster %s information: %v", joinRequest.ControlPlaneClusterCode, err)
		common.HandleError(c, 500, err)
		return
	}

	if IsControlPlaneCluster(clusterInfo.Type) {
		log.Errorf("join cluster %s type is %s, can not register to controlPlane", clusterInfo.Clustername, clusterInfo.Type)
		common.HandleError(c, 400, fmt.Errorf("join cluster %s type is %s, can not register to controlPlane", clusterInfo.Clustername, clusterInfo.Type))
		return
	}

	if !IsControlPlaneCluster(controlPlaneClusterInfo.Type) {
		log.Errorf("controlplane cluster %s type is %s, can not register to controlPlane", controlPlaneClusterInfo.Clustername, controlPlaneClusterInfo.Type)
		common.HandleError(c, 400, fmt.Errorf("join cluster %s type is %s, can not register to controlPlane", controlPlaneClusterInfo.Clustername, controlPlaneClusterInfo.Type))
		return
	}

	clusterKubeClient, err := h.clusterClientManager.Client(clusterInfo.Clusterid)
	if err != nil {
		log.Errorf("failed to get client for cluster %s : %v", clusterInfo.Clusterid, err)
		common.HandleError(c, 500, err)
		return
	}

	controlPlaneKubeClient, err := h.clusterClientManager.Client(controlPlaneClusterInfo.Clusterid)
	if err != nil {
		log.Errorf("failed to get cluster client for cluster %s : %v", controlPlaneClusterInfo.Clusterid, err)
		common.HandleError(c, 500, err)
		return
	}

	opts := clusterutil.JoinOptions{
		ControlPlaneKubeClient: controlPlaneKubeClient,
		ClusterKubeClient:      clusterKubeClient,
		Namespace:              DefaultKarmadaClusterNamespace,
		Provider:               joinRequest.Provider,
		Region:                 joinRequest.Region,
		Zone:                   joinRequest.Zone,
		DisplayName:            clusterInfo.Clustername,
		Name:                   clusterInfo.Clusterid,
		Type:                   clusterInfo.Type,
		Grafana:                clusterInfo.Grafana,
		MasterUrl:              clusterInfo.Clusterurl,
	}
	cluster, err := opts.JoinCluster()
	if err != nil {
		log.Errorf("failed to join cluster %s error: %v", clusterInfo.Clusterid, err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, cluster)
}

// 将集群从karmada移除
func (h *handler) unJoinCluster(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "unjoin cluster from karmada control")
	defer span.Finish()

	joinRequest := JoinRequest{}
	if err := c.BindJSON(&joinRequest); err != nil {
		log.Errorf("failed to bind json: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	controlPlaneClusterInfo, err := h.clusterClientManager.FetchTiZone(joinRequest.ControlPlaneClusterCode)
	if err != nil {
		log.Errorf("failed to query cluster %s information: %v", joinRequest.ControlPlaneClusterCode, err)
		common.HandleError(c, 500, err)
		return
	}

	if !IsControlPlaneCluster(controlPlaneClusterInfo.Type) {
		log.Errorf("controlplane cluster %s type is %s, can not register to controlPlane", controlPlaneClusterInfo.Clustername, controlPlaneClusterInfo.Type)
		common.HandleError(c, 400, fmt.Errorf("unjoin cluster %s type is %s, can not register to controlPlane", controlPlaneClusterInfo.Clustername, controlPlaneClusterInfo.Type))
		return
	}

	controlPlaneKubeClient, err := h.clusterClientManager.Client(controlPlaneClusterInfo.Clusterid)
	if err != nil {
		log.Errorf("failed to get cluster client for cluster %s : %v", controlPlaneClusterInfo.Clusterid, err)
		common.HandleError(c, 500, err)
		return
	}

	opts := &clusterutil.UnJoinOptions{
		ControlPlaneKubeClient: controlPlaneKubeClient,
		Namespace:              DefaultKarmadaClusterNamespace,
		Name:                   joinRequest.ClusterCode,
	}

	if err := opts.UnJoinCluster(); err != nil {
		log.Errorf("failed to unjoin cluster %s error: %v", joinRequest.ClusterCode, err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, struct{}{})
}

// list the cluster workload cluster
func (h *handler) workloadClusters(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "list workload cluster")
	defer span.Finish()

	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err.Error())
		common.HandleError(c, 500, err)
		return
	}

	clusters, err := clusterutil.ListClusters(client, labelSelector)
	if err != nil {
		log.Errorf("failed to list workload cluster error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, clusters)
	return
}

// all controlPlane type must be karmada
func IsControlPlaneCluster(clusterType string) bool {
	if strings.ToUpper(clusterType) == clientset.KARMADA {
		return true
	}
	return false
}

func (h *handler) clusterMoreInformation(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get cluster more information")
	defer span.Finish()

	clusterID := c.GetHeader("clusterID")

	clusterInfo, err := h.clusterClientManager.FetchTiZone(clusterID)
	if err != nil {
		log.Errorf("failed to query cluster %s information: %v", clusterID, err)
		common.HandleError(c, 500, err)
		return
	}

	clusterClient, err := h.clusterClientManager.GetClientFromCache(clusterID)
	if err != nil {
		log.Errorf("failed to get cluster %s client: %v", clusterID, err)
		common.HandleError(c, 500, err)
		return
	}

	cluster := ClusterMoreInformation{
		Name:        clusterInfo.Clustername,
		Code:        clusterInfo.Clusterid,
		Type:        clusterInfo.Type,
		NotesNameIp: make(map[string]string),
	}

	nodeList, err := clusterClient.CoreV1().Nodes().List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to list node: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	for _, node := range nodeList.Items {
		for _, addr := range node.Status.Addresses {
			if addr.Type != corev1.NodeInternalIP {
				continue
			}
			cluster.NotesNameIp[node.Name] = addr.Address
			if clusterInfo.Type == clientset.OCP {
				var l labels.Set
				l = node.Labels
				if l.Get("router") == "true" {
					cluster.RouteIps = append(cluster.RouteIps, addr.Address)
				}
			}
			break
		}
	}

	if clusterInfo.Type == clientset.K8S {
		deployList, err := clusterClient.AppsV1().Deployments("kube-system").List(ctx, metav1.ListOptions{
			LabelSelector: DceKeepAlivedLabel,
		})
		if err != nil {
			log.Errorf("failed to get keepalived deployment: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		for _, deploy := range deployList.Items {
			lb := LoadBalance{}
			annnotations := deploy.Spec.Template.Annotations
			if val, ok := annnotations["io.daocloud/dce.keepalived.l4.vip"]; ok {
				lb.L4VIP = val
			}
			if val, ok := annnotations["io.daocloud/dce.keepalived.l7.vip"]; ok {
				lb.L7VIP = val
			}
			if val, ok := annnotations["io.daocloud/dce.keepalived.l7-http-port"]; ok {
				lb.HttpPort = val
			}
			if val, ok := annnotations["io.daocloud/dce.keepalived.l7-https-port"]; ok {
				lb.HttpsPort = val
			}
			cluster.LoadBalance = append(cluster.LoadBalance, &lb)
		}
	}

	c.JSON(200, cluster)
}
