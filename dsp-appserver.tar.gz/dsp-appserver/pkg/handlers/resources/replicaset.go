package resources

import (
	"github.com/gin-gonic/gin"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/kubectl/pkg/scheme"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

func (h *handler) listEventOfReplicaSet(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list events of replicaSet")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	replicaSet, err := client.AppsV1().ReplicaSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get replicaSet: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	eventList, err := client.CoreV1().Events(namespace).Search(scheme.Scheme, replicaSet)
	if err != nil {
		log.Errorf("failed to get events: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	eventList.APIVersion = "v1"
	eventList.Kind = "List"
	for index := range eventList.Items {
		eventList.Items[index].APIVersion = "v1"
		eventList.Items[index].Kind = "Event"
	}
	c.JSON(200, eventList)

}
