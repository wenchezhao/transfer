package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"
	batchv1 "k8s.io/api/batch/v1"
	v1beta1 "k8s.io/api/batch/v1beta1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/kubernetes/scheme"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

func (h *handler) createCronJob(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create CronJob")
	defer span.Finish()

	namespace := c.Param("namespace")

	cjRequest := v1beta1.CronJob{}
	err := c.BindJSON(&cjRequest)
	if err != nil {
		log.Errorf("failed to get CronJob request Body : %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cronJob, err := client.BatchV1beta1().CronJobs(namespace).Create(ctx, &cjRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to create CronJob : %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cronJob.APIVersion = "batch/v1beta1"
	cronJob.Kind = "CronJob"

	c.JSON(200, cronJob)
	return
}

func (h *handler) updateCronJob(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update CronJob")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	cjRequest := v1beta1.CronJob{}
	err := c.BindJSON(&cjRequest)
	if err != nil {
		log.Errorf("failed to get CronJob request Body : %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	oldCronJob, err := client.BatchV1beta1().CronJobs(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get CronJob : %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cjRequest.ResourceVersion = oldCronJob.ResourceVersion

	cronJob, err := client.BatchV1beta1().CronJobs(namespace).Update(ctx, &cjRequest, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update CronJob : %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cronJob.APIVersion = "batch/v1beta1"
	cronJob.Kind = "CronJob"

	c.JSON(200, cronJob)
	return
}

func (h *handler) getCronJob(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get cronjob")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cj, err := client.BatchV1beta1().CronJobs(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get cronjob: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cj.APIVersion = "batch/v1beta1"
	cj.Kind = "CronJob"

	c.JSON(200, cj)
}

func (h *handler) getCronJobEvents(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get cronjob evnents")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cj, err := client.BatchV1beta1().CronJobs(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get cronjob: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	eventList, err := client.CoreV1().Events(namespace).Search(scheme.Scheme, cj)
	if err != nil {
		log.Errorf("failed to get cronjob events: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	eventList.APIVersion = "v1"
	eventList.Kind = "List"
	for index := range eventList.Items {
		eventList.Items[index].APIVersion = "v1"
		eventList.Items[index].Kind = "Event"
	}

	c.JSON(200, eventList)
}

func (h *handler) listCronJob(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list cronjob")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	gvr := schema.GroupVersionResource{Group: "batch", Version: "v1beta1", Resource: "cronjobs"}
	if informer != nil && informer.IsInformerSynced(gvr) {
		l, err := labels.Parse(labelSelector)
		if err != nil {
			log.Errorf("failed to parse labelSelector: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		results, err := informer.Lister(gvr).ByNamespace(namespace).List(l)
		if err != nil {
			log.Errorf("informer failed to list cronjob: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		c.JSON(200, map[string]interface{}{
			"kind":       "List",
			"apiVersion": "v1",
			"items":      results,
		})
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cjs, err := client.BatchV1beta1().CronJobs(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to list cronjob: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cjs.Kind = "List"
	cjs.APIVersion = "v1"
	for index := range cjs.Items {
		cjs.Items[index].APIVersion = "batch/v1beta1"
		cjs.Items[index].Kind = "CronJob"
	}

	c.JSON(200, cjs)
}

func (h *handler) deleteCronJob(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete cronjob")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	policy := metav1.DeletePropagationBackground
	var deleteOptions metav1.DeleteOptions
	deleteOptions.PropagationPolicy = &policy
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}
	if err := client.BatchV1beta1().CronJobs(namespace).Delete(ctx, name, deleteOptions); err != nil {
		log.Errorf("failed to delete cronjob: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, struct{}{})
}

func (h *handler) listJobForCJ(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list jobs of a cronjob")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cj, err := client.BatchV1beta1().CronJobs(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get cronjob: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	jsResp, err := client.BatchV1().Jobs(namespace).List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to list job: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	js := &batchv1.JobList{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "v1",
			Kind:       "List",
		},
		Items: []batchv1.Job{},
	}

	for _, job := range jsResp.Items {
		if metav1.IsControlledBy(&job, cj) {
			job.APIVersion = "batch/v1"
			job.Kind = "Job"
			js.Items = append(js.Items, job)
		}
	}

	c.JSON(200, js)
}
