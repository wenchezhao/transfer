package resources

import (
	"github.com/gin-gonic/gin"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/kubectl/pkg/scheme"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

func (h *handler) listReplicationController(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list rc")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	replicationController, err := client.CoreV1().ReplicationControllers(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to list replicationController: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	replicationController.APIVersion = "v1"
	replicationController.Kind = "List"
	for index := range replicationController.Items {
		replicationController.Items[index].Kind = "ReplicationController"
		replicationController.Items[index].APIVersion = "v1"
	}
	c.JSON(200, replicationController)
}

func (h *handler) listEventOfReplicationController(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list events of rc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	replicationController, err := client.CoreV1().ReplicationControllers(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get replicationController: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	eventList, err := client.CoreV1().Events(namespace).Search(scheme.Scheme, replicationController)
	if err != nil {
		log.Errorf("failed to get events: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	eventList.APIVersion = "v1"
	eventList.Kind = "List"
	for index := range eventList.Items {
		eventList.Items[index].APIVersion = "v1"
		eventList.Items[index].Kind = "Event"
	}
	c.JSON(200, eventList)

}
