package resources

import (
	"github.com/gin-gonic/gin"

	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	monitoringv1 "github.com/prometheus-operator/prometheus-operator/pkg/apis/monitoring/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

// list listPrometheusRuleNamespaces
func (h *handler) listPrometheusRuleNamespaces(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list namespaces selected by prometheus rules")
	defer span.Finish()

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	prometheuses, err := client.MonitoringV1().Prometheuses(metav1.NamespaceAll).List(ctx, metav1.ListOptions{})
	if err != nil {
		if !kapierrors.IsNotFound(err) {
			log.Errorf("failed to list prometheus: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		c.JSON(200, []string{})
		return
	}
	if len(prometheuses.Items) == 0 {
		c.JSON(200, []string{})
		return
	}

	prometheus := prometheuses.Items[0]
	if prometheus.Spec.RuleNamespaceSelector == nil {
		c.JSON(200, []string{prometheus.Namespace})
		return
	}

	ruleNamespaceSelector, err := metav1.LabelSelectorAsSelector(prometheus.Spec.RuleNamespaceSelector)
	if err != nil {
		log.Errorf("failed to get ruleNamespaceSelector: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	nsList, err := client.CoreV1().Namespaces().List(ctx, metav1.ListOptions{
		LabelSelector: ruleNamespaceSelector.String(),
	})
	if err != nil {
		log.Errorf("failed to list namespaces: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	namespaces := []string{}
	for _, ns := range nsList.Items {
		namespaces = append(namespaces, ns.Name)
	}
	c.JSON(200, namespaces)
}

// list prometheus rules
func (h *handler) listPrometheusRule(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list prometheus rules")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	prometheuses, err := client.MonitoringV1().PrometheusRules(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("get configmapList error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	prometheuses.APIVersion = "v1"
	prometheuses.Kind = "List"
	for index := range prometheuses.Items {
		prometheuses.Items[index].Kind = "PrometheusRule"
		prometheuses.Items[index].APIVersion = "monitoring.coreos.com/v1"
	}

	c.JSON(200, prometheuses)
}

// get prometheus rule
func (h *handler) getPrometheusRule(c *gin.Context) {

	span, ctx := utiltrace.StartSpanFromGin(c, "get prometheus rule")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	rules, err := client.MonitoringV1().PrometheusRules(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("get prometheus rule error :%v", err)
		common.HandleError(c, 500, err)
		return
	}

	rules.Kind = "PrometheusRule"
	rules.APIVersion = "monitoring.coreos.com/v1"

	c.JSON(200, rules)
}

// create prometheus rule
func (h *handler) createPrometheusRule(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create prometheus rule")
	defer span.Finish()

	namespace := c.Param("namespace")

	ruleRequest := &monitoringv1.PrometheusRule{}
	err := c.BindJSON(ruleRequest)
	if err != nil {
		log.Errorf("get requestBody error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	// force namespace
	ruleRequest.Namespace = namespace

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	rule, err := client.MonitoringV1().PrometheusRules(namespace).Create(ctx, ruleRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("create prometheus rule error %v", err)
		common.HandleError(c, 500, err)
		return
	}

	rule.Kind = "PrometheusRule"
	rule.APIVersion = "monitoring.coreos.com/v1"
	c.JSON(200, rule)
}

func (h *handler) deletePrometheusRule(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete prometheus rule")
	defer span.Finish()
	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	err = client.MonitoringV1().PrometheusRules(namespace).Delete(ctx, name, metav1.DeleteOptions{})
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
			return
		} else {
			log.Errorf("delete prometheus rule error: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	}
	c.JSON(200, struct{}{})
}

func (h *handler) updatePrometheusRule(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update prometheus rule")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	rule := &monitoringv1.PrometheusRule{}
	err := c.BindJSON(rule)
	if err != nil {
		log.Errorf("error requestBody: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	got, err := client.MonitoringV1().PrometheusRules(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get prometheus rule: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	rule.ResourceVersion = got.ResourceVersion
	updated, err := client.MonitoringV1().PrometheusRules(namespace).Update(ctx, rule, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update prometheus rule: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	updated.Kind = "PrometheusRule"
	updated.APIVersion = "monitoring.coreos.com/v1"
	c.JSON(200, updated)

}
