package resources

import (
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
	corev1 "k8s.io/api/core/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/kubectl/pkg/scheme"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	serviceutil "github.com/daocloud/dsp-appserver/pkg/util/service"
)

func (h *handler) listService(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list svc")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	gvr := schema.GroupVersionResource{Group: "", Version: "v1", Resource: "services"}
	if informer != nil && informer.IsInformerSynced(gvr) {
		l, err := labels.Parse(labelSelector)
		if err != nil {
			log.Errorf("failed to parse labelSelector: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		results, err := informer.Lister(gvr).ByNamespace(namespace).List(l)
		if err != nil {
			log.Errorf("informer failed to list services: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		c.JSON(200, map[string]interface{}{
			"kind":       "List",
			"apiVersion": "v1",
			"items":      results,
		})
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	serviceList, err := client.CoreV1().Services(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	serviceList.Kind = "List"
	serviceList.APIVersion = "v1"

	for index := range serviceList.Items {
		serviceList.Items[index].APIVersion = "v1"
		serviceList.Items[index].Kind = "Service"
	}
	c.JSON(200, serviceList)

}

func (h *handler) getService(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get svc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	service, err := client.CoreV1().Services(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	service.APIVersion = "v1"
	service.Kind = "Service"
	c.JSON(200, service)
}

func (h *handler) createService(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create svc")
	defer span.Finish()

	namespace := c.Param("namespace")

	serviceRequest := &corev1.Service{}
	err := c.BindJSON(serviceRequest)
	if err != nil {
		log.Errorf("failed to get service request body: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	// force namespace
	serviceRequest.Namespace = namespace

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	// check service nodePort, can not be null and not exit
	if serviceRequest.Spec.Type == corev1.ServiceTypeNodePort {
		for _, port := range serviceRequest.Spec.Ports {
			if port.NodePort == 0 {
				log.Errorf("the service type is NodePort, so spec.ports.nodePort filed can not be null")
				common.HandleError(c, 400, fmt.Errorf("the service type is NodePort, so nodePort filed can not be null"))
				return
			}
			err = serviceutil.CheckServiceNodePort(ctx, client, fmt.Sprint(port.NodePort))
			if err != nil {
				log.Errorf("nodePort %s  is conflict", port)
				common.HandleError(c, 400, err)
				return
			}
		}
	}

	service, err := client.CoreV1().Services(namespace).Create(ctx, serviceRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to create service : %v", err)
		common.HandleError(c, 500, err)
		return
	}
	service.APIVersion = "v1"
	service.Kind = "Service"
	c.JSON(200, service)
}

func (h *handler) updateService(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update svc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	serviceRequest := &corev1.Service{}

	err := c.BindJSON(serviceRequest)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	// check service nodePort, can not be null and not exit
	if serviceRequest.Spec.Type == corev1.ServiceTypeNodePort {
		for _, port := range serviceRequest.Spec.Ports {
			if port.NodePort == 0 {
				log.Errorf("the service type is NodePort, so spec.ports.nodePort filed can not be null")
				common.HandleError(c, 400, fmt.Errorf("the service type is NodePort, so nodePort filed can not be null"))
				return
			}
			err = serviceutil.CheckServiceNodePort(ctx, client, fmt.Sprint(port.NodePort))
			if err != nil {
				log.Errorf("nodePort %s  is conflict", port)
				common.HandleError(c, 400, err)
				return
			}
		}
	}

	service, err := client.CoreV1().Services(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	serviceRequest.ResourceVersion = service.ResourceVersion
	serviceRequest.Spec.ClusterIP = service.Spec.ClusterIP
	updateService, err := client.CoreV1().Services(namespace).Update(ctx, serviceRequest, metav1.UpdateOptions{})
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	updateService.APIVersion = "v1"
	updateService.Kind = "Service"
	c.JSON(200, updateService)
}

func (h *handler) deleteService(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete svc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}
	err = client.CoreV1().Services(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		log.Errorf("failed to delete service : %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, struct{}{})
}

func (h *handler) listServiceEvent(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list events of svc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	service, err := client.CoreV1().Services(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}

	eventList, err := client.CoreV1().Events(namespace).Search(scheme.Scheme, service)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	eventList.APIVersion = "v1"
	eventList.Kind = "List"
	for index := range eventList.Items {
		eventList.Items[index].APIVersion = "v1"
		eventList.Items[index].Kind = "Event"
	}

	c.JSON(200, eventList)
}

func (h *handler) listServiceTrafficObject(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "list route or ingress of svc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	objs := []metav1.Object{}

	if _, err := client.ClusterVersion(clientset.OCP); err == nil {
		routes, err := serviceutil.ListRoute(client.OpenshiftRouteV1(), namespace, name)
		if err != nil && !kapierrors.IsNotFound(err) {
			common.HandleError(c, 500, err)
			return
		}
		for index := range routes {
			objs = append(objs, &routes[index])
		}
	}

	ings, err := serviceutil.ListIngress(client, namespace, name)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	for index := range ings {
		objs = append(objs, &ings[index])
	}

	c.JSON(200, objs)
}

func (h *handler) listServiceRoute(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list route of svc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	routeList, err := client.OpenshiftRouteV1().Routes(namespace).List(ctx, metav1.ListOptions{
		FieldSelector: fmt.Sprintf("spec.to.name=%s", name),
	})

	if err != nil {
		common.HandleError(c, 500, err)
		return
	}

	routeList.APIVersion = "v1"
	routeList.Kind = "List"
	for index := range routeList.Items {
		routeList.Items[index].APIVersion = "v1"
		routeList.Items[index].Kind = "Route"
	}

	c.JSON(200, routeList)
}

func (h *handler) listServicePod(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list pods of svc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	service, err := client.CoreV1().Services(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}

	if len(service.Spec.Selector) == 0 {
		var podList corev1.PodList
		podList.APIVersion = "v1"
		podList.Kind = "List"
		podList.Items = []corev1.Pod{}
		c.JSON(200, podList)
		return
	}

	selector := &metav1.LabelSelector{
		MatchLabels: service.Spec.Selector,
	}
	labelSelector, err := metav1.LabelSelectorAsSelector(selector)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}

	podList, err := client.CoreV1().Pods(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector.String(),
	})
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}

	podList.APIVersion = "v1"
	podList.Kind = "List"
	for index := range podList.Items {
		podList.Items[index].APIVersion = "v1"
		podList.Items[index].Kind = "Pod"
	}

	c.JSON(200, podList)
}
