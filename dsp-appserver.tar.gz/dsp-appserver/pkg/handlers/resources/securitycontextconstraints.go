package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"
	securityv1 "github.com/openshift/api/security/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

func (h *handler) createSecurityContextConstraints(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create SecurityContextConstraints")
	defer span.Finish()

	sscRequest := &securityv1.SecurityContextConstraints{}
	err := c.BindJSON(sscRequest)
	if err != nil {
		log.Errorf("failed to bind json ssc request: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	scc, err := client.OpenshiftSecurityV1().SecurityContextConstraints().Create(ctx, sscRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to create SecurityContextConstraints: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	scc.APIVersion = "security.openshift.io/v1"
	scc.Kind = "SecurityContextConstraints"
	c.JSON(200, scc)
}

func (h *handler) updateSecurityContextConstraints(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update SecurityContextConstraints")
	defer span.Finish()

	name := c.Param("name")

	sscRequest := &securityv1.SecurityContextConstraints{}
	err := c.BindJSON(sscRequest)
	if err != nil {
		log.Errorf("failed to bind json ssc request:%v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	scc, err := client.OpenshiftSecurityV1().SecurityContextConstraints().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get SecurityContextConstraints: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	sscRequest.ResourceVersion = scc.ResourceVersion
	updateScc, err := client.OpenshiftSecurityV1().SecurityContextConstraints().Update(ctx, sscRequest, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update scc: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	updateScc.Kind = "SecurityContextConstraints"
	updateScc.APIVersion = "security.openshift.io/v1"
	c.JSON(200, updateScc)
}

func (h *handler) getSecurityContextConstraints(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get SecurityContextConstraints")
	defer span.Finish()

	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	scc, err := client.OpenshiftSecurityV1().SecurityContextConstraints().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get SecurityContextConstraints: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	scc.APIVersion = "security.openshift.io/v1"
	scc.Kind = "SecurityContextConstraints"
	c.JSON(200, scc)
}

func (h *handler) listSecurityContextConstraints(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list SecurityContextConstraints")
	defer span.Finish()

	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	sccList, err := client.OpenshiftSecurityV1().SecurityContextConstraints().List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to get SecurityContextConstraints: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	sccList.APIVersion = "v1"
	sccList.Kind = "List"
	for index := range sccList.Items {
		sccList.Items[index].APIVersion = "security.openshift.io/v1"
		sccList.Items[index].Kind = "SecurityContextConstraints"
	}
	c.JSON(200, sccList)
}

func (h *handler) deleteSecurityContextConstraints(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete SecurityContextConstraints")
	defer span.Finish()

	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}

	err = client.OpenshiftSecurityV1().SecurityContextConstraints().Delete(ctx, name, deleteOptions)
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
		} else {
			log.Errorf("failed to delete SecurityContextConstraints: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	} else {
		c.JSON(200, struct{}{})
	}

}
