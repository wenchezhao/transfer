package resources

import (
	"strconv"

	discoveryutil "github.com/daocloud/dsp-appserver/pkg/util/discovery"
	"github.com/gin-gonic/gin"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

var (
	gvr = schema.GroupVersionResource{
		Group:    "inplaceset.cib.io",
		Version:  "v1beta1",
		Resource: "cibdeployments",
	}
)

//判断cibDeployment资源是否存在
func (h *handler) getCibDeploymentCRD(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "getCibDeploymentCRD")
	defer span.Finish()

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client:%v", err)
		common.HandleError(c, 500, err)
		return
	}
	//这里使用gvk来获取资源，因为在client-go版本中根本不存在cibdeployment资源对象的client封装
	//https://github.com/kubernetes/kubernetes/pull/63797/files
	gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), schema.GroupVersionKind{
		Group:   "apiextensions.k8s.io",
		Version: "v1beta1",
		Kind:    "CustomResourceDefinition",
	})
	if err != nil {
		log.Errorf("failed to get gvr error:%v", err)
		common.HandleError(c, 410, err)
		return
	}
	_, err = client.Resource(gvr).Get(ctx, "cibdeployments.inplaceset.cib.io", metav1.GetOptions{})
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, false)
			return
		}
		log.Errorf("failed to list cibdeployment by gvr:%v, error:%v", gvr, err)
		common.HandleError(c, 410, err)
		return
	}
	c.JSON(200, true)
}

//获取cibDeployment列表
func (h *handler) listCibDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list cibDeployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client:%v", err)
		common.HandleError(c, 500, err)
		return
	}

	cibdeployList, err := client.Resource(gvr).Namespace(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to list cibdeployments by gvr:%v,error:%v", gvr, err)
		common.HandleError(c, 410, err)
		return
	}
	c.JSON(200, cibdeployList)
}

//获取某个特定的cibDeployment
func (h *handler) getCibDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get cibDeployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client:%v", err)
		common.HandleError(c, 500, err)
		return
	}

	cibdeploy, err := client.Resource(gvr).Namespace(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get cibdeployments by gvr:%v,error:%v", gvr, err)
		common.HandleError(c, 410, err)
		return
	}
	c.JSON(200, cibdeploy)
}

//创建cibDeployment
func (h *handler) createCibDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create cibDeployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	request := &unstructured.Unstructured{}
	err := c.BindJSON(request)
	if err != nil {
		log.Errorf("error requestbody:%v", err)
		common.HandleError(c, 500, err)
		return
	}
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client:%v", err)
		common.HandleError(c, 500, err)
		return
	}

	cibdeploy, err := client.Resource(gvr).Namespace(namespace).Create(ctx, request, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to create cibdeployments by gvr:%v,error:%v", gvr, err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, cibdeploy)
}

//更新指定的cibDeployment
func (h *handler) updateCibDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update cibDeployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	request := &unstructured.Unstructured{}
	err := c.BindJSON(request)
	if err != nil {
		log.Errorf("error requestBody:%v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client:%v", err)
		common.HandleError(c, 500, err)
		return
	}
	//获取当前cibdeployment的版本信息
	cibDeploymentInfo, err := client.Resource(gvr).Namespace(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get cibdeployments by gvr:%v,error:%v", gvr, err)
		common.HandleError(c, 500, err)
		return
	}
	request.SetResourceVersion(cibDeploymentInfo.GetResourceVersion())

	//更新cibDeployment
	cibdeployment, err := client.Resource(gvr).Namespace(namespace).Update(ctx, request, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update cibdeployments :%v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, cibdeployment)
}

//删除指定的cibDeployment
func (h *handler) deleteCibDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete cibDeployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client:%v", err)
		common.HandleError(c, 500, err)
		return
	}
	policy := metav1.DeletePropagationBackground
	var deleteOptions metav1.DeleteOptions
	deleteOptions.PropagationPolicy = &policy
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise != nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}
	err = client.Resource(gvr).Namespace(namespace).Delete(ctx, name, deleteOptions)
	if err != nil && !kapierrors.IsNotFound(err) {
		log.Errorf("failed to delete cibdeployments :%v", err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, struct{}{})
}
