package resources

import (
	"fmt"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/types"
	utilerrors "k8s.io/apimachinery/pkg/util/errors"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/client-go/tools/reference"
	"k8s.io/kubectl/pkg/scheme"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	"github.com/daocloud/dsp-appserver/pkg/util/drain"
)

// listAllNodeLabels return a label set for some nodes.
// It skips all the master node and drops all the built-in labels
// that contains a 'kubernetes.io' suffix in a label's key or
// in a prefix of a label's key.
func (h *handler) listAllNodeLabels(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list all node labels")
	defer span.Finish()

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	nodes, err := client.CoreV1().Nodes().List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to list nodes: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	labelSet := make(map[string][]string)
	for _, node := range nodes.Items {
		// skip master node
		if labels.Set(node.Labels).Has("node-role.kubernetes.io/master") {
			continue
		}

		for k, v := range node.Labels {
			// drop built-in label
			parts := strings.SplitN(k, "/", 2)
			if strings.HasSuffix(parts[0], "kubernetes.io") {
				continue
			}

			// insert kv pair into the labelSet
			if values, ok := labelSet[k]; ok {
				labelSet[k] = sets.NewString(values...).Insert(v).List()
			} else {
				labelSet[k] = sets.NewString(v).List()
			}
		}
	}

	c.JSON(200, labelSet)
	return

}

// listAllNodeIPs returns a list of IP address of nodes
func (h *handler) listAllNodeIPs(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list all node IP addresses")
	defer span.Finish()

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	nodes, err := client.CoreV1().Nodes().List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to list nodes: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	addrs := make([]string, 0, len(nodes.Items))
	for _, node := range nodes.Items {
		for _, address := range node.Status.Addresses {
			if address.Type == "InternalIP" {
				addrs = append(addrs, address.Address)
			}
		}
	}
	c.JSON(200, addrs)
}

// get node list
func (h *handler) listNode(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list node")
	defer span.Finish()

	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	nodeList, err := client.CoreV1().Nodes().List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to get node list: %+v", err)
		common.HandleError(c, 500, err)
		return
	}

	// add kind and apiVersion
	nodeList.Kind = "List"
	nodeList.APIVersion = "v1"
	for index := range nodeList.Items {
		nodeList.Items[index].APIVersion = "apps/v1"
		nodeList.Items[index].Kind = "Node"
	}

	c.JSON(200, nodeList)
}

// get node detail
func (h *handler) getNode(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get node")
	defer span.Finish()

	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	node, err := client.CoreV1().Nodes().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get node: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	node.Kind = "Node"
	node.APIVersion = "apps/v1"

	c.JSON(200, node)
}

// get node pod list
func (h *handler) getNodePods(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get node pods")
	defer span.Finish()

	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	opts := metav1.ListOptions{FieldSelector: fmt.Sprintf("spec.nodeName=%s", name)}

	podList, err := client.CoreV1().Pods(metav1.NamespaceAll).List(ctx, opts)
	if err != nil {
		log.Errorf("failed to get node pods: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	// add kind and apiVersion
	podList.Kind = "List"
	podList.APIVersion = "v1"
	for index := range podList.Items {
		podList.Items[index].APIVersion = "apps/v1"
		podList.Items[index].Kind = "Pod"
	}

	c.JSON(200, podList)
}

// update node information,include annotation label taint and scheduler
func (h *handler) updateNode(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update node")
	defer span.Finish()

	name := c.Param("name")

	updateNode := &v1.Node{}
	err := c.BindJSON(updateNode)
	if err != nil {
		log.Errorf("get body error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	node, err := client.CoreV1().Nodes().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("fetch node error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	updateNode.ResourceVersion = node.ResourceVersion

	nodeInfo, err := client.CoreV1().Nodes().Update(ctx, updateNode, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update node: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, nodeInfo)
}

// get node event list, pay special attention to get and post method in kubectl
func (h *handler) listEventsOfNode(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get node events")
	defer span.Finish()

	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	node, err := client.CoreV1().Nodes().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("fetch node error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	// see: read-->https://github.com/kubernetes/kubernetes/blob/master/staging/src/k8s.io/kubectl/pkg/describe/describe.go#L3255
	// see: write-->https://github.com/kubernetes/kubernetes/blob/master/pkg/kubelet/kubelet.go#L446
	ref, err := reference.GetReference(scheme.Scheme, node)
	if err != nil {
		log.Errorf("Unable to construct reference to '%#v': %v", node, err)
		common.HandleError(c, 500, err)
		return
	}
	ref.UID = types.UID(ref.Name)

	eventList, err := client.CoreV1().Events(metav1.NamespaceAll).Search(scheme.Scheme, ref)
	if err != nil {
		log.Errorf("failed to get events: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	// add kind and apiVersion
	eventList.APIVersion = "v1"
	eventList.Kind = "List"
	for index := range eventList.Items {
		eventList.Items[index].APIVersion = "v1"
		eventList.Items[index].Kind = "Event"
	}
	c.JSON(200, eventList)
}

func (h *handler) cordonOrUncordonNode(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "cordon or uncordon node")
	defer span.Finish()

	name := c.Param("name")
	unschedulable := c.Query("unschedulable")
	desired := false
	if unschedulable == "true" {
		desired = true
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	node, err := client.CoreV1().Nodes().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("fetch node error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	_, err = drain.RunCordonOrUncordon(client, node, desired)
	if err != nil {
		log.Errorf("cordon or uncordon node %s error: %v", node.Name, err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, struct{}{})
}

func (h *handler) drainNode(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "drain node")
	defer span.Finish()

	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	node, err := client.CoreV1().Nodes().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("fetch node error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	nodeInfo, err := drain.RunCordonOrUncordon(client, node, true)
	if err != nil {
		log.Errorf("cordon node %s error: %v", node.Name, err)
		common.HandleError(c, 500, err)
		return
	}

	// FIXME：这里使用异步操作，原因是节点pod驱逐速度很慢，而接口要求效率，但是没有处理错误
	drainer := drain.NewHelper(client, 60*time.Second)
	go func(drainer *drain.Helper) {
		list, errs := drainer.GetPodsForDeletion(nodeInfo.Name)
		if errs != nil {
			log.Errorf("faile to get pods for deletion: %v", utilerrors.NewAggregate(errs))
			return
		}
		if warnings := list.Warnings(); warnings != "" {
			log.Warnf("WARNING: %s\n", warnings)
		}
		if err := drainer.DeleteOrEvictPods(list.Pods()); err != nil {
			pendingList, newErrs := drainer.GetPodsForDeletion(node.Name)
			if pendingList != nil {
				pods := pendingList.Pods()
				if len(pods) != 0 {
					log.Errorf("There are pending pods in node %q when an error occurred: %v\n", nodeInfo.Name, err)
					for _, pendingPod := range pods {
						log.Errorf("%s/%s\n", "pod", pendingPod.Name)
					}
				}
			}
			if newErrs != nil {
				log.Errorf("Following errors occurred while getting the list of pods to delete:\n%s", utilerrors.NewAggregate(newErrs))
			}
			log.Errorf("filed to evict pod: %v", err)
			return
		}
	}(drainer)

	c.JSON(200, struct{}{})
}
