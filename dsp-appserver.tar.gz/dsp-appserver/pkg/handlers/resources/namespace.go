package resources

import (
	"github.com/gin-gonic/gin"
	corev1 "k8s.io/api/core/v1"
	kerr "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	utilnamespace "github.com/daocloud/dsp-appserver/pkg/util/namespace"
)

type NamespaceRequestParams struct {
	Namespaces []string `json:"namespaces"` // 命名空间列表
	Clusters   []string `json:"clusters"`   // 可用区列表
	SystemCode string   `json:"systemCode"` // 系统唯一标示
}

// bind namespace and create quota
func (h *handler) bindNamespace(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create namespace")
	defer span.Finish()

	params := &NamespaceRequestParams{}
	if err := c.BindJSON(params); err != nil {
		log.Errorf("failed to parse request body: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	// 去每一个集群创建ns
	for _, ID := range params.Clusters {
		client, err := h.clusterClientManager.GetClientFromCache(ID)
		if err != nil {
			log.Errorf("failed to get or create kubernetes client: %v", err)
			common.HandleError(c, 500, err)
			return
		}

		verInfo, err := client.ClusterVersion("")
		if err != nil {
			log.Errorf("failed to get cluster version: %v", err)
			common.HandleError(c, 500, err)
			return
		}

		// 每个集群创建多个ns，并以systemCode为值添加label
		for _, namespace := range params.Namespaces {
			if err := utilnamespace.CreateNamespaceOrProjectIfNotPresent(
				ctx,
				client,
				namespace,
				params.SystemCode,
				verInfo,
			); err != nil {
				log.Errorf("failed to create namespace: %v", err)
				common.HandleError(c, 500, err)
				return
			}

			request := &corev1.ResourceQuota{}
			request.Name = GenericQuotaName
			request.Namespace = namespace
			request.Kind = "ResourceQuota"
			request.APIVersion = "v1"
			zero := resource.MustParse("0")
			request.Spec.Scopes = []corev1.ResourceQuotaScope{"NotBestEffort"}
			request.Spec.Hard = map[corev1.ResourceName]resource.Quantity{
				"limits.cpu":    zero,
				"limits.memory": zero,
			}

			_, err := client.CoreV1().ResourceQuotas(namespace).Get(ctx, request.Name, metav1.GetOptions{})
			if kerr.IsNotFound(err) {
				log.Infof("Creating ResourceQuotas %s/%s.", namespace, request.Name)
				_, err = client.CoreV1().ResourceQuotas(namespace).Create(ctx, request, metav1.CreateOptions{})
				if err != nil {
					log.Errorf("failed to create resourcequota: %v", err)
					common.HandleError(c, 500, err)
					return
				}
			} else if err != nil {
				log.Errorf("failed to get resourcequota: %v", err)
				common.HandleError(c, 500, err)
				return
			}

			request2 := &corev1.ResourceQuota{}
			request2.Name = StorageQuotaName
			request2.Namespace = namespace
			request2.Kind = "ResourceQuota"
			request2.APIVersion = "v1"
			request2.Spec.Hard = map[corev1.ResourceName]resource.Quantity{
				"requests.storage": zero,
			}
			_, err = client.CoreV1().ResourceQuotas(namespace).Get(ctx, request2.Name, metav1.GetOptions{})
			if kerr.IsNotFound(err) {
				log.Infof("Creating ResourceQuotas %s/%s.", namespace, request2.Name)
				_, err = client.CoreV1().ResourceQuotas(namespace).Create(ctx, request2, metav1.CreateOptions{})
				if err != nil {
					log.Errorf("failed to create resourcequota: %v", err)
					common.HandleError(c, 500, err)
					return
				}

			} else if err != nil {
				log.Errorf("failed to get resourcequota: %v", err)
				common.HandleError(c, 500, err)
				return
			}

			// 如果是DCE类型集群，需要更改无法删除的best-effort和删除limitRange
			if verInfo.Type == clientset.DCE {
				go utilnamespace.UpdateDceQuotaAndDeleteDceLimitRange(client, namespace)
			}
		}

	}

	c.JSON(200, struct{}{})
}

func (h *handler) listNamespace(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list namespaces")
	defer span.Finish()

	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	namespaces, err := client.CoreV1().Namespaces().List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to list namespaces: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	namespaces.APIVersion = "v1"
	namespaces.Kind = "List"

	c.JSON(200, namespaces)

}
