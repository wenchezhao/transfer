package resources

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	corev1 "k8s.io/api/core/v1"
	kerr "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

var (
	GenericQuotaName = "dsp-quota-default"
	StorageQuotaName = "dsp-quota-storage"
)

// 定义资源响应结构
type GetResourceQuotaTotalResponse struct {
	Cpu     map[string]int64 `json:"cpu"`     // cpu资源信息
	Memory  map[string]int64 `json:"memory"`  // 内存资源信息
	Storage map[string]int64 `json:"storage"` // 存储资源信息
}

func SetStorageInformation(resourcequota, resourcequota2 *corev1.ResourceQuota) {
	if resourcequota.Status.Hard == nil {
		resourcequota.Status.Hard = make(map[corev1.ResourceName]resource.Quantity)
	}

	if resourcequota.Status.Used == nil {
		resourcequota.Status.Used = make(map[corev1.ResourceName]resource.Quantity)
	}

	resourcequota.APIVersion = "v1"
	resourcequota.Kind = "ResourceQuota"

	cpu := resourcequota.Spec.Hard["limits.cpu"]
	cpuValue := cpu.MilliValue()
	cpuUpdate := resource.NewQuantity(cpuValue, resource.DecimalExponent)
	resourcequota.Spec.Hard["limits.cpu"] = *cpuUpdate

	memory := resourcequota.Spec.Hard["limits.memory"]
	memoryValue := memory.Value()
	memoryUpdate := resource.NewQuantity(memoryValue, resource.DecimalExponent)
	resourcequota.Spec.Hard["limits.memory"] = *memoryUpdate

	storage := resourcequota2.Spec.Hard["requests.storage"]
	storageValue := storage.Value()
	storageUpdate := resource.NewQuantity(storageValue, resource.DecimalExponent)
	resourcequota.Spec.Hard["requests.storage"] = *storageUpdate

	cpu = resourcequota.Status.Hard["limits.cpu"]
	cpuValue = cpu.MilliValue()
	cpuUpdate = resource.NewQuantity(cpuValue, resource.DecimalExponent)
	resourcequota.Status.Hard["limits.cpu"] = *cpuUpdate

	memory = resourcequota.Status.Hard["limits.memory"]
	memoryValue = memory.Value()
	memoryUpdate = resource.NewQuantity(memoryValue, resource.DecimalExponent)
	resourcequota.Status.Hard["limits.memory"] = *memoryUpdate

	storage = resourcequota2.Status.Hard["requests.storage"]
	storageValue = storage.Value()
	storageUpdate = resource.NewQuantity(storageValue, resource.DecimalExponent)
	resourcequota.Status.Hard["requests.storage"] = *storageUpdate

	cpu = resourcequota.Status.Used["limits.cpu"]
	cpuValue = cpu.MilliValue()
	cpuUpdate = resource.NewQuantity(cpuValue, resource.DecimalExponent)
	resourcequota.Status.Used["limits.cpu"] = *cpuUpdate

	memory = resourcequota.Status.Used["limits.memory"]
	memoryValue = memory.Value()
	memoryUpdate = resource.NewQuantity(memoryValue, resource.DecimalExponent)
	resourcequota.Status.Used["limits.memory"] = *memoryUpdate

	storage = resourcequota2.Status.Used["requests.storage"]
	storageValue = storage.Value()
	storageUpdate = resource.NewQuantity(storageValue, resource.DecimalExponent)
	resourcequota.Status.Used["requests.storage"] = *storageUpdate
}

func (h *handler) getResourceQuota(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get resourcequota")
	defer span.Finish()

	// parse request parameters
	namespace := c.Param("namespace")
	if namespace == "" {
		err := fmt.Errorf("the namespace parameters is required")
		common.HandleError(c, http.StatusBadRequest, err)
		return
	}

	clusters := c.QueryArray("clusters")
	if len(clusters) == 0 {
		err := fmt.Errorf("the clustes parameter is required")
		common.HandleError(c, http.StatusBadRequest, err)
		return
	}

	resArr := make([]map[string]*corev1.ResourceQuota, 0)
	// 如果获取不到配额信息，直接跳过这个集群
	for _, cluster := range clusters {
		client, err := h.clusterClientManager.GetClientFromCache(cluster)
		if err != nil {
			log.Errorf("skip it. failed to get cluster client: %v", err)
			continue
		}
		resourcequota, err := client.CoreV1().ResourceQuotas(namespace).Get(ctx, GenericQuotaName, metav1.GetOptions{})
		if err != nil {
			log.Errorf("skip it. failed to get quota %s: %v", GenericQuotaName, err)
			continue
		}

		resourcequota2, err := client.CoreV1().ResourceQuotas(namespace).Get(ctx, StorageQuotaName, metav1.GetOptions{})
		if err != nil {
			log.Errorf("skip it. failed to get quota %s: %v", StorageQuotaName, err)
			continue
		}

		// fix panic: assignment to entry in nil map
		// nil map可以读不可以写
		SetStorageInformation(resourcequota, resourcequota2)

		resArr = append(resArr, map[string]*corev1.ResourceQuota{cluster: resourcequota})
	}

	c.JSON(200, resArr)
}

func (h *handler) updateResourceQuota(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create or update resourcequota")
	defer span.Finish()

	namespace := c.Param("namespace")

	request := &corev1.ResourceQuota{}
	err := c.BindJSON(request)
	if err != nil {
		log.Errorf("error requestBody: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	cpu := request.Spec.Hard["limits.cpu"]

	cpuUpdate := resource.NewMilliQuantity(cpu.Value(), resource.DecimalSI)
	request.Spec.Hard["limits.cpu"] = *cpuUpdate

	requestsStorage := request.Spec.Hard["requests.storage"]

	request.Spec.Scopes = []corev1.ResourceQuotaScope{"NotBestEffort"}
	delete(request.Spec.Hard, "requests.storage")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	_, err = client.CoreV1().ResourceQuotas(namespace).Get(ctx, GenericQuotaName, metav1.GetOptions{})
	if kerr.IsNotFound(err) {
		log.Infof("Creating ResourceQuotas %s/%s.", namespace, GenericQuotaName)
		resourcequota, err := client.CoreV1().ResourceQuotas(namespace).Create(ctx, request, metav1.CreateOptions{})
		if err != nil {
			log.Errorf("failed to creater resourcequota: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		resourcequota.APIVersion = "v1"
		resourcequota.Kind = "ResourceQuota"
	} else if err != nil {
		log.Errorf("failed to get resourcequota: %v", err)
		common.HandleError(c, 500, err)
		return
	} else {
		log.Infof("Updating ResourceQuotas %s/%s.", namespace, GenericQuotaName)
		resourcequota, err := client.CoreV1().ResourceQuotas(namespace).Update(ctx, request, metav1.UpdateOptions{})
		if err != nil {
			log.Errorf("failed to update resourcequota: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		resourcequota.APIVersion = "v1"
		resourcequota.Kind = "ResourceQuota"
	}

	request2, err := client.CoreV1().ResourceQuotas(namespace).Get(ctx, StorageQuotaName, metav1.GetOptions{})
	if kerr.IsNotFound(err) {
		log.Infof("Creating ResourceQuotas %s/%s.", namespace, StorageQuotaName)
		request2 := &corev1.ResourceQuota{}
		request2.Kind = "ResourceQuota"
		request2.APIVersion = "v1"
		request2.Name = StorageQuotaName
		request2.Namespace = namespace

		resourceList := make(corev1.ResourceList)
		resourceList["requests.storage"] = requestsStorage
		request2.Spec.Hard = resourceList

		_, err := client.CoreV1().ResourceQuotas(namespace).Create(ctx, request2, metav1.CreateOptions{})
		if err != nil {
			log.Errorf("failed to create resourcequota: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	} else if err != nil {
		log.Errorf("failed to get resourcequota: %v", err)
		common.HandleError(c, 500, err)
		return
	} else {
		log.Infof("Updating ResourceQuotas %s/%s.", namespace, GenericQuotaName)
		request2.Spec.Hard["requests.storage"] = requestsStorage
		resourcequota2, err := client.CoreV1().ResourceQuotas(namespace).Update(ctx, request2, metav1.UpdateOptions{})
		if err != nil {
			log.Errorf("failed to update resourcequota: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		resourcequota2.APIVersion = "v1"
		resourcequota2.Kind = "ResourceQuota"
	}

	c.JSON(200, struct{}{})
}

func (h *handler) getResourceQuotaByClusters(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get resourcequota by clusters")
	defer span.Finish()

	namespace := c.Param("namespace")
	if len(namespace) == 0 {
		err := fmt.Errorf("the namespace parameter is required")
		common.HandleError(c, http.StatusBadRequest, err)
		return
	}

	clusters := c.QueryArray("clusters")

	resMap := make(map[string]interface{})
	for _, cluster := range clusters {
		resMap[cluster] = make(map[string]int64)
		client, err := h.clusterClientManager.GetClientFromCache(cluster)
		if err != nil {
			log.Errorf("skip it. failed to get cluster client")
			continue
		}

		quotas, err := client.CoreV1().ResourceQuotas(namespace).List(ctx, metav1.ListOptions{})
		if err != nil {
			log.Errorf("skip it. failed to list quota : %v", err)
			continue
		}

		var (
			cpuValue     int64
			cpuTotal     int64
			memoryValue  int64
			memoryTotal  int64
			storageValue int64
			storageTotal int64
		)

		for _, quota := range quotas.Items {
			if quota.Name == GenericQuotaName {
				cpuUsed := quota.Status.Used["limits.cpu"]
				cpuValue = cpuUsed.MilliValue()

				cpuHard := quota.Status.Hard["limits.cpu"]
				cpuTotal = cpuHard.MilliValue()

				memoryUsed := quota.Status.Used["limits.memory"]
				memoryValue = memoryUsed.Value()

				memoryHard := quota.Status.Hard["limits.memory"]
				memoryTotal = memoryHard.Value()
			} else if quota.Name == StorageQuotaName {
				storageUsed := quota.Status.Used["requests.storage"]
				storageValue = storageUsed.Value()

				storageHard := quota.Status.Hard["requests.storage"]
				storageTotal = storageHard.Value()
			}
		}

		resMap[cluster] = map[string]int64{
			"cpuUsed":      cpuValue,
			"cpuTotal":     cpuTotal,
			"memoryUsed":   memoryValue,
			"memoryTotal":  memoryTotal,
			"storageUsed":  storageValue,
			"storageTotal": storageTotal,
		}
	}

	c.JSON(200, resMap)
}
