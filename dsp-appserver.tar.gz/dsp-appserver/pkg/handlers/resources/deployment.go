package resources

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	appsv1 "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/kubectl/pkg/scheme"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	podutil "github.com/daocloud/dsp-appserver/pkg/util/pod"
)

func (h *handler) listDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list deployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	gvr := schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "deployments"}
	if informer != nil && informer.IsInformerSynced(gvr) {
		l, err := labels.Parse(labelSelector)
		if err != nil {
			log.Errorf("failed to parse labelSelector: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		results, err := informer.Lister(gvr).ByNamespace(namespace).List(l)
		if err != nil {
			log.Errorf("informer failed to list deployment: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		c.JSON(200, map[string]interface{}{
			"kind":       "List",
			"apiVersion": "v1",
			"items":      results,
		})
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	deploymentList, err := client.AppsV1().Deployments(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to get deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	deploymentList.Kind = "List"
	deploymentList.APIVersion = "v1"
	for index := range deploymentList.Items {
		deploymentList.Items[index].APIVersion = "apps/v1"
		deploymentList.Items[index].Kind = "Deployment"
	}
	c.JSON(200, deploymentList)
}

func (h *handler) getDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get deployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	deployment, err := client.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	deployment.Kind = "Deployment"
	deployment.APIVersion = "apps/v1"

	c.JSON(200, deployment)
}

func (h *handler) createDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create deployment")
	defer span.Finish()

	namespace := c.Param("namespace")

	deploymentRequest := &appsv1.Deployment{}
	err := c.BindJSON(deploymentRequest)
	if err != nil {
		log.Errorf("error requestBody: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	// force namespace
	deploymentRequest.Namespace = namespace

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	deployment, err := client.AppsV1().Deployments(namespace).Create(ctx, deploymentRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to get deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	deployment.APIVersion = "apps/v1"
	deployment.Kind = "Deployment"
	c.JSON(200, deployment)
}

func (h *handler) updateDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update deployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	deploymentRequest := &appsv1.Deployment{}
	err := c.BindJSON(deploymentRequest)
	if err != nil {
		log.Errorf("error requestBody: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	resultDeployment, err := client.AppsV1().Deployments(namespace).Update(ctx, deploymentRequest, metav1.UpdateOptions{})
	if err != nil && !kapierrors.IsConflict(err) {
		log.Errorf("failed to update deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	if err == nil {
		resultDeployment.Kind = "Deployment"
		resultDeployment.APIVersion = "apps/v1"
		c.JSON(200, resultDeployment)
		return
	}

	deployment, err := client.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	deploymentRequest.ResourceVersion = deployment.ResourceVersion
	resultDeployment, err = client.AppsV1().Deployments(namespace).Update(ctx, deploymentRequest, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	resultDeployment.Kind = "Deployment"
	resultDeployment.APIVersion = "apps/v1"
	c.JSON(200, resultDeployment)

}

func (h *handler) scaleDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "scale deployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	replicasStr := c.Query("replicas")

	if replicasStr == "" {
		common.HandleError(c, 400, fmt.Errorf("replicas can not be null"))
		return
	}
	temp, err := strconv.Atoi(replicasStr)
	if err != nil {
		log.Errorf("failed to convert replicas: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	deployment, err := client.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	replicas := int32(temp)
	deployment.Spec.Replicas = &replicas
	update, err := client.AppsV1().Deployments(namespace).Update(ctx, deployment, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	update.Kind = "Deployment"
	update.APIVersion = "apps/v1"
	c.JSON(200, update)
}

func (h *handler) deleteDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete deployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	policy := metav1.DeletePropagationBackground
	var deleteOptions metav1.DeleteOptions
	deleteOptions.PropagationPolicy = &policy
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}
	err = client.AppsV1().Deployments(namespace).Delete(ctx, name, deleteOptions)

	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
		} else {
			log.Errorf("failed to delete deployment: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	}
	c.JSON(200, struct{}{})

}

func (h *handler) listPodOfDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list pods of deployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	deployment, err := client.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	pods, err := podutil.ListDeploymentPods(client, *deployment)
	resultList := v1.PodList{
		Items: pods,
	}
	resultList.APIVersion = "v1"
	resultList.Kind = "List"
	for index := range resultList.Items {
		resultList.Items[index].Kind = "Pod"
		resultList.Items[index].APIVersion = "v1"
	}
	c.JSON(200, resultList)

}

// restart deployment
func (h *handler) restartDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "restart deployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	_, err = client.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	patchBody := `
	{
		"spec":{
		  "template":{
			"metadata":{
			  "annotations":{
				"kubectl.kubernetes.io/restartedAt":"timeFormat"
			  }
			}
		  }
		}
	  }
	`

	now := time.Now()
	timeFormat := now.Format(time.RFC3339)
	patchBody = strings.Replace(patchBody, "timeFormat", timeFormat, -1)

	_, err = client.AppsV1().Deployments(namespace).Patch(ctx,
		name,
		types.StrategicMergePatchType, []byte(patchBody), metav1.PatchOptions{})

	if err != nil {
		log.Errorf("failed to patch pods of deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, struct{}{})
}

// delete pod ### restart deployment
func (h *handler) restartDeploymentOld(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "restart deployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	deployment, err := client.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	selector, err := metav1.LabelSelectorAsSelector(deployment.Spec.Selector)
	if err != nil {
		log.Errorf("failed to get selector: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	log.Infof("labelselector %s", selector)
	err = client.CoreV1().Pods(namespace).DeleteCollection(ctx, metav1.DeleteOptions{}, metav1.ListOptions{
		LabelSelector: selector.String(),
	})
	if err != nil {
		log.Errorf("failed to delete pods of deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, struct{}{})
}

func (h *handler) listEventOfDeployment(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list events of deployment")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	deployment, err := client.AppsV1().Deployments(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get deployment: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	eventList, err := client.CoreV1().Events(namespace).Search(scheme.Scheme, deployment)
	if err != nil {
		log.Errorf("failed to get events: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	eventList.APIVersion = "v1"
	eventList.Kind = "List"
	for index := range eventList.Items {
		eventList.Items[index].APIVersion = "v1"
		eventList.Items[index].Kind = "Event"
	}
	c.JSON(200, eventList)

}
