package resources

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"

	appsv1 "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/kubectl/pkg/scheme"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	podutil "github.com/daocloud/dsp-appserver/pkg/util/pod"
)

func (h *handler) listStatefulset(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	gvr := schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "statefulsets"}
	if informer != nil && informer.IsInformerSynced(gvr) {
		l, err := labels.Parse(labelSelector)
		if err != nil {
			log.Errorf("failed to parse labelSelector: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		results, err := informer.Lister(gvr).ByNamespace(namespace).List(l)
		if err != nil {
			log.Errorf("informer failed to list statefulsets: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		c.JSON(200, map[string]interface{}{
			"kind":       "List",
			"apiVersion": "v1",
			"items":      results,
		})
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	statefulSetList, err := client.AppsV1().StatefulSets(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to get statefulset list: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	statefulSetList.APIVersion = "v1"
	statefulSetList.Kind = "List"
	for index := range statefulSetList.Items {
		statefulSetList.Items[index].Kind = "StatefulSet"
		statefulSetList.Items[index].APIVersion = "apps/v1"
	}
	c.JSON(200, statefulSetList)
}

func (h *handler) getStatefulset(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	statefulSet, err := client.AppsV1().StatefulSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	statefulSet.APIVersion = "apps/v1"
	statefulSet.Kind = "StatefulSet"
	c.JSON(200, statefulSet)
}

func (h *handler) createStatefulset(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")

	statefulSetRequest := &appsv1.StatefulSet{}
	err := c.BindJSON(statefulSetRequest)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	// force namespace
	statefulSetRequest.Namespace = namespace
	log.Infof("create statefulset requestBody: %v", statefulSetRequest)

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	statefulSet, err := client.AppsV1().StatefulSets(namespace).Create(ctx, statefulSetRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to create statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	statefulSet.APIVersion = "apps/v1"
	statefulSet.Kind = "StatefulSet"
	c.JSON(200, statefulSet)
}

func (h *handler) updateStatefulset(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	statefulSetRequest := &appsv1.StatefulSet{}
	err := c.BindJSON(statefulSetRequest)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	log.Infof("update statefulset requestBodu: %v", statefulSetRequest)

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	statefulSet, err := client.AppsV1().StatefulSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get original statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	statefulSetRequest.ResourceVersion = statefulSet.ResourceVersion
	result, err := client.AppsV1().StatefulSets(namespace).Update(ctx, statefulSetRequest, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	result.APIVersion = "apps/v1"
	result.Kind = "StatefulSet"
	c.JSON(200, result)

}

func (h *handler) deleteStatefulset(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	policy := metav1.DeletePropagationBackground
	var deleteOptions metav1.DeleteOptions
	deleteOptions.PropagationPolicy = &policy
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}
	err = client.AppsV1().StatefulSets(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
		} else {
			log.Errorf("failed todelete statefulset: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	}
	c.JSON(200, struct{}{})
}

func (h *handler) scaleStatefulset(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "scale statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	replicasStr := c.Query("replicas")

	if replicasStr == "" {
		common.HandleError(c, 400, fmt.Errorf("replicas can not be null"))
		return
	}
	temp, err := strconv.Atoi(replicasStr)
	if err != nil {
		log.Errorf("failed to convert replicas: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	statefulSet, err := client.AppsV1().StatefulSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get original statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	replicas := int32(temp)
	statefulSet.Spec.Replicas = &replicas
	update, err := client.AppsV1().StatefulSets(namespace).Update(ctx, statefulSet, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	update.APIVersion = "apps/v1"
	update.Kind = "StatefulSet"
	c.JSON(200, update)
}

func (h *handler) getPodsOfStatefulset(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list pods of statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	statefulSet, err := client.AppsV1().StatefulSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	pods, err := podutil.ListStatefulSetPods(client, *statefulSet)
	if err != nil {
		log.Errorf("failed to list pods: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	podList := v1.PodList{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "v1",
			Kind:       "List",
		},
	}
	for _, pod := range pods {
		pod.APIVersion = "v1"
		pod.Kind = "Pod"
		podList.Items = append(podList.Items, pod)
	}

	c.JSON(200, podList)
}

func (h *handler) getEventsOfStatefulset(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list events of statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	statefulSet, err := client.AppsV1().StatefulSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get statefulSet: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	eventList, err := client.CoreV1().Events(namespace).Search(scheme.Scheme, statefulSet)
	if err != nil {
		log.Errorf("failed to get event of statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	eventList.APIVersion = "v1"
	eventList.Kind = "List"
	for index := range eventList.Items {
		eventList.Items[index].APIVersion = "v1"
		eventList.Items[index].Kind = "Event"
	}
	c.JSON(200, eventList)
}

func (h *handler) restartStatefulset(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "restart statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	_, err = client.AppsV1().StatefulSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	patchBody := `
	{
		"spec":{
		  "template":{
			"metadata":{
			  "annotations":{
				"kubectl.kubernetes.io/restartedAt":"timeFormat"
			  }
			}
		  }
		}
	  }
	`

	now := time.Now()
	timeFormat := now.Format(time.RFC3339)
	patchBody = strings.Replace(patchBody, "timeFormat", timeFormat, -1)

	_, err = client.AppsV1().StatefulSets(namespace).Patch(ctx,
		name,
		types.StrategicMergePatchType, []byte(patchBody), metav1.PatchOptions{})

	if err != nil {
		log.Errorf("failed to delete pods of statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, struct{}{})
}

//delete pod ,old
func (h *handler) restartStatefulsetOld(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "restart statefulset")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	statefulSet, err := client.AppsV1().StatefulSets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	selector, err := metav1.LabelSelectorAsSelector(statefulSet.Spec.Selector)
	if err != nil {
		log.Errorf("failed to get selector: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	log.Infof("labelselector %s", selector)
	err = client.CoreV1().Pods(namespace).DeleteCollection(ctx, metav1.DeleteOptions{}, metav1.ListOptions{
		LabelSelector: selector.String(),
	})
	if err != nil {
		log.Errorf("failed to delete pods of statefulset: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, struct{}{})
}
