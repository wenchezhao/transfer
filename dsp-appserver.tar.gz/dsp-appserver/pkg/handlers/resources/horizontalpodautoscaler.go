package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"

	hpav2beta1 "k8s.io/api/autoscaling/v2beta1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

func (h *handler) listHorizontalPodAutoscaler(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list hpa")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	list, err := client.AutoscalingV2beta1().HorizontalPodAutoscalers(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to list hpa in the namespace %q: %v", namespace, err)
		common.HandleError(c, 500, err)
		return
	}

	list.APIVersion = "v1"
	list.Kind = "List"
	for index := range list.Items {
		list.Items[index].TypeMeta = metav1.TypeMeta{
			APIVersion: "autoscaling/v2beta1",
			Kind:       "HorizontalPodAutoscaler",
		}
	}
	c.JSON(200, list)
}

func (h *handler) getHorizontalPodAutoscaler(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get hpa")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	hpa, err := client.AutoscalingV2beta1().HorizontalPodAutoscalers(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get hpa %s/%s: %v", namespace, name, err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, hpa)
}

func (h *handler) updateHorizontalPodAutoscaler(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update hpa")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	hpa := &hpav2beta1.HorizontalPodAutoscaler{}
	if err := c.BindJSON(hpa); err != nil {
		log.Errorf("error requestBody: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	oldHPA, err := client.AutoscalingV2beta1().HorizontalPodAutoscalers(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get hpa %s/%s: %v", namespace, name, oldHPA)
		common.HandleError(c, 500, err)
		return
	}
	hpa.ResourceVersion = oldHPA.ResourceVersion

	updatedHPA, err := client.AutoscalingV2beta1().HorizontalPodAutoscalers(namespace).Update(ctx, hpa, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update hpa %s/%s: %v", namespace, name, err)
		return
	}
	c.JSON(200, updatedHPA)
}

func (h *handler) deleteHorizontalPodAutoscaler(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete hpa")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}
	err = client.AutoscalingV2beta1().HorizontalPodAutoscalers(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
		} else {
			log.Errorf("failed to delete hpa: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	}
	c.JSON(200, struct{}{})
}
