package resources

import (
	"github.com/gin-gonic/gin"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	"github.com/daocloud/dsp-appserver/pkg/kube"
)

func (h *handler) handleDeploymentHistory(c *gin.Context) {
	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	history, err := kube.ViewHistoryForDeployment(client, namespace, name)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, history)
}
