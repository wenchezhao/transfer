package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/kubectl/pkg/scheme"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

// pv列表
func (h *handler) listPersistentVolume(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list persistentVolumes")
	defer span.Finish()

	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	pvList, err := client.CoreV1().PersistentVolumes().List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to list persistentVolumes: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	pvList.Kind = "List"
	pvList.APIVersion = "v1"

	for index := range pvList.Items {
		pvList.Items[index].APIVersion = "v1"
		pvList.Items[index].Kind = "PersistentVolume"
	}

	c.JSON(200, pvList)
	return
}

// 获取pv详情
func (h *handler) getPersistentVolume(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get persistentVolume")
	defer span.Finish()

	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolume, err := client.CoreV1().PersistentVolumes().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get persistentVolume: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolume.APIVersion = "v1"
	persistentVolume.Kind = "PersistentVolume"

	c.JSON(200, persistentVolume)
	return
}

// 创建pv
func (h *handler) createPersistentVolume(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create persistentVolume")
	defer span.Finish()

	pvRequest := corev1.PersistentVolume{}
	err := c.BindJSON(&pvRequest)
	if err != nil {
		log.Errorf("failed to BindJSON pvRequest: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolume, err := client.CoreV1().PersistentVolumes().Create(ctx, &pvRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to create persistentVolume: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolume.APIVersion = "v1"
	persistentVolume.Kind = "PersistentVolume"

	c.JSON(200, persistentVolume)
	return
}

// 更新pv
func (h *handler) updatePersistentVolume(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update persistentVolume")
	defer span.Finish()

	name := c.Param("name")

	pvRequest := corev1.PersistentVolume{}
	err := c.BindJSON(&pvRequest)
	if err != nil {
		log.Errorf("failed to BindJSON pvRequest: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	oldPersistentVolume, err := client.CoreV1().PersistentVolumes().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get persistentVolume: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	pvRequest.ResourceVersion = oldPersistentVolume.ResourceVersion

	persistentVolume, err := client.CoreV1().PersistentVolumes().Update(ctx, &pvRequest, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update persistentVolume: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolume.APIVersion = "v1"
	persistentVolume.Kind = "PersistentVolume"

	c.JSON(200, persistentVolume)
	return
}

// 删除pv
func (h *handler) deletePersistentVolume(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete persistentVolume")
	defer span.Finish()

	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}
	err = client.CoreV1().PersistentVolumes().Delete(ctx, name, deleteOptions)
	if err != nil {
		log.Errorf("failed to delete persistentVolume: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, struct{}{})
	return
}

// pv event list
func (h *handler) listPersistentVolumeEvent(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list persistentVolume event")
	defer span.Finish()

	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolume, err := client.CoreV1().PersistentVolumes().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get persistentVolume: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	eventList, err := client.CoreV1().Events(metav1.NamespaceAll).Search(scheme.Scheme, persistentVolume)
	if err != nil {
		log.Errorf("failed to get persistentVolume eventList: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	eventList.APIVersion = "v1"
	eventList.Kind = "List"
	for index := range eventList.Items {
		eventList.Items[index].APIVersion = "v1"
		eventList.Items[index].Kind = "Event"
	}
	c.JSON(200, eventList)
	return
}
