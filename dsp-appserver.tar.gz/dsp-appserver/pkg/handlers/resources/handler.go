package resources

import (
	"github.com/gin-gonic/gin"

	"github.com/daocloud/dsp-appserver/pkg/informermanager"
	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
)

var log = logi.Log.Sugar()

type handler struct {
	clusterClientManager *multicluster.ClusterClientManager
	informerManager      informermanager.InformerManager
}

// InstallHandlers install Handlers
func InstallHandlers(
	routerGroup *gin.RouterGroup,
	clusterClientManager *multicluster.ClusterClientManager,
	informerManager informermanager.InformerManager) {

	h := &handler{
		clusterClientManager: clusterClientManager,
		informerManager:      informerManager,
	}

	routerGroup.GET("/v1/apiresources", h.listApiResources)

	routerGroup.POST("/v1/bindnamespaces", h.bindNamespace)
	routerGroup.GET("/v1/namespaces", h.listNamespace)

	routerGroup.GET("/v1/namespaces/:namespace/persistentvolumeclaims/:name", h.getPersistentVolumeClaim)
	routerGroup.GET("/v1/namespaces/:namespace/persistentvolumeclaims/:name/objrefs", h.listPersistentVolumeClaimObjectReference)
	routerGroup.GET("/v1/namespaces/:namespace/persistentvolumeclaims", h.listPersistentVolumeClaim)
	routerGroup.POST("/v1/namespaces/:namespace/persistentvolumeclaims", h.createPersistentVolumeClaim)
	routerGroup.PUT("/v1/namespaces/:namespace/persistentvolumeclaims/:name", h.updatePersistentVolumeClaim)
	routerGroup.DELETE("/v1/namespaces/:namespace/persistentvolumeclaims/:name", h.deletePersistentVolumeClaim)
	routerGroup.GET("/v1/namespaces/:namespace/persistentvolumeclaims/:name/events", h.listPersistentVolumeClaimEvent)
	routerGroup.GET("/v1/namespaces/:namespace/persistentvolumeclaims/:name/pods", h.listPodOfPersistentVolumeClaim)

	routerGroup.GET("/v1/persistentvolumes", h.listPersistentVolume)
	routerGroup.GET("/v1/persistentvolumes/:name", h.getPersistentVolume)
	routerGroup.POST("/v1/persistentvolumes", h.createPersistentVolume)
	routerGroup.PUT("/v1/persistentvolumes/:name", h.updatePersistentVolume)
	routerGroup.DELETE("/v1/persistentvolumes/:name", h.deletePersistentVolume)
	routerGroup.GET("/v1/persistentvolumes/:name/events", h.listPersistentVolumeEvent)

	routerGroup.GET("/v1/namespaces/:namespace/services", h.listService)
	routerGroup.GET("/v1/namespaces/:namespace/services/:name", h.getService)
	routerGroup.POST("/v1/namespaces/:namespace/services", h.createService)
	routerGroup.PUT("/v1/namespaces/:namespace/services/:name", h.updateService)
	routerGroup.DELETE("/v1/namespaces/:namespace/services/:name", h.deleteService)
	routerGroup.GET("/v1/namespaces/:namespace/services/:name/events", h.listServiceEvent)
	routerGroup.GET("/v1/namespaces/:namespace/services/:name/routes", h.listServiceRoute)
	routerGroup.GET("/v1/namespaces/:namespace/services/:name/trafficobjects", h.listServiceTrafficObject)
	routerGroup.GET("/v1/namespaces/:namespace/services/:name/pods", h.listServicePod)

	routerGroup.GET("/v1/namespaces/:namespace/pods/:name/events", h.listPodEvents)
	routerGroup.GET("/v1/namespaces/:namespace/pods", h.listPods)
	routerGroup.GET("/v1/namespaces/:namespace/pods/:name", h.getPod)
	routerGroup.DELETE("/v1/namespaces/:namespace/pods/:name", h.deletePod)
	routerGroup.DELETE("/v1/namespaces/:namespace/pods", h.deletePodList)

	routerGroup.POST("/v1/namespaces/:namespace/routes", h.createRoute)
	routerGroup.PUT("/v1/namespaces/:namespace/routes/:name", h.updateRoute)
	routerGroup.GET("/v1/namespaces/:namespace/routes/:name", h.getRoute)
	routerGroup.GET("/v1/namespaces/:namespace/routes/:name/pods", h.listRoutePods)
	routerGroup.GET("/v1/namespaces/:namespace/routes", h.listRoute)
	routerGroup.DELETE("/v1/namespaces/:namespace/routes/:name", h.deleteRoute)

	routerGroup.GET("/v1/namespaces/:namespace/deployments", h.listDeployment)
	routerGroup.GET("/v1/namespaces/:namespace/deployments/:name", h.getDeployment)
	routerGroup.GET("/v1/namespaces/:namespace/deployments/:name/pods", h.listPodOfDeployment)
	routerGroup.GET("/v1/namespaces/:namespace/deployments/:name/events", h.listEventOfDeployment)
	routerGroup.PUT("/v1/namespaces/:namespace/deployments/:name/restart", h.restartDeployment)
	routerGroup.POST("/v1/namespaces/:namespace/deployments", h.createDeployment)
	routerGroup.PUT("/v1/namespaces/:namespace/deployments/:name", h.updateDeployment)
	routerGroup.DELETE("/v1/namespaces/:namespace/deployments/:name", h.deleteDeployment)
	routerGroup.PUT("/v1/namespaces/:namespace/deployments/:name/scale", h.scaleDeployment)
	routerGroup.GET("/v1/namespaces/:namespace/deployments/:name/replicasets", h.handleDeploymentHistory)
	routerGroup.PUT("/v1/namespaces/:namespace/deployments/:name/rollback", h.handleDeploymentRollback)

	routerGroup.GET("/v1/namespaces/:namespace/replicaset/:name/events", h.listEventOfReplicaSet)

	routerGroup.GET("/v1/namespaces/:namespace/statefulsets", h.listStatefulset)
	routerGroup.GET("/v1/namespaces/:namespace/statefulsets/:name", h.getStatefulset)
	routerGroup.POST("/v1/namespaces/:namespace/statefulsets", h.createStatefulset)
	routerGroup.PUT("/v1/namespaces/:namespace/statefulsets/:name", h.updateStatefulset)
	routerGroup.DELETE("/v1/namespaces/:namespace/statefulsets/:name", h.deleteStatefulset)
	routerGroup.GET("/v1/namespaces/:namespace/statefulsets/:name/events", h.getEventsOfStatefulset)
	routerGroup.PUT("/v1/namespaces/:namespace/statefulsets/:name/scale", h.scaleStatefulset)
	routerGroup.PUT("/v1/namespaces/:namespace/statefulsets/:name/restart", h.restartStatefulset)
	routerGroup.GET("/v1/namespaces/:namespace/statefulsets/:name/pods", h.getPodsOfStatefulset)

	routerGroup.GET("/v1/namespaces/:namespace/configmaps", h.listConfigMap)
	routerGroup.GET("/v1/namespaces/:namespace/configmaps/:name", h.getConfigMap)
	routerGroup.GET("/v1/namespaces/:namespace/configmaps/:name/objrefs", h.listConfigMapObjectReference)
	routerGroup.POST("/v1/namespaces/:namespace/configmaps", h.createConfigMap)
	routerGroup.PUT("/v1/namespaces/:namespace/configmaps/:name", h.updateConfigMap)
	routerGroup.DELETE("/v1/namespaces/:namespace/configmaps/:name", h.deleteConfigMap)

	routerGroup.GET("/v1/namespaces/:namespace/ingresses", h.listIngress)
	routerGroup.GET("/v1/namespaces/:namespace/ingresses/:name", h.getIngress)
	routerGroup.GET("/v1/namespaces/:namespace/ingresses/:name/pods", h.listIngressPods)
	routerGroup.POST("/v1/namespaces/:namespace/ingresses", h.createIngress)
	routerGroup.PUT("/v1/namespaces/:namespace/ingresses/:name", h.updateIngress)
	routerGroup.DELETE("/v1/namespaces/:namespace/ingresses/:name", h.deleteIngress)

	routerGroup.GET("/v1/namespaces/:namespace/horizontalpodautoscalers", h.listHorizontalPodAutoscaler)
	routerGroup.GET("/v1/namespaces/:namespace/horizontalpodautoscalers/:name", h.getHorizontalPodAutoscaler)
	routerGroup.PUT("/v1/namespaces/:namespace/horizontalpodautoscalers/:name", h.updateHorizontalPodAutoscaler)
	routerGroup.DELETE("/v1/namespaces/:namespace/horizontalpodautoscalers/:name", h.deleteHorizontalPodAutoscaler)

	routerGroup.GET("/v1/namespaces/:namespace/replicationcontrollers", h.listReplicationController)
	routerGroup.GET("/v1/namespaces/:namespace/replicationcontrollers/:name/events", h.listEventOfReplicationController)

	routerGroup.DELETE("/v1/namespaces/:namespace/imagestreams/:name", h.deleteImagestreams)

	routerGroup.GET("/v1/namespaces/:namespace/secrets", h.listSecret)
	routerGroup.GET("/v1/namespaces/:namespace/secrets/:name", h.getSecret)
	routerGroup.GET("/v1/namespaces/:namespace/secrets/:name/objrefs", h.listSecretObjectReference)
	routerGroup.POST("/v1/namespaces/:namespace/secrets", h.createSecret)
	routerGroup.PUT("/v1/namespaces/:namespace/secrets/:name", h.updateSecret)
	routerGroup.DELETE("/v1/namespaces/:namespace/secrets/:name", h.deleteSecret)

	routerGroup.GET("/v1/namespaces/:namespace/endpoints", h.listEndPoints)
	routerGroup.GET("/v1/namespaces/:namespace/endpoints/:name", h.getEndPoints)

	routerGroup.GET("/v1/namespaces/:namespace/resourcequota", h.getResourceQuota)
	routerGroup.PUT("/v1/namespaces/:namespace/resourcequota", h.updateResourceQuota)
	routerGroup.GET("/v1/namespaces/:namespace/resourcequotamany", h.getResourceQuotaByClusters)

	routerGroup.GET("/v1/namespaces/:namespace/cronjobs", h.listCronJob)
	routerGroup.GET("/v1/namespaces/:namespace/cronjobs/:name", h.getCronJob)
	routerGroup.GET("/v1/namespaces/:namespace/cronjobs/:name/events", h.getCronJobEvents)
	routerGroup.GET("/v1/namespaces/:namespace/cronjobs/:name/jobs", h.listJobForCJ)
	routerGroup.POST("/v1/namespaces/:namespace/cronjobs", h.createCronJob)
	routerGroup.PUT("/v1/namespaces/:namespace/cronjobs/:name", h.updateCronJob)
	routerGroup.DELETE("/v1/namespaces/:namespace/cronjobs/:name", h.deleteCronJob)

	routerGroup.GET("/v1/nodes", h.listNode)
	routerGroup.GET("/v1/nodelabels", h.listAllNodeLabels)
	routerGroup.GET("/v1/nodeips", h.listAllNodeIPs)
	routerGroup.GET("/v1/nodes/:name", h.getNode)
	routerGroup.GET("/v1/nodes/:name/pods", h.getNodePods)
	routerGroup.GET("/v1/nodes/:name/events", h.listEventsOfNode)
	routerGroup.PUT("/v1/nodes/:name", h.updateNode)
	routerGroup.PUT("/v1/nodes/:name/drain", h.drainNode)
	routerGroup.PUT("/v1/nodes/:name/cordonoruncordon", h.cordonOrUncordonNode)

	routerGroup.GET("/v1/namespaces/:namespace/otherresources", h.listResources)
	routerGroup.GET("/v1/namespaces/:namespace/otherresources/:name", h.getResource)
	routerGroup.POST("/v1/namespaces/:namespace/otherresources", h.createResource)
	routerGroup.PUT("/v1/namespaces/:namespace/otherresources/:name", h.updateResource)
	routerGroup.DELETE("/v1/namespaces/:namespace/otherresources/:name", h.deleteResource)

	routerGroup.GET("/v1/prometheus/rulenamespaces", h.listPrometheusRuleNamespaces)
	routerGroup.GET("/v1/namespaces/:namespace/prometheusrules", h.listPrometheusRule)
	routerGroup.GET("/v1/namespaces/:namespace/prometheusrules/:name", h.getPrometheusRule)
	routerGroup.POST("/v1/namespaces/:namespace/prometheusrules", h.createPrometheusRule)
	routerGroup.PUT("/v1/namespaces/:namespace/prometheusrules/:name", h.updatePrometheusRule)
	routerGroup.DELETE("/v1/namespaces/:namespace/prometheusrules/:name", h.deletePrometheusRule)

	routerGroup.GET("/v1/securitycontextconstraints", h.listSecurityContextConstraints)
	routerGroup.GET("/v1/securitycontextconstraints/:name", h.getSecurityContextConstraints)
	routerGroup.POST("/v1/securitycontextconstraints", h.createSecurityContextConstraints)
	routerGroup.PUT("/v1/securitycontextconstraints/:name", h.updateSecurityContextConstraints)
	routerGroup.DELETE("/v1/securitycontextconstraints/:name", h.deleteSecurityContextConstraints)

	routerGroup.GET("/v1/cibdeployments/crd", h.getCibDeploymentCRD)
	routerGroup.GET("/v1/namespaces/:namespace/cibdeployments", h.listCibDeployment)
	routerGroup.GET("/v1/namespaces/:namespace/cibdeployments/:name", h.getCibDeployment)
	routerGroup.POST("/v1/namespaces/:namespace/cibdeployments", h.createCibDeployment)
	routerGroup.PUT("/v1/namespaces/:namespace/cibdeployments/:name", h.updateCibDeployment)
	routerGroup.DELETE("/v1/namespaces/:namespace/cibdeployments/:name", h.deleteCibDeployment)

}
