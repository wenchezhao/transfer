package resources

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"k8s.io/client-go/discovery"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

func (h *handler) listApiResources(c *gin.Context) {
	span, _ := utiltrace.StartSpanFromGin(c, "list configmap")
	defer span.Finish()

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	apiResources, err := client.CachedDiscoveryInterface().ServerPreferredNamespacedResources()
	if err != nil && !discovery.IsGroupDiscoveryFailedError(err) {
		log.Errorf("failed to get api resources: %v", err)
		common.HandleError(c, 500, fmt.Errorf("failed to get api resources: %v", err))
		return
	}
	c.JSON(200, apiResources)
	return
}
