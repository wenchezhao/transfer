package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"

	extensionsv1beta1 "k8s.io/api/extensions/v1beta1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"
	extensionsutil "kmodules.xyz/client-go/extensions/v1beta1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	podutil "github.com/daocloud/dsp-appserver/pkg/util/pod"
)

// list ingress
func (h *handler) listIngress(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list ingress")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	gvr := schema.GroupVersionResource{Group: "extensions", Version: "v1beta1", Resource: "ingresses"}
	if informer != nil && informer.IsInformerSynced(gvr) {
		l, err := labels.Parse(labelSelector)
		if err != nil {
			log.Errorf("failed to parse labelSelector: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		results, err := informer.Lister(gvr).ByNamespace(namespace).List(l)
		if err != nil {
			log.Errorf("informer failed to list ingress: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		c.JSON(200, map[string]interface{}{
			"kind":       "List",
			"apiVersion": "v1",
			"items":      results,
		})
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	ings, err := client.ExtensionsV1beta1().Ingresses(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("list ingress error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	ings.APIVersion = "v1"
	ings.Kind = "List"
	for index := range ings.Items {
		ings.Items[index].Kind = "Ingress"
		ings.Items[index].APIVersion = "v1"
	}

	c.JSON(200, ings)
}

// get ingress
func (h *handler) getIngress(c *gin.Context) {

	span, ctx := utiltrace.StartSpanFromGin(c, "get ingress")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	ing, err := client.ExtensionsV1beta1().Ingresses(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("get configmap error :%v", err)
		common.HandleError(c, 500, err)
		return
	}

	ing.Kind = "Ingress"
	ing.APIVersion = "extensions/v1beta1"

	c.JSON(200, ing)
}

// list ingress pods
func (h *handler) listIngressPods(c *gin.Context) {

	span, ctx := utiltrace.StartSpanFromGin(c, "list pods of ingress")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	ing, err := client.ExtensionsV1beta1().Ingresses(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("get ingress error :%v", err)
		common.HandleError(c, 500, err)
		return
	}

	pods, err := podutil.ListIngressPods(client, ing)
	if err != nil {
		log.Errorf("get pods error :%v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, pods)
}

// create ingress
func (h *handler) createIngress(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create ingress")
	defer span.Finish()

	namespace := c.Param("namespace")

	ingToCreate := &extensionsv1beta1.Ingress{}
	err := c.BindJSON(ingToCreate)
	if err != nil {
		log.Errorf("get requestBody error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	// force namespace
	ingToCreate.Namespace = namespace

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	createdIng, err := client.ExtensionsV1beta1().Ingresses(namespace).Create(ctx, ingToCreate, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("create ingress error %v", err)
		common.HandleError(c, 500, err)
		return
	}

	createdIng.Kind = "Ingress"
	createdIng.APIVersion = "extensions/v1beta1"

	c.JSON(200, createdIng)
}

// update ingress
func (h *handler) updateIngress(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update ingress")
	defer span.Finish()

	ingToUpdate := &extensionsv1beta1.Ingress{}
	err := c.BindJSON(ingToUpdate)
	if err != nil {
		log.Errorf("get requestBody error %v", err)
		common.HandleError(c, 500, err)
		return
	}
	log.Infof("requestBody: %v", ingToUpdate)

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	updated, err := extensionsutil.TryUpdateIngress(ctx, client, ingToUpdate.ObjectMeta, func(old *extensionsv1beta1.Ingress) *extensionsv1beta1.Ingress {
		ingToUpdate.ResourceVersion = old.ResourceVersion
		return ingToUpdate
	}, metav1.UpdateOptions{})

	if err != nil {
		log.Errorf("update ingress error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	updated.Kind = "Ingress"
	updated.APIVersion = "extensions/v1beta1"
	c.JSON(200, updated)
}

// delete ingress
func (h *handler) deleteIngress(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete ingress")
	defer span.Finish()
	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}

	err = client.ExtensionsV1beta1().Ingresses(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
			return
		} else {
			log.Errorf("delete ingress error: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	}
	c.JSON(200, struct{}{})
}
