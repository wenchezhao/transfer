package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"

	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

func (h *handler) deleteImagestreams(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete is")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	// get cluster client
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}

	err = client.OpenshiftImageV1().ImageStreams(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		if kapierrors.IsNotFound(err) {
			log.Errorf("Imagestreams is not found")
			c.JSON(200, struct{}{})
			return
		} else {
			log.Errorf("failed to delete Imagestreams: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	}

	c.JSON(200, struct{}{})
}
