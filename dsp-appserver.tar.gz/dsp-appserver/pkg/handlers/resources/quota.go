package resources

import (
	"fmt"
	resourceutil "github.com/daocloud/dsp-appserver/pkg/util/resource"
	kappsapi "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
)

type Quota struct {
	LimitCpu    int64
	LimitMemory int64
	Disk        int64
}

func getQuota(obj *unstructured.Unstructured) ([]Quota, error) {
	o, err := resourceutil.GetObjectFromData(*obj)
	if err != nil {
		log.Errorf("get runtime object failed, err is %+v", err)
		return nil, err
	}

	var quotas []Quota
	switch obj.GetKind() {
	case "Pod":
		pod, ok := o.(*v1.Pod)
		if ok {
			for _, container := range pod.Spec.Containers {
				quota, err := getContainerQuota(container)
				if err != nil {
					return nil, err
				}
				quotas = append(quotas, quota)
			}
		}
	case "Deployment":
		deployment, ok := o.(*kappsapi.Deployment)
		if ok {
			var qs []Quota
			for _, container := range deployment.Spec.Template.Spec.Containers {
				quota, err := getContainerQuota(container)
				if err != nil {
					return nil, err
				}
				qs = append(qs, quota)
			}

			for i := 0; i < int(*deployment.Spec.Replicas); i++ {
				quotas = append(quotas, qs...)
			}
		}
	case "StatefulSet":
		statefulset, ok := o.(*kappsapi.StatefulSet)
		if ok {
			var qs []Quota
			for _, container := range statefulset.Spec.Template.Spec.Containers {
				quota, err := getContainerQuota(container)
				if err != nil {
					return nil, err
				}
				qs = append(qs, quota)
			}

			for i := 0; i < int(*statefulset.Spec.Replicas); i++ {
				quotas = append(quotas, qs...)
			}
		}
	case "PersistentVolumeClaim":
		pvc, ok := o.(*v1.PersistentVolumeClaim)
		if ok {
			if q, ok := pvc.Spec.Resources.Requests["storage"]; ok {
				quota := Quota{}
				quota.Disk = q.Value()
				quotas = append(quotas, quota)
			}
		}
	default:
		log.Debugf("%s ignore to validate quota", obj.GetKind())
		return nil, nil
	}
	return quotas, nil
}

func getContainerQuota(c v1.Container) (Quota, error) {
	quota := Quota{}
	if c.Resources.Limits == nil {
		return quota, fmt.Errorf("the container %s is no quota", c.Name)
	}
	if len(c.Resources.Limits) == 0 {
		return quota, fmt.Errorf("the container %s is no quota", c.Name)
	}

	if c.Resources.Limits.Cpu() != nil {
		quota.LimitCpu = c.Resources.Limits.Cpu().MilliValue()
	} else {
		return quota, fmt.Errorf("the container %s is no quota", c.Name)
	}

	if c.Resources.Limits.Memory() != nil {
		quota.LimitMemory = c.Resources.Limits.Memory().Value()
	} else {
		return quota, fmt.Errorf("the container %s is no quota", c.Name)
	}

	return quota, nil
}
