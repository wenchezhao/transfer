package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"
	routeapi "github.com/openshift/api/route/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	podutil "github.com/daocloud/dsp-appserver/pkg/util/pod"
	routeutil "github.com/daocloud/dsp-appserver/pkg/util/route"
)

func (h *handler) createRoute(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create route")
	defer span.Finish()

	namespace := c.Param("namespace")

	routeRequest := &routeapi.Route{}
	err := c.BindJSON(routeRequest)
	if err != nil {
		log.Errorf("failed to bind json router request: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	// force namespace
	routeRequest.Namespace = namespace
	log.Infof("requestBody: %v", routeRequest)

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	// check target port
	err = routeutil.CheckRoutePortAndHost(ctx, client, routeRequest)
	if err != nil {
		log.Errorf("check route port and host is conflict: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	route, err := client.OpenshiftRouteV1().Routes(namespace).Create(ctx, routeRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to create route: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	route.APIVersion = "route.openshift.io/v1"
	route.Kind = "Route"
	c.JSON(200, route)
}

func (h *handler) updateRoute(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update route")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	routeRequest := &routeapi.Route{}
	err := c.BindJSON(routeRequest)
	if err != nil {
		common.HandleError(c, 500, err)
		return
	}
	log.Infof("update route requestBody: %v", routeRequest)

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	routeRequest.Namespace = namespace

	// check target port
	err = routeutil.CheckRoutePortAndHost(ctx, client, routeRequest)
	if err != nil {
		log.Errorf("nodePort is conflict: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	route, err := client.OpenshiftRouteV1().Routes(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get original route: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	routeRequest.ResourceVersion = route.ResourceVersion
	updateRoute, err := client.OpenshiftRouteV1().Routes(namespace).Update(ctx, routeRequest, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update route: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	updateRoute.Kind = "Route"
	updateRoute.APIVersion = "route.openshift.io/v1"
	c.JSON(200, updateRoute)
}

func (h *handler) getRoute(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get route")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	route, err := client.OpenshiftRouteV1().Routes(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get route: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	route.APIVersion = "route.openshift.io/v1"
	route.Kind = "Route"
	c.JSON(200, route)

}

func (h *handler) listRoute(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list route")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	gvr := schema.GroupVersionResource{Group: "route.openshift.io", Version: "v1", Resource: "routes"}
	if informer != nil && informer.IsInformerSynced(gvr) {
		l, err := labels.Parse(labelSelector)
		if err != nil {
			log.Errorf("failed to parse labelSelector: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		results, err := informer.Lister(gvr).ByNamespace(namespace).List(l)
		if err != nil {
			log.Errorf("informer failed to list route: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		c.JSON(200, map[string]interface{}{
			"kind":       "List",
			"apiVersion": "v1",
			"items":      results,
		})
		return
	}

	// create cluster client
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	routeList, err := client.OpenshiftRouteV1().Routes(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to get route list: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	routeList.APIVersion = "v1"
	routeList.Kind = "List"
	for index := range routeList.Items {
		routeList.Items[index].Kind = "Route"
		routeList.Items[index].APIVersion = "route.openshift.io/v1"
	}
	c.JSON(200, routeList)

}

func (h *handler) listRoutePods(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list pods of route")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	// create cluster client
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	route, err := client.OpenshiftRouteV1().Routes(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get route: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	pods, err := podutil.ListRoutePods(client, route)
	if err != nil {
		log.Errorf("failed to get pods: %v", err)
		common.HandleError(c, 500, err)
	}

	c.JSON(200, pods)
}

func (h *handler) deleteRoute(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete route")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	// create cluster client
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}

	err = client.OpenshiftRouteV1().Routes(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
		} else {
			log.Errorf("failed to delete route: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	} else {
		c.JSON(200, struct{}{})
	}

}
