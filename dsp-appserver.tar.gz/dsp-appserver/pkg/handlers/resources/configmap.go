package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"

	corev1 "k8s.io/api/core/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"
	v1 "kmodules.xyz/client-go/core/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	cmutil "github.com/daocloud/dsp-appserver/pkg/util/configmap"
)

// list configMap
func (h *handler) listConfigMap(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list configmap")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	gvr := schema.GroupVersionResource{Group: "", Version: "v1", Resource: "configmaps"}
	if informer != nil && informer.IsInformerSynced(gvr) {
		l, err := labels.Parse(labelSelector)
		if err != nil {
			log.Errorf("failed to parse labelSelector: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		results, err := informer.Lister(gvr).ByNamespace(namespace).List(l)
		if err != nil {
			log.Errorf("informer failed to list configmap: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		c.JSON(200, map[string]interface{}{
			"kind":       "List",
			"apiVersion": "v1",
			"items":      results,
		})
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	configMapList, err := client.CoreV1().ConfigMaps(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("get configmapList error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	configMapList.APIVersion = "v1"
	configMapList.Kind = "List"
	for index := range configMapList.Items {
		configMapList.Items[index].Kind = "ConfigMap"
		configMapList.Items[index].APIVersion = "v1"
	}

	c.JSON(200, configMapList)
}

// get configmap
func (h *handler) getConfigMap(c *gin.Context) {

	span, ctx := utiltrace.StartSpanFromGin(c, "get configmap")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	configMap, err := client.CoreV1().ConfigMaps(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("get configmap error :%v", err)
		common.HandleError(c, 500, err)
		return
	}

	configMap.Kind = "ConfigMap"
	configMap.APIVersion = "v1"

	c.JSON(200, configMap)
}

// create configMap
func (h *handler) createConfigMap(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create configmap")
	defer span.Finish()

	namespace := c.Param("namespace")

	configMapRequest := &corev1.ConfigMap{}
	err := c.BindJSON(configMapRequest)
	if err != nil {
		log.Errorf("get requestBody error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	// force namespace
	configMapRequest.Namespace = namespace

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	configMap, err := client.CoreV1().ConfigMaps(namespace).Create(ctx, configMapRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("create configMap error %v", err)
		common.HandleError(c, 500, err)
		return
	}

	configMap.Kind = "ConfigMap"
	configMap.APIVersion = "v1"
	c.JSON(200, configMap)
}

func (h *handler) updateConfigMap(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update configmap")
	defer span.Finish()

	configMapRequest := &corev1.ConfigMap{}
	err := c.BindJSON(configMapRequest)
	if err != nil {
		log.Errorf("get requestBody error %v", err)
		common.HandleError(c, 500, err)
		return
	}
	log.Infof("requestBody: %v", configMapRequest)

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	configMap, err := v1.TryUpdateConfigMap(ctx, client, configMapRequest.ObjectMeta, func(d *corev1.ConfigMap) *corev1.ConfigMap {
		configMapRequest.ResourceVersion = d.ResourceVersion
		return configMapRequest
	}, metav1.UpdateOptions{})

	if err != nil {
		log.Errorf("update configMap error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	// configMap.ObjectMeta.Name =

	// configMap, err := client.CoreV1().ConfigMaps(namespace).Update(name, metav1.GetOptions{})
	configMap.Kind = "ConfigMap"
	configMap.APIVersion = "v1"
	c.JSON(200, configMap)
}

func (h *handler) deleteConfigMap(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete configmap")
	defer span.Finish()
	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}

	err = client.CoreV1().ConfigMaps(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
			return
		} else {
			log.Errorf("delete configMap error: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	}
	c.JSON(200, struct{}{})
}

func (h *handler) listConfigMapObjectReference(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list object references of a configmap")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	references, err := cmutil.ListObjectReference(ctx, client, namespace, name)
	if err != nil {
		log.Errorf("failed to list object references of the configmap %s in the namespace %s: %v", name, namespace, err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, references)
}
