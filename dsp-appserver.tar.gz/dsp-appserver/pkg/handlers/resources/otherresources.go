package resources

import (
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/gin-gonic/gin"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime/schema"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	resourceutil "github.com/daocloud/dsp-appserver/pkg/util/resource"
)

func getRvrByQuery(c *gin.Context) (*schema.GroupVersionResource, error) {
	gvrStr := c.Query("gvr")
	if len(gvrStr) == 0 {
		return nil, fmt.Errorf("gvr is required")
	}

	gvr := schema.GroupVersionResource{}
	err := json.Unmarshal([]byte(gvrStr), &gvr)
	if err != nil {
		return nil, fmt.Errorf("can not unmarshal gvr %s error: %v", gvrStr, err)
	}

	return &gvr, nil
}

// list other resources by gvr
func (h *handler) listResources(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list other resources")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	gvr, err := getRvrByQuery(c)
	if err != nil {
		log.Errorf("get gvr from query error: %v", err)
		common.HandleError(c, 400, fmt.Errorf("get gvr from query error: %v", err))
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	resourceList, err := client.Resource(*gvr).Namespace(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to list resources : %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resourceList)
	return
}

// get resource by gvr and name
func (h *handler) getResource(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get other resources")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	gvr, err := getRvrByQuery(c)
	if err != nil {
		log.Errorf("get gvr from query error: %v", err)
		common.HandleError(c, 400, fmt.Errorf("get gvr from query error: %v", err))
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	resource, err := client.Resource(*gvr).Namespace(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get resource : %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resource)
	return
}

// create resource by gvr and yaml
func (h *handler) createResource(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create other resources")
	defer span.Finish()

	namespace := c.Param("namespace")

	gvr, err := getRvrByQuery(c)
	if err != nil {
		log.Errorf("get gvr from query error: %v", err)
		common.HandleError(c, 400, fmt.Errorf("get gvr from query error: %v", err))
		return
	}

	updateRequest := unstructured.Unstructured{}
	err = c.Bind(&updateRequest)
	if err != nil {
		log.Errorf("failed to bind request body: %v", err)
		common.HandleError(c, 400, fmt.Errorf("failed to bind request body: %v", err))
		return
	}
	updateRequest.SetNamespace(namespace)

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	// check nodePort
	if err = resourceutil.CheckNodePort(client, &updateRequest); err != nil {
		log.Errorf("failed to check nodePort: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	resource, err := client.Resource(*gvr).Namespace(namespace).Create(ctx, &updateRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to create resource: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resource)
	return
}

// update resource by gvr,name and yaml
func (h *handler) updateResource(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update other resources")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	gvr, err := getRvrByQuery(c)
	if err != nil {
		log.Errorf("get gvr from query error: %v", err)
		common.HandleError(c, 400, fmt.Errorf("get gvr from query error: %v", err))
		return
	}

	updateRequest := unstructured.Unstructured{}
	err = c.Bind(&updateRequest)
	if err != nil {
		log.Errorf("failed to bind request body: %v", err)
		common.HandleError(c, 400, fmt.Errorf("failed to bind request body: %v", err))
		return
	}

	// check name
	if updateRequest.GetName() != name {
		log.Errorf("name not equal post %s but param is %s", updateRequest.GetName(), name)
		common.HandleError(c, 400, fmt.Errorf("name not equal post %s but param is %s", updateRequest.GetName(), name))
		return
	}
	updateRequest.SetNamespace(namespace)

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	// check nodePort
	if err = resourceutil.CheckNodePort(client, &updateRequest); err != nil {
		log.Errorf("failed to check nodePort: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	resource, err := client.Resource(*gvr).Namespace(namespace).Update(ctx, &updateRequest, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to create resource: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, resource)
	return
}

// delete resource by name and gvr
func (h *handler) deleteResource(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete other resources")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	gvr, err := getRvrByQuery(c)
	if err != nil {
		log.Errorf("get gvr from query error: %v", err)
		common.HandleError(c, 400, fmt.Errorf("get gvr from query error: %v", err))
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}

	err = client.Resource(*gvr).Namespace(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		log.Errorf("failed to delete resources: %v", err)
		common.HandleError(c, 500, fmt.Errorf("failed to delete resources: %v", err))
		return
	}

	c.JSON(200, struct{}{})
	return
}
