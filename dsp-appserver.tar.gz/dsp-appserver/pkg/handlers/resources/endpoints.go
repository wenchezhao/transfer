package resources

import (
	"github.com/gin-gonic/gin"
	"github.com/opentracing/opentracing-go"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func (h *handler) listEndPoints(c *gin.Context) {
	span, ctx := opentracing.StartSpanFromContext(c.Request.Context(), "list EndPoints")
	defer span.Finish()

	// parse request params
	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	list, err := client.CoreV1().Endpoints(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to list Endpoints: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	list.Kind = "List"
	list.APIVersion = "v1"

	for index := range list.Items {
		list.Items[index].APIVersion = "apps.openshift.io/v1"
		list.Items[index].Kind = "EndPoints"
	}
	c.JSON(200, list)
}

func (h *handler) getEndPoints(c *gin.Context) {
	span, ctx := opentracing.StartSpanFromContext(c.Request.Context(), "get EndPoints")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	endpoint, err := client.CoreV1().Endpoints(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get EndPoints: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	endpoint.APIVersion = "v1"
	endpoint.Kind = "EndPoints"

	c.JSON(200, endpoint)

}
