package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/kubectl/pkg/scheme"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	pvcutil "github.com/daocloud/dsp-appserver/pkg/util/pvc"
)

func (h *handler) listPersistentVolumeClaim(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list pvc")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	persistentVolumeClaimList, err := client.CoreV1().PersistentVolumeClaims(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("failed to list pvc: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	persistentVolumeClaimList.Kind = "List"
	persistentVolumeClaimList.APIVersion = "v1"

	for index := range persistentVolumeClaimList.Items {
		persistentVolumeClaimList.Items[index].APIVersion = "v1"
		persistentVolumeClaimList.Items[index].Kind = "PersistentVolumeClaim"
	}
	c.JSON(200, persistentVolumeClaimList)

}

func (h *handler) getPersistentVolumeClaim(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get pvc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolumeClaim, err := client.CoreV1().PersistentVolumeClaims(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get pvc: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolumeClaim.APIVersion = "v1"
	persistentVolumeClaim.Kind = "PersistentVolumeClaim"

	c.JSON(200, persistentVolumeClaim)

}

func (h *handler) createPersistentVolumeClaim(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create pvc")
	defer span.Finish()

	namespace := c.Param("namespace")

	pvcRequest := &corev1.PersistentVolumeClaim{}
	err := c.BindJSON(pvcRequest)
	if err != nil {
		log.Errorf("failed to BindJSON pvcRequest: %v", err)
		common.HandleError(c, 400, err)
		return
	}
	// force namespace
	pvcRequest.Namespace = namespace

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolumeClaim, err := client.CoreV1().PersistentVolumeClaims(namespace).Create(ctx, pvcRequest, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("failed to create pvc: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolumeClaim.APIVersion = "v1"
	persistentVolumeClaim.Kind = "PersistentVolumeClaim"

	c.JSON(200, persistentVolumeClaim)

}

func (h *handler) updatePersistentVolumeClaim(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update pvc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	pvcRequest := &corev1.PersistentVolumeClaim{}
	err := c.BindJSON(pvcRequest)
	if err != nil {
		log.Errorf("failed to BindJSON pvcRequest: %v", err)
		common.HandleError(c, 400, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	oldPersistentVolumeClaim, err := client.CoreV1().PersistentVolumeClaims(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get pvc: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	pvcRequest.ResourceVersion = oldPersistentVolumeClaim.ResourceVersion

	persistentVolumeClaim, err := client.CoreV1().PersistentVolumeClaims(namespace).Update(ctx, pvcRequest, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to update pvc: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolumeClaim.APIVersion = "v1"
	persistentVolumeClaim.Kind = "PersistentVolumeClaim"

	c.JSON(200, persistentVolumeClaim)
	return
}

func (h *handler) deletePersistentVolumeClaim(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete pvc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}
	err = client.CoreV1().PersistentVolumeClaims(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		log.Errorf("failed to delete pvc: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, struct{}{})

}

func (h *handler) listPersistentVolumeClaimObjectReference(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list object references of a pvc")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	references, err := pvcutil.ListObjectReference(ctx, client, namespace, name)
	if err != nil {
		log.Errorf("failed to list object references of the pvc %s in the namespace %s: %v", name, namespace, err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, references)
}

func (h *handler) listPersistentVolumeClaimEvent(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list persistentVolumeClaim eventList")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	persistentVolumeClaim, err := client.CoreV1().PersistentVolumeClaims(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get persistentVolumeClaim: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	eventList, err := client.CoreV1().Events(namespace).Search(scheme.Scheme, persistentVolumeClaim)
	if err != nil {
		log.Errorf("failed to get persistentVolume eventList: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	eventList.APIVersion = "v1"
	eventList.Kind = "List"
	for index := range eventList.Items {
		eventList.Items[index].APIVersion = "v1"
		eventList.Items[index].Kind = "Event"
	}
	c.JSON(200, eventList)
	return
}

// list pod of a pvc
func (h *handler) listPodOfPersistentVolumeClaim(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list pod of persistentVolumeClaim")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	pods, err := pvcutil.ListPodOfPersistentVolumeClaim(ctx, client, namespace, name)
	if err != nil {
		log.Errorf("failed to get pods of persistentVolumeClaim: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	podList := &corev1.PodList{}
	podList.APIVersion = "v1"
	podList.Kind = "List"
	podList.Items = pods

	c.JSON(200, podList)
	return

}
