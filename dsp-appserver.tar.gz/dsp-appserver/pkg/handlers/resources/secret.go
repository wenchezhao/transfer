package resources

import (
	"strconv"

	"github.com/gin-gonic/gin"

	corev1 "k8s.io/api/core/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime/schema"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
	secretutil "github.com/daocloud/dsp-appserver/pkg/util/secret"
)

func (h *handler) getSecret(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "get secret")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	secret, err := client.CoreV1().Secrets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("get secret error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	secret.Kind = "Secret"
	secret.APIVersion = "v1"
	c.JSON(200, secret)
}

func (h *handler) listSecret(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list secret")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	informer := h.informerManager.GetSingleClusterManager(c.GetHeader("clusterID"))
	gvr := schema.GroupVersionResource{Group: "", Version: "v1", Resource: "secrets"}
	if informer != nil && informer.IsInformerSynced(gvr) {
		l, err := labels.Parse(labelSelector)
		if err != nil {
			log.Errorf("failed to parse labelSelector: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		results, err := informer.Lister(gvr).ByNamespace(namespace).List(l)
		if err != nil {
			log.Errorf("informer failed to list secret: %v", err)
			common.HandleError(c, 500, err)
			return
		}
		c.JSON(200, map[string]interface{}{
			"kind":       "List",
			"apiVersion": "v1",
			"items":      results,
		})
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	secretList, err := client.CoreV1().Secrets(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("get secretlist error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	secretList.Kind = "List"
	secretList.APIVersion = "v1"
	for index := range secretList.Items {
		secretList.Items[index].APIVersion = "v1"
		secretList.Items[index].Kind = "Secret"
	}
	c.JSON(200, secretList)

}

func (h *handler) createSecret(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "create secret")
	defer span.Finish()

	namespace := c.Param("namespace")

	requestBody := &corev1.Secret{}
	err := c.BindJSON(requestBody)
	if err != nil {
		log.Errorf("get body error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	// force namespace
	requestBody.Namespace = namespace

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	secret, err := client.CoreV1().Secrets(namespace).Create(ctx, requestBody, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("create secret error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	secret.APIVersion = "v1"
	secret.Kind = "Secret"
	c.JSON(200, secret)
}

func (h *handler) updateSecret(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "update secret")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	requestBody := &corev1.Secret{}
	err := c.BindJSON(requestBody)
	if err != nil {
		log.Errorf("get body error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	secret, err := client.CoreV1().Secrets(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("query secret error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	requestBody.ResourceVersion = secret.ResourceVersion
	updateSecret, err := client.CoreV1().Secrets(namespace).Update(ctx, requestBody, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("update secret error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	updateSecret.Kind = "Secret"
	updateSecret.APIVersion = "v1"
	c.JSON(200, updateSecret)
}

func (h *handler) deleteSecret(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "delete secret")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")
	gracePeriodSeconds := c.Query("gracePeriodSeconds")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	var deleteOptions metav1.DeleteOptions
	if gracePeriodSeconds != "" {
		gracePeriodSecondInt, ise := strconv.ParseInt(gracePeriodSeconds, 10, 64)
		if ise == nil {
			deleteOptions.GracePeriodSeconds = &gracePeriodSecondInt
		}
	}

	err = client.CoreV1().Secrets(namespace).Delete(ctx, name, deleteOptions)
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
			return
		} else {
			log.Errorf("delete secret error: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	}
	c.JSON(200, struct{}{})
}

func (h *handler) listSecretObjectReference(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "list object references of a secret")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	references, err := secretutil.ListObjectReference(ctx, client, namespace, name)
	if err != nil {
		log.Errorf("failed to list object references of the secret %s in the namespace %s: %v", name, namespace, err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, references)
}
