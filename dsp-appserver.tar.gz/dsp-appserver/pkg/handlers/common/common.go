package common

import (
	"fmt"

	"github.com/gin-gonic/gin"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"

	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/model/zone"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
)

var log = logi.Log.Sugar()

// 统一的错误返回结构
type Response struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

// 将错误的返回处理独立到一个模块，由该模块维护handler公用的功能
func HandleError(c *gin.Context, code int, err error) {
	if err != nil {
		log.Errorf("err: %+v", err)
	}

	r := Response{
		Code:    code,
		Message: fmt.Sprintf("appserver: %s", err.Error()),
	}

	switch t := err.(type) {
	case kapierrors.APIStatus:
		r.Code = int(t.Status().Code)
		r.Message = fmt.Sprintf("appserver: %s", t.Status().Message)
	}

	c.JSON(r.Code, r)
}

// 检查请求头中是否有clusterID
func CheckCluster(cluster string) error {
	if cluster == "" {
		log.Errorf("clusterID can not be null")
		return fmt.Errorf("clusterID can not be null")
	}
	return nil
}

// 根据请求头中的clusterID,获取kubernets客户端
func GetClientByClusterInfo(mgr *multicluster.ClusterClientManager, c *gin.Context) (client clientset.Interface, err error) {
	clusterID := c.GetHeader("clusterID")

	err = CheckCluster(clusterID)
	if err != nil {
		return nil, err
	}

	client, err = mgr.GetClientFromCache(clusterID)
	if err != nil {
		return nil, err
	}

	return client, nil
}

// 根据请求头中的clusterID,获取kubernets客户端
func GetZoneByClusterInfo(mgr *multicluster.ClusterClientManager, c *gin.Context) (zoneInfo *zone.TiZone, err error) {
	clusterID := c.GetHeader("clusterID")

	err = CheckCluster(clusterID)
	if err != nil {
		return nil, err
	}

	zoneInfo, err = mgr.FetchTiZone(clusterID)
	if err != nil {
		return nil, err
	}

	return zoneInfo, nil
}
