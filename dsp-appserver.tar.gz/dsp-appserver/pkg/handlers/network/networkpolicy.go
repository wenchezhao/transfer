package network

import (
	"github.com/gin-gonic/gin"

	networkV1 "k8s.io/api/networking/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

// list networkpolicy
func (h *handler) listNetworkpolicy(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "listNetworkpolicy")
	defer span.Finish()

	namespace := c.Param("namespace")
	labelSelector := c.Query("labelSelector")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	networkpolicys, err := client.NetworkingV1().NetworkPolicies(namespace).List(ctx, metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil {
		log.Errorf("list ingress error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	networkpolicys.APIVersion = "v1"
	networkpolicys.Kind = "List"
	for index := range networkpolicys.Items {
		networkpolicys.Items[index].Kind = "NetworkPolicy"
		networkpolicys.Items[index].APIVersion = "v1"
	}

	c.JSON(200, networkpolicys)
}

// get Networkpolicy
func (h *handler) getNetworkpolicy(c *gin.Context) {

	span, ctx := utiltrace.StartSpanFromGin(c, "getNetworkpolicy")
	defer span.Finish()

	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	ing, err := client.NetworkingV1().NetworkPolicies(namespace).Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("getNetworkpolicy error :%v", err)
		common.HandleError(c, 500, err)
		return
	}

	ing.Kind = "Networkpolicy"
	ing.APIVersion = "v1"

	c.JSON(200, ing)
}

// create Networkpolicy
func (h *handler) createNetworkpolicy(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "createNetworkpolicy")
	defer span.Finish()

	namespace := c.Param("namespace")

	networkpolicyToCreate := &networkV1.NetworkPolicy{}
	err := c.BindJSON(networkpolicyToCreate)
	if err != nil {
		log.Errorf("get requestBody error: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	// force namespace
	networkpolicyToCreate.Namespace = namespace

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	_, err = client.NetworkingV1().NetworkPolicies(namespace).Create(ctx, networkpolicyToCreate, metav1.CreateOptions{})
	if err != nil {
		log.Errorf("create networkpolicy error %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, struct{}{})
}

// update Networkpolicy
func (h *handler) updateNetworkpolicy(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "updateNetworkpolicy")
	defer span.Finish()

	namespace := c.Param("namespace")

	networkpolicyToUpdate := &networkV1.NetworkPolicy{}
	err := c.BindJSON(networkpolicyToUpdate)
	if err != nil {
		log.Errorf("get requestBody error %v", err)
		common.HandleError(c, 500, err)
		return
	}
	log.Infof("requestBody: %v", networkpolicyToUpdate)

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	_, err = client.NetworkingV1().NetworkPolicies(namespace).Update(ctx, networkpolicyToUpdate, metav1.UpdateOptions{})

	if err != nil {
		log.Errorf("update networkpolicy error: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	c.JSON(200, struct{}{})
}

// delete Networkpolicy
func (h *handler) deleteNetworkpolicy(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "deleteNetworkpolicy")
	defer span.Finish()
	namespace := c.Param("namespace")
	name := c.Param("name")

	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	err = client.NetworkingV1().NetworkPolicies(namespace).Delete(ctx, name, metav1.DeleteOptions{})
	if err != nil {
		if kapierrors.IsNotFound(err) {
			c.JSON(200, struct{}{})
			return
		} else {
			log.Errorf("deleteNetworkpolicy error: %v", err)
			common.HandleError(c, 500, err)
			return
		}
	}
	c.JSON(200, struct{}{})
}
