package network

import (
	"sort"
	"strconv"

	"github.com/gin-gonic/gin"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

type portType string

const (
	routerType  portType = "Route"
	serviceType portType = "Service"
)

type portDetail struct {
	Port        int      `json:"port"`
	Namespace   string   `json:"namespace"`
	Type        portType `json:"type"`
	ServiceName string   `json:"serviceName"`
}

type portsList []portDetail

func (a portsList) Len() int {
	return len(a)
}
func (a portsList) Swap(i, j int) {
	a[i], a[j] = a[j], a[i]
}
func (a portsList) Less(i, j int) bool {
	return a[i].Port < a[j].Port
}

func (h *handler) listPorts(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "listPorts")
	defer span.Finish()

	// create cluster client
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err.Error())
		common.HandleError(c, 500, err)
		return
	}

	routeList, err := client.OpenshiftRouteV1().Routes(metav1.NamespaceAll).List(ctx, metav1.ListOptions{})
	if err != nil && !kapierrors.IsNotFound(err) {
		log.Errorf("failed to get route list: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	serviceList, err := client.CoreV1().Services(metav1.NamespaceAll).List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to get service list: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var portsListRet portsList
	for _, route := range routeList.Items {
		value, ok := route.ObjectMeta.Annotations["haproxy.router.openshift.io/external-tcp-port"]
		if !ok {
			continue
		}
		valuePort, _ := strconv.Atoi(value)
		portsListRet = append(portsListRet, portDetail{
			Namespace:   route.Namespace,
			Port:        valuePort,
			Type:        routerType,
			ServiceName: route.Name,
		})
	}
	for _, service := range serviceList.Items {
		for _, port := range service.Spec.Ports {
			nodePort := 0
			if port.NodePort > 0 {
				nodePort = int(port.NodePort)
			}
			if nodePort > 0 {
				portsListRet = append(portsListRet, portDetail{
					Namespace:   service.Namespace,
					Port:        nodePort,
					Type:        serviceType,
					ServiceName: service.Name,
				})
			}
		}
	}

	sort.Sort(portsListRet)
	c.JSON(200, portsListRet)
}
