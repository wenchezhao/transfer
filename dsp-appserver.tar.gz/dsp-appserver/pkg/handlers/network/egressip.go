package network

import (
	"errors"

	"github.com/gin-gonic/gin"
	networkapi "github.com/openshift/api/network/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	k8string "k8s.io/apimachinery/pkg/util/sets"

	"github.com/daocloud/dsp-appserver/pkg/handlers/common"
	utiltrace "github.com/daocloud/dsp-appserver/pkg/trace"
)

type netnamespaceDetail struct {
	Namespace string                            `json:"namespace"`
	Nodes     []string                          `json:"nodes"`
	Egressips []networkapi.NetNamespaceEgressIP `json:"egressips"`
}

type netnamespaceList struct {
	Items []netnamespaceDetail `json:"items"`
}

type egressipsList struct {
	Egressips []networkapi.HostSubnetEgressIP `json:"egressips"`
}

func (h *handler) getNetnamespace(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "getNetnamespace")
	defer span.Finish()

	name := c.Param("name")

	if len(name) < 1 {
		common.HandleError(c, 400, errors.New("name can not be null"))
		return
	}

	// create cluster client
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err.Error())
		common.HandleError(c, 500, err)
		return
	}

	netNamespace, err := client.OpenshiftNetNamespaceV1().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get netNamespace: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var netnamespaceDetailRet netnamespaceDetail
	netnamespaceDetailRet.Egressips = netNamespace.EgressIPs
	netnamespaceDetailRet.Namespace = netNamespace.Name
	netnamespaceDetailRet.Nodes = []string{}

	c.JSON(200, netnamespaceDetailRet)

}

func (h *handler) listNetnamespace(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "listNetnamespace")
	defer span.Finish()

	// create cluster client
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err.Error())
		common.HandleError(c, 500, err)
		return
	}

	netNamespaces, err := client.OpenshiftNetNamespaceV1().List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to get netNamespace: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	hostsubents, err := client.OpenshiftHostSubnetV1().List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to get hostsubents: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	hostsubentMapSet := make(map[string]k8string.String)
	for _, hostsubent := range hostsubents.Items {
		if len(hostsubent.EgressIPs) > 0 {
			hostsubentEgressIP := k8string.NewString()
			for _, egressIP := range hostsubent.EgressIPs {
				hostsubentEgressIP = hostsubentEgressIP.Insert(string(egressIP))
			}
			hostsubentMapSet[hostsubent.Host] = hostsubentEgressIP
		}
	}

	var netnamespaceListRet netnamespaceList
	for _, netNamespace := range netNamespaces.Items {
		var netnamespaceDetailRet netnamespaceDetail
		if len(netNamespace.EgressIPs) > 0 {
			netNamespaceEgressIP := k8string.NewString()
			for _, egressIP := range netNamespace.EgressIPs {
				netNamespaceEgressIP = netNamespaceEgressIP.Insert(string(egressIP))
			}

			for host, hostsubnetSet := range hostsubentMapSet {
				if netNamespaceEgressIP.HasAny(hostsubnetSet.UnsortedList()...) {
					netnamespaceDetailRet.Nodes = append(netnamespaceDetailRet.Nodes, host)
				}
			}
		}
		netnamespaceDetailRet.Egressips = netNamespace.EgressIPs
		netnamespaceDetailRet.Namespace = netNamespace.Name

		netnamespaceListRet.Items = append(netnamespaceListRet.Items, netnamespaceDetailRet)
	}

	c.JSON(200, netnamespaceListRet)
}

func (h *handler) listEgressIps(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "listEgressIps")
	defer span.Finish()

	// create cluster client
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err.Error())
		common.HandleError(c, 500, err)
		return
	}

	hostsubents, err := client.OpenshiftHostSubnetV1().List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to get hostsubents: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	netNamespaces, err := client.OpenshiftNetNamespaceV1().List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to get netNamespace: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	var egressipsListRet egressipsList

	egressipsHostsubnets := k8string.NewString()
	egressipsNetnamespaces := k8string.NewString()

	for _, hostsubent := range hostsubents.Items {
		if len(hostsubent.EgressIPs) > 0 {
			for _, egressIPs := range hostsubent.EgressIPs {
				egressipsHostsubnets.Insert(string(egressIPs))
			}
		}
	}
	for _, netnamespace := range netNamespaces.Items {
		if len(netnamespace.EgressIPs) > 0 {
			for _, egressIPs := range netnamespace.EgressIPs {
				egressipsNetnamespaces.Insert(string(egressIPs))
			}
		}
	}

	differents := egressipsHostsubnets.Difference(egressipsNetnamespaces)
	if differents != nil {
		differentsList := differents.List()
		for _, differentIp := range differentsList {
			egressipsListRet.Egressips = append(egressipsListRet.Egressips, networkapi.HostSubnetEgressIP(differentIp))
		}
	}

	c.JSON(200, egressipsListRet)
}

func (h *handler) updateNetnamespace(c *gin.Context) {
	span, ctx := utiltrace.StartSpanFromGin(c, "getNetnamespace")
	defer span.Finish()

	name := c.Param("name")
	egressips := c.QueryArray("egressips")

	if len(name) < 1 {
		common.HandleError(c, 400, errors.New("name can not be null"))
		return
	}

	// create cluster client
	client, err := common.GetClientByClusterInfo(h.clusterClientManager, c)
	if err != nil {
		log.Errorf("failed to get cluster client: %v", err.Error())
		common.HandleError(c, 500, err)
		return
	}

	netNamespace, err := client.OpenshiftNetNamespaceV1().Get(ctx, name, metav1.GetOptions{})
	if err != nil {
		log.Errorf("failed to get netNamespace: %v", err)
		common.HandleError(c, 500, err)
		return
	}

	netNamespace.EgressIPs = []networkapi.NetNamespaceEgressIP{}

	for _, s := range egressips {
		netNamespace.EgressIPs = append(netNamespace.EgressIPs, networkapi.NetNamespaceEgressIP(s))
	}

	_, err = client.OpenshiftNetNamespaceV1().Update(ctx, netNamespace, metav1.UpdateOptions{})
	if err != nil {
		log.Errorf("failed to Update netNamespace: %v", err)
		common.HandleError(c, 500, err)
		return
	}
	c.JSON(200, "success")

}
