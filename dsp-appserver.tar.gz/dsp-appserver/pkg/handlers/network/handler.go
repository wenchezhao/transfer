package network

import (
	"github.com/gin-gonic/gin"

	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
)

var log = logi.Log.Sugar()

type handler struct {
	clusterClientManager *multicluster.ClusterClientManager
}

func InstallHandlers(routerGroup *gin.RouterGroup, clusterClientManager *multicluster.ClusterClientManager) {
	h := &handler{
		clusterClientManager: clusterClientManager,
	}

	routerGroup.GET("/v1/network/ports", h.listPorts)

	routerGroup.GET("/v1/network/egressip", h.listEgressIps)
	routerGroup.GET("/v1/network/netnamespace", h.listNetnamespace)
	routerGroup.GET("/v1/network/netnamespace/:name", h.getNetnamespace)
	routerGroup.PUT("/v1/network/netnamespace/:name", h.updateNetnamespace)

	routerGroup.GET("/v1/namespaces/:namespace/networkpolicy", h.listNetworkpolicy)
	routerGroup.GET("/v1/namespaces/:namespace/networkpolicy/:name", h.getNetworkpolicy)
	routerGroup.POST("/v1/namespaces/:namespace/networkpolicy", h.createNetworkpolicy)
	routerGroup.PUT("/v1/namespaces/:namespace/networkpolicy/:name", h.updateNetworkpolicy)
	routerGroup.DELETE("/v1/namespaces/:namespace/networkpolicy/:name", h.deleteNetworkpolicy)
}
