package config

import (
	"reflect"
	"testing"

	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
)

func TestConfig_ToMap(t *testing.T) {
	type fields struct {
		KubernetesOptions *kubeclient.KubernetesOptions
	}
	tests := []struct {
		name   string
		fields fields
		want   map[string]bool
	}{
		{
			name: "test1",
			fields: fields{
				KubernetesOptions: kubeclient.NewKubernetesOptions(),
			},
			want: map[string]bool{"addon": true, "authorization": true, "ghippo": true, "kangaroo": false, "kubernetes": true, "observability": true, "redis": false, "extra": false},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			conf := &Config{
				KubernetesOptions: tt.fields.KubernetesOptions,
			}
			if got := conf.ToMap(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ToMap() = %v, want %v", got, tt.want)
			}
		})
	}
}
