package apiserver

import (
	"bytes"
	"context"
	"crypto/tls"
	"fmt"
	clusterpediav1beta1 "github.com/clusterpedia-io/api/clusterpedia/v1beta1"
	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/sharedcli/profileflag"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
	"github.com/daocloud/dsp-appserver/pkg/util/promhttp"
	"io"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/discovery"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"k8s.io/klog/v2"

	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	"github.com/daocloud/dsp-appserver/pkg/config"
	apphandlers "github.com/daocloud/dsp-appserver/pkg/handlers/app"
	clusterhandlers "github.com/daocloud/dsp-appserver/pkg/handlers/cluster"
	dashboardhandlers "github.com/daocloud/dsp-appserver/pkg/handlers/dashboard"
	dceHandle "github.com/daocloud/dsp-appserver/pkg/handlers/dce"
	networkhandlers "github.com/daocloud/dsp-appserver/pkg/handlers/network"
	resourceshandlers "github.com/daocloud/dsp-appserver/pkg/handlers/resources"
	websockethandlers "github.com/daocloud/dsp-appserver/pkg/handlers/websocket"
	"github.com/daocloud/dsp-appserver/pkg/informermanager"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
)

type APIServer struct {
	Cfg *config.Config

	Engine               *gin.Engine
	ClusterClientManager *multicluster.ClusterClientManager
	InformerManager      informermanager.InformerManager
	HttpServer           *http.Server

	ProfileOpts profileflag.Options

	// kubeClient is a collection of all kubernetes(include CRDs) objects clientset
	KubernetesClient kubeclient.Client

	ClusterClient clusterclient.ClusterClients

	InformerFactory informers.SharedInformerFactory
}

func (s *APIServer) PrepareRun(ctx context.Context) error {
	if !s.Cfg.Debug {
		gin.SetMode(gin.ReleaseMode)
	}
	if s.Cfg.Debug {
		// 打印body
		s.Engine.Use(RequestLoggerMiddleware)
	}

	// TODO: add middleware here

	s.RegisterBaseAPI()

	return s.RegisterCoreAPI()
}

func (s *APIServer) RegisterBaseAPI() {
	http.Handle("/ping", s.Engine)
	http.Handle("/metrics", s.Engine)
	http.Handle("/v1/", s.Engine)
	// install healthz
	s.Engine.GET("/ping", func(c *gin.Context) {
		c.String(200, "pong")
	})
	// install metrics
	s.Engine.GET("/metrics", promhttp.HandlerForGins)
}

func (s *APIServer) RegisterCoreAPI() error {
	// enable basic auth
	router := s.Engine.Group("/", gin.BasicAuth(gin.Accounts{
		s.Cfg.BasicAuthUser: s.Cfg.BasicAuthPassword,
	}))

	// register cloudshell handler
	err := RegisterCloudshellHandler(router, s.KubernetesClient, s.InformerFactory, s.ClusterClient)
	if err != nil {
		return err
	}

	// install user handlers
	apphandlers.InstallHandlers(router, s.ClusterClientManager, s.InformerManager)
	clusterhandlers.InstallHandlers(router, s.ClusterClientManager, s.Cfg.ResourcesC)
	websockethandlers.InstallHandlers(router, s.ClusterClientManager)
	dashboardhandlers.InstallHandlers(router, s.ClusterClientManager, s.Cfg.ResourcesC)
	resourceshandlers.InstallHandlers(router, s.ClusterClientManager, s.InformerManager)
	//网络管理
	networkhandlers.InstallHandlers(router, s.ClusterClientManager)

	//dce 网络对接
	v1dces := router.Group("/v1/dce")
	dceHandle.InstallHandlers(v1dces, s.ClusterClientManager)
	return nil
}

func (s *APIServer) Run(ctx context.Context) error {
	// start pprof server
	profileflag.ListenAndServe(s.ProfileOpts)

	// sync cluster resources informer
	err := s.waitForResourceSync(ctx)
	if err != nil {
		return err
	}

	// start http server
	go func() {
		if s.Cfg.CertPath != "" && s.Cfg.KeyPath != "" {
			klog.V(4).Infof("CertPath and KeyPath is not null,try to load certificate and key")
			cer, err := tls.LoadX509KeyPair(s.Cfg.CertPath, s.Cfg.KeyPath)
			if err != nil {
				klog.Errorf("failed to load certificate and key: %v", err)
				return
			}
			tlsconfig := &tls.Config{Certificates: []tls.Certificate{cer}}
			s.HttpServer.TLSConfig = tlsconfig
			klog.V(4).Infof("Successful import certificate and key, appserver begins begin to use https")
			if err := s.HttpServer.ListenAndServeTLS(s.Cfg.CertPath, s.Cfg.KeyPath); err != nil && err != http.ErrServerClosed {
				klog.Fatalf("err: %+v", err)
			}
		} else {
			klog.V(4).Infof("CertPath and KeyPath is null, appserver begins to use http")
			if err := s.HttpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				klog.Fatalf("err: %+v", err)
			}
		}
	}()

	s.InformerManager.Start()

	quit := make(chan os.Signal)
	// kill (no param) default send syscanll.SIGTERM
	// kill -2 is syscall.SIGINT
	// kill -9 is syscall. SIGKILL but can"t be catch, so don't need add it
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-ctx.Done()
	klog.V(4).Info("shutdown server ...")

	s.Stop(ctx)
	return nil
}

func (s *APIServer) Stop(ctx context.Context) {
	c, _ := context.WithTimeout(ctx, 3*time.Second)
	if err := s.HttpServer.Shutdown(c); err != nil {
		klog.Errorf("server shutdown err: %+v", err)
		return
	}
	klog.V(4).Info("http server shutdown")
}

// RequestLoggerMiddleware print request and response information
func RequestLoggerMiddleware(c *gin.Context) {
	var buf bytes.Buffer
	tee := io.TeeReader(c.Request.Body, &buf)
	body, _ := io.ReadAll(tee)
	c.Request.Body = io.NopCloser(&buf)
	klog.V(6).Infof("request url: %s", c.Request.RequestURI)
	klog.V(6).Infof("request header: %s", c.Request.Header)
	klog.V(6).Infof("request body: %s", body)
	c.Next()
}

func (s *APIServer) waitForResourceSync(ctx context.Context) error {
	klog.V(0).Info("Start cache objects")

	stopCh := ctx.Done()

	discoveryClient := s.KubernetesClient.Kubernetes().Discovery()
	_, apiResourcesList, err := discoveryClient.ServerGroupsAndResources()
	if err != nil {
		discoveryErr, ok := err.(*discovery.ErrGroupDiscoveryFailed)
		if !ok {
			return err
		}

		clusterPediaErr, exist := discoveryErr.Groups[clusterpediav1beta1.SchemeGroupVersion]
		if exist {
			return clusterPediaErr
		}
	}

	isResourceExists := func(resource schema.GroupVersionResource) bool {
		for _, apiResource := range apiResourcesList {
			if apiResource.GroupVersion == resource.GroupVersion().String() {
				for _, rsc := range apiResource.APIResources {
					if rsc.Name == resource.Resource {
						return true
					}
				}
			}
		}
		return false
	}

	kpandaGVRs := []schema.GroupVersionResource{
		{Group: "cluster.kpanda.io", Version: "v1alpha1", Resource: "clusters"},
	}

	for _, gvr := range kpandaGVRs {
		if !isResourceExists(gvr) {
			return apierrors.NewServiceUnavailable(fmt.Sprintf("resource %s not exists in the cluster", gvr))
		}

		_, err = s.InformerFactory.ForResource(gvr)
		if err != nil {
			return err
		}
	}

	s.InformerFactory.Start(stopCh)
	s.InformerFactory.WaitForCacheSync(stopCh)

	klog.V(0).Info("Finished caching objects")

	return nil
}
