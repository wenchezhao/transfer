package apiserver

import (
	"github.com/gin-gonic/gin"

	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/handlers/cloudshell"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
)

func RegisterCloudshellHandler(router *gin.RouterGroup, kubeclient kubeclient.Client, factory informers.SharedInformerFactory, clusterClient clusterclient.ClusterClients) error {
	handler, err := cloudshell.NewCloudShellHandler(kubeclient, pedia.NewClients(), factory, clusterClient)
	if err != nil {
		return err
	}
	router.GET("/v1/cluster/:clusters/namespaces/:namespace/cloudshell", handler.GetCloudshell)
	router.POST("/v1/cluster/:clusters/namespaces/:namespace/cloudshell", handler.CreateCloudshell)

	return nil
}

// TODO: register other handler here
