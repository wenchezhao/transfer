package trace

import (
	"context"
	"github.com/uber/jaeger-client-go"
	jaegercfg "github.com/uber/jaeger-client-go/config"
	jaegerzap "github.com/uber/jaeger-client-go/log/zap"

	"github.com/gin-gonic/gin"
	"github.com/opentracing/opentracing-go"

	"github.com/daocloud/dsp-appserver/pkg/logi"
)

var log = logi.Log.Sugar()

func SetupTrace(ctx context.Context) (opentracing.Tracer, error) {
	traceCfg, err := jaegercfg.FromEnv()
	if err != nil {
		// parsing errors might happen here, such as when we get a string where we expect a number
		log.Errorf("Could not parse Jaeger env vars: %s", err.Error())
		return nil, err
	}

	if traceCfg.ServiceName == "" {
		traceCfg.ServiceName = "dsp-appserver"
	}

	if logi.IsDebug() {
		// DEBUG
		traceCfg.Sampler.Type = jaeger.SamplerTypeConst
		traceCfg.Sampler.Param = 1
		traceCfg.Reporter.LogSpans = true
	}

	tracer, closer, err := traceCfg.NewTracer(jaegercfg.Logger(jaegerzap.NewLogger(logi.Log)))
	if err != nil {
		log.Errorf("Could not initialize jaeger tracer: %s", err.Error())
		return nil, err
	}

	opentracing.SetGlobalTracer(tracer)
	log.Info("set global tracer")

	go func() {
		<-ctx.Done()
		closer.Close()
		log.Info("tracer close")
	}()

	return tracer, nil
}

// StartSpanFromGin starts and returns a Span with `operationName`, using
// any Span found within `ctx` as a ChildOfRef. If no such parent could be
// found, StartSpanFromGin creates a root (parentless) Span.
func StartSpanFromGin(c *gin.Context, operationName string, opts ...opentracing.StartSpanOption) (opentracing.Span, context.Context) {
	header := c.Request.Header
	carrier := opentracing.HTTPHeadersCarrier(header)
	tracer := opentracing.GlobalTracer()
	spanContext, err := tracer.Extract(opentracing.TextMap, carrier)
	if err != nil {
		span := tracer.StartSpan(operationName, opts...)
		return span, opentracing.ContextWithSpan(c.Request.Context(), span)
	}

	logSpanContext(spanContext)
	opts = append(opts, opentracing.ChildOf(spanContext))
	return opentracing.StartSpanFromContext(c.Request.Context(), operationName, opts...)
}

func logSpanContext(sc opentracing.SpanContext) {
	log.Info("span context:")
	sc.ForeachBaggageItem(func(k, v string) bool {
		log.Infof("key=%s, value=%s", k, v)
		return false
	})
}
