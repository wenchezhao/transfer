/*
Copyright 2022 Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package k8s

import (
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"

	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	rest "k8s.io/client-go/rest"
)

type FakeClient struct {
	// kubernetes client interface
	KubeClient kubernetes.Interface

	// discovery client
	DynamicClient dynamic.Interface

	// generated clientset
	GeneratedClient clusterclientset.Interface

	MasterURL string

	KubeConfig *rest.Config
}

func NewFakeClientSets(kubeClient kubernetes.Interface, dynamicClient dynamic.Interface, kpandaClient clusterclientset.Interface, masterURL string, kubeConfig *rest.Config) Client {
	return &FakeClient{
		KubeClient:      kubeClient,
		DynamicClient:   dynamicClient,
		GeneratedClient: kpandaClient,
		MasterURL:       masterURL,
		KubeConfig:      kubeConfig,
	}
}

func (n *FakeClient) Kubernetes() kubernetes.Interface {
	return n.KubeClient
}

func (n *FakeClient) Generated() clusterclientset.Interface {
	return n.GeneratedClient
}

func (n *FakeClient) Dynamic() dynamic.Interface {
	return n.DynamicClient
}

func (n *FakeClient) Master() string {
	return n.MasterURL
}

func (n *FakeClient) Config() *rest.Config {
	return n.KubeConfig
}
