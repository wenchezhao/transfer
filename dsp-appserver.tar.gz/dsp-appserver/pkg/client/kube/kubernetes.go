/*
Copyright 2022 Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package k8s

import (
	clusterclientset "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned"

	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	rest "k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
)

type Client interface {
	Kubernetes() kubernetes.Interface
	Generated() clusterclientset.Interface
	Dynamic() dynamic.Interface
	Master() string
	Config() *rest.Config
}

type kubernetesClient struct {
	// kubernetes client interface
	kubeClient kubernetes.Interface

	// dynamic client
	dynamicClient dynamic.Interface

	// generated clientset
	clusterclientset clusterclientset.Interface

	master string

	config *rest.Config
}

// NewKubernetesClient creates a KubernetesClient.
func NewKubernetesClient(options *KubernetesOptions) (Client, error) {
	config, err := clientcmd.BuildConfigFromFlags("", options.KubeConfig)
	if err != nil {
		return nil, err
	}
	return NewKubernetesClientWithConfig(options, config)
}

// NewKubernetesClientWithConfig creates a KubernetesClient.
func NewKubernetesClientWithConfig(options *KubernetesOptions, config *rest.Config) (Client, error) {
	config.QPS = options.QPS
	config.Burst = options.Burst
	var err error
	var k kubernetesClient
	k.kubeClient, err = kubernetes.NewForConfig(config)
	if err != nil {
		return nil, err
	}

	k.dynamicClient, err = dynamic.NewForConfig(config)
	if err != nil {
		return nil, err
	}

	k.clusterclientset, err = clusterclientset.NewForConfig(config)
	if err != nil {
		return nil, err
	}

	k.master = options.Master
	k.config = config

	return &k, nil
}

func (k *kubernetesClient) Kubernetes() kubernetes.Interface {
	return k.kubeClient
}

func (k *kubernetesClient) Dynamic() dynamic.Interface {
	return k.dynamicClient
}

func (k *kubernetesClient) Generated() clusterclientset.Interface {
	return k.clusterclientset
}

// master address used to generate kubeConfig for downloading.
func (k *kubernetesClient) Master() string {
	return k.master
}

func (k *kubernetesClient) Config() *rest.Config {
	return k.config
}
