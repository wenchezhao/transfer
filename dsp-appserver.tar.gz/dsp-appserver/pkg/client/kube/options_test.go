package k8s

import (
	"fmt"
	"testing"
	"time"

	"github.com/spf13/pflag"
)

func Test_NewKubernetesOptions(t *testing.T) {
	options := NewKubernetesOptions()
	if options == nil {
		t.Fail()
	}
}

func TestKubernetesOptions_Validate(t *testing.T) {
	tests := []struct {
		name string
		args func() bool
		want bool
	}{
		{
			name: "good options",
			args: func() bool {
				options := NewKubernetesOptions()
				return len(options.Validate()) == 0
			},
			want: true,
		},
		{
			name: "bad options with no-exist file",
			args: func() bool {
				options := NewKubernetesOptions()
				options.KubeConfig = fmt.Sprintf("/tmp/%d", time.Now().UnixNano()/1e6)
				return len(options.Validate()) > 0
			},
			want: true,
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if test.args() != test.want {
				t.Fail()
			}
		})
	}
}

func TestKubernetesOptions_ApplyTo(t *testing.T) {
	optionsOrigin := NewKubernetesOptions()
	optionsOrigin.Burst = 11011
	optionsNew := NewKubernetesOptions()
	optionsOrigin.ApplyTo(optionsNew)
	if optionsNew.Burst != 11011 {
		t.Fail()
	}
}

func TestKubernetesOptions_AddFlags(t *testing.T) {
	options := NewKubernetesOptions()
	options1 := NewKubernetesOptions()
	set := pflag.FlagSet{}
	options.AddFlags(&set, options1)
	if set.HasFlags() != true {
		t.Fail()
	}
}
