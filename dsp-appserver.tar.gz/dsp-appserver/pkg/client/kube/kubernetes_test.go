package k8s

import (
	"testing"

	rest "k8s.io/client-go/rest"
)

func Test_NewKubernetesClientWithConfig(t *testing.T) {
	tests := []struct {
		name string
		args func() bool
		want bool
	}{
		{
			name: "config will work",
			args: func() bool {
				options := &KubernetesOptions{}
				options.QPS, options.Burst, options.Master = 10, 10, "master"
				config := &rest.Config{}
				client, err := NewKubernetesClientWithConfig(options, config)
				return client != nil && err == nil && client.Kubernetes() != nil && client.Config() != nil && client.Generated() != nil && client.Dynamic() != nil && len(client.Master()) != 0
			},
			want: true,
		},
		{
			name: "bad config",
			args: func() bool {
				options := &KubernetesOptions{}
				options.QPS, options.Burst, options.Master = 10, 0, "master"
				config := &rest.Config{}
				client, err := NewKubernetesClientWithConfig(options, config)
				return client != nil && err == nil && client.Kubernetes() != nil
			},
			want: false,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if test.args() != test.want {
				t.Fail()
			}
		})
	}
}
