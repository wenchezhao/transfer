package server

import (
	"bytes"
	"context"
	"crypto/tls"
	"io"
	"io/ioutil"
	"net/http"
	_ "net/http/pprof"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/opentracing-contrib/go-gin/ginhttp"
	"github.com/opentracing/opentracing-go"

	"github.com/daocloud/dsp-appserver/pkg/config"
	apphandlers "github.com/daocloud/dsp-appserver/pkg/handlers/app"
	clusterhandlers "github.com/daocloud/dsp-appserver/pkg/handlers/cluster"
	dashboardhandlers "github.com/daocloud/dsp-appserver/pkg/handlers/dashboard"
	dceHandle "github.com/daocloud/dsp-appserver/pkg/handlers/dce"
	networkhandlers "github.com/daocloud/dsp-appserver/pkg/handlers/network"
	resourceshandlers "github.com/daocloud/dsp-appserver/pkg/handlers/resources"
	websockethandlers "github.com/daocloud/dsp-appserver/pkg/handlers/websocket"
	"github.com/daocloud/dsp-appserver/pkg/informermanager"
	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster"
	"github.com/daocloud/dsp-appserver/pkg/trace"
	"github.com/daocloud/dsp-appserver/pkg/util/promhttp"
)

var log = logi.Log.Sugar()

type Server struct {
	ctx    context.Context
	cancel context.CancelFunc

	cfg *config.Config

	engine               *gin.Engine
	clusterClientManager *multicluster.ClusterClientManager
	informerManager      informermanager.InformerManager

	httpServer *http.Server
}

func New(cfg *config.Config) (*Server, error) {
	ctx, cancel := context.WithCancel(context.Background())

	s := &Server{
		ctx:    ctx,
		cancel: cancel,
		cfg:    cfg,
	}

	tracer, err := trace.SetupTrace(ctx)
	if err != nil {
		log.Fatalf("err: %+v", err.Error())
	}
	cfg.Tracer = tracer

	clusterMgr, err := multicluster.NewClusterClientManager(cfg)
	if err != nil {
		return nil, err
	}
	s.clusterClientManager = clusterMgr

	clientConfigGetter, err := informermanager.NewClientConfigGetter(*cfg)
	if err != nil {
		return nil, err
	}
	s.informerManager = informermanager.NewInformerManager(s.ctx.Done(), informermanager.DefaultGVRs, clientConfigGetter)

	s.InstallDefaultHandlers()

	return s, nil
}

func (s *Server) GetMux() http.Handler {
	return s.engine
}

// InstallDefaultHandlers registers the default set of supported HTTP request
// patterns with the Gin framework.
func (s *Server) InstallDefaultHandlers() {
	if !s.cfg.Debug {
		gin.SetMode(gin.ReleaseMode)
	}

	s.engine = gin.Default()

	if s.cfg.Debug {
		// 打印body
		s.engine.Use(RequestLoggerMiddleware)
	}

	// trace
	var tracer opentracing.Tracer
	if s.cfg.Tracer == nil {
		tracer = opentracing.NoopTracer{}
	} else {
		tracer = s.cfg.Tracer
	}
	s.engine.Use(ginhttp.Middleware(tracer))

	http.Handle("/ping", s.engine)
	http.Handle("/metrics", s.engine)
	http.Handle("/v1/", s.engine)

	// install healthz
	s.engine.GET("/ping", func(c *gin.Context) {
		c.String(200, "pong")
	})

	// install metrics
	s.engine.GET("/metrics", promhttp.HandlerForGins)

	// enable basic auth
	authorized := s.engine.Group("/", gin.BasicAuth(gin.Accounts{
		s.cfg.BasicAuthUser: s.cfg.BasicAuthPassword,
	}))

	// install user handlers
	apphandlers.InstallHandlers(authorized, s.clusterClientManager, s.informerManager)
	clusterhandlers.InstallHandlers(authorized, s.clusterClientManager, s.cfg.ResourcesC)
	websockethandlers.InstallHandlers(authorized, s.clusterClientManager)
	dashboardhandlers.InstallHandlers(authorized, s.clusterClientManager, s.cfg.ResourcesC)
	resourceshandlers.InstallHandlers(authorized, s.clusterClientManager, s.informerManager)
	//网络管理
	networkhandlers.InstallHandlers(authorized, s.clusterClientManager)

	//dce 网络对接
	v1dces := authorized.Group("/v1/dce")
	dceHandle.InstallHandlers(v1dces, s.clusterClientManager)

}

// https://github.com/gin-gonic/gin/issues/961#issuecomment-557931409
func RequestLoggerMiddleware(c *gin.Context) {
	var buf bytes.Buffer
	tee := io.TeeReader(c.Request.Body, &buf)
	body, _ := ioutil.ReadAll(tee)
	c.Request.Body = ioutil.NopCloser(&buf)
	log.Debugf("request url: %s", c.Request.RequestURI)
	log.Debugf("request header: %s", c.Request.Header)
	log.Debugf("request body: %s", body)
	c.Next()
}

func (s *Server) Run() {
	server := &http.Server{
		Addr:           ":" + s.cfg.Port,
		Handler:        http.DefaultServeMux,
		ReadTimeout:    300 * time.Second,
		WriteTimeout:   300 * time.Second,
		MaxHeaderBytes: 1 << 20,
	}
	s.httpServer = server

	go func() {
		if s.cfg.CertPath != "" && s.cfg.KeyPath != "" {
			log.Infof("CertPath and KeyPath is not null,try to load certificate and key")
			cer, err := tls.LoadX509KeyPair(s.cfg.CertPath, s.cfg.KeyPath)
			if err != nil {
				log.Errorf("failed to load certificate and key: %v", err)
				return
			}
			tlsconfig := &tls.Config{Certificates: []tls.Certificate{cer}}
			server.TLSConfig = tlsconfig
			log.Infof("Successful import certificate and key, appserver begins begin to use https")
			if err := server.ListenAndServeTLS(s.cfg.CertPath, s.cfg.KeyPath); err != nil && err != http.ErrServerClosed {
				log.Fatalf("err: %+v", err)
			}
		} else {
			log.Infof("CertPath and KeyPath is null, appserver begins to use http")
			if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
				log.Fatalf("err: %+v", err)
			}
		}
	}()

	s.informerManager.Start()

	quit := make(chan os.Signal)
	// kill (no param) default send syscanll.SIGTERM
	// kill -2 is syscall.SIGINT
	// kill -9 is syscall. SIGKILL but can"t be catch, so don't need add it
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Info("shutdown server ...")

	s.Stop()
}

func (s *Server) Stop() {
	ctx, _ := context.WithTimeout(s.ctx, 3*time.Second)
	if err := s.httpServer.Shutdown(ctx); err != nil {
		log.Errorf("server shutdown err: %+v", err)
		return
	}
	log.Info("http server shutdown")

	s.cancel()
	time.Sleep(100 * time.Millisecond) // wait goroutine cancel
}
