package dce

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
	"time"

	"github.com/daocloud/dsp-appserver/pkg/dce/apis"
	"github.com/daocloud/dsp-appserver/pkg/logi"
)

var log = logi.Log.Sugar()

const (
	SubnetNamespace  = "Namespace"
	SubnetSubnetName = "SubnetName"
	Success          = "success"
	Error            = "error"
	RULE_IS_EMPTY    = "rule is empty"
)

type DceNetworkApi interface {
	GetSubnetOne(token, addrs, subnetName string) (*apis.OvsSubnetList, error)
	GetSubnets(token, addrs, typeK, typeV string) (*apis.OvsSubnetList, error)
	// rules crud
	GetRules(token, addrs, namespace, poolname string) (*apis.OvsRuleList, error)
	GetRuleOne(token, addrs, namespace, poolname, rulename string) (*apis.OvsRule, error)
	DeleteRuleOne(token, addrs, namespace, poolname, rulename string) (*apis.AddPostResp, error)
	AddRule(token, addrs, namespace, poolname string, addOvsRule apis.AddOvsRule) (*apis.AddPostResp, error)
	UpdateRule(token, addrs, namespace, poolname, ruleNames string, addOvsRule apis.AddOvsRule) (*apis.AddPostResp, error)

	//pools crud
	GetPools(token, addrs, namespace, subnet string) (*apis.OvsPoolList, error)
	DeletePoolOne(token, addrs, namespace, poolename string) (*apis.AddPostResp, error)
	GetPoolOne(token, addrs, namespace, poolename string) (*apis.OvsPool, error)
	AddPoolOne(token, addrs, namespace, subnet string, addPool apis.AddOvsPool) (*apis.AddPostResp, error)
}

func (dceClient *DceClient) GetSubnetOne(token, addrs, subnetName string) (*apis.OvsSubnetList, error) {
	obj := &apis.OvsSubnetList{}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/subnet?SubnetName=%s", subnetName)

	if err := dceClient.fetch(url, obj, token); err != nil {
		return nil, err
	}

	return obj, nil
}

func (dceClient *DceClient) GetSubnets(token, addrs, typeK, typeV string) (*apis.OvsSubnetList, error) {
	obj := &apis.OvsSubnetList{}
	url := ""
	if typeK == SubnetNamespace {
		url = addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/subnet?Namespace=%s", typeV)
	} else if typeK == SubnetSubnetName {
		url = addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/subnet?SubnetName=%s", typeV)
	} else {
		log.Errorf("params is error %v", typeK)
		return nil, errors.New("param error")
	}

	if err := dceClient.fetch(url, obj, token); err != nil {
		return nil, err
	}

	return obj, nil
}

func (dceClient *DceClient) GetRules(token, addrs, namespace, poolname string) (*apis.OvsRuleList, error) {
	obj := &apis.OvsRuleList{}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/%s/rules?Namespace=%s", poolname, namespace)
	if err := dceClient.fetch(url, obj, token); err != nil {
		return nil, err
	}
	return obj, nil
}

func (dceClient *DceClient) GetRuleOne(token, addrs, namespace, poolname, rulename string) (*apis.OvsRule, error) {
	obj := &apis.OvsRule{}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/%s/rule/%s", poolname, rulename)
	if err := dceClient.fetch(url, obj, token); err != nil {
		return nil, err
	}
	return obj, nil
}

/*

PATCH IPRule： /apis/parcel.dce.daocloud.io/v1beta1/ovs/vlan0-default/rule/test3
*/
func (dceClient *DceClient) UpdateRule(token, addrs, namespace, poolname, ruleName string, addOvsRule apis.AddOvsRule) (*apis.AddPostResp, error) {
	obj := &apis.AddPostResp{}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/%s/rule/%s", poolname, ruleName)

	addJson, ise := json.Marshal(addOvsRule)
	if ise != nil {
		return nil, ise
	}

	ise = dceClient.post(http.MethodPatch, url, obj, token, addJson)
	if ise != nil {
		return nil, ise
	}
	if obj.Msg == "" && obj.Details == "" {
		obj.Code = 200
		obj.Msg = "success"
	}
	return obj, nil
}

func (dceClient *DceClient) AddRule(token, addrs, namespace, poolname string, addOvsRule apis.AddOvsRule) (*apis.AddPostResp, error) {
	obj := &apis.AddPostResp{}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/%s/rules", poolname)

	addJson, ise := json.Marshal(addOvsRule)
	if ise != nil {
		return nil, ise
	}

	ise = dceClient.post(http.MethodPost, url, obj, token, addJson)
	if ise != nil {
		return nil, ise
	}
	if obj.Msg == "" && obj.Details == "" {
		obj.Code = 200
		obj.Msg = "success"
	}
	return obj, nil
}

func (dceClient *DceClient) DeleteRuleOne(token, addrs, namespace, poolname, rulename string) (*apis.AddPostResp, error) {
	obj := &apis.AddPostResp{}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/%s/rule/%s", poolname, rulename)

	ise := dceClient.post(http.MethodDelete, url, obj, token, nil)
	if ise != nil {
		return nil, ise
	}
	if obj.Msg == "" && obj.Details == "" {
		obj.Code = 200
		obj.Msg = "success"
	}
	return obj, nil

}

func (dceClient *DceClient) GetPools(token, addrs, namespace, subnet string) (*apis.OvsPoolList, error) {
	obj := &apis.OvsPoolList{}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/pools/%s", subnet)
	if err := dceClient.fetch(url, obj, token); err != nil {
		return nil, err
	}
	return obj, nil
}

func (dceClient *DceClient) DeletePoolOne(token, addrs, namespace, poolename string) (*apis.AddPostResp, error) {
	obj := &apis.AddPostResp{}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/pool/%s", poolename)

	ise := dceClient.post(http.MethodDelete, url, obj, token, nil)
	if ise != nil {
		return nil, ise
	}
	if obj.Msg == "" && obj.Details == "" {
		obj.Code = 200
		obj.Msg = "success"
	}
	return obj, nil

}

func (dceClient *DceClient) GetPoolOne(token, addrs, namespace, poolename string) (*apis.OvsPool, error) {
	obj := &apis.OvsPool{}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/pool/%s", poolename)
	if err := dceClient.fetch(url, obj, token); err != nil {
		return nil, err
	}
	return obj, nil
}

func (dceClient *DceClient) AddPoolOne(token, addrs, namespace, subnet string, addPool apis.AddOvsPool) (*apis.AddPostResp, error) {
	obj := &apis.AddPostResp{}
	addJson, ise := json.Marshal(addPool)
	if ise != nil {
		return nil, ise
	}
	url := addrs + fmt.Sprintf("/apis/parcel.dce.daocloud.io/v1beta1/ovs/pools/%s?Namespace=%s", subnet, namespace)
	ise = dceClient.post(http.MethodPost, url, obj, token, addJson)
	if ise != nil {
		return nil, ise
	}
	if obj.Msg == "" && obj.Details == "" {
		obj.Code = 200
		obj.Msg = "success"
	}
	return obj, nil
}

func (dceClient *DceClient) fetch(url string, obj interface{}, token string) error {
	log.Infof("get dce api \n url=%v , token=%v", url, len(token))
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	req.Header.Add("Authorization", "Bearer "+token)
	resp, err := dceClient.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	bytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}

	log.Infof("dce response is %v ", string(bytes))
	// 处理获取规则不存在情况，返回错误
	// 此处dce返回200状态码，内容为 "Query <子网IP池>/<规则名> rule is empty"
	if resp.StatusCode == http.StatusOK && strings.Contains(string(bytes), RULE_IS_EMPTY) {
		return fmt.Errorf("%v", RULE_IS_EMPTY)
	}

	if err := json.Unmarshal(bytes, obj); err != nil {
		return fmt.Errorf("failed to unmarshal response body: %v", err)
	}
	return nil
}

func (dceClient *DceClient) post(method, url string, obj interface{}, token string, bodyStr []byte) error {
	log.Infof("dce api \n url=%v , method=%v, token=%v,bodyStr=%v", url, method, len(token), string(bodyStr))

	var req *http.Request
	var err error
	if len(bodyStr) > 0 {
		req, err = http.NewRequest(method, url, bytes.NewBuffer(bodyStr))
		req.Header.Add("Content-Type", "application/json")
	} else {
		req, err = http.NewRequest(method, url, nil)
	}

	if err != nil {
		return err
	}

	req.Header.Add("Authorization", "Bearer "+token)
	resp, err := dceClient.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	bytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}

	log.Infof("dce response is %v ", string(bytes))

	if resp.StatusCode == 200 {
		return nil
	}

	if err := json.Unmarshal(bytes, obj); err != nil {
		return fmt.Errorf("failed to unmarshal response body: %v", err)
	}
	return nil
}

type DceClient struct {
	client *http.Client
}

func New() DceNetworkApi {
	client := &http.Client{
		Timeout: 15 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				InsecureSkipVerify: true,
			},
		},
	}
	lister := &DceClient{
		client: client,
	}
	return lister
}
