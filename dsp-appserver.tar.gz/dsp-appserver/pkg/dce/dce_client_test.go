package dce

import (
	"encoding/json"
	"testing"

	"github.com/daocloud/dsp-appserver/pkg/dce/apis"
)

var (
	addrs     = "http://10.23.101.12"
	token     = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImRubm1RaEdmWmNPTGhsdzUwWDdOTUhadWJvRUdzZ05vcXNrajNsS3VUaHMifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJkZWZhdWx0Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZWNyZXQubmFtZSI6ImRlZmF1bHQtdG9rZW4tbG14d3IiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoiZGVmYXVsdCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6Ijg3ZWVjZjJjLWFmMjQtNGY1Ni05MDUyLThlMzIyZTIyMjE1YiIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDpkZWZhdWx0OmRlZmF1bHQifQ.DR7WcExSGVbEdZ2hAAz2A2DuR-VhU-zFjm4mVgkAa-35PJhWTVibuuZbURnITEy4dK8HnlpDkpfP_03ZodW5oApPWdRTbQfuMR8Mrj0-NIJh7WZtNqEvYaXqqPR54iWyT4OVUmJN3ZeHZ67vJsTuw4nHyIuVG5CQ0h0ZtheEfPCqLb1sI3yVe5SpVM2FaJIvDZ2gZ0h-ff-YzTnyf9ifO8_Y48KyR16MXKTViwEL2zUuE7J9n1PVKgssHdJHTPAr-S_cDqquttxzBtxPYL2bBc1lAeFHAFmnWbHkoWYG8jhdCPi0QI0bIEHxLG4VlDduJA14F-LLVdOatFtzFCQgfw"
	namespace = "testnetwork"
)

var dceClient DceNetworkApi

func init() {
	dceClient = New()
}

func TestAppPoolList(t *testing.T) {
	ret, ise := AppPoolList(dceClient, token, addrs, namespace)
	jsonS, _ := json.Marshal(ret)
	log.Infof("AppPoolList \n %v  \n is error %v", string(jsonS), ise)
}

func TestAppRules(t *testing.T) {
	ret, ise := AppRuleList(dceClient, token, addrs, namespace, "")
	jsonS, _ := json.Marshal(ret)
	log.Infof("AppRuleList \n %v  \n is error %v", string(jsonS), ise)
}

func TestAppRuleOne(t *testing.T) {
	ret, ise := dceClient.GetRuleOne(token, addrs, namespace, "vlan0-default", "test2")
	jsonS, _ := json.Marshal(ret)
	log.Infof("GetRuleOne \n %v  \n is error %v", string(jsonS), ise)
}

func TestDeleteRuleOne(t *testing.T) {
	ret, ise := dceClient.DeleteRuleOne(token, addrs, namespace, "vlan0-default", "test311")
	jsonS, _ := json.Marshal(ret)
	log.Infof("DeleteRuleOne \n %v  \n is error %v", string(jsonS), ise)
}

func TestAppPoolOne(t *testing.T) {
	ret, ise := dceClient.GetPoolOne(token, addrs, namespace, "vlan0-dce-system")
	jsonS, _ := json.Marshal(ret)
	log.Infof("GetPoolOne \n %v  \n is error %v", string(jsonS), ise)
}

func TestSubnetNamespace(t *testing.T) {
	subnets, _ := dceClient.GetSubnets(token, addrs, SubnetNamespace, namespace)

	ret2, _ := json.Marshal(subnets)
	log.Warnf("before is : %v ", string(ret2))

	for inx, subnet := range subnets.Items {
		var ovsPools []apis.OvsPool
		for _, pool := range subnet.Pools {
			// if pool.Namespace != namespace {
			// 	log.Warnf("filter public pools:%v , my namespace is :%v", pool.Namespace, namespace)
			// 	continue
			// }
			ovsPools = append(ovsPools, pool)
		}
		subnets.Items[inx].Pools = ovsPools
	}
	for inx, subnet := range subnets.Items {
		for inx2, pool := range subnet.Pools {
			subnets.Items[inx].Pools[inx2].IpList = nil
			poolObj, ise := dceClient.GetPoolOne(token, addrs, namespace, pool.PoolName)
			if ise != nil {
				log.Infof("failed to get GetPoolOne %v", ise)
			} else {
				subnets.Items[inx].Pools[inx2].Ips = poolObj.Ips
			}
		}
	}
	ret, _ := json.Marshal(subnets)
	log.Warnf("after is : %v", string(ret))
}

func TestAddRule(t *testing.T) {
	var ruleOne apis.AddOvsRule
	ruleOne.ApiVersion = apis.ApiVersion
	ruleOne.Kind = apis.KindRule
	ruleOne.Metadata.Name = "name1"
	ruleOne.Metadata.Namespace = namespace
	ruleOne.Description = "desc1"
	ruleOne.IpList = []string{"192.168.10.1", "192.168.10.2"}
	ruleOne.PoolName = "pool1"
	ruleOne.Subnet = "subnet"
	ruleOne.SubnetName = "namexx"

	ret, ise := dceClient.AddRule(token, addrs, namespace, "vlan0-default", ruleOne)
	jsonS, _ := json.Marshal(ret)
	log.Infof("AddRule \n %v  \n is error %v", string(jsonS), ise)

}

func TestAddPool(t *testing.T) {
	var poolOne apis.AddOvsPool
	poolOne.ApiVersion = apis.ApiVersion
	poolOne.Kind = apis.KindOvsPoolRequest
	poolOne.Metadata.Namespace = namespace
	poolOne.DefaultRouteV4 = "10.6.0.1"
	poolOne.DefaultRouteV6 = ""
	poolOne.Route = []string{}
	poolOne.SubnetName = "vlan0"
	poolOne.V4MapV6 = []string{"10.6.111.2>", "10.6.111.3>", "10.6.111.4>", "10.6.111.5>", "10.6.111.6>", "10.6.111.7>", "10.6.111.8>"}
	ret, ise := dceClient.AddPoolOne(token, addrs, namespace, "vlan0", poolOne)
	jsonS, _ := json.Marshal(ret)
	log.Infof("AddPoolOne \n %v  \n is error %v", string(jsonS), ise)

}

func TestDeletePool(t *testing.T) {
	ret, ise := dceClient.DeletePoolOne(token, addrs, namespace, "vlan0-vlan")
	jsonS, _ := json.Marshal(ret)
	log.Infof("DeletePoolOne \n %v  \n is error %v", string(jsonS), ise)
}
