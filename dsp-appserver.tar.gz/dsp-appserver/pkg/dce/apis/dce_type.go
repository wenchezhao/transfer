package apis

const (
	ApiVersion         = "parcel.dce.daocloud.io/v1beta1"
	KindRule           = "OvsRule"
	KindPool           = "OvsPool"
	KindOvsPoolRequest = "OvsPoolRequest"
)

type AddPostResp struct {
	Code    int    `json:"code"`
	Msg     string `json:"msg"`
	Details string `json:"details"`
}
type Metadata struct {
	Name      string `json:"name"`
	Namespace string `json:"namespace"`
}

type IpCondition struct {
	IpV6           string      `json:"IpV6"`
	Mac            string      `json:"Mac"`
	PodName        string      `json:"PodName"`
	PoolName       string      `json:"PoolName"`
	RuleName       string      `json:"RuleName"`
	OwnerNamespace string      `json:"OwnerNamespace"`
	Uuid           string      `json:"Uuid"`
	V4Conflict     interface{} `json:"V4Conflict"`
	V6Conflict     interface{} `json:"V6Conflict"`
}

type OvsRule struct {
	ApiVersion string   `json:"apiVersion"`
	Kind       string   `json:"kind"`
	Metadata   Metadata `json:"metadata"`

	CurrentApp        string   `json:"CurrentApp"`
	CurrentController string   `json:"CurrentController"`
	Description       string   `json:"Description"`
	PoolName          string   `json:"PoolName"`
	SubnetName        string   `json:"SubnetName"`
	Subnet            string   `json:"Subnet"`
	IpList            []string `json:"IpList"`

	Ips map[string]IpCondition `json:"Ips"`
}

type AddOvsRule struct {
	ApiVersion string   `json:"apiVersion"`
	Kind       string   `json:"kind"`
	Metadata   Metadata `json:"metadata"`

	Description string   `json:"Description"`
	IpList      []string `json:"IpList"`
	PoolName    string   `json:"PoolName"`
	Subnet      string   `json:"Subnet"`
	SubnetName  string   `json:"SubnetName"`
}

type OvsRuleList struct {
	// ApiVersion string   `json:"apiVersion"`
	// Kind       string   `json:"kind"`
	// Metadata   Metadata `json:"metadata"`

	Items []OvsRule `json:"items"`
}

type OvsPool struct {
	ApiVersion string   `json:"apiVersion"`
	Kind       string   `json:"kind"`
	Metadata   Metadata `json:"metadata"`

	Namespace        string `json:"Namespace"`
	TotalIpNumber    int    `json:"TotalIpNumber"`
	IdleIpNumber     int    `json:"IdleIpNumber"`
	ConflictIpNumber int    `json:"ConflictIpNumber"`

	IpRuleNumber int `json:"IpRuleNumber"`

	DisplayVlan int `json:"DisplayVlan"`

	DefaultRouteV4 string `json:"DefaultRouteV4"`
	DefaultRouteV6 string `json:"DefaultRouteV6"`

	PoolName   string                 `json:"PoolName"`
	SubnetName string                 `json:"SubnetName"`
	Subnet     string                 `json:"Subnet"`
	IpList     []string               `json:"IpList,omitempty"`
	Ips        map[string]IpCondition `json:"Ips"`
}

type AddOvsPool struct {
	ApiVersion string `json:"apiVersion"`
	Kind       string `json:"kind"`
	Metadata   struct {
		//	Name      string `json:"name"`
		Namespace string `json:"namespace"`
	} `json:"metadata"`

	DefaultRouteV4 string   `json:"DefaultRouteV4"`
	DefaultRouteV6 string   `json:"DefaultRouteV6"`
	Route          []string `json:"Route"`
	SubnetName     string   `json:"SubnetName"`
	V4MapV6        []string `json:"V4MapV6"`
}

type OvsPoolList struct {
	ApiVersion string    `json:"apiVersion"`
	Kind       string    `json:"kind"`
	Metadata   Metadata  `json:"metadata"`
	Items      []OvsPool `json:"items"`
}
type OvsSubnetAvailableIps struct {
	SubnetName   string   `json:"subnetName"`
	AvailableIps []string `json:"availableIps"`
}

type OvsNamespacesAvailableIps struct {
	Namespace    string   `json:"namespace"`
	AvailableIps []string `json:"availableIps"`
}

type OvsNamespacesIps struct {
	SubnetName string             `json:"subnetName"`
	Namespace  []OvsNamespacesObj `json:"namespace"`
}
type OvsNamespacesObj struct {
	Namespace string   `json:"namespace"`
	Ips       []IpsObj `json:"ips"`
}

type IpsObj struct {
	Ip      string `json:"ip"`
	Status  int    `json:"status"`
	PodName string `json:"podName"`
}

type OvsSubnet struct {
	// ApiVersion string   `json:"apiVersion"`
	// Kind       string   `json:"kind"`
	Metadata Metadata `json:"metadata"`

	Subnet string    `json:"subnet"`
	Pools  []OvsPool `json:"Pools"`

	DisplayVlan    int    `json:"DisplayVlan"`
	DefaultRouteV4 string `json:"DefaultRouteV4"`
	DefaultRouteV6 string `json:"DefaultRouteV6"`

	SubnetName string `json:"SubnetName"`
}

type OvsSubnetList struct {
	// ApiVersion string   `json:"apiVersion"`
	// Kind       string   `json:"kind"`
	// Metadata   Metadata `json:"metadata"`

	Items []OvsSubnet `json:"items"`
}
