package apis

import (
	"strconv"
	"strings"
)

type AppResponse struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

type AppPoolList struct {
	Items []struct {
		Name             string `json:"name"`
		DisplayVlan      int    `json:"displayVlan"`
		TotalIpNumber    int    `json:"totalIpNumber"`
		IdleIpNumber     int    `json:"idleIpNumber"`
		ConflictIpNumber int    `json:"conflictIpNumber"`
		SubnetName       string `json:"SubnetName"`
		Namespace        string `json:"Namespace"`
		RuleLen          int    `json:"ruleLen"`
	} `json:"items"`
}

type IpDetail struct {
	Ip       string `json:"ip"`
	Mac      string `json:"mac"`
	RuleName string `json:"ruleName"`
	Status   string `json:"status"`
	Pod      string `json:"pod"`
}

type ipList []IpDetail

func (a ipList) Len() int {
	return len(a)
}
func (a ipList) Swap(i, j int) {
	a[i], a[j] = a[j], a[i]
}
func (a ipList) Less(i, j int) bool {

	iInt, _ := strconv.Atoi(strings.Join(strings.Split(a[i].Ip, "."), ""))
	jInt, _ := strconv.Atoi(strings.Join(strings.Split(a[j].Ip, "."), ""))

	return iInt < jInt
}

type AppPoolDetail struct {
	Name           string `json:"name"`
	Subnet         string `json:"Subnet"`
	SubnetName     string `json:"SubnetName"`
	DefaultRouteV4 string `json:"defaultRouteV4"`
	DisplayVlan    int    `json:"DisplayVlan"`
	Items          ipList `json:"ips"`
}

type AppRuleList struct {
	Items []struct {
		Name         string                 `json:"name"`
		Describe     string                 `json:"describe"`
		IpNum        int                    `json:"ipNum"`
		IdleIpNumber int                    `json:"idleIpNumber"`
		PoolName     string                 `json:"poolName"`
		Ips          map[string]IpCondition `json:"Ips"`
		//PoolObj           OvsPool `json:"poolObj"`
		CurrentApp        string `json:"CurrentApp"`
		CurrentController string `json:"CurrentController"`
	} `json:"items"`
}
type AppRuleInfo struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	PoolName    string `json:"poolName"`
	Subnet      string `json:"subnet"`
	SubnetName  string `json:"subnetName"`
}
type AppRuleDetailMore struct {
	AppRuleInfo
	// 需要返回ip状态
	AppRuleDetail
}
type AppRuleDetail struct {
	Items []struct {
		Ip     string `json:"ip"`
		Status string `json:"status"`
	} `json:"ips"`
}

type AppAddRule struct {
	AppRuleInfo
	IpList []string `json:"ipList"`
}

type AppAddPool struct {
	DefaultRouteV4 string   `json:"defaultRouteV4"`
	DefaultRouteV6 string   `json:"defaultRouteV6"`
	Route          []string `json:"route"`
	SubnetName     string   `json:"subnetName"`
	V4MapV6        []string `json:"v4MapV6"`
}

type AppOvsSubnet struct {
	DisplayVlan    int    `json:"DisplayVlan"`
	DefaultRouteV4 string `json:"DefaultRouteV4"`
	DefaultRouteV6 string `json:"DefaultRouteV6"`

	SubnetName string `json:"SubnetName"`
	Subnet     string `json:"subnet"`
}
