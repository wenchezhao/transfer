package dce

import (
	"github.com/daocloud/dsp-appserver/pkg/dce/apis"
)

func AppPoolList(dceClient DceNetworkApi, token, addrs, namespace string) (apis.AppPoolList, error) {
	var appPoolList apis.AppPoolList

	ret, ise := dceClient.GetSubnets(token, addrs, "SubnetName", namespace)
	if ise != nil {
		log.Errorf("err %v", ise)
	} else {
		for _, item := range ret.Items {
			for _, pool := range item.Pools {
				if pool.Namespace == namespace {
					continue
				}
				appPoolList.Items = append(appPoolList.Items, struct {
					Name             string "json:\"name\""
					DisplayVlan      int    "json:\"displayVlan\""
					TotalIpNumber    int    "json:\"totalIpNumber\""
					IdleIpNumber     int    "json:\"idleIpNumber\""
					ConflictIpNumber int    "json:\"conflictIpNumber\""
					SubnetName       string "json:\"SubnetName\""
					Namespace        string `json:"Namespace"`
					RuleLen          int    "json:\"ruleLen\""
				}{pool.PoolName, pool.DisplayVlan, pool.TotalIpNumber, pool.IdleIpNumber,
					pool.ConflictIpNumber, pool.SubnetName,
					pool.Namespace,
					pool.IpRuleNumber})

			}
		}
	}
	return appPoolList, nil
}

func AppRuleList(dceClient DceNetworkApi, token, addrs, namespace, poolName string) (apis.AppRuleList, error) {
	var appRuleList apis.AppRuleList

	ret2, ise := dceClient.GetRules(token, addrs, namespace, poolName)
	if ise != nil {
		log.Errorf("err %v", ise)
	} else {
		for _, item2 := range ret2.Items {
			if item2.CurrentController != "" || item2.CurrentApp != "" {
				log.Warnf("CurrentController=%v ,CurrentApp=%v not ''  ", item2.CurrentController, item2.CurrentApp)
			}
			usedNum := 0
			for _, value := range item2.Ips {
				if value.PodName != "" {
					usedNum++
				}
			}

			appRuleList.Items = append(appRuleList.Items, struct {
				Name         string                      "json:\"name\""
				Describe     string                      "json:\"describe\""
				IpNum        int                         "json:\"ipNum\""
				IdleIpNumber int                         "json:\"idleIpNumber\""
				PoolName     string                      "json:\"poolName\""
				Ips          map[string]apis.IpCondition `json:"Ips"`
				//PoolObj           apis.OvsPool "json:\"poolObj\""
				CurrentApp        string "json:\"CurrentApp\""
				CurrentController string "json:\"CurrentController\""
			}{item2.Metadata.Name,
				item2.Description,
				len(item2.IpList),
				len(item2.IpList) - usedNum,
				poolName,
				item2.Ips,
				//apis.OvsPool{},
				item2.CurrentApp, item2.CurrentController})
		}
	}
	return appRuleList, nil
}
