package dce

func DceParcelAnotation(dCEParcelType, dCEParcelValue string) (annotationsMap map[string]string) {
	annotationsMap = make(map[string]string)
	if len(dCEParcelType) > 0 &&
		len(dCEParcelValue) > 0 {
		//这里的拼接 value 需要注意 ： 号连接

		// 默认calico网络 ， 未提供calico 的list接口
		//	dce.daocloud.io/parcel.net.type: calico
		//	dce.daocloud.io/parcel.net.value: default-ipv4-ippool

		//ovs- ip 池：
		//	dce.daocloud.io/parcel.net.type: ovs
		//	dce.daocloud.io/parcel.net.value: pool:vlan4095-yyyyyyyy

		//ovs- ip规则
		//   dce.daocloud.io/parcel.net.type: ovs
		//   dce.daocloud.io/parcel.net.value: rule:vlan4095-yyyyyyyy:rule1

		if dCEParcelType == DCEParcelNetworkCalico {
			annotationsMap[AnotationKeyType] = DCEParcelNetworkCalico
			annotationsMap[AnotationKeyValue] = CalicoValue
		} else if dCEParcelType == DCEParcelNetworkOvs {
			annotationsMap[AnotationKeyType] = DCEParcelNetworkOvs
			annotationsMap[AnotationKeyValue] = dCEParcelValue
		}
	}
	return
}
