package dce

const (
	DCEParcelNetworkCalico = "calico"
	DCEParcelNetworkOvs    = "ovs"

	OvsRule = "rule"
	OvsPool = "pool"

	CalicoValue       = "default-ipv4-ippool"
	AnotationKeyType  = "dce.daocloud.io/parcel.net.type"
	AnotationKeyValue = "dce.daocloud.io/parcel.net.value"
)
