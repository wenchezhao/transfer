package app

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"strings"
	"time"

	"github.com/opentracing/opentracing-go"
	"github.com/tidwall/gjson"
	autoscalingv1 "k8s.io/api/autoscaling/v1"
	corev1 "k8s.io/api/core/v1"
	kapierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	utilerrors "k8s.io/apimachinery/pkg/util/errors"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/apimachinery/pkg/util/yaml"
	syaml "sigs.k8s.io/yaml"

	"github.com/daocloud/dsp-appserver/pkg/informermanager"
	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	apputil "github.com/daocloud/dsp-appserver/pkg/util/app"
	discoveryutil "github.com/daocloud/dsp-appserver/pkg/util/discovery"
	podutil "github.com/daocloud/dsp-appserver/pkg/util/pod"
	"github.com/daocloud/dsp-appserver/pkg/util/resource"
	vpautil "github.com/daocloud/dsp-appserver/pkg/util/vpa"
)

var log = logi.Log.Sugar()

func ApplyApplication(oldCtx context.Context, namespace string, oldYamls []string, newYaml string, client clientset.Interface) *apputil.ApplicationStatus {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"apply application with yaml",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	var errs []error
	var resources []*unstructured.Unstructured

	toBeCreated, toBeDeleted, err := prepareUpgrade(newYaml, oldYamls, namespace, client)
	if err != nil {
		errs = append(errs, fmt.Errorf("error when prepare upgrade: %v", err))
	}

	for _, obj := range toBeCreated {
		// ensure namespace
		obj.SetNamespace(namespace)
		gvk := obj.GroupVersionKind()
		gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			log.Errorf("unable to discovery resource for gvk %s: %v", gvk, err)
			errs = append(errs, err)
			continue
		}
		// ensure resource
		ri := client.Resource(gvr).Namespace(namespace)
		err = wait.PollImmediate(50*time.Millisecond, 2*time.Second, func() (bool, error) {
			oldObj, err := ri.Get(ctx, obj.GetName(), metav1.GetOptions{})
			if err != nil {
				if !kapierrors.IsNotFound(err) {
					return false, err
				}
				obj.SetResourceVersion("")
				created, err := ri.Create(context.TODO(), &obj, metav1.CreateOptions{})
				if err != nil {
					if kapierrors.IsAlreadyExists(err) {
						return false, nil
					}
					return false, err
				}
				resources = append(resources, created)
				return true, nil
			}

			// update resource
			obj.SetResourceVersion(oldObj.GetResourceVersion())
			patchData, err := obj.MarshalJSON()
			if err != nil {
				return false, err
			}
			updated, err := ri.Patch(context.TODO(), obj.GetName(), types.MergePatchType, patchData, metav1.PatchOptions{})
			if err != nil {
				if kapierrors.IsConflict(err) {
					return false, nil
				}
				return false, err
			}
			resources = append(resources, updated)
			return true, nil
		})
		if err != nil {
			err = fmt.Errorf("unable to ensure resource %s %s/%s: %v", obj.GetKind(), namespace, obj.GetName(), err)
			log.Errorf(err.Error())
			errs = append(errs, err)
		}
	}

	for _, obj := range toBeDeleted {
		// ensure namespace
		obj.SetNamespace(namespace)
		gvk := obj.GroupVersionKind()
		gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			log.Errorf("unable to discovery resource for gvk %s: %v", gvk, err)
			errs = append(errs, err)
			continue
		}
		// delete old resource
		ri := client.Resource(gvr).Namespace(namespace)
		err = wait.PollImmediate(50*time.Millisecond, 2*time.Second, func() (bool, error) {
			err = ri.Delete(context.TODO(), obj.GetName(), metav1.DeleteOptions{})
			if err != nil {
				if kapierrors.IsNotFound(err) {
					return true, nil
				}
				if kapierrors.IsConflict(err) || kapierrors.IsTooManyRequests(err) {
					return false, nil
				}
				return false, err
			}
			return true, nil
		})
		if err != nil {
			err = fmt.Errorf("unable to delete resource %s %s/%s: %v", obj.GetKind(), namespace, obj.GetName(), err)
			log.Errorf(err.Error())
			errs = append(errs, err)
		}
	}

	return getApplicationStatus(resources, errs)
}

func DeleteApplication(oldCtx context.Context, namespace string, oldYamls []string, client clientset.Interface) error {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"delete application with yaml",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	var toBeDeleted []unstructured.Unstructured
	toBeDeletedRefs := sets.NewString()
	for _, yaml := range oldYamls {
		resources, err := parseResourcesFromYAML(yaml)
		if err != nil {
			return err
		}
		for _, resource := range resources {
			ref := fmt.Sprintf("%s %s", resource.GroupVersionKind().String(), resource.GetName())
			if !toBeDeletedRefs.Has(ref) {
				toBeDeletedRefs.Insert(ref)
				toBeDeleted = append(toBeDeleted, resource)
			}
		}
	}

	var errs []error
	for _, obj := range toBeDeleted {
		gvk := obj.GroupVersionKind()
		gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			errs = append(errs, err)
			continue
		}
		err = client.Resource(gvr).Namespace(namespace).Delete(ctx, obj.GetName(), metav1.DeleteOptions{})
		if err != nil && !kapierrors.IsNotFound(err) {
			errs = append(errs, err)
		}
	}
	return utilerrors.NewAggregate(errs)
}

func CheckApplicationYAML(oldCtx context.Context, client clientset.Interface, namespace string, reader io.Reader) error {
	span, _ := opentracing.StartSpanFromContext(
		oldCtx,
		"check application yaml",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	return resource.CheckFromReader(client, namespace, reader)
}

func ListAll(oldCtx context.Context, namespace string, kinds []string, manifests []byte, client clientset.Interface, informer informermanager.SingleClusterInformerManager) ([]metav1.Object, error) {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"list all",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	kindSet := sets.NewString()
	for _, kind := range kinds {
		if len(kind) != 0 {
			kindSet.Insert(kind)
		}
	}
	all := make([]metav1.Object, 0)
	decoder := yaml.NewYAMLOrJSONDecoder(bytes.NewBuffer(manifests), 4096)
	for {
		obj := &unstructured.Unstructured{}
		if err := decoder.Decode(obj); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return nil, err
		}

		gvk := obj.GroupVersionKind()
		if len(kindSet) != 0 && !kindSet.Has(gvk.Kind) {
			continue
		}

		gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			if kapierrors.IsNotFound(err) {
				continue
			}
			return nil, err
		}

		if informer != nil && informer.IsInformerSynced(gvr) {
			got, err := informer.Lister(gvr).ByNamespace(namespace).Get(obj.GetName())
			if err != nil {
				if kapierrors.IsNotFound(err) {
					// skip it if the resource doesn't exist.
					continue
				}
				return nil, err
			}
			all = append(all, got.(*unstructured.Unstructured))
		} else {
			got, err := client.Resource(gvr).Namespace(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
			if err != nil {
				if kapierrors.IsNotFound(err) {
					// skip it if the resource doesn't exist.
					continue
				}
				return nil, err
			}
			all = append(all, got)
		}
	}
	return all, nil
}

// ListWorkloads returns underlying workloads according to the given manifests.
func ListWorkloads(oldCtx context.Context, namespace string, manifests []byte, client clientset.Interface, informer informermanager.SingleClusterInformerManager) ([]metav1.Object, error) {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"list workloads",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	workloads := make([]metav1.Object, 0)
	kinds := sets.NewString("Deployment", "StatefulSet", "CronJob")
	decoder := yaml.NewYAMLOrJSONDecoder(bytes.NewBuffer(manifests), 4096)
	for {
		obj := &unstructured.Unstructured{}
		if err := decoder.Decode(obj); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return nil, err
		}

		gvk := obj.GroupVersionKind()
		if !kinds.Has(gvk.Kind) {
			continue
		}

		gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			if kapierrors.IsNotFound(err) {
				continue
			}
			return nil, err
		}

		if informer != nil && informer.IsInformerSynced(gvr) {
			got, err := informer.Lister(gvr).ByNamespace(namespace).Get(obj.GetName())
			if err != nil {
				if kapierrors.IsNotFound(err) {
					// skip it if the resource doesn't exist.
					continue
				}
				return nil, err
			}
			workloads = append(workloads, got.(*unstructured.Unstructured))
		} else {
			got, err := client.Resource(gvr).Namespace(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
			if err != nil {
				if kapierrors.IsNotFound(err) {
					// skip it if the resource doesn't exist.
					continue
				}
				return nil, err
			}
			workloads = append(workloads, got)
		}
	}
	return workloads, nil
}

func ListApplicationPods(oldCtx context.Context, namespace string, manifests []byte, client clientset.Interface) (*corev1.PodList, error) {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"list application pods",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	matchingPods := make([]corev1.Pod, 0)
	decoder := yaml.NewYAMLOrJSONDecoder(bytes.NewBuffer(manifests), 4096)
	for {
		obj := &unstructured.Unstructured{}
		if err := decoder.Decode(obj); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return nil, err
		}

		gvk := obj.GroupVersionKind()
		switch gvk.Kind {
		case "Deployment":
			got, err := client.AppsV1().Deployments(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
			if err != nil {
				if kapierrors.IsNotFound(err) {
					continue
				}
				return nil, err
			}
			pods, err := podutil.ListDeploymentPods(client, *got)
			if err != nil {
				return nil, err
			}
			matchingPods = append(matchingPods, pods...)
		case "StatefulSet":
			got, err := client.AppsV1().StatefulSets(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
			if err != nil {
				if kapierrors.IsNotFound(err) {
					continue
				}
				return nil, err
			}
			pods, err := podutil.ListStatefulSetPods(client, *got)
			if err != nil {
				return nil, err
			}
			matchingPods = append(matchingPods, pods...)
		case "CronJob":
			got, err := client.BatchV1beta1().CronJobs(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
			if err != nil {
				if kapierrors.IsNotFound(err) {
					continue
				}
				return nil, err
			}
			pods, err := podutil.ListCronJobPods(client, *got)
			if err != nil {
				return nil, err
			}
			matchingPods = append(matchingPods, pods...)
		}
	}

	list := &corev1.PodList{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "v1",
			Kind:       "PodList",
		},
		Items: matchingPods,
	}

	for index := range list.Items {
		list.Items[index].TypeMeta = metav1.TypeMeta{
			APIVersion: "v1",
			Kind:       "Pod",
		}
	}
	return list, nil
}

func ListDiscovery(oldCtx context.Context, namespace string, manifests []byte, client clientset.Interface, informer informermanager.SingleClusterInformerManager) ([]metav1.Object, error) {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"list discover",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	networkings := make([]metav1.Object, 0)
	kinds := sets.NewString("Service", "Ingress", "Route")
	decoder := yaml.NewYAMLOrJSONDecoder(bytes.NewBuffer(manifests), 4096)
	for {
		obj := &unstructured.Unstructured{}
		if err := decoder.Decode(obj); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return nil, err
		}

		gvk := obj.GroupVersionKind()
		if !kinds.Has(gvk.Kind) {
			continue
		}
		gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			if kapierrors.IsNotFound(err) {
				// skip it if the resource doesn't exist.
				continue
			}
			return nil, err
		}
		if informer != nil && informer.IsInformerSynced(gvr) {
			got, err := informer.Lister(gvr).ByNamespace(namespace).Get(obj.GetName())
			if err != nil {
				if kapierrors.IsNotFound(err) {
					// skip it if the resource doesn't exist.
					continue
				}
				return nil, err
			}
			networkings = append(networkings, got.(*unstructured.Unstructured))
		} else {
			got, err := client.Resource(gvr).Namespace(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
			if err != nil {
				if kapierrors.IsNotFound(err) {
					// skip it if the resource doesn't exist.
					continue
				}
				return nil, err
			}
			networkings = append(networkings, got)
		}

	}
	return networkings, nil
}

func ListStorage(oldCtx context.Context, namespace string, manifests []byte, client clientset.Interface, informer informermanager.SingleClusterInformerManager) ([]metav1.Object, error) {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"list storage yaml",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	resources := make([]metav1.Object, 0)
	kinds := sets.NewString("ConfigMap", "Secret", "PersistentVolumeClaim")
	decoder := yaml.NewYAMLOrJSONDecoder(bytes.NewBuffer(manifests), 4096)
	for {
		obj := &unstructured.Unstructured{}
		if err := decoder.Decode(obj); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return nil, err
		}

		gvk := obj.GroupVersionKind()
		if !kinds.Has(gvk.Kind) {
			continue
		}

		gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			if kapierrors.IsNotFound(err) {
				continue
			}
			return nil, err
		}

		if informer != nil && informer.IsInformerSynced(gvr) {
			got, err := informer.Lister(gvr).ByNamespace(namespace).Get(obj.GetName())
			if err != nil {
				if kapierrors.IsNotFound(err) {
					// skip it if the resource doesn't exist.
					continue
				}
				return nil, err
			}
			resources = append(resources, got.(*unstructured.Unstructured))
		} else {
			got, err := client.Resource(gvr).Namespace(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
			if err != nil {
				if kapierrors.IsNotFound(err) {
					// skip it if the resource doesn't exist.
					continue
				}
				return nil, err
			}
			resources = append(resources, got)
		}
	}
	return resources, nil
}

func ListOther(oldCtx context.Context, namespace string, manifests []byte, client clientset.Interface) ([]metav1.Object, error) {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"list other resources yaml",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	resources := make([]metav1.Object, 0)
	excludeKinds := sets.NewString(
		"ConfigMap", "Secret", "PersistentVolumeClaim",
		"Service", "Ingress", "Route",
		"Deployment", "StatefulSet", "CronJob",
	)
	decoder := yaml.NewYAMLOrJSONDecoder(bytes.NewBuffer(manifests), 4096)
	for {
		obj := &unstructured.Unstructured{}
		if err := decoder.Decode(obj); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return nil, err
		}

		gvk := obj.GroupVersionKind()
		if excludeKinds.Has(gvk.Kind) {
			continue
		}

		gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			if kapierrors.IsNotFound(err) {
				continue
			}
			return nil, err
		}
		got, err := client.Resource(gvr).Namespace(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
		if err != nil {
			if kapierrors.IsNotFound(err) {
				// skip it if the resource doesn't exist.
				continue
			}
			return nil, err
		}
		resources = append(resources, got)
	}
	return resources, nil
}

func ListVPA(oldCtx context.Context, namespace string, manifests []byte, client clientset.Interface) ([]map[string]interface{}, error) {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"list vpa yaml",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	resources := []map[string]interface{}{}

	// 这里使用gvk来获取资源，是因为当前client-go版本中不存在vpa资源对象的client封装
	// https://github.com/kubernetes/kubernetes/pull/63797/files
	gvk := schema.GroupVersionKind{
		Group:   "autoscaling.k8s.io",
		Version: "v1",
		Kind:    "VerticalPodAutoscaler",
	}

	gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
	if err != nil {
		log.Errorf("failed to get gvr by gvk:%v, error:%v", gvk, err)
		return resources, nil
	}

	vpaList, err := client.Resource(gvr).Namespace(namespace).List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to list vpa by gvr:%v, error:%v", gvr, err)
		return resources, nil
	}
	vpaKinds := sets.NewString("Deployment", "StatefulSet")

	decoder := yaml.NewYAMLOrJSONDecoder(bytes.NewBuffer(manifests), 4096)
	for {
		obj := &unstructured.Unstructured{}
		if err := decoder.Decode(obj); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return nil, err
		}

		oGvk := obj.GroupVersionKind()
		if !vpaKinds.Has(oGvk.Kind) {
			continue
		}

		// 这里的vpa名称规则是固定的
		vpaName := fmt.Sprintf("%s-%s-vpa", strings.ToLower(oGvk.Kind), obj.GetName())
		for _, vpa := range vpaList.Items {
			if vpa.GetName() == vpaName {
				// 这里需要获取容器设置值 推荐值和实际值
				// 同时需要转换单位，由于在当前client-go版本中，不存在vpa对象，所以定义了推荐存储的对象
				// 用于解析vpa对象
				bytes, err := vpa.MarshalJSON()
				if err != nil {
					continue
				}
				r := gjson.ParseBytes(bytes)
				reR := []vpautil.RecommendedContainerResources{}
				results := []map[string]interface{}{}
				if r.Get("status").Get("recommendation").Exists() {
					if err := json.Unmarshal([]byte(r.Get("status").Get("recommendation").Get("containerRecommendations").String()), &reR); err == nil {
						actual := make(map[string]map[string]int64)
						expect := make(map[string]map[string]int64)
						switch oGvk.Kind {
						case "Deployment":
							deploy, err := client.AppsV1().Deployments(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
							if err == nil {
								expect = vpautil.RevertContainerResourcesUnit(deploy.Spec.Template.Spec.Containers)
								pods, err := podutil.ListDeploymentPods(client, *deploy)
								if err == nil && len(pods) > 0 {
									actual = vpautil.RevertContainerResourcesUnit(pods[0].Spec.Containers)
								}
							}

						case "StatefulSet":
							sts, err := client.AppsV1().StatefulSets(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
							if err == nil {
								expect = vpautil.RevertContainerResourcesUnit(sts.Spec.Template.Spec.Containers)
								pods, err := podutil.ListStatefulSetPods(client, *sts)
								if err == nil && len(pods) > 0 {
									actual = vpautil.RevertContainerResourcesUnit(pods[0].Spec.Containers)
								}
							}
						}
						for _, r1 := range reR {
							containerR := make(map[string]interface{})
							containerR["name"] = r1.ContainerName
							containerR["recommend"] = map[string]int64{
								"cpu":    r1.Target.CPU().MilliValue(),
								"memory": r1.Target.Memory().Value(),
							}
							// 获取推荐值
							if ev, ok := expect[r1.ContainerName]; ok {
								containerR["expect"] = ev
							}
							// 获取实际值
							if av, ok := actual[r1.ContainerName]; ok {
								containerR["actual"] = av
							}
							results = append(results, containerR)
						}
					}
				}

				resources = append(resources, map[string]interface{}{
					"vpa":          vpa.Object,
					"vpaResources": results,
				})
			}
		}
	}
	return resources, nil
}

func ListHPA(oldCtx context.Context, namespace string, manifests []byte, client clientset.Interface) ([]autoscalingv1.HorizontalPodAutoscaler, error) {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"list hpa yaml",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	hpaList, err := client.AutoscalingV1().HorizontalPodAutoscalers(namespace).List(ctx, metav1.ListOptions{})
	if err != nil {
		log.Errorf("failed to list namespace %s hpa error:%v", namespace, err)
		return nil, err
	}

	targetKinds := sets.NewString("Deployment", "StatefulSet")
	resList := []autoscalingv1.HorizontalPodAutoscaler{}
	decoder := yaml.NewYAMLOrJSONDecoder(bytes.NewBuffer(manifests), 4096)
	for {
		obj := &unstructured.Unstructured{}
		if err := decoder.Decode(obj); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return nil, err
		}

		gvk := obj.GroupVersionKind()
		if !targetKinds.Has(gvk.Kind) {
			continue
		}

		for _, hpa := range hpaList.Items {
			if hpa.Spec.ScaleTargetRef.Kind == gvk.Kind && hpa.Spec.ScaleTargetRef.Name == obj.GetName() {
				hpa.APIVersion = "autoscaling/v1"
				hpa.Kind = "HorizontalPodAutoscaler"
				resList = append(resList, hpa)
			}
		}
	}
	return resList, nil
}

func GetApplicationStatus(oldCtx context.Context, namespace string, manifests []byte, client clientset.Interface, informer informermanager.SingleClusterInformerManager) (*apputil.ApplicationStatus, error) {
	span, ctx := opentracing.StartSpanFromContext(
		oldCtx,
		"get application status",
		opentracing.ChildOf(opentracing.SpanFromContext(oldCtx).Context()))
	defer span.Finish()

	var (
		resources []*unstructured.Unstructured
		errs      []error
	)

	// fetch component resources
	decoder := yaml.NewYAMLOrJSONDecoder(bytes.NewBuffer(manifests), 4096)
	for {
		obj := &unstructured.Unstructured{}
		if err := decoder.Decode(obj); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			return nil, err
		}
		gvk := obj.GroupVersionKind()
		gvr, err := discoveryutil.ResourceForGVK(client.CachedDiscoveryInterface(), gvk)
		if err != nil {
			log.Errorf("unable to discovery resource for gvk %s: %v", gvk, err)
			errs = append(errs, err)
			continue
		}
		if informer != nil && informer.IsInformerSynced(gvr) {
			got, err := informer.Lister(gvr).ByNamespace(namespace).Get(obj.GetName())
			if err != nil {
				log.Warnf("unable to get resource %s %s/%s: %v", obj.GetKind(), namespace, obj.GetName(), err)
				errs = append(errs, err)
				continue
			}
			resources = append(resources, got.(*unstructured.Unstructured))
		} else {
			got, err := client.Resource(gvr).Namespace(namespace).Get(ctx, obj.GetName(), metav1.GetOptions{})
			if err != nil {
				log.Warnf("unable to get resource %s %s/%s: %v", obj.GetKind(), namespace, obj.GetName(), err)
				errs = append(errs, err)
				continue
			}
			resources = append(resources, got)
		}

	}

	return getApplicationStatus(resources, errs), nil
}

func getApplicationStatus(resources []*unstructured.Unstructured, errs []error) *apputil.ApplicationStatus {
	newApplicationStatus := &apputil.ApplicationStatus{}

	objectStatuses := objectStatuses(resources, &errs)
	aggReady, countReady := aggregateReady(objectStatuses)
	newApplicationStatus.Components = objectStatuses
	newApplicationStatus.ComponentsReady = fmt.Sprintf("%d/%d", countReady, len(objectStatuses))

	if err := utilerrors.NewAggregate(errs); err != nil {
		apputil.SetReadyUnknownCondition(newApplicationStatus, "ComponentsReadyUnknown", "failed to aggregate all components' statuses, check the Error condition for details")
		apputil.SetErrorCondition(newApplicationStatus, "ErrorSeen", err.Error())
	} else if aggReady {
		apputil.SetReadyCondition(newApplicationStatus, "ComponentsReady", "all components ready")
		apputil.ClearErrorCondition(newApplicationStatus)
	} else {
		apputil.SetNotReadyCondition(newApplicationStatus, "ComponentsNotReady", fmt.Sprintf("%d components not ready", len(objectStatuses)-countReady))
		apputil.ClearErrorCondition(newApplicationStatus)
	}
	return newApplicationStatus
}

func objectStatuses(resources []*unstructured.Unstructured, errs *[]error) []apputil.ObjectStatus {
	var oss []apputil.ObjectStatus
	for _, resource := range resources {
		os := apputil.ObjectStatus{
			APIGroup: resource.GroupVersionKind().Group,
			Kind:     resource.GetKind(),
			Name:     resource.GetName(),
		}
		s, err := apputil.Status(resource)
		if err != nil {
			log.Errorf("unable to compute status for resource %s %s/%s: %v",
				resource.GroupVersionKind().String(), resource.GetNamespace(), resource.GetName(), err)
			*errs = append(*errs, err)
		}
		os.Status = s
		oss = append(oss, os)
	}
	return oss
}

func aggregateReady(objectStatuses []apputil.ObjectStatus) (bool, int) {
	countReady := 0
	for _, os := range objectStatuses {
		if os.Status == apputil.StatusReady {
			countReady++
		}
	}
	if countReady == len(objectStatuses) {
		return true, countReady
	}
	return false, countReady
}

// prepareUpgrade parses and validates resources from yamls for an upgrade operation
func prepareUpgrade(newYaml string, oldYamls []string, namespace string, client clientset.Interface) ([]unstructured.Unstructured, []unstructured.Unstructured, error) {
	toBeCreated, err := parseResourcesFromYAML(newYaml)
	if err != nil {
		return nil, nil, err
	}

	toBeCreatedRefs := sets.NewString()
	for _, resource := range toBeCreated {
		ref := fmt.Sprintf("%s %s", resource.GroupVersionKind().String(), resource.GetName())
		toBeCreatedRefs.Insert(ref)
	}

	var toBeDeleted []unstructured.Unstructured
	toBeDeletedRefs := sets.NewString()
	for _, yaml := range oldYamls {
		resources, err := parseResourcesFromYAML(yaml)
		if err != nil {
			return nil, nil, err
		}
		for _, resource := range resources {
			ref := fmt.Sprintf("%s %s", resource.GroupVersionKind().String(), resource.GetName())
			if !toBeDeletedRefs.Has(ref) && !toBeCreatedRefs.Has(ref) {
				toBeDeletedRefs.Insert(ref)
				toBeDeleted = append(toBeDeleted, resource)
			}
		}
	}

	// validate node port
	var errs []error
	for _, obj := range toBeCreated {
		obj.SetNamespace(namespace)
		if err := resource.CheckNodePort(client, &obj); err != nil {
			errs = append(errs, err)
		}
	}
	if len(errs) > 0 {
		return nil, nil, utilerrors.NewAggregate(errs)
	}

	return toBeCreated, toBeDeleted, nil
}

// parseResourcesFromYAML returns resources
func parseResourcesFromYAML(content string) ([]unstructured.Unstructured, error) {
	var resources []unstructured.Unstructured
	decoder := yaml.NewYAMLOrJSONDecoder(strings.NewReader(content), 4096)
	for {
		// unmarshals the next object from the underlying stream into the provide object
		ext := runtime.RawExtension{}
		if err := decoder.Decode(&ext); err != nil {
			if err == io.EOF {
				break
			}
			log.Errorf("failed to decode the next object from the underlying stream into an unstructured object: %v", err)
			continue
		}
		ext.Raw = bytes.TrimSpace(ext.Raw)
		if len(ext.Raw) == 0 || bytes.Equal(ext.Raw, []byte("null")) {
			continue
		}

		obj := unstructured.Unstructured{}
		if err := syaml.Unmarshal(ext.Raw, &obj); err != nil {
			continue
		}
		resources = append(resources, obj)
	}
	return resources, nil
}
