package informermanager

import (
	"encoding/base64"
	"fmt"

	utilerrors "k8s.io/apimachinery/pkg/util/errors"
	"k8s.io/client-go/rest"

	"github.com/daocloud/dsp-appserver/pkg/config"
	"github.com/daocloud/dsp-appserver/pkg/model/zone"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/svc"
)

// ClientConfigGetter is used to make it easy to get a kube-apiserver client
type ClientConfigGetter interface {
	// Get returns a completed client config for a given cluster
	Get(cluster string) (*rest.Config, error)
	// List returns a list of completed client configs
	List() (map[string]*rest.Config, error)
}

// ClientConfigGetter constructs a new instance of clientConfigGetterImpl.
func NewClientConfigGetter(cfg config.Config) (ClientConfigGetter, error) {
	source, err := svc.NewServiceContext(cfg.DBConfig)
	if err != nil {
		return nil, err
	}
	return &clientConfigGetterImpl{
		source: source,
	}, nil
}

type clientConfigGetterImpl struct {
	source *svc.ServiceContext
}

// Get returns a complete client config for a given cluster
func (g *clientConfigGetterImpl) Get(cluster string) (*rest.Config, error) {
	got, err := g.source.Model.FindOne(cluster)
	if err != nil {
		return nil, err
	}

	return g.toRestConfig(got)
}

// List returns a list of complete client configs
func (g *clientConfigGetterImpl) List() (map[string]*rest.Config, error) {
	clusters, err := g.source.Model.List()
	if err != nil {
		return nil, err
	}
	clusterMapping := make(map[string]*rest.Config)
	for _, cluster := range clusters {
		// if cluster is offline, we assume that it will be removed by platform admin soon.
		// value '2' means offline.
		if cluster.Status == 2 {
			continue
		}
		if err := g.validate(&cluster); err != nil {
			log.Infof("skip it, because the auth info of cluster %q (%q) is uncompeleted: %v", cluster.Clusterid, cluster.Clustername, err)
			continue
		}
		clientConfig, err := g.toRestConfig(&cluster)
		if err != nil {
			log.Errorf("failed to construct rest config for the cluster %q (%q): %v", cluster.Clusterid, cluster.Clustername, err)
			// skip it
			continue
		}
		clusterMapping[cluster.Clusterid] = clientConfig
	}
	return clusterMapping, nil
}

func (g *clientConfigGetterImpl) validate(cluster *zone.TiZone) error {
	var errs []error
	if cluster.Clusterurl == "" {
		errs = append(errs, fmt.Errorf("the kube-apiserver address of the cluster %q (%q) is missing", cluster.Clusterid, cluster.Clustername))
	}
	if cluster.Certificateauthoritydata == "" {
		errs = append(errs, fmt.Errorf("the certificate authority  of the cluster %q (%q) is missing", cluster.Clusterid, cluster.Clustername))
	}
	if cluster.Clientcertificatedata == "" {
		errs = append(errs, fmt.Errorf("the client certificate of the cluster %q (%q) is missing", cluster.Clusterid, cluster.Clustername))
	}
	if cluster.Clientkeydata == "" {
		errs = append(errs, fmt.Errorf("the client key of the cluster %q (%q) is missing", cluster.Clusterid, cluster.Clustername))
	}
	return utilerrors.NewAggregate(errs)
}

func (g *clientConfigGetterImpl) toRestConfig(cluster *zone.TiZone) (*rest.Config, error) {
	caData, err := base64.StdEncoding.DecodeString(cluster.Certificateauthoritydata)
	if err != nil {
		return nil, err
	}
	certData, err := base64.StdEncoding.DecodeString(cluster.Clientcertificatedata)
	if err != nil {
		return nil, err
	}
	keyData, err := base64.StdEncoding.DecodeString(cluster.Clientkeydata)
	if err != nil {
		return nil, err
	}
	return clientset.NewRestConfig(cluster.Clusterurl, caData, certData, keyData)
}
