package informermanager

import (
	"fmt"
	"time"

	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/apimachinery/pkg/util/wait"
	"k8s.io/client-go/discovery"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/cache"

	"github.com/daocloud/dsp-appserver/pkg/logi"
)

var log = logi.Log.Sugar()

var DefaultGVRs = []schema.GroupVersionResource{
	// for kubernetes
	{Group: "", Version: "v1", Resource: "pods"},
	{Group: "", Version: "v1", Resource: "services"},
	{Group: "", Version: "v1", Resource: "configmaps"},
	{Group: "", Version: "v1", Resource: "secrets"},
	{Group: "", Version: "v1", Resource: "serviceaccounts"},
	{Group: "apps", Version: "v1", Resource: "deployments"},
	{Group: "apps", Version: "v1", Resource: "statefulsets"},
	{Group: "batch", Version: "v1beta1", Resource: "cronjobs"},
	{Group: "extensions", Version: "v1beta1", Resource: "ingresses"},
	// for openshift
	{Group: "route.openshift.io", Version: "v1", Resource: "routes"},
}

// InformerManager manages dynamic shared informer for all resources, include Kubernetes resource and
// custom resources defined by CustomResourceDefinition, across multi-cluster.
type InformerManager interface {
	// GetSingleClusterManager gets the informer manager for a specific cluster.
	// The informer manager should be created before, otherwise, nil will be returned.
	GetSingleClusterManager(cluster string) SingleClusterInformerManager

	// IsInformerSynced checks if the resource's informer is synced.
	// A informer is synced means:
	// - The informer has been created.
	// - The informer has started(by method 'Start').
	// - The informer's cache has been synced.
	IsInformerSynced(cluster string, gvr schema.GroupVersionResource) bool
	// Start will run all informers across multi-cluster, the informers will keep running until the channel closed.
	Start()
}

type informerManagerImpl struct {
	manager      MultiClusterInformerManager
	configGetter ClientConfigGetter
	defaultGVRs  []schema.GroupVersionResource
	stopCh       <-chan struct{}
}

// NewInformerManager constructs a new instance of informerManagerImpl.
func NewInformerManager(stopCh <-chan struct{}, defaultGVRs []schema.GroupVersionResource, configGetter ClientConfigGetter) InformerManager {
	return &informerManagerImpl{
		manager:      NewMultiClusterInformerManager(stopCh),
		defaultGVRs:  defaultGVRs,
		configGetter: configGetter,
		stopCh:       stopCh,
	}
}

// GetSingleClusterManager gets the informer manager for a specific cluster.
// The informer manager should be created before, otherwise, nil will be returned.
func (m *informerManagerImpl) GetSingleClusterManager(cluster string) SingleClusterInformerManager {
	return m.manager.GetSingleClusterManager(cluster)
}

// IsInformerSynced checks if the resource's informer is synced.
// A informer is synced means:
// - The informer has been created.
// - The informer has started(by method 'Start').
// - The informer's cache has been synced.
func (m *informerManagerImpl) IsInformerSynced(cluster string, gvr schema.GroupVersionResource) bool {
	clusterManager := m.manager.GetSingleClusterManager(cluster)
	if clusterManager == nil {
		return false
	}
	return clusterManager.IsInformerSynced(gvr)
}

// Start will run all informers across multi-cluster, the informers will keep running until the channel closed.
func (m *informerManagerImpl) Start() {
	log.Infof("starting informer manager")
	go wait.Until(m.sync, time.Minute, m.stopCh)
}

func (m *informerManagerImpl) sync() {
	configs, err := m.configGetter.List()
	if err != nil {
		log.Errorf("failed to list cluster client configs: %v", err)
		return
	}
	// expected holds all the cluster names which are expected to start informers.
	expected := sets.NewString()

	// start informers
	for cluster, config := range configs {
		expected.Insert(cluster)
		// skip it if the cluster has been managed.
		// Fixme(@carlory): we should rebuild manager if the client config was changed.
		if m.manager.IsManagerExist(cluster) {
			continue
		}

		log.Infof("add cluster %q into manager", cluster)
		client, err := dynamic.NewForConfig(config)
		if err != nil {
			log.Errorf("failed to create a new dynamic client for the cluster %q: %v", cluster, config)
			continue
		}

		gvrs, err := m.getGVRs(config)
		if err != nil {
			log.Errorf("failed to get GVRs for the cluster %q: %v", cluster, config)
			continue
		}

		// we don't need re-sync logic.
		clusterInformerMgr := m.manager.ForCluster(cluster, client, 0)
		for _, gvr := range gvrs {
			clusterInformerMgr.ForResource(gvr, &cache.ResourceEventHandlerFuncs{})
		}
		log.Infof("start informer and wait for cluster %q cache sync ...", cluster)
		m.manager.Start(cluster)
		if err := func() error {
			synced := m.manager.WaitForCacheSyncWithTimeout(cluster, 5*time.Minute)
			if synced == nil {
				return fmt.Errorf("no informerFactory for cluster %q exist", cluster)
			}
			for _, gvr := range gvrs {
				if !synced[gvr] {
					return fmt.Errorf("informer for %s hasn't synced", gvr)
				}
			}
			return nil
		}(); err != nil {
			log.Errorf("failed to sync cache for cluster %q: %v", cluster, err)
			m.manager.Stop(cluster)
			continue
		}
		log.Infof("cluster %s cache has been synced", cluster)
	}

	// stop informers
	for _, cluster := range m.manager.ListManagedClusters() {
		if !expected.Has(cluster) {
			m.manager.Stop(cluster)
			log.Infof("stoped all informers for the cluster %q", cluster)
		}
	}
}

// getGVRs returns a list of gvrs for which we will build a dynamic shared informer
func (m *informerManagerImpl) getGVRs(config *rest.Config) ([]schema.GroupVersionResource, error) {
	client, err := discovery.NewDiscoveryClientForConfig(config)
	if err != nil {
		return nil, fmt.Errorf("failed to create a discovery client: %v", err)
	}
	_, resources, err := client.ServerGroupsAndResources()
	if err != nil {
		log.Warnf("unable to get all supported resources from server: %v", err)
	}
	if len(resources) == 0 {
		return nil, fmt.Errorf("unable to get any supported resources from server: %v", err)
	}

	discovered := sets.NewString()
	for _, rl := range resources {
		gv, err := schema.ParseGroupVersion(rl.GroupVersion)
		if err != nil {
			log.Errorf("failed to parse GroupVersion %q, skipping: %v", rl.GroupVersion, err)
			continue
		}
		for _, r := range rl.APIResources {
			gvr := schema.GroupVersionResource{Group: gv.Group, Version: gv.Version, Resource: r.Name}
			discovered.Insert(gvr.String())
		}
	}

	gvrs := []schema.GroupVersionResource{}
	for _, gvr := range m.defaultGVRs {
		if discovered.Has(gvr.String()) {
			gvrs = append(gvrs, gvr)
		}
	}

	return gvrs, nil
}
