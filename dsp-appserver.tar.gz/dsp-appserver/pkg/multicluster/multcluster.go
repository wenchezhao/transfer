package multicluster

import (
	"encoding/base64"
	"reflect"
	"sync"

	errors2 "github.com/pkg/errors"
	restclient "k8s.io/client-go/rest"

	"github.com/daocloud/dsp-appserver/pkg/config"
	"github.com/daocloud/dsp-appserver/pkg/logi"
	"github.com/daocloud/dsp-appserver/pkg/model/zone"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/clientset"
	"github.com/daocloud/dsp-appserver/pkg/multicluster/svc"
)

var log = logi.Log.Sugar()

type clientWithConfig struct {
	ClientConfig *restclient.Config
	client       clientset.Interface
}

// ClusterClientManager stores kubernetes client instance per cluster
type ClusterClientManager struct {
	mu      sync.RWMutex
	clients map[string]clientWithConfig
	service *svc.ServiceContext
}

// NewClusterClientManager creates ClusterClientManager instance
func NewClusterClientManager(c *config.Config) (*ClusterClientManager, error) {
	service, err := svc.NewServiceContext(c.DBConfig)
	if err != nil {
		return nil, err
	}
	return &ClusterClientManager{
		clients: map[string]clientWithConfig{},
		service: service,
	}, nil
}

// 获取集群信息，如果缓存中有，直接从缓存中取，如果没有，读库并更新缓存
func (m *ClusterClientManager) GetClientFromCache(clusterID string) (clientset.Interface, error) {
	if cc, ok := m.clients[clusterID]; ok {
		return cc.client, nil
	}

	clientConfig, err := m.fetchClientConfig(clusterID)
	if err != nil {
		return nil, errors2.Wrap(err, "")
	}

	cc, err := m.updateClientWithConfig(clusterID, clientConfig)
	if err != nil {
		return nil, errors2.Wrap(err, "")
	}
	return cc.client, nil
}

func (m *ClusterClientManager) Client(cluster string) (clientset.Interface, error) {
	clientConfig, err := m.fetchClientConfig(cluster)
	if err != nil {
		return nil, errors2.Wrap(err, "")
	}
	cc, err := m.updateClientWithConfig(cluster, clientConfig)
	if err != nil {
		return nil, errors2.Wrap(err, "")
	}
	return cc.client, nil
}

// updateClientWithConfig creates new cluster client if necessary (the ClientConfig has changed or there is no client for the cluster),
// the method returns created or stored cluster client with config.
func (m *ClusterClientManager) updateClientWithConfig(cluster string, clientConfig *restclient.Config) (clientWithConfig, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	existing, found := m.clients[cluster]

	if !found || configHasChanged(existing.ClientConfig, clientConfig) {
		log.Debugf("Update client for cluster %q", cluster)
		return m.createClientWithConfig(cluster, clientConfig)
	}

	return existing, nil
}

// createClientWithConfig stores new client with config and returns it.
func (m *ClusterClientManager) createClientWithConfig(cluster string, clientConfig *restclient.Config) (clientWithConfig, error) {

	client, err := clientset.NewForConfig(clientConfig)
	if err != nil {
		return clientWithConfig{}, err
	}

	m.clients[cluster] = clientWithConfig{
		client:       client,
		ClientConfig: clientConfig,
	}
	return m.clients[cluster], nil
}

func (m *ClusterClientManager) fetchClientConfig(cluster string) (*restclient.Config, error) {
	if cluster == "" {
		return restclient.InClusterConfig()
	}
	clusterInfo, err := m.service.Model.FindOne(cluster)
	if err != nil {
		return nil, err
	}
	ca, err := base64.StdEncoding.DecodeString(clusterInfo.Certificateauthoritydata)
	if err != nil {
		return nil, err
	}
	crt, err := base64.StdEncoding.DecodeString(clusterInfo.Clientcertificatedata)
	if err != nil {
		return nil, err
	}
	key, err := base64.StdEncoding.DecodeString(clusterInfo.Clientkeydata)
	if err != nil {
		return nil, err
	}

	return clientset.NewRestConfig(
		clusterInfo.Clusterurl,
		ca,
		crt,
		key,
	)
}

func (m *ClusterClientManager) FetchTiZone(cluster string) (*zone.TiZone, error) {
	clusterInfo, err := m.service.Model.FindOne(cluster)
	if err != nil {
		return nil, err
	}
	return clusterInfo, nil
}

func configHasChanged(cfg1 *restclient.Config, cfg2 *restclient.Config) bool {
	return !reflect.DeepEqual(cfg1, cfg2)
}
