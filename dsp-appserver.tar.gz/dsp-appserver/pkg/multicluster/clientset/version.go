package clientset

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	errors2 "github.com/pkg/errors"
	"k8s.io/apimachinery/pkg/version"

	"github.com/daocloud/dsp-appserver/pkg/util/caller"
)

const (
	K8S     = "K8S"
	OCP     = "OCP"
	DCE     = "DCE"
	KARMADA = "KARMADA"

	path_k8s = "/version"

	// 经测试此接口在openshift中不需要权限
	// 包含在system:openshift:discovery这个clusterrole中授权给了system:unauthenticated
	path_ocp = "/version/openshift"

	// TODO dce获取version接口待确认
	path_dce = "/version/dce"
)

type Version struct {
	Type string        `json:"type"`
	Info *version.Info `json:"info"`
}

func (c *Clientset) newVersion(t string, i *version.Info) *Version {
	return &Version{
		Type: t,
		Info: i,
	}
}

func (c *Clientset) ClusterVersion(clusterType string) (ver *Version, err error) {
	err = caller.TimeoutWrap(8*time.Second, func() error {
		ver, err = c.clusterVersion(clusterType)
		return err
	})

	return
}

func (c *Clientset) clusterVersion(clusterType string) (*Version, error) {
	var err error
	var info *version.Info

	switch clusterType {
	case "":
		// 为空时按顺序检测clusterType
		return c.sequenceDetectVersion()
	case OCP:
		info, err = c.k8sVersion(path_ocp)
	case DCE:
		info, err = c.k8sVersion(path_k8s)
	case K8S:
		info, err = c.k8sVersion(path_dce)
	default:
		return nil, errors2.New("unsupported type")
	}

	if err == nil {
		return c.newVersion(clusterType, info), nil
	}

	return nil, errors2.Wrap(err, "get cluster version failed")
}

// 顺序检测集群version，特征明显的放前面
func (c *Clientset) sequenceDetectVersion() (*Version, error) {
	info, err := c.k8sVersion(path_ocp)
	if err == nil {
		return c.newVersion(OCP, info), nil
	}

	info, err = c.k8sVersion(path_dce)
	if err == nil {
		return c.newVersion(DCE, info), nil
	}

	info, err = c.k8sVersion(path_k8s)
	if err == nil {
		return c.newVersion(K8S, info), nil
	}

	return nil, errors2.Wrap(err, "detect cluster version failed")
}

// reference discovery.ServerVersion
func (c *Clientset) k8sVersion(path string) (*version.Info, error) {
	body, err := c.RESTClient().Get().AbsPath(path).Do(context.TODO()).Raw()
	if err != nil {
		return nil, err
	}
	var info version.Info
	err = json.Unmarshal(body, &info)
	if err != nil {
		return nil, fmt.Errorf("unable to parse the server version: %v", err)
	}
	return &info, nil
}
