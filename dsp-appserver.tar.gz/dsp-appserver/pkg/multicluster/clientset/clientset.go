package clientset

import (
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	openshiftappsv1 "github.com/openshift/client-go/apps/clientset/versioned/typed/apps/v1"
	openshiftimagev1 "github.com/openshift/client-go/image/clientset/versioned/typed/image/v1"
	openshiftnetworkclientsetv1 "github.com/openshift/client-go/network/clientset/versioned"
	openshiftnetworkv1 "github.com/openshift/client-go/network/clientset/versioned/typed/network/v1"
	openshiftprojectv1 "github.com/openshift/client-go/project/clientset/versioned/typed/project/v1"
	openshiftroutev1 "github.com/openshift/client-go/route/clientset/versioned/typed/route/v1"
	openshiftsecuritycontextconstraintsv1 "github.com/openshift/client-go/security/clientset/versioned/typed/security/v1"
	monitoringv1 "github.com/prometheus-operator/prometheus-operator/pkg/client/versioned/typed/monitoring/v1"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/discovery"
	diskcached "k8s.io/client-go/discovery/cached/disk"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/metadata"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
	"k8s.io/client-go/util/homedir"
	"k8s.io/kubectl/pkg/util/openapi"
	openapivalidation "k8s.io/kubectl/pkg/util/openapi/validation"
	"k8s.io/kubectl/pkg/validation"
)

// Interface defines the external client interface for kubernetes and openshift cluster.
type Interface interface {
	kubernetes.Interface
	dynamic.Interface
	Metadata() metadata.Interface
	OpenshiftProjectV1() openshiftprojectv1.ProjectV1Interface
	OpenshiftAppsV1() openshiftappsv1.AppsV1Interface
	OpenshiftRouteV1() openshiftroutev1.RouteV1Interface
	OpenshiftImageV1() openshiftimagev1.ImageV1Interface
	OpenshiftNetNamespaceV1() openshiftnetworkv1.NetNamespaceInterface
	OpenshiftHostSubnetV1() openshiftnetworkv1.HostSubnetInterface
	OpenshiftSecurityV1() openshiftsecuritycontextconstraintsv1.SecurityV1Interface
	ClientConfig() *rest.Config
	ClusterVersion(string) (*Version, error) // 获取集群的版本信息
	CachedDiscoveryInterface() discovery.CachedDiscoveryInterface
	MonitoringV1() monitoringv1.MonitoringV1Interface
	Validator(validate bool) (validation.Schema, error)
}

// make sure that a Clientset instance implement the interface.
var _ = Interface(&Clientset{})

// Clientset contains the clients for groups. Each group has exactly one
// version included in a Clientset.
type Clientset struct {
	config *rest.Config
	*kubernetes.Clientset
	dynamicClient           dynamic.Interface
	appsV1                  *openshiftappsv1.AppsV1Client
	routeV1                 *openshiftroutev1.RouteV1Client
	imageV1                 *openshiftimagev1.ImageV1Client
	projectV1               *openshiftprojectv1.ProjectV1Client
	securityV1              *openshiftsecuritycontextconstraintsv1.SecurityV1Client
	hostsubnetV1            openshiftnetworkv1.HostSubnetInterface
	netnamespaceV1          openshiftnetworkv1.NetNamespaceInterface
	metadata                metadata.Interface
	monitoringV1            monitoringv1.MonitoringV1Interface
	cachableDiscoveryClient discovery.CachedDiscoveryInterface

	// openAPIGetter loads and caches openapi specs
	openAPIGetter openAPIGetter
}

type openAPIGetter struct {
	once sync.Once
	//getter openapi.Getter
}

// OpenshiftProjectV1 retrieves the ProjectV1Interface for openshift
func (c *Clientset) OpenshiftProjectV1() openshiftprojectv1.ProjectV1Interface {
	return c.projectV1
}

// OpenshiftAppsV1 retrieves the AppsV1Interface for openshift
func (c *Clientset) OpenshiftAppsV1() openshiftappsv1.AppsV1Interface {
	return c.appsV1
}

// openshiftnetworkv1 retrieves the NetNamespaceInterface for openshift
func (c *Clientset) OpenshiftNetNamespaceV1() openshiftnetworkv1.NetNamespaceInterface {
	return c.netnamespaceV1
}

// openshiftnetworkv1 retrieves the HostSubnetInterface for openshift
func (c *Clientset) OpenshiftHostSubnetV1() openshiftnetworkv1.HostSubnetInterface {
	return c.hostsubnetV1
}

// OpenshiftImageV1 retrieves the OpenshiftImageV1 for openshift
func (c *Clientset) OpenshiftImageV1() openshiftimagev1.ImageV1Interface {
	return c.imageV1
}

// OpenshiftRouteV1 retrieves the RouteV1Interface for openshift
func (c *Clientset) OpenshiftRouteV1() openshiftroutev1.RouteV1Interface {
	return c.routeV1
}

// OpenshiftSecurityV1 retrieves the SecurityV1Interface for openshift
func (c *Clientset) OpenshiftSecurityV1() openshiftsecuritycontextconstraintsv1.SecurityV1Interface {
	return c.securityV1
}

// Metadata return metadata client
func (c *Clientset) Metadata() metadata.Interface {
	return c.metadata
}

// Resource implement kuberentes dynamic interface
func (c *Clientset) Resource(resource schema.GroupVersionResource) dynamic.NamespaceableResourceInterface {
	return c.dynamicClient.Resource(resource)
}

// CachedDiscoveryInterface returns a CachedDiscoveryInterface using a computed RESTConfig.
func (c *Clientset) CachedDiscoveryInterface() discovery.CachedDiscoveryInterface {
	return c.cachableDiscoveryClient
}

// MonitoringV1 retrieves the MonitoringV1Interface for prometheus-operator
func (c *Clientset) MonitoringV1() monitoringv1.MonitoringV1Interface {
	return c.monitoringV1
}

func (c *Clientset) Validator(validate bool) (validation.Schema, error) {
	if !validate {
		return validation.NullSchema{}, nil
	}

	resources, err := c.OpenAPISchema()
	if err != nil {
		return nil, err
	}

	return validation.ConjunctiveSchema{
		openapivalidation.NewSchemaValidation(resources),
		validation.NoDoubleKeySchema{},
	}, nil
}

// OpenAPISchema returns metadata and structural information about Kubernetes object definitions.
func (c *Clientset) OpenAPISchema() (openapi.Resources, error) {
	// Lazily initialize the OpenAPIGetter once
	//c.openAPIGetter.once.Do(func() {
	//	// Create the caching OpenAPIGetter
	//	c.openAPIGetter.getter = openapi.NewOpenAPIGetter(c.cachableDiscoveryClient)
	//})
	//
	//// Delegate to the OpenAPIGetter
	//return c.openAPIGetter.getter.Get()
	return nil, nil
}

// ClientConfig returns a complete client config
func (c *Clientset) ClientConfig() *rest.Config {
	if c == nil {
		return nil
	}
	return c.config
}

// NewForConfig creates a new Clientset for the given config.
func NewForConfig(c *rest.Config) (*Clientset, error) {
	var sc Clientset
	var err error

	sc.config = c

	sc.Clientset, err = kubernetes.NewForConfig(c)
	if err != nil {
		return nil, err
	}
	sc.metadata, err = metadata.NewForConfig(c)
	if err != nil {
		return nil, err
	}
	sc.dynamicClient, err = dynamic.NewForConfig(c)
	if err != nil {
		return nil, err
	}
	sc.projectV1, err = openshiftprojectv1.NewForConfig(c)
	if err != nil {
		return nil, err
	}
	sc.appsV1, err = openshiftappsv1.NewForConfig(c)
	if err != nil {
		return nil, err
	}
	sc.routeV1, err = openshiftroutev1.NewForConfig(c)
	if err != nil {
		return nil, err
	}
	sc.imageV1, err = openshiftimagev1.NewForConfig(c)
	if err != nil {
		return nil, err
	}
	sc.securityV1, err = openshiftsecuritycontextconstraintsv1.NewForConfig(c)
	if err != nil {
		return nil, err
	}

	openshiftnetworkclientsetv1, err := openshiftnetworkclientsetv1.NewForConfig(c)
	if err != nil {
		return nil, err
	}
	sc.netnamespaceV1 = openshiftnetworkclientsetv1.NetworkV1().NetNamespaces()
	sc.hostsubnetV1 = openshiftnetworkclientsetv1.NetworkV1().HostSubnets()

	mclient, err := monitoringv1.NewForConfig(c)
	if err != nil {
		return nil, err
	}
	sc.monitoringV1 = mclient

	config := *c
	// The more groups you have, the more discovery requests you need to make.
	// given 25 groups (our groups + a few custom resources) with one-ish version each, discovery needs to make 50 requests
	// double it just so we don't end up here again for a while.  This config is only used for discovery.
	config.Burst = 100

	httpCacheDir := filepath.Join(homedir.HomeDir(), ".kube", "http-cache")
	discoveryCacheDir := computeDiscoverCacheDir(filepath.Join(homedir.HomeDir(), ".kube", "cache", "discovery"), config.Host)
	cachableDiscoveryClient, err := diskcached.NewCachedDiscoveryClientForConfig(&config, discoveryCacheDir, httpCacheDir, time.Duration(10*time.Minute))
	if err != nil {
		return nil, err
	}
	sc.cachableDiscoveryClient = cachableDiscoveryClient

	return &sc, nil
}

func NewRestConfig(server string, caData []byte, certData []byte, keyData []byte) (*rest.Config, error) {
	config := clientcmdapi.Config{
		Preferences: *clientcmdapi.NewPreferences(),
		Clusters: map[string]*clientcmdapi.Cluster{
			"kubernetes": &clientcmdapi.Cluster{
				Server:                   server,
				CertificateAuthorityData: caData,
			},
		},
		AuthInfos: map[string]*clientcmdapi.AuthInfo{
			"kubernetes": &clientcmdapi.AuthInfo{
				ClientCertificateData: certData,
				ClientKeyData:         keyData,
			},
		},
		Contexts: map[string]*clientcmdapi.Context{
			"kubernetes": &clientcmdapi.Context{
				Cluster:  "kubernetes",
				AuthInfo: "kubernetes",
			},
		},
		CurrentContext: "kubernetes",
	}
	return clientcmd.NewNonInteractiveClientConfig(config, config.CurrentContext, &clientcmd.ConfigOverrides{}, nil).ClientConfig()
}

// overlyCautiousIllegalFileCharacters matches characters that *might* not be supported.  Windows is really restrictive, so this is really restrictive
var overlyCautiousIllegalFileCharacters = regexp.MustCompile(`[^(\w/\.)]`)

// computeDiscoverCacheDir takes the parentDir and the host and comes up with a "usually non-colliding" name.
func computeDiscoverCacheDir(parentDir, host string) string {
	// strip the optional scheme from host if its there:
	schemelessHost := strings.Replace(strings.Replace(host, "https://", "", 1), "http://", "", 1)
	// now do a simple collapse of non-AZ09 characters.  Collisions are possible but unlikely.  Even if we do collide the problem is short lived
	safeHost := overlyCautiousIllegalFileCharacters.ReplaceAllString(schemelessHost, "_")
	return filepath.Join(parentDir, safeHost)
}
