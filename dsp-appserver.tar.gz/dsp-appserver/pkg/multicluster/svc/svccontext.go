package svc

import (
	"github.com/daocloud/dsp-appserver/pkg/config"
	"github.com/daocloud/dsp-appserver/pkg/database"
	"github.com/daocloud/dsp-appserver/pkg/model/zone"
)

// 使用同 gozero,业务层直接调用svc层，svc可以互相调用
type ServiceContext struct {
	Config *config.DBConfig
	Model  zone.TiZoneModel
}

func NewServiceContext(c *config.DBConfig) (*ServiceContext, error) {
	var zoneModel zone.TiZoneModel
	if c.Type == config.DbDMType {
		zoneModel = zone.NewTiZoneDmModel(c)
	} else {
		db, err := database.NewDB(c)
		if err != nil {
			return nil, err
		}
		zoneModel = zone.NewTiZoneModel(db)
	}
	return &ServiceContext{
		Config: c,
		Model:  zoneModel,
	}, nil

}
