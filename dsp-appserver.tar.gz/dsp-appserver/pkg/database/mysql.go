package database

import (
	"database/sql"
	"fmt"

	_ "github.com/go-sql-driver/mysql"

	"github.com/daocloud/dsp-appserver/pkg/config"
)

func NewDB(confD *config.DBConfig) (*sql.DB, error) {
	dbConfig := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		confD.User,
		confD.Password,
		confD.Host,
		confD.Port,
		confD.Name)

	db, err := sql.Open("mysql", dbConfig)
	if err != nil {
		return nil, err
	}
	return db, nil
}
