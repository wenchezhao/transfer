package database

import (
	"database/sql"
	"fmt"

	_ "gitee.com/chunanyong/dm"

	"github.com/daocloud/dsp-appserver/pkg/config"
)

func NewDmDB(conf *config.DBConfig) (*sql.DB, error) {
	var db *sql.DB
	var err error
	dataSourceName := fmt.Sprintf("dm://%s:%s@%s:%s", conf.User, conf.Password, conf.Host, conf.Port)
	if db, err = sql.Open("dm", dataSourceName); err != nil {
		return nil, err
	}
	if err = db.Ping(); err != nil {
		return nil, err
	}
	return db, nil
}
