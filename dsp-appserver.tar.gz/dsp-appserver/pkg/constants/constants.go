/*
Copyright 2022 The Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package constants

import (
	"strings"

	metallb "go.universe.tf/metallb/api/v1beta1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime/schema"
	vpav1 "k8s.io/autoscaler/vertical-pod-autoscaler/pkg/apis/autoscaling.k8s.io/v1"
)

const (
	KpandaRBACFinalizer    = "kpanda.io/rbac-controller"
	ControllerLabelKey     = "node-role.kubernetes.io/control-plane"
	MasterLabelKey         = "node-role.kubernetes.io/master"
	WorkerLabelKey         = "node-role.kubernetes.io/worker"
	NodeSchedulingDisabled = "SchedulingDisabled"

	ManagedByLabelKey = "kpanda.io/managed-by"

	WorkspaceLabelKey = "kpanda.io/workspace"

	GlobalCluster         = "kpanda-global-cluster"
	GlobalClusterProvider = "DAOCLOUD_KUBESPRAY"
	KpandaSystem          = "kpanda-system"
	KubeSystem            = "kube-system"
	InsightSystem         = "insight-system"
	MspiderSystem         = "mspider-system"
	Kubernetes            = "kubernetes"
	KangarooMenus         = "kangaroo-menus"
	DCEComponentKpanda    = "kpanda"
	DCEComponentInsight   = "insight"
	DCEComponentMspider   = "mspider"

	ExclusiveNamespaceNodeLabelKey = "node.kpanda.io/exclusive-namespace"
	ExclusiveNamespaceTaintKey     = "ExclusiveNamespace"

	// NSDefaultTolerations is the annotation key for default tolerations.
	// More info: https://github.com/kubernetes/kubernetes/blob/master/plugin/pkg/admission/podtolerationrestriction/admission.go
	NSDefaultTolerations string = "scheduler.alpha.kubernetes.io/defaultTolerations"

	// NamespaceNodeSelector is for assigning node selectors labels to
	// namespaces. Default value is the annotation key
	// scheduler.alpha.kubernetes.io/node-selector.
	NamespaceNodeSelector = "scheduler.alpha.kubernetes.io/node-selector"

	OtelAgentAddrENV = "OTEL_EXPORTER_OTLP_ENDPOINT"

	// CustomAnnotationKey defines the custom annotation keys to cluster.
	CustomAnnotationKey = "kpanda.io/custom-annotation-keys"

	// CustomLabelKey defines the custom label keys to cluster.
	CustomLabelKey = "kpanda.io/custom-label-keys"

	// CustomParamKey defines the custom param keys to cluster.
	CustomParamKey = "kpanda.io/custom-param-keys"

	// UnifiedPasswordLabelKey defines the flag whether use the unity user info.
	UnifiedPasswordLabelKey = "kpanda.io/unity-password"

	// DisableFirewallLabelKey defines the flag whether disable firewall.
	DisableFirewallLabelKey = "kpanda.io/disable-firewall"
	// EnableVerboseloggingKey defines the flag whether enable verboselogging.
	EnableVerboseloggingKey = "kpanda.io/enable-verboselogging"
	// ShareSCNamespaceKey record the namespaces of the shared sc.
	ShareSCNamespaceKey = "kubernetes.io/share-namespaces"
)

// pod resource type.
const (
	RestartCount  = "restartCount"
	CPURequest    = "cpuRequest"
	CPULimit      = "cpuLimit"
	MemoryRequest = "memoryRequest"
	MemoryLimit   = "memoryLimit"
)

// k8s workLoad resource type.
const (
	Pods         = "pods"
	Deployments  = "deployments"
	DaemonSets   = "daemonsets"
	StatefulSets = "statefulsets"
	Jobs         = "jobs"
	CronJobs     = "cronjobs"
	ReplicaSets  = "replicasets"
)

type WorkloadState string

const (
	WorkloadRunning  WorkloadState = "Running"
	WorkloadDeleting WorkloadState = "Deleting"
	// WorkloadNotReady add _ to ease convert to frontend enum .
	WorkloadNotReady WorkloadState = "Not_Ready"
	WorkloadUnknown  WorkloadState = "Unknown"
	WorkloadStopped  WorkloadState = "Stopped"
	WorkloadWaiting  WorkloadState = "Waiting"
)

type ClusterRole string

// clusterRole.
const (
	ClusterRoleLabel         = "cluster-role.kpanda.io"
	ClusterRoleLabelTemplate = "cluster-role.kpanda.io/%s"

	ClusterRoleUnknown       ClusterRole = "unknown"
	ClusterRoleManager       ClusterRole = "manager"
	ClusterRoleGlobalService ClusterRole = "global-service"
	ClusterRoleWorker        ClusterRole = "worker"
	ClusterRoleThirdParty    ClusterRole = "third-party"
)

const (
	WorkloadSnapshotAnnotationLastRestartTimestamp = "workload.kpanda.io/last-restart-timestamp"
	WorkloadLastReplicasAnnoKey                    = "workload.kpanda.io/last-replicas"
	WorkloadAnnotationChangeCause                  = "kubernetes.io/change-cause"
	WorkloadAnnotationRevision                     = "deployment.kubernetes.io/revision"
	JobRevisionsAnnotationKey                      = "revisions"

	DaemonsetGenerationRevisionAnnation = "deprecated.daemonset.template.generation"
)

const (
	ClusterPediaShadowClusterAnnotation = "shadow.clusterpedia.io/cluster-name"
)

const (
	AliasNameAnnotation = "kpanda.io/alias-name"
)

type RBACSourceReference string

const (
	RBACSourceReferenceUI      RBACSourceReference = "ui"
	RBACSourceReferenceBuiltin RBACSourceReference = "built-in"
	RBACSourceReferenceGhippo  RBACSourceReference = "ghippo"
	RBACSourceReferenceOthers  RBACSourceReference = "others"

	RBACSourceLabel = "rbac.kpanda.io/source"

	ClusterAdminRole   = "role-template-cluster-admin"
	ClusterRoleBinding = "ClusterRoleBinding"
)

type RBACSourceKind string

const (
	RBACKindWorkspace        RBACSourceKind = "workspace"
	RBACKindGlobalRole       RBACSourceKind = "global-role"
	RBACKindKarshipWorkspace RBACSourceKind = "karship-workspace"

	RBACKindLabel = "rbac.kpanda.io/kind"

	RBACDigestLabel = "rbac.kpanda.io/digest"
)

const (
	IamRoleTemplatePrefix = "role-template-"

	IamRoleBindingTemplatePrefix        = "rolebinding-template-"
	IamClusterRoleBindingTemplatePrefix = "clusterrolebinding-template-"
)

const (
	OrderByDesc = "desc"
	OrderByAsc  = "asc"
)

// KubeConfTemplate kubeConfig as X509 certs.
var KubeConfTemplate = strings.TrimSpace(`
apiVersion: v1
kind: Config
clusters:
- cluster:
    certificate-authority-data: %s 
    server: %s 
  name: %q
contexts:
- context:
    cluster: %q
    user: %q
  name: %q
current-context: %q
users:
- name: %q
  user:
    client-certificate-data: %s
    client-key-data: %s 
`)

// KubeConfigDefaultTokenTemplate kubeConfig as service account token.
var KubeConfigDefaultTokenTemplate = strings.TrimSpace(`
apiVersion: v1
kind: Config
clusters:
- name: kpanda-cluster
  cluster:
    certificate-authority-data: %s
    server: %s
contexts:
- name: kpanda-cluster
  context:
    cluster: kpanda-cluster
    user: kpanda-cluster
current-context: kpanda-cluster
users:
- name: kpanda-cluster
  user:
    token: %s
`)

// KubeConfigTemplateToken kubeConfig template as join or update cluster.
var KubeConfigTemplateToken = strings.TrimSpace(`
apiVersion: v1
kind: Config
clusters:
- name: %s
  cluster:
    certificate-authority-data: %s
    server: %s
contexts:
- name: %q
  context:
    cluster: %q
    user: %q
current-context: %q
users:
- name: %q
  user:
    token: %s
`)

// KubeConfDefaultWithoutTLSVerifyTemplate kubeConfig as X509 certs.
var KubeConfDefaultWithoutTLSVerifyTemplate = strings.TrimSpace(`
apiVersion: v1
kind: Config
clusters:
- cluster:
    insecure-skip-tls-verify: true 
    server: %s 					
  name: %q							
contexts:
- context:
    cluster: %q				
    user: %q			    			
  name: %q							
current-context: %q			
users:
- name: %q				    
  user:
    client-certificate-data: %s
    client-key-data: %s 
`)

// KubeConfTemplateWithoutTLSVerify kubeConfig as X509 certs.
var KubeConfTemplateWithoutTLSVerify = strings.TrimSpace(`
apiVersion: v1
kind: Config
clusters:
- cluster:
    insecure-skip-tls-verify: true 
    server: %s 
  name: %q 
contexts:
- context:
    cluster: %q
    user: %q
  name: %q
current-context: %q
users:
- name: %q
  user:
    client-certificate-data: %s
    client-key-data: %s 
`)

var KubeConfTemplateTokenWithoutTLSVerify = strings.TrimSpace(`
apiVersion: v1
kind: Config
clusters:
- cluster:
    insecure-skip-tls-verify: true 
    server: %s 
  name: %q
contexts:
- context:
    cluster: %q
    user: %q
  name: %q
current-context: %q
users:
- name: %q
  user:
    token: %s
`)

type LoadResourceSchema string

const (
	LoadResourceSchemaKey LoadResourceSchema = "schema"
)

const (
	ClusterPedia  LoadResourceSchema = "pedia"
	MemberCluster LoadResourceSchema = "member"
)

var (
	CustomResourceDefinitionGVR = schema.GroupVersionResource{Version: "v1", Resource: "customresourcedefinitions", Group: "apiextensions.k8s.io"}
	VolumeSnapshotsGVR          = schema.GroupVersionResource{Version: "v1", Resource: "volumesnapshots", Group: "snapshot.storage.k8s.io"}
	MetaLlbGVR                  = metallb.GroupVersion.WithResource("ipaddresspools")
	VPAGVR                      = vpav1.SchemeGroupVersion.WithResource("verticalpodautoscalers")
	GlobalMeshGroup             = "discovery.mspider.io"
	GlobalMeshVersion           = "v3alpha1"
	GlobalMeshResource          = "globalmeshes"
)

var BuiltInRoleTemplate = `---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  annotations:
    kpanda.io/creator: system
  labels:
    rbac.kpanda.io/source:  "built-in"
  finalizers:
    - kpanda.io/bindings-syncer-controller
  name: role-template-cluster-admin
rules:
  - apiGroups:
      - '*'
    resources:
      - '*'
    verbs:
      - '*'
  - nonResourceURLs:
      - '*'
    verbs:
      - '*'
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  annotations:
    kpanda.io/creator: system
  labels:
    rbac.kpanda.io/source:  "built-in"
  finalizers:
    - kpanda.io/bindings-syncer-controller
  name: role-template-cluster-edit
rules:
  - apiGroups:
      - '*'
    resources:
      - '*'
    verbs:
      - get
      - list
      - watch
  - nonResourceURLs:
      - '*'
    verbs:
      - get
      - list
      - watch
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  annotations:
    kpanda.io/creator: system
  labels:
    rbac.kpanda.io/source:  "built-in"
  finalizers:
    - kpanda.io/bindings-syncer-controller
  name: role-template-cluster-view
rules:
  - apiGroups:
      - '*'
    resources:
      - '*'
    verbs:
      - get
      - list
      - watch
  - nonResourceURLs:
      - '*'
    verbs:
      - get
      - list
      - watch
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  annotations:
    kpanda.io/creator: system
  labels:
    rbac.kpanda.io/source:  "built-in"
  finalizers:
    - kpanda.io/bindings-syncer-controller
  name: kpanda-admin
rules:
  - apiGroups:
      - '*'
    resources:
      - '*'
    verbs:
      - '*'
  - nonResourceURLs:
      - '*'
    verbs:
      - '*'
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  annotations:
    kpanda.io/creator: system
  labels:
    rbac.kpanda.io/source:  "built-in"
  finalizers:
    - kpanda.io/bindings-syncer-controller
  name: role-template-ns-admin
rules:
- apiGroups:
  - ""
  resources:
  - configmaps
  - secrets
  - endpoints
  - persistentvolumeclaims
  - persistentvolumeclaims/status
  - pods
  - pods/exec
  - replicationcontrollers
  - replicationcontrollers/scale
  - serviceaccounts
  - services
  - services/status
  - users
  - resources
  verbs:
  - '*'
- apiGroups:
  - ""
  resources:
  - bindings
  - events
  - pods/log
  - pods/status
  - replicationcontrollers/status
  verbs:
  - '*'
- apiGroups:
  - apps
  resources:
  - controllerrevisions
  - daemonsets
  - daemonsets/status
  - deployments
  - deployments/scale
  - deployments/status
  - replicasets
  - replicasets/scale
  - replicasets/status
  - statefulsets
  - statefulsets/scale
  - statefulsets/status
  verbs:
  - '*'
- apiGroups:
  - autoscaling
  resources:
  - horizontalpodautoscalers
  - horizontalpodautoscalers/status
  - metricvalues
  - custommetricsummary
  verbs:
  - '*'
- apiGroups:
  - batch
  resources:
  - cronjobs
  - cronjobs/status
  - jobs
  - jobs/status
  verbs:
  - '*'
- apiGroups:
  - extensions
  resources:
  - daemonsets
  - daemonsets/status
  - deployments
  - deployments/scale
  - deployments/status
  - ingresses
  - ingresses/status
  - networkpolicies
  - replicasets
  - replicasets/scale
  - replicasets/status
  - replicationcontrollers/scale
  verbs:
  - '*'
- apiGroups:
  - policy
  resources:
  - poddisruptionbudgets
  - poddisruptionbudgets/status
  verbs:
  - '*'
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses
  - ingresses/status
  - networkpolicies
  - ingressclasssummary
  - metallb
  - ippools
  verbs:
  - '*'
- apiGroups:
  - rbac.authorization.k8s.io
  resources:
  - rolebindings
  - roles
  verbs:
  - '*'
- apiGroups:
  - cluster.kpanda.io
  resources:
  - clusters
  verbs:
  - list
  - get
- apiGroups:
  - helm.kpanda.io
  resources:
  - helmrepos/helmcharts
  - helmrepos
  - helmcharts
  verbs:
  - list
  - get
- apiGroups:
  - helm.kpanda.io
  resources:
  - helmreleases
  - helmreleases/resources
  verbs:
  - '*'
- apiGroups:
  - helm.kpanda.io
  resources:
  - helmoperations
  - helmoperations/status
  verbs:
  - '*'
- apiGroups:
  - ""
  resources:
  - resourcequotas
  - limitranges
  - resourcequotas/status
  - namespaces
  - namespaces/status
  - nodes
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - autoscaling.alibabacloud.com
  resources:
  - cronhorizontalpodautoscalers
  verbs:
  - '*'
- apiGroups:
  - autoscaling.k8s.io
  resources:
  - verticalpodautoscalers
  verbs:
  - '*'
- apiGroups:
  - snapshot.storage.k8s.io
  resources:
  - volumesnapshots
  verbs:
  - '*'
- apiGroups:
  - storage.k8s.io
  resources:
  - storageclasses
  verbs:
  - list
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  annotations:
    kpanda.io/creator: system
  labels:
    rbac.kpanda.io/source:  "built-in"
  finalizers:
    - kpanda.io/bindings-syncer-controller
  name: role-template-ns-edit
rules:
- apiGroups:
  - ""
  resources:
  - configmaps
  - secrets
  - endpoints
  - persistentvolumeclaims
  - persistentvolumeclaims/status
  - pods
  - pods/exec
  - replicationcontrollers
  - replicationcontrollers/scale
  - serviceaccounts
  - services
  - services/status
  - resources
  verbs:
  - '*'
- apiGroups:
  - ""
  resources:
  - bindings
  - events
  - pods/log
  - pods/status
  - replicationcontrollers/status
  verbs:
  - '*'
- apiGroups:
  - apps
  resources:
  - controllerrevisions
  - daemonsets
  - daemonsets/status
  - deployments
  - deployments/scale
  - deployments/status
  - replicasets
  - replicasets/scale
  - replicasets/status
  - statefulsets
  - statefulsets/scale
  - statefulsets/status
  verbs:
  - '*'
- apiGroups:
  - autoscaling
  resources:
  - horizontalpodautoscalers
  - horizontalpodautoscalers/status
  - metricvalues
  - custommetricsummary
  verbs:
  - '*'
- apiGroups:
  - batch
  resources:
  - cronjobs
  - cronjobs/status
  - jobs
  - jobs/status
  verbs:
  - '*'
- apiGroups:
  - extensions
  resources:
  - daemonsets
  - daemonsets/status
  - deployments
  - deployments/scale
  - deployments/status
  - ingresses
  - ingresses/status
  - networkpolicies
  - replicasets
  - replicasets/scale
  - replicasets/status
  - replicationcontrollers/scale
  verbs:
  - '*'
- apiGroups:
  - policy
  resources:
  - poddisruptionbudgets
  - poddisruptionbudgets/status
  verbs:
  - '*'
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses
  - ingresses/status
  - networkpolicies
  - ingressclasssummary
  - metallb
  - ippools
  verbs:
  - '*'
- apiGroups:
  - cluster.kpanda.io
  resources:
  - clusters
  verbs:
  - list
  - get
- apiGroups:
  - helm.kpanda.io
  resources:
  - helmrepos/helmcharts
  - helmrepos
  - helmcharts
  verbs:
  - list
  - get
- apiGroups:
  - helm.kpanda.io
  resources:
  - helmreleases
  - helmreleases/resources
  verbs:
  - '*'
- apiGroups:
  - helm.kpanda.io
  resources:
  - helmoperations
  - helmoperations/status
  verbs:
  - '*'
- apiGroups:
  - ""
  resources:
  - limitranges
  - resourcequotas
  - resourcequotas/status
  - namespaces
  - namespaces/status
  - nodes
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - autoscaling.alibabacloud.com
  resources:
  - cronhorizontalpodautoscalers
  verbs:
  - '*'
- apiGroups:
  - autoscaling.k8s.io
  resources:
  - verticalpodautoscalers
  verbs:
  - '*'
- apiGroups:
  - snapshot.storage.k8s.io
  resources:
  - volumesnapshots
  verbs:
  - '*'
- apiGroups:
  - storage.k8s.io
  resources:
  - storageclasses
  verbs:
  - list
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  annotations:
    kpanda.io/creator: system
  labels:
    rbac.kpanda.io/source:  "built-in"
  finalizers:
    - kpanda.io/bindings-syncer-controller
  name: role-template-ns-view
rules:
- apiGroups:
  - ""
  resources:
  - configmaps
  - endpoints
  - persistentvolumeclaims
  - persistentvolumeclaims/status
  - pods
  - replicationcontrollers
  - replicationcontrollers/scale
  - serviceaccounts
  - services
  - services/status
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - ""
  resources:
  - bindings
  - events
  - pods/log
  - pods/status
  - replicationcontrollers/status
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - ""
  resources:
  - secrets
  verbs:
  - list
- apiGroups:
  - apps
  resources:
  - controllerrevisions
  - daemonsets
  - daemonsets/status
  - deployments
  - deployments/scale
  - deployments/status
  - replicasets
  - replicasets/scale
  - replicasets/status
  - statefulsets
  - statefulsets/scale
  - statefulsets/status
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - autoscaling
  resources:
  - horizontalpodautoscalers
  - horizontalpodautoscalers/status
  - metricvalues
  - custommetricsummary
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - batch
  resources:
  - cronjobs
  - cronjobs/status
  - jobs
  - jobs/status
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - extensions
  resources:
  - daemonsets
  - daemonsets/status
  - deployments
  - deployments/scale
  - deployments/status
  - ingresses
  - ingresses/status
  - networkpolicies
  - replicasets
  - replicasets/scale
  - replicasets/status
  - replicationcontrollers/scale
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - policy
  resources:
  - poddisruptionbudgets
  - poddisruptionbudgets/status
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses
  - ingresses/status
  - networkpolicies
  - ingressclasssummary
  - metallb
  - ippools
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - cluster.kpanda.io
  resources:
  - clusters
  verbs:
  - list
  - get
- apiGroups:
  - helm.kpanda.io
  resources:
  - helmrepos/helmcharts
  - helmrepos
  - helmcharts
  verbs:
  - list
  - get
- apiGroups:
  - helm.kpanda.io
  resources:
  - helmreleases
  - helmreleases/resources
  verbs:
  - list
  - get
  - watch
- apiGroups:
  - helm.kpanda.io
  resources:
  - helmoperations
  verbs:
  - list
  - get
  - watch
- apiGroups:
  - ""
  resources:
  - limitranges
  - resourcequotas
  - resourcequotas/status
  - namespaces
  - namespaces/status
  - nodes
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - autoscaling.alibabacloud.com
  resources:
  - cronhorizontalpodautoscalers
  verbs:
  - get
  - list
- apiGroups:
  - autoscaling.k8s.io
  resources:
  - verticalpodautoscalers
  verbs:
  - get
  - list
- apiGroups:
  - snapshot.storage.k8s.io
  resources:
  - volumesnapshots
  verbs:
  - get
  - list
- apiGroups:
  - storage.k8s.io
  resources:
  - storageclasses
  verbs:
  - list
`

var BuiltInClusterRoleBindingTemplate = `---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  annotations:
    kpanda.io/creator: system
  labels:
    rbac.kpanda.io/source: "built-in"
  finalizers:
    - kpanda.io/bindings-syncer-controller
  name: kpanda-admin-%s
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: kpanda-admin
subjects:
- kind: User
  name: kpanda-admin-%s`

const (
	BuiltInAdminName = "kpanda-admin-%s"
)

const (
	KindDeployment                  string = "Deployment"
	KindStatefulset                 string = "StatefulSet"
	KindDaemonset                   string = "DaemonSet"
	KindPod                         string = "Pod"
	KindService                     string = "Service"
	KindIngress                     string = "Ingress"
	KindJob                         string = "Job"
	KindCronJob                     string = "CronJob"
	KindReplicaSet                  string = "ReplicaSet"
	KindNetworkPolicy               string = "NetworkPolicy"
	KindHorizontalPodAutoscaler     string = "HorizontalPodAutoscaler"
	KindCronHorizontalPodAutoscaler string = "CronHPA"
	KindPersistentVolumeClaim       string = "PersistentVolumeClaim"
	KindGroupVersionResource        string = "GroupVersionResource"
)

const (
	WorkspaceIDLabelKey       string = "workspace.ghippo.io/id"
	WorkspaceAliasAnnotations string = "workspace.ghippo.io/alias"
)

type HelmReleaseSource string

type HelmReleaseDriver string

const (
	RepositoryNextAnnotations string = "helmrepo.kpanda.io/next"
	RepositorySizeAnnotations string = "helmrepo.kpanda.io/size"

	RepositoryDescription    string = "helmrepo.kpanda.io/description"
	RepositoryBuiltIn        string = "helmrepo.kpanda.io/built-in"
	RepositoryBuiltInCluster string = "helmrepo.kpanda.io/built-in-cluster"
	HelmChartRequiredAnnoKey string = "addon.kpanda.io/required"

	HelmOperationPrefix                  string = "helm-operation-"
	HelmOperationInstallPrefix           string = "helm-operation-install-"
	HelmOperationUninstallPrefix         string = "helm-operation-uninstall-"
	HelmOperationJobDefaultTimeoutSecond        = int64(1800)
	HelmOperationJobCPURequests          string = "100m"
	HelmOperationJobCPULimits            string = "100m"
	HelmOperationJobMemoryRequests       string = "400Mi"
	HelmOperationJobMemoryLimits         string = "400Mi"

	HelmReleaseDefaultName      string            = "addon.kpanda.io/release-name"
	HelmReleaseDefaultNamespace string            = "addon.kpanda.io/namespace"
	HelmReleaseNameAnnoKey      string            = "meta.helm.sh/release-name"
	HelmReleaseNamespaceAnnoKey string            = "meta.helm.sh/release-namespace"
	HelmManagedLabelKey         string            = "app.kubernetes.io/managed-by"
	HelmManagedLabelValue       string            = "Helm"
	HelmRepoAnnoKey             string            = "addon.kpanda.io/repo"
	HelmReleaseSourceAnnoKey    string            = "addon.kpanda.io/source"
	HelmReleaseSourceAddon      HelmReleaseSource = "addon"
	HelmReleaseSourceAppStore   HelmReleaseSource = "app-store"
	HelmReleaseSourceOthers     HelmReleaseSource = "others"
	HelmReleaseDriverAnnoKey    string            = "addon.kpanda.io/driver"
	HelmReleaseDriverSecret     HelmReleaseDriver = "secret"
	HelmReleaseDriverConfigMap  HelmReleaseDriver = "configmap"

	HelmReleaseResourcesSyncedReason  = "ResourcesHasBeenSynced"
	HelmReleaseUpdatedFailedReason    = "HelmReleaseUpdatedFailed"
	HelmReleaseResourcesSyncedMessage = "related resources has been synced to the helmrelease"

	SelectAddonConfigMapLabel  string = "addon.kpanda.io/init-cluster"
	SelectAddonConfigMapSuffix string = "-addon-config"
)

const (
	// GlobalRoleNameTemplate is the format of clusterRoleBinding name, it's format is
	// kpanda-memberType-userName-globalRole.
	GlobalRoleNameTemplate string = "kpanda-%s-%s-%s"

	// WorkspaceRoleNameTemplate is the format of Binding name, it's format is
	// kpanda-workspaceID-admin-workspace.
	WorkspaceRoleNameTemplate string = "kpanda-%d-%s-workspace"

	KarshipWorkspaceRoleNameTemplate string = "karship-%d-%s-workspace"

	ClusterGlobalRoleInitAnnoKey = "kpanda.io/global-role-bootstrapping"

	// InsightAgentDeployedLabelKey will be labeled on cluster if cluster installed insight-agent.
	InsightAgentDeployedLabelKey = "addon.kpanda.io/insight-agent"
)

const (
	AllowVolumeExpansion string = "storageclass.kpanda.io/allow-volume-expansion"
	SupportSnapshot      string = "storageclass.kpanda.io/support-snapshot"
	True                 string = "true"
)

const (
	KpandaQuota string = "quota"
)

type ClusterLCMAction string

const (
	ClusterLCMActionAnno string = "cluster-lcm.kpanda.io/action"

	// This annotation will be used to record the clusterlcm trigger time.
	// The format of it is RFC3339 such as "2006-01-02T15:04:05Z07:00".
	ClusterLCMLastChangeTriggerTimeAnno string = "cluster-lcm.kpanda.io/last-change-trigger-time"

	ClusterLCMClusterUIDAnno string = "cluster-lcm.kpanda.io/cluster-uid"

	ClusterLCMKubernetesVersionAnno string = "clusters-lcm.kpanda.io/kubernetes-version"

	ClusterLCMNodesAnno string = "cluster-lcm.kpanda.io/nodes"

	ClusterLCMActionUpgradeCluster   ClusterLCMAction = "upgrade-cluster"
	ClusterLCMActionCreateCluster    ClusterLCMAction = "create-cluster"
	ClusterLCMActionResetCluster     ClusterLCMAction = "reset-cluster"
	ClusterLCMActionAddWorkerNode    ClusterLCMAction = "add-worker-node"
	ClusterLCMActionCheckNode        ClusterLCMAction = "check-node"
	ClusterLCMActionChePrecheck      ClusterLCMAction = "pre-check"
	ClusterLCMActionRemoveWorkerNode ClusterLCMAction = "remove-worker-node"

	ClusterReadyConditionKey string = "cluster.kpanda.io/ready"
)

const (
	ClusterPediaAPIPath       = "/apis/clusterpedia.io/v1beta1/resources"
	ClusterPediaOriginAPIPath = "/apis/clusterpedia.io/v1beta1"
)

const (
	MatchCNIDaemonSetCilium  = "Cilium"
	MatchCNIDaemonSetAntrea  = "Antrea"
	MatchCNIDaemonSetDanm    = "Danm-cni"
	MatchCNIDaemonSetFabedge = "Fabedge"
	MatchCNIDaemonSetFlannel = "Flannel"
	MatchCNIDaemonSetOvn     = "Kube-ovn"
	MatchCNIDaemonSetRouter  = "Kube-router"
	MatchCNIDaemonSetWeave   = "Weave"
	MatchCNIDaemonSetCalico  = "Calico"
	MatchCNIDaemonSetCanal   = "Canal"
	MatchCNIDaemonSetMultus  = "Multus"
)

type InsightContextKey string

const (
	ClusterContextKey InsightContextKey = "cluster-info"
)

// constant var for EtcdBackupRestore.
const (
	EtcdBackupRestoreScheduleTypeAnnoKey = "etcdbackrestore.kpanda.io/schedule-type"
	NeverScheduleSpec                    = "* * 31 2 *"
)

var SystemNamespaces = []string{metav1.NamespaceDefault, metav1.NamespaceSystem, metav1.NamespacePublic, corev1.NamespaceNodeLease}

const PodSecurityLabelTemplate = "pod-security.kubernetes.io/%s"

var OSFamilyMap = map[string]interface{}{
	"Debian":     nil,
	"RedHat":     nil,
	"Suse":       nil,
	"Archlinux":  nil,
	"Mandrake":   nil,
	"Solaris":    nil,
	"Slackware":  nil,
	"Altlinux":   nil,
	"SMGL":       nil,
	"Gentoo":     nil,
	"Alpine":     nil,
	"AIX":        nil,
	"HP-UX":      nil,
	"Darwin":     nil,
	"FreeBSD":    nil,
	"ClearLinux": nil,
	"DragonFly":  nil,
	"NetBSD":     nil,
}

const (
	MYSQL    string = "mysql"
	Postgres string = "postgres"
)

// configmap constants name.
const (
	// GPUTypeSettingConfigMapName is the name of configmap which stores the kpanda support gpu type.
	GPUTypeSettingConfigMapName = "gpu-type-config"
	// GPUTypeSettingConfigMapDataKey is the key of configmap which stores the kpanda support gpu type.
	GPUTypeSettingConfigMapDataKey = "gpu-type.json"

	GPUTypeMIGName  = "nvidia-mig"
	GPUTypeMIGAlias = "Nvidia MIG"
)
