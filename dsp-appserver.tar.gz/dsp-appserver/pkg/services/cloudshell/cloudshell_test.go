/*
Copyright 2022 Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package cloudshell

import (
	"context"
	"strings"
	"testing"

	cloudshellv1alpha1 "github.com/cloudtty/cloudtty/pkg/apis/cloudshell/v1alpha1"
	cloudshellclientset "github.com/cloudtty/cloudtty/pkg/generated/clientset/versioned/fake"
	"github.com/onsi/gomega"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	clientsetfake "k8s.io/client-go/kubernetes/fake"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	clusterclientsetfake "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/fake"
	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/engine"
)

func Test_CommandBuild(t *testing.T) {
	type fields struct {
		namespace   string
		podName     string
		container   string
		commandType CommandType
		logCount    int32
	}
	tests := []struct {
		name   string
		fields fields
		want   string
	}{
		{
			name: "test bash commandType",
			fields: fields{
				commandType: CommandTypeBash,
			},
			want: "bash",
		},
		{
			name: "test exec commandType",
			fields: fields{
				namespace:   "cloudshell-system",
				podName:     "kpanda-apiserver",
				commandType: CommandTypeExec,
			},
			want: "kubectl exec -it kpanda-apiserver -n cloudshell-system -- sh -c \"bash||sh\"",
		},
		{
			name: "test logs commandType",
			fields: fields{
				namespace:   "cloudshell-system",
				podName:     "kpanda-apiserver",
				commandType: CommandTypeLogs,
				logCount:    500,
			},
			want: "kubectl logs -f --tail 500 kpanda-apiserver -n cloudshell-system",
		},
		{
			name: "test default namespace",
			fields: fields{
				namespace:   "",
				podName:     "kpanda-apiserver",
				commandType: CommandTypeLogs,
			},
			want: "kubectl logs -f --tail 100 kpanda-apiserver",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			command := CommandBuild(tt.fields.namespace, tt.fields.podName, tt.fields.container, tt.fields.logCount, tt.fields.commandType)
			if !strings.EqualFold(command, tt.want) {
				t.Errorf("CommandBuild() want = %v, but = %v", tt.want, command)
			}
		})
	}
}

func Test_CreateCloudshell(t *testing.T) {
	// build fake cloudshell service.
	cloudshellClientset := cloudshellclientset.NewSimpleClientset()
	clusterClientset := clusterclientsetfake.NewSimpleClientset()
	clientset := clientsetfake.NewSimpleClientset()

	kubeclient := kubeclient.NewFakeClientSets(clientset, nil, clusterClientset, "", nil)
	fakeServices := &cloudshellServices{
		cloudshellEngine: engine.NewCloudshellEngine(cloudshellClientset, kubeclient),
	}

	g := gomega.NewGomegaWithT(t)

	// test cloudshellService create cloudshell.
	cloudshell := &cloudshellv1alpha1.CloudShell{
		TypeMeta: metav1.TypeMeta{
			Kind:       "CloudShell",
			APIVersion: "cloudshell.daocloud.io/v1alpha1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "cloudshell-sample",
			Namespace: constants.KpandaSystem,
		},
		Spec: cloudshellv1alpha1.CloudShellSpec{
			RunAsUser:     "root",
			CommandAction: "bash",
			Ttl:           500,
		},
	}
	_, err := cloudshellClientset.CloudshellV1alpha1().CloudShells(constants.KpandaSystem).Create(context.TODO(), cloudshell, metav1.CreateOptions{})
	g.Expect(err).NotTo(gomega.HaveOccurred())

	// test cloudshellService get cloudshell.
	// check if create the configmap.
	_, err = fakeServices.GetCloudshell(context.TODO(), "cloudshell-sample")
	g.Expect(err).NotTo(gomega.HaveOccurred())
}

func TestUserGroupKey(t *testing.T) {
	type args struct {
		cluster string
		user    string
		groups  []string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "test UserGroupKey",
			args: args{
				cluster: "cluster1",
				user:    "admin",
				groups:  []string{"aaa"},
			},
			want: "cluster1:admin-aaa",
		},
	}
	for _, tt := range tests {
		cache := &UserInfo{
			Cluster: &clusterv1alpha1.Cluster{
				ObjectMeta: metav1.ObjectMeta{
					Name: tt.args.cluster,
				},
			},
			UserName: tt.args.user,
			Groups:   tt.args.groups,
		}
		t.Run(tt.name, func(t *testing.T) {
			if got, err := UserGroupKeyFunc(cache); err != nil || got != tt.want {
				t.Errorf("UserGroupKey() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_validateConfig(t *testing.T) {
	const kubeconfig = "YXBpVmVyc2lvbjogdjEKY2x1c3RlcnM6Ci0gY2x1c3RlcjoKICAgIGNlcnRpZmljYXRlLWF1dGhvcml0eS1kYXRhOiBMUzB0TFMxQ1JVZEpUaUJEUlZKVVNVWkpRMEZVUlMwdExTMHRDazFKU1VNMWVrTkRRV01yWjBGM1NVSkJaMGxDUVVSQlRrSm5hM0ZvYTJsSE9YY3dRa0ZSYzBaQlJFRldUVkpOZDBWUldVUldVVkZFUlhkd2NtUlhTbXdLWTIwMWJHUkhWbnBOUWpSWVJGUkplVTFFV1hoT2FrRTBUbFJSTVU1V2IxaEVWRTE1VFVSWmVFMTZRVFJPVkZFeFRsWnZkMFpVUlZSTlFrVkhRVEZWUlFwQmVFMUxZVE5XYVZwWVNuVmFXRkpzWTNwRFEwRlRTWGRFVVZsS1MyOWFTV2gyWTA1QlVVVkNRbEZCUkdkblJWQkJSRU5EUVZGdlEyZG5SVUpCU21ZMUNqVkRUbHBsZEhodlUzRTJNVkJNYURWSk4xTldjVVI1Y1RSS2QyZFhObVY2TjNkUmFGYzVaVVZYU0hCSVoxQTFXRWhyU0dreGVUUmFRVmt2UzAxblJVc0tUMGcyZURsTFNtUkxNVEZUVEZnMk5UZGhMMUJXTVdSaFRtVkJabGs0ZVhkcGN6UnVTMjlUSzFVclRFSjVXbVpZUjBkQ2FVVXdla2RVT1ZsdGVWVnBWZ3BXWW1ScVdrZHhjazFpWXpaUE5WQlJVMGRsT0dWT01YbFpRbW81Y3pjdk5uaHJObkJLU2tWMlIydG1NSGgyUWxKb2JESXlOMjR4WjFkTE9IUnlNVzE0Q2pGT1RtRmpialpYWXpGTWQzZHdNV3BaWlhsV2N6aHNURVpoYlhkSlJYbHRZMlZUV0ZSUFVVY3hiamg2Umsxc00wRkxhRzlFTVdaSVVERjJTR3RpWmswS09VOXJla3M0WmtKWVZVNXNWVXR1TkVwd2JuVjZTbFZDYjFKUU5scExkek5yUXpjeGRrcFJWV2QxVG1ka1YzRkNkSEZUTkhoMk1FRm5TWGd6WlRKMlV3cEhkRFpSWlRZNGNrVjBNVkZQYUUxdmQxWkZRMEYzUlVGQllVNURUVVZCZDBSbldVUldVakJRUVZGSUwwSkJVVVJCWjB0clRVRTRSMEV4VldSRmQwVkNDaTkzVVVaTlFVMUNRV1k0ZDBoUldVUldVakJQUWtKWlJVWkZPRnA1YVdKSU0yWXpUbGx6UjNCTU5tZFhWbTFqVVhSdVIwcE5RVEJIUTFOeFIxTkpZak1LUkZGRlFrTjNWVUZCTkVsQ1FWRkRVRnByWmt0YVV6TnBkblpXTjAxTlpEaHFOVVk0UmpGc2VrWnhlVWhSY0dneFNtWmtVbmc1ZVc1eE5TdFhUSFJXYndwVlNVdFFZMjl1VVhsc2VHSklUalY2TldGV01XeDJSSFpQYmpCaVltTlJUVE5KVkUxUGFVaHNjRzVuTkZab1UySlhVamxQWkdkV09IaEZSRVZsUkhKSUNuZzNjVFpKUnpoTmRVdHRkUzlFVWxkSGEyVmpVWFpXYzA5V01WcEpjVFEzZHl0TWNIZEROVzB3ZGl0dWJYWnROMDlXVlcxc1RHcG5iVVJxU2xWR01ERUtXU3MyZEVWNFJYQlJXbkUyZVUxc1VFNWlRbGhoV1ZOU1ZGY3hTRE5MVjBSRWNFOW1aREJVYmpsRkswNUpjWEp5WlhkRGQwVXlVRzV1ZWxaclEwaFlTd3BvVGtKSmNuVnVVVXN5UTFSV1lVZEVUelJrU0c1SlVVNVBXaXR5Y1dJMVJXMDJia0pWSzJKak1YQnNia1ExZDJ0a2VVNTZTM05ZZDNrdlJITTRZVnBYQ2k4d1JWcE9jMDl0THl0bFZFeEdOV1kwY2tkdlkxTkZaVlI2VERNNFN6RnpOelJ3ZWdvdExTMHRMVVZPUkNCRFJWSlVTVVpKUTBGVVJTMHRMUzB0Q2c9PQogICAgc2VydmVyOiBodHRwczovLzEyNy4wLjAuMQogIG5hbWU6IGNsdXN0ZXIubG9jYWwKY29udGV4dHM6Ci0gY29udGV4dDoKICAgIGNsdXN0ZXI6IGNsdXN0ZXIubG9jYWwKICAgIHVzZXI6IGt1YmVybmV0ZXMtYWRtaW4KICBuYW1lOiBrdWJlcm5ldGVzLWFkbWluQGNsdXN0ZXIubG9jYWwKY3VycmVudC1jb250ZXh0OiBrdWJlcm5ldGVzLWFkbWluQGNsdXN0ZXIubG9jYWwKa2luZDogQ29uZmlnCnByZWZlcmVuY2VzOiB7fQp1c2VyczoKLSBuYW1lOiBrdWJlcm5ldGVzLWFkbWluCiAgdXNlcjoKICAgIGNsaWVudC1jZXJ0aWZpY2F0ZS1kYXRhOiBMUzB0TFMxQ1JVZEpUaUJEUlZKVVNVWkpRMEZVUlMwdExTMHRDazFKU1VSRmVrTkRRV1oxWjBGM1NVSkJaMGxKWW05TmFVaFRVVU52UmpSM1JGRlpTa3R2V2tsb2RtTk9RVkZGVEVKUlFYZEdWRVZVVFVKRlIwRXhWVVVLUVhoTlMyRXpWbWxhV0VwMVdsaFNiR042UVdWR2R6QjVUV3BCTWsxVVdYZFBSRlV3VGxSV1lVWjNNSGxOZWtFeVRWUlpkMDlFVlRCT1ZHUmhUVVJSZUFwR2VrRldRbWRPVmtKQmIxUkViazQxWXpOU2JHSlVjSFJaV0U0d1dsaEtlazFTYTNkR2QxbEVWbEZSUkVWNFFuSmtWMHBzWTIwMWJHUkhWbnBNVjBackNtSlhiSFZOU1VsQ1NXcEJUa0puYTNGb2EybEhPWGN3UWtGUlJVWkJRVTlEUVZFNFFVMUpTVUpEWjB0RFFWRkZRVGRQYkhGTFRUaGhSbXBUZERWdU0za0tRa2RQY2t4TVMydGFSVkpZZWpKVUszUlFXbkJQTm5obFJrUTBaRzlQV1hGS1ZtWnRMMHBCWVRRNUx6QjBlR0puU0RObmRtbFVhblYzZURGTVJtUTBZd3BDUlZsQmNtNXFaSGRJSzA1TVRTdFNVbWRhYVhGUWNWWlpVM0ZXYUdOYU1UUTNSMFZRVFVWRVRIRkxUblZ0UWxoQ1puZzVXVzFPV0d4cGFYRjNObG95Q2t4Q2JVWTRXWE5tUzJGdFJXUk1kbVZIY1c1aFUzUXJjV1I2YUdOYVNFNDJjVWwxZG5KbFpqQnZlREowTW5aUVpESXJkMmxqU21WMmQxaHZkakUwVjNRS09FVXZXVzlGUlVWT1ZWUjFTMWRLZGtwVU5uZDNaMU5YVW5KVmJVOUNXbGxPWmtKdGVHeHBNV3RUY1hkbGMyVXdWVzFtVldVdlExWjFWbFpwY0hoNmRncERhbGt4Vnl0c2NGbEhjR0ZKVEZWdE5qVm1XWGw2VkNzNFMwMHJaREp4YWpWMmIza3JVWFoyUmpCMFpVTk5NMGxGZFhjeE5FaENNbE14ZUZSMWEwWnVDakZvYVcxTmQwbEVRVkZCUW04d1ozZFNha0ZQUW1kT1ZraFJPRUpCWmpoRlFrRk5RMEpoUVhkRmQxbEVWbEl3YkVKQmQzZERaMWxKUzNkWlFrSlJWVWdLUVhkSmQwaDNXVVJXVWpCcVFrSm5kMFp2UVZWVWVHNUxTbk5tWkM5ak1XbDNZV3QyY1VKYVYxcDRRekpqV1d0M1JGRlpTa3R2V2tsb2RtTk9RVkZGVEFwQ1VVRkVaMmRGUWtGSFRuaFdVMDVMWmsxbGFHMUxTRmd4UTFOUVZ6Vm5lVEJ4WVd4MlNGSjRTV2d5U1hSV0wwcDVjbXBwU0dWNFZ6SlFRVWg1U1dZekNqWnZZbk5vVGs1UWNWWmtjazl6UlV4TWEwNUJPSFZNZFhKdVZrVnNRVmh3T1Rsb1UwVnpiemh0T1VoSVNtcHBZMlZJYldGUE5tWkZOSEp1Y0RFeFR5OEtRV0ZtZWxOclJIWktkSFpxTWtVeFJITlViV0p2Tm1wdE9EUktTek5JVFd3NWNUZDJSeXRXVkhRckwxbHVTVk4zV214ak0xbGFibmxNVDBFelZubG1Ud3BEYkRaRFpDOU5hMFo0YW1GalZIcHZWVXdyYm01SldUSkdUbnAwYlhwcU1sazFlSGxHZEhsWWQwRXJaVXRSVEc1V2NFSTVabmRNZG1sQ05VSk1MMUZFQ21aR1VHVXlaRm8xVmxGQ09WSlNjRGRRTjJsdU9GWm1Sa0kzT0RGWGNTOTZkVEIxWkZOWE5VVmpOaThyWlVKM05VMTJaME55WjFKdlUzRkZaMHhWZDFnS1RFVjRNbWx0Wm5Nd1FYcG9VWGh5ZDFaV09IaEVMMjVxYW5kV1JreDNaejBLTFMwdExTMUZUa1FnUTBWU1ZFbEdTVU5CVkVVdExTMHRMUW89CiAgICBjbGllbnQta2V5LWRhdGE6IExTMHRMUzFDUlVkSlRpQlNVMEVnVUZKSlZrRlVSU0JMUlZrdExTMHRMUXBOU1VsRmNFRkpRa0ZCUzBOQlVVVkJOMDlzY1V0Tk9HRkdhbE4wTlc0emVVSkhUM0pNVEV0cldrVlNXSG95VkN0MFVGcHdUelo0WlVaRU5HUnZUMWx4Q2twV1ptMHZTa0ZoTkRrdk1IUjRZbWRJTTJkMmFWUnFkWGQ0TVV4R1pEUmpRa1ZaUVhKdWFtUjNTQ3RPVEUwclVsSm5XbWx4VUhGV1dWTnhWbWhqV2pFS05EZEhSVkJOUlVSTWNVdE9kVzFDV0VKbWVEbFpiVTVZYkdscGNYYzJXakpNUW0xR09GbHpaa3RoYlVWa1RIWmxSM0Z1WVZOMEszRmtlbWhqV2toT05ncHhTWFYyY21WbU1HOTRNblF5ZGxCa01pdDNhV05LWlhaM1dHOTJNVFJYZERoRkwxbHZSVVZGVGxWVWRVdFhTblpLVkRaM2QyZFRWMUp5VlcxUFFscFpDazVtUW0xNGJHa3hhMU54ZDJWelpUQlZiV1pWWlM5RFZuVldWbWx3ZUhwMlEycFpNVmNyYkhCWlIzQmhTVXhWYlRZMVpsbDVlbFFyT0V0TksyUXljV29LTlhadmVTdFJkblpHTUhSbFEwMHpTVVYxZHpFMFNFSXlVekY0VkhWclJtNHhhR2x0VFhkSlJFRlJRVUpCYjBsQ1FVUmlTMjlRTDBKTWFVcFhiWEZYUmdwSFZsVkZha0pGZUZjMk0wa3hTbTlzYmtoaVZIbHVReTl2TlRaQk5IazVWVXhCYTI4NVJWbFVUMlpVWWpGbFowZFNWakZvTWxoVFpVVjZTbE00ZDNWcENuRTROR1JPYjJ0cVkxQXpWbEZvZUUxQlUyY3hlamx0VHpSeU9YWk1kR1ZoYkRaa1MxcGxMemRJTjFwSllVRnFhbmRTZVd0VldXUlJka2hCUWtKalZuTUtSMVZoU0haS0szQmpiRXRpV0hkUU1HTjVRM1JwWTNad1VVczJSR2swVGxNelQycHFhVXg0VTA1YWR5OXhhbGQ2ZFZsTk1WUTBXSGRyV2pZNVRrOTZTd3A2ZWxGSFYzVlJlSE5GY2tReFZHZG9hMVVyTlZscWQwaENWbTlsV1VzcmVUUkdTU3QzYjB4emRXdExTMVJTVjBWSlVVbFpiVTVtZDJaWVdEY3ZUM3BtQ2pCSFpESnJXVzFUYURoMFNqRnJhemhWV0drclIwcExZbm95VVVOTE5FZFVZbkZqU0hCSlZXeG9PQ3RYUzJsd2NUaE5NR1ZyTms5WlpERm9NVzVPTmtFS2JIbGFPRmx0UlVObldVVkJLM2hWVUUxVFZtdzRVemxzZUhjMVFTOXlSazFyTTJsSFltVTBjVE5yUzJWdFMyMTZiVXhaWmt0SlVtRmFiUzlrYlhWclZ3cEJUMko1UW10WmFuRlRaM0l3UkdOR1NtMXRRamsyYWtveU5HNDNhMEp1VVcxcU9XeExjRGwwWjNjMFUyTlBiR3h1VXpkS1FtMURaVTQzZW1obmVsbFFDaTl6UzFFeldGWTVhRzFJU2poVFprcEtNek5EWTJoc2RWTlRZalpWTTBKR2FtcHZTVkJvVkdORFQxZG1kMUY1UWpGRE5YWktLMDFEWjFsRlFUaFpNVTRLZDBsdlpHcDRTR1p4YVhWcFNua3dVU3M1TlV0b1JsaFdhakZzTjNaM1JtVTVhV05aV0drNFRGUXdPVmhYVURaTmQySnRhV013ZHpKQ2VXc3ZlbEJ0YndvM2RGQXZTbkJSYm01b2EyeFFSVUZNUlhWQldVWk1ZbmhsWWtJd2RreHVaVzVwYXpCak1IZ3ZlVWRoYmtkTVQxTTJOMWhaWkdwS2EzVnFXa3BKTVhocENrOXpRMUpQWjNWTWNWVlBXakkxTVNzNU0wODNRaXQzVXlzdlpGbFZNMFJ1VDFOUlNIVllSVU5uV1VWQmEwWlhOREV2TW5oeWIxbGhjMlZWYkhjNFVGVUtVekp2WW1wU1NTdHViVzlhYkZwVWIxbDZPQ3RvYVVsbVpsbGxUa1Z6U1haSVprZHJOalp3YVZWYWJVRkthaXRoZGtWM2JYQkhTSEJQUlZWSU1HWjViQXBEUTJGMFZqSlZlWEJSV0hZekszbHlkREJJZGpKaVUzTXZNRzFpVFdKNFoxVlphM3ByWW5NMmJqUmxWR1ZSWm5kQlRESjNhVGR5UjNoV1MyTXdSalZZQ2k5aWVYRm9SbGRzWWpRdlp6SkRPRU5oZVVWUFZWSlZRMmRaUlVGelJHcHhaRWxHVDNRd1dFODJlRTFUU2xseFdGUlhhMHMzUTJwRGRVOVpUR2hZYlRJS2EyUmFUSHBOY0RsalkzSnpZWEI1Y1drNWNXMVVXRGxaUjNwc1dYUnRNbVJrVkRselkyWlRPRkZ1WTA0eGVuSlNNbFk1Y25Ob1JWWmphbGgwZEVwSVZncGxORmROU1cxSE5VSTNZamhUVDFWYVZuRlZMekpzZEVKaFUybGFhWGhoYmtGNk0yaDBXSE5sTVUxdVozZFlkbEpYVXpSNFZVMUtSbmd4VkZsT01tVjZDa05PYW10WFkwVkRaMWxDU201d1JsaE5iVWRZYTJKVVpHUlZkbGRtVDNOUmJtVkhkVEJwVFV4M05sVm1XbkJpUm05M016SkdiVzVwUWxSU2EyZHZhbEVLY2xJMWJFeHNibGwwU1daU1JrNTNlWEJ2TlUwM1ZFbFNNRFJETTJocVVrZEVNMmszYkRkQ1QxUkhLME56WkRSVFRXbFlOakVyWXpCbVdYSmtVa3BzY1FveVQwazNPR1EwYTNwdVNHaHplazF5WjI1MGRVWm5VVVJGYkhwRU4xUnhNMk00TDBSdFkxZFpSRzFvYmpJMloyRnFRMjFDYUVFOVBRb3RMUzB0TFVWT1JDQlNVMEVnVUZKSlZrRlVSU0JMUlZrdExTMHRMUW89Cg=="
	type args struct {
		cluster *clusterv1alpha1.Cluster
		cache   *UserInfo
	}
	tests := []struct {
		name    string
		args    args
		want    bool
		wantErr bool
	}{
		{
			name: "kubeconfig is invalid base64",
			args: args{
				cluster: &clusterv1alpha1.Cluster{},
				cache: &UserInfo{
					Cluster:    &clusterv1alpha1.Cluster{},
					KubeConfig: "kubeconfig",
				},
			},
			want:    false,
			wantErr: true,
		},
		{
			name: "kubeconfig is invalid",
			args: args{
				cluster: &clusterv1alpha1.Cluster{},
				cache: &UserInfo{
					Cluster:    &clusterv1alpha1.Cluster{},
					KubeConfig: "YWJjCg==",
				},
			},
			want:    false,
			wantErr: true,
		},
		{
			name: "cluster is not latest",
			args: args{
				cluster: &clusterv1alpha1.Cluster{},
				cache: &UserInfo{
					Cluster:    &clusterv1alpha1.Cluster{},
					KubeConfig: kubeconfig,
				},
			},
			want:    false,
			wantErr: true,
		},
		{
			name: "kubeconfig is latest",
			args: args{
				cluster: &clusterv1alpha1.Cluster{
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace:       "ns",
							Name:            "secret",
							ResourceVersion: "",
						},
					},
					Status: clusterv1alpha1.ClusterStatus{
						ProxyURL: "https://127.0.0.1",
					},
				},
				cache: &UserInfo{
					Cluster:    &clusterv1alpha1.Cluster{Spec: clusterv1alpha1.ClusterSpec{SecretRef: &clusterv1alpha1.LocalSecretReference{Namespace: "ns", Name: "secret", ResourceVersion: ""}}},
					KubeConfig: kubeconfig,
				},
			},
			want:    true,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := validateConfig(tt.args.cluster, tt.args.cache)
			if (err != nil) != tt.wantErr {
				t.Errorf("validateConfig() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("validateConfig() = %v, want %v", got, tt.want)
			}
		})
	}
}
