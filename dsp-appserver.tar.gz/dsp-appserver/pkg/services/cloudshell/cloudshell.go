/*
Copyright 2022 Kpanda Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cloudshell

import (
	"context"
	"encoding/base64"
	"fmt"
	"strings"
	"time"

	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/engine"
	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/services/clusters"
	"github.com/daocloud/dsp-appserver/pkg/services/workloads"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"

	cloudshellv1alpha1 "github.com/cloudtty/cloudtty/pkg/apis/cloudshell/v1alpha1"
	cloudshellclient "github.com/cloudtty/cloudtty/pkg/generated/clientset/versioned"
	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/equality"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	utilruntime "k8s.io/apimachinery/pkg/util/runtime"
	"k8s.io/client-go/tools/cache"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/klog/v2"
	ctrlutil "sigs.k8s.io/controller-runtime/pkg/controller/controllerutil"
)

// CommandType string describes the cloudshell command type.
type CommandType string

const (
	// CommandTypeBash is a CommandType that indicates the commands can be executed from the terminal.
	CommandTypeBash CommandType = "bash"
	// CommandTypeExec is a CommandType that indicates into the container.
	CommandTypeExec CommandType = "exec"
	// CommandTypeLogs is a CommandType that indicates query pod logs.
	CommandTypeLogs CommandType = "logs"
	// CommandTypeUpload is a CommandType that indicates upload a file to pod.
	CommandTypeUpload CommandType = "upload"
	// CommandTypeDownload is a CommandType that indicates download a file from pod.
	CommandTypeDownload CommandType = "download"
)

const (
	// the cert key in secret.
	CertKey             = "kubeconfig"
	CloudshellConfigKey = "config"
	DefaultTTL          = 1500
	// Default expiration time of the certificate.
	defaultExpirationDuration time.Duration = 60 * 60 * 24 * 365 * 3 * time.Second
)

var (
	currentNamespace = util.GetCurrentNSOrDefault()
	scheme           = runtime.NewScheme()
	AccessURLPrefix  = "/api/kpanda.io"

	// the defaults of the timeout to wait cloudshell server is running.
	defaultCloudshellTimeout = time.Second * 100
)

func init() {
	utilruntime.Must(cloudshellv1alpha1.AddToScheme(scheme))
}

type Services interface {
	CreateCloudshell(ctx context.Context, clusterName, namespace, podName, container, filePath string, logCount int32, commandType CommandType, cloudshell *cloudshellv1alpha1.CloudShell) (*cloudshellv1alpha1.CloudShell, error)
	GetCloudshell(ctx context.Context, name string) (*cloudshellv1alpha1.CloudShell, error)
	DeleteCloudshell(ctx context.Context, name string) error
}

type cloudshellServices struct {
	store            cache.Store
	clusterService   clusters.Services
	workloadService  workloads.Service
	cloudshellEngine engine.Cloudshell
}

func NewCloudshellServices(cloudshellclient cloudshellclient.Interface, kubeclient kubeclient.Client, pclient pedia.Clients, factory informers.SharedInformerFactory, clusterClient clusterclient.ClusterClients) (Services, error) {
	workloadService, err := workloads.NewWorkloadServices(factory, pclient, clusterClient)
	if err != nil {
		return nil, err
	}

	return &cloudshellServices{
		clusterService:   clusters.NewClusterServices(kubeclient, pclient, factory, clusterClient),
		workloadService:  workloadService,
		cloudshellEngine: engine.NewCloudshellEngine(cloudshellclient, kubeclient),
		store:            cache.NewStore(UserGroupKeyFunc),
	}, nil
}

type UserInfo struct {
	UserName   string
	Groups     []string
	Cluster    *clusterv1alpha1.Cluster
	KubeConfig string
}

func UserGroupKeyFunc(obj interface{}) (string, error) {
	userInfo, ok := obj.(*UserInfo)
	if !ok {
		return "", fmt.Errorf("obj is not struct of kubeConfigCache")
	}
	return fmt.Sprintf("%s:%s-%s", userInfo.Cluster.Name, userInfo.UserName, strings.Join(userInfo.Groups, ",")), nil
}

func (c *cloudshellServices) CreateCloudshell(ctx context.Context, clusterName, namespace, podName, container, filePath string, logCount int32, commandType CommandType, cloudshell *cloudshellv1alpha1.CloudShell) (*cloudshellv1alpha1.CloudShell, error) {
	start := time.Now()
	// get the cluster and secret info.
	cluster, err := c.clusterService.GetCluster(ctx, clusterName)

	klog.V(5).InfoS("cloudshell: GetCluster", "cluster", clusterName, "namespaces", namespace, "pod", podName, "container", container, "cost", time.Since(start))
	start = time.Now()
	if err != nil {
		return nil, err
	}
	user, groups, err := c.clusterService.GetCurrentUserNameAndGroup(ctx)

	klog.V(5).InfoS("cloudshell: GetCurrentUserNameAndGroup", "cluster", clusterName, "namespaces", namespace, "pod", podName, "container", container, "cost", time.Since(start))
	start = time.Now()
	if err != nil {
		return nil, err
	}

	userInfo := &UserInfo{
		UserName: user,
		Groups:   groups,
		Cluster:  cluster,
	}

	if obj, exist, _ := c.store.Get(userInfo); exist {
		klog.V(4).InfoS("cloudshell:user info already store in cache", "user", userInfo)
		userInfo = obj.(*UserInfo)
		if validate, _ := validateConfig(cluster, userInfo); !validate {
			klog.V(4).InfoS("cloudshell:user info already store in cache but invalidate,will create csr again", "user", userInfo)
			// Generate the user's certificate and Kubeconfig
			// Certificate generation is very slow and can be optimized.
			userInfo.KubeConfig, err = c.clusterService.CreateOpenAPIClusterCertWithClusterByCNAndOrgs(ctx, cluster, defaultExpirationDuration, user, groups, true)
			if err != nil {
				return nil, err
			}
			if err := c.store.Update(userInfo); err != nil {
				return nil, err
			}
		}
	} else {
		userInfo.KubeConfig, err = c.clusterService.CreateOpenAPIClusterCertWithClusterByCNAndOrgs(ctx, cluster, defaultExpirationDuration, user, groups, true)
		if err != nil {
			return nil, err
		}
		if err := c.store.Add(userInfo); err != nil {
			return nil, err
		}
	}

	klog.V(5).InfoS("cloudshell: CreateOpenAPIClusterCertWithClusterByCNAndOrgs", "cluster", clusterName, "namespaces", namespace, "pod", podName, "container", container, "cost", time.Since(start))
	start = time.Now()

	cloudshell, err = c.CreateOriginCloudshell(ctx, namespace, podName, container, userInfo.KubeConfig, filePath, logCount, commandType, cloudshell)
	if err != nil {
		return nil, err
	}

	klog.V(5).InfoS("cloudshell: CreateOriginCloudshell", "cluster", clusterName, "namespaces", namespace, "pod", podName, "container", container, "cost", time.Since(start))
	start = time.Now()

	cloudShell, err := c.cloudshellEngine.GetCompletedCloudshell(ctx, cloudshell.Namespace, cloudshell.Name, cloudshell.ResourceVersion, defaultCloudshellTimeout)

	klog.V(5).InfoS("cloudshell: GetCompletedCloudshell", "cluster", clusterName, "namespaces", namespace, "pod", podName, "container", container, "cost", time.Since(start))

	return cloudShell, err
}

func (c *cloudshellServices) CreateOriginCloudshell(ctx context.Context, namespace, podName, container, kubeconfig, filePath string, logCount int32, commandType CommandType, cloudshell *cloudshellv1alpha1.CloudShell) (*cloudshellv1alpha1.CloudShell, error) {
	if len(kubeconfig) == 0 {
		klog.ErrorS(fmt.Errorf("kubeconfig is empty"), "the cloudshell maybe not work", "cloudshell", klog.KRef(namespace, cloudshell.Name))
	}

	// create configmap to cloudshell. the load can be remove while cloudshell
	// can load the secret as the kubeconfig.
	kubeconfigBytes, _ := base64.StdEncoding.DecodeString(kubeconfig)
	secret, err := c.workloadService.CreateSecret(context.TODO(), constants.GlobalCluster, currentNamespace, &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Namespace:    currentNamespace,
			GenerateName: fmt.Sprintf("cloudshell-%s-", cloudshell.Name),
		},
		Data: map[string][]byte{CloudshellConfigKey: kubeconfigBytes},
	})
	if err != nil {
		return nil, err
	}

	// set the namespace, configmap, tls and commandAction of cloudshell.
	// if the cloudshell phase change to "Complated", delete the cloudshell cr directly.
	cloudshell.Spec.Cleanup = true
	cloudshell.Spec.ExposeMode = "VirtualService"
	cloudshell.Namespace = currentNamespace
	cloudshell.Spec.SecretRef = &cloudshellv1alpha1.LocalSecretReference{Name: secret.GetName()}
	cloudshell.Spec.PathPrefix = AccessURLPrefix
	cloudshell.Spec.CommandAction = CommandBuild(namespace, podName, container, logCount, commandType)
	if cloudshell.Spec.Ttl == 0 {
		cloudshell.Spec.Ttl = DefaultTTL
	}

	if commandType == CommandTypeUpload || commandType == CommandTypeDownload {
		cloudshell.Spec.Env = []corev1.EnvVar{
			{Name: "POD_NAME", Value: podName},
			{Name: "POD_NAMESPACE", Value: namespace},
			{Name: "CONTAINER", Value: container},
		}
		cloudshell.Spec.PathSuffix = fmt.Sprintf("%s%s", commandType, filePath)
	}

	// set vs config.
	cloudshell.Spec.VirtualServiceConfig = &cloudshellv1alpha1.VirtualServiceConfig{
		VirtualServiceName: "kpanda-cloudtty",
		Namespace:          currentNamespace,
		ExportTo:           "istio-system",
		Gateway:            "ghippo-system/ghippo-gateway",
	}

	cloudshell, err = c.cloudshellEngine.CreateCloudshell(ctx, cloudshell)
	if err != nil {
		return nil, err
	}

	// set OwnerReference of configmap, it will also be deleted if delete cloudshell.
	if err = ctrlutil.SetOwnerReference(cloudshell, secret, scheme); err != nil {
		return nil, err
	}
	if _, err = c.workloadService.UpdateSecret(context.TODO(), constants.GlobalCluster, secret); err != nil {
		return nil, err
	}
	return cloudshell, nil
}

func (c *cloudshellServices) GetCloudshell(ctx context.Context, name string) (*cloudshellv1alpha1.CloudShell, error) {
	return c.cloudshellEngine.GetCloudshell(ctx, constants.KpandaSystem, name)
}

func (c *cloudshellServices) DeleteCloudshell(ctx context.Context, name string) error {
	return c.cloudshellEngine.DeleteCloudshell(ctx, constants.KpandaSystem, name)
}

func CommandBuild(namespace, podName, container string, logCount int32, commandType CommandType) string {
	var command strings.Builder
	switch commandType {
	case CommandTypeBash:
		command.WriteString(string(CommandTypeBash))
	case CommandTypeExec:
		command.WriteString(fmt.Sprintf("kubectl exec -it %s", podName))
		if namespace != "" {
			command.WriteString(fmt.Sprintf(" -n %s", namespace))
		}
		if container != "" {
			command.WriteString(fmt.Sprintf(" -c %s", container))
		}
		command.WriteString(" -- sh -c \"bash||sh\"")
	case CommandTypeLogs:
		if logCount == 0 {
			logCount = 100
		}
		command.WriteString(fmt.Sprintf("kubectl logs -f --tail %d %s", logCount, podName))
		if namespace != "" {
			command.WriteString(fmt.Sprintf(" -n %s", namespace))
		}
		if container != "" {
			command.WriteString(fmt.Sprintf(" -c %s", container))
		}
	default:
		command.WriteString(string(CommandTypeBash))
	}
	return command.String()
}

func validateConfig(cluster *clusterv1alpha1.Cluster, userInfo *UserInfo) (bool, error) {
	configBytes, err := base64.StdEncoding.DecodeString(userInfo.KubeConfig)
	if err != nil {
		return false, err
	}
	kubeconfig, err := clientcmd.RESTConfigFromKubeConfig(configBytes)
	if err != nil {
		return false, err
	}
	if cluster.Status.ProxyURL == kubeconfig.Host && equality.Semantic.DeepEqual(cluster.Spec.SecretRef, userInfo.Cluster.Spec.SecretRef) {
		return true, nil
	}
	return false, fmt.Errorf("cluster is not the latest")
}
