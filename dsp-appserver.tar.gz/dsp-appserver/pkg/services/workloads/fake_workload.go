package workloads

import (
	"github.com/daocloud/dsp-appserver/pkg/engine"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
)

func NewFakeWorkloadService(clusterClient clusterclient.ClusterClients) *WorkloadServices {
	return &WorkloadServices{
		engine: engine.NewFakeWorkloadEngine(clusterClient),
	}
}
