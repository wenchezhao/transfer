package workloads

import (
	"context"
	"fmt"
	"reflect"
	"testing"
	"time"

	clusterpediav1beta1 "github.com/clusterpedia-io/api/clusterpedia/v1beta1"
	"github.com/golang/mock/gomock"
	apivolumesnapshotv1 "github.com/kubernetes-csi/external-snapshotter/client/v4/apis/volumesnapshot/v1"
	"github.com/stretchr/testify/assert"
	appsv1 "k8s.io/api/apps/v1"
	autoscalingv2 "k8s.io/api/autoscaling/v2"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	storagev1 "k8s.io/api/storage/v1"
	apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/json"
	"k8s.io/apimachinery/pkg/watch"
	cmapi "k8s.io/metrics/pkg/apis/custom_metrics/v1beta2"
	"sigs.k8s.io/controller-runtime/pkg/client"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	clusterscheme "github.com/daocloud/dsp-appserver/api/crd/client/clientset/versioned/scheme"
	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/engine"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/helper"
)

type WorkloadTest struct {
	_ListNamespaces              func(ctx context.Context, clusters []string, queryPage *util.QueryPage) (*corev1.NamespaceList, error)
	_GetNamespace                func(ctx context.Context, cluster, name string) (*corev1.Namespace, error)
	_ListResourceQuotas          func(ctx context.Context, opts metav1.ListOptions) (*corev1.ResourceQuotaList, error)
	_GetResourceQuota            func(ctx context.Context, cluster, namespace, name string) (*corev1.ResourceQuota, error)
	_ListPods                    func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PodList, error)
	_ListReplicaSets             func(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.ReplicaSetList, error)
	_ListDaemonSets              func(ctx context.Context, clusters []string, namespace string) (*appsv1.DaemonSetList, error)
	_ListStatefulSets            func(ctx context.Context, clusters []string, namespace string) (*appsv1.StatefulSetList, error)
	_ListEvents                  func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.EventList, error)
	_ListDaemonSetsByQueryPage   func(ctx context.Context, clusters []string, namespace string, queryPage *util.QueryPage) ([]appsv1.DaemonSet, error)
	_ListStatefulSetsByQueryPage func(ctx context.Context, clusters []string, namespace string, queryPage *util.QueryPage) ([]appsv1.StatefulSet, error)
	_ListPodsByQueryPage         func(ctx context.Context, clusters []string, namespace string, queryPage *util.QueryPage) ([]corev1.Pod, error)
	_ListPodsByFieldSelector     func(ctx context.Context, cluster, field string, values []string, queryPage *util.QueryPage) ([]corev1.Pod, error)
	_GetDeployment               func(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error)
	_GetStatefulSet              func(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error)
	_GetDaemonSet                func(ctx context.Context, cluster, namespace, name string) (*appsv1.DaemonSet, error)
	//_PutDeployment                 func(ctx context.Context, clusterName string, deploy *appsv1.Deployment) (*appsv1.Deployment, error)
	_ListPodsByDeploymentUID       func(ctx context.Context, cluster, namespace, deploymentUID string) ([]corev1.Pod, error)
	_ListEventsByUIDs              func(ctx context.Context, cluster []string, namespace string, uids []string, queryPage *util.QueryPage) ([]corev1.Event, error)
	_ListPodsByOwnerReferencesUIDs func(ctx context.Context, cluster, namespace string, uids []string) ([]corev1.Pod, error)
	// _GetDeployStatus                    func(ctx context.Context, cluster string, deploy *appsv1.Deployment) constants.WorkloadState
	// _GetStatefulStatus                  func(ctx context.Context, cluster string, statefulSet *appsv1.StatefulSet) constants.WorkloadState
	_ListClusterCronJobsJob            func(ctx context.Context, cluster, nameSpace, job string, queryPage *util.QueryPage) ([]batchv1.Job, error)
	_ListClusterJobs                   func(ctx context.Context, cluster, nameSpace string, queryPage *util.QueryPage) ([]batchv1.Job, error)
	_ListClusterCronJobs               func(ctx context.Context, cluster, nameSpace string, queryPage *util.QueryPage) ([]batchv1.CronJob, error)
	_ListAllCronJobs                   func(ctx context.Context, cluster []string, nameSpace string, queryPage *util.QueryPage) ([]batchv1.CronJob, error)
	_ListAllJobs                       func(ctx context.Context, cluster []string, nameSpace string, queryPage *util.QueryPage) ([]batchv1.Job, error)
	_ListPodsByJobName                 func(ctx context.Context, cluster, nameSpace, job string, queryPage *util.QueryPage) ([]corev1.Pod, error)
	_ListPodsByOwnerUIDsQueryPage      func(ctx context.Context, cluster, namespace string, ownerUIDs []string, queryPage *util.QueryPage) ([]corev1.Pod, error)
	_ListPodsUIDsByOwnerReferencesUIDs func(ctx context.Context, cluster, namespace string, uids []string) ([]string, error)
	_ListReplicaSetsByDeploymentUID    func(ctx context.Context, cluster, namespace, deploymentUID string) ([]appsv1.ReplicaSet, error)
	_ListReplicaSetUIDsByDeploymentUID func(ctx context.Context, cluster, namespace, deploymentUID string) ([]string, error)
	_ListPodsByDeploymentUIDQueryPage  func(ctx context.Context, cluster, namespace, deploymentUID string, queryPage *util.QueryPage) ([]corev1.Pod, error)
	_GetPod                            func(ctx context.Context, cluster, namespaceName, podName string) (*corev1.Pod, error)
	_ListDeployments                   func(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.DeploymentList, error)
	_ListServices                      func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.ServiceList, error)
	_GetService                        func(ctx context.Context, cluster, namespace, name string) (*corev1.Service, error)
	_CreateService                     func(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error)
	_UpdateService                     func(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error)
	_DeleteService                     func(ctx context.Context, cluster, namespace, name string) error
	_ListIngresses                     func(ctx context.Context, cluster []string, namespace string, queryPage *util.QueryPage) (*networkingv1.IngressList, error)
	_GetIngress                        func(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error)
	_CreateIngress                     func(ctx context.Context, cluster, namespace string, configmap *unstructured.Unstructured) (*unstructured.Unstructured, error)
	_UpdateIngress                     func(ctx context.Context, cluster, namespace string, configmap *unstructured.Unstructured) (*unstructured.Unstructured, error)
	_PatchIngress                      func(ctx context.Context, cluster, namespace, name string) (*networkingv1.Ingress, error)
	_DeleteIngress                     func(ctx context.Context, cluster, namespace, name string) error
	_GetNetworkPolicy                  func(ctx context.Context, cluster, namespace, name string) (*networkingv1.NetworkPolicy, error)
	_CreateNetworkPolicy               func(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error)
	_UpdateNetworkPolicy               func(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error)
	_DeleteNetworkPolicy               func(ctx context.Context, cluster, namespace, name string) error
	_ListPersistentVolumeClaims        func(ctx context.Context, cluster, namespace string) (*corev1.PersistentVolumeClaimList, error)
	_UpdateSecret                      func(ctx context.Context, cluster string, secret *corev1.Secret) (*corev1.Secret, error)
	_GetSecret                         func(ctx context.Context, clusterName, namespace, name string) (*corev1.Secret, error)
	_DeleteSecret                      func(ctx context.Context, cluster, namespace, name string) error
	_DeleteJob                         func(ctx context.Context, cluster, namespace, name string) error
	_DeleteCronJob                     func(ctx context.Context, cluster, namespace, name string) error
	_PatchCronJob                      func(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*unstructured.Unstructured, error)
	_ListJobs                          func(ctx context.Context, cluster string, queryPage *util.QueryPage) (*batchv1.JobList, error)
	_ListCronJobs                      func(ctx context.Context, cluster string, queryPage *util.QueryPage) (*batchv1.CronJobList, error)
	_DeletePod                         func(ctx context.Context, cluster, namespace, name string) error
	_DeleteDaemonSet                   func(ctx context.Context, cluster, namespace, name string) error
	_RestartJob                        func(ctx context.Context, cluster, namespace, name, resourceVersion string) (*batchv1.Job, error)
	_GetCronJob                        func(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error)
	_GetJob                            func(ctx context.Context, cluster, namespace, name string) (*batchv1.Job, error)
	_CreateResourceQuota               func(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error)
	_UpdateResourceQuota               func(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error)
	_GetLimitRange                     func(ctx context.Context, cluster, namespace, name string) (*corev1.LimitRange, error)
	_CreateLimitRange                  func(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error)
	_UpdateLimitRange                  func(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error)
	_DeleteLimitRange                  func(ctx context.Context, cluster, namespace, name string) error
	_DeleteNamespace                   func(ctx context.Context, cluster, namespace string) error
	_CreateNamespace                   func(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error)
	_WatchNamespace                    func(ctx context.Context, cluster, namespace string) (*corev1.Namespace, error)
	_UpdateNameSpace                   func(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error)
	_PatchNameSpace                    func(ctx context.Context, cluster, name string, patchType types.PatchType, patchData []byte) (*corev1.Namespace, error)
	_CreateSecret                      func(ctx context.Context, cluster, namespace string, secret *corev1.Secret) (*corev1.Secret, error)
	_PatchDeployment                   func(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.Deployment, error)
	_GetNode                           func(ctx context.Context, cluster, name string) (*corev1.Node, error)
	_UpdateNode                        func(ctx context.Context, cluster string, node *corev1.Node) (*corev1.Node, error)
	_PutNodeLabels                     func(ctx context.Context, clusterName, name string, loadBytes []byte) (map[string]string, error)
	_PutNodeTaints                     func(ctx context.Context, clusterName, name string, loadBytes []byte) ([]corev1.Taint, error)
	_CordonNode                        func(ctx context.Context, cluster, node string, loadBytes []byte) (*corev1.Node, error)

	_ListCustomResources  func(ctx context.Context, gvr schema.GroupVersionResource, listOptions metav1.ListOptions) (*unstructured.UnstructuredList, error)
	_GetCustomResource    func(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource) (*unstructured.Unstructured, error)
	_CreateCustomResource func(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error)
	_UpdateCustomResource func(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error)
	_DeleteCustomResource func(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource, p *metav1.DeletionPropagation) error

	_ListRolebindings         func(ctx context.Context, listOptions metav1.ListOptions) (*rbacv1.RoleBindingList, error)
	_ListClusterRolebindings  func(ctx context.Context, listOptions metav1.ListOptions) (*rbacv1.ClusterRoleBindingList, error)
	_DeleteRolebinding        func(ctx context.Context, cluster, namespace, name string) error
	_CreateRolebinding        func(ctx context.Context, cluster, nemaspece string, RoleBinding *rbacv1.RoleBinding) (*rbacv1.RoleBinding, error)
	_CreateClusterRolebinding func(ctx context.Context, cluster string, clusterRolebinding *rbacv1.ClusterRoleBinding) (*rbacv1.ClusterRoleBinding, error)
	_DeleteClusterRolebinding func(ctx context.Context, cluster, name string) error

	_FetchCollectionResource func(ctx context.Context, name string, opts metav1.ListOptions, params map[string]string) (*clusterpediav1beta1.CollectionResource, error)
}

func (fake *WorkloadTest) ListServiceAccounts(_ context.Context, _ metav1.ListOptions) (*corev1.ServiceAccountList, error) {
	// TODO implement me
	panic("implement me")
}

func (fake *WorkloadTest) UpdateServiceAccount(_ context.Context, _, _ string, _ *corev1.ServiceAccount) (*corev1.ServiceAccount, error) {
	panic("implement me")
}

func (fake *WorkloadTest) DeleteServiceAccount(_ context.Context, _, _, _ string) error {
	// TODO implement me
	panic("implement me")
}

var _ engine.Workload = new(WorkloadTest)

func (fake *WorkloadTest) UpdateCustomResourceStatus(_ context.Context, _, _ string, _ schema.GroupVersionResource, _ *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	panic("implement me")
}

func (fake *WorkloadTest) GetAPIResourceList(_ context.Context, _ string) ([]*metav1.APIResourceList, error) {
	panic("implement me")
}

func (fake *WorkloadTest) ListIngressClasses(_ context.Context, _ metav1.ListOptions) (*networkingv1.IngressClassList, error) {
	panic("implement me")
}

func (fake *WorkloadTest) ListMetricValues(_ context.Context, _, _ string, _ schema.GroupKind, _ labels.Selector, _ string, _ labels.Selector) (*cmapi.MetricValueList, error) {
	panic("implement me")
}

func (fake *WorkloadTest) RESTGetInto(_ context.Context, _, _ string, _ map[string]string, _ runtime.Object) error {
	panic("implement me")
}

func (*WorkloadTest) PatchCustomResource(_ context.Context, _, _, _ string, _ schema.GroupVersionResource, _ types.PatchType, _ []byte, _ ...string) (*unstructured.Unstructured, error) {
	panic("unimplemented")
}

func (*WorkloadTest) CreateCronJob(_ context.Context, _, _ string, _ *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	panic("unimplemented")
}

func (*WorkloadTest) UpdateCronJob(_ context.Context, _, _ string, _ *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) GetReplicaSet(_ context.Context, _, _, _ string) (*appsv1.ReplicaSet, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) UpdateReplicaSet(_ context.Context, _, _ string, _ *appsv1.ReplicaSet) (*appsv1.ReplicaSet, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) DeleteReplicaSet(_ context.Context, _, _, _ string) error {
	panic("unimplemented")
}

func (fake *WorkloadTest) CreateRole(_ context.Context, _, _ string, _ *rbacv1.Role) (*rbacv1.Role, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreateClusterRole(_ context.Context, _ string, _ *rbacv1.ClusterRole) (*rbacv1.ClusterRole, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreateServiceAccount(_ context.Context, _, _ string, _ *corev1.ServiceAccount) (*corev1.ServiceAccount, error) {
	panic("implement me")
}

func (fake *WorkloadTest) GetServiceAccount(_ context.Context, _, _, _ string) (*corev1.ServiceAccount, error) {
	panic("implement me")
}

func (fake *WorkloadTest) WatchServiceAccount(_ context.Context, _, _ string, _ metav1.ListOptions) (watch.Interface, error) {
	panic("implement me")
}

func (fake *WorkloadTest) WatchPod(_ context.Context, _, _ string, _ metav1.ListOptions) (watch.Interface, error) {
	panic("implement me")
}

func (*WorkloadTest) GetClientSet(_ context.Context, _ string) (client.Client, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) UpdateVolumeSnapshot(_ context.Context, _, _ string, _ *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error) {
	panic("implement me")
}

func (fake *WorkloadTest) ListVolumeSnapshots(_ context.Context, _ schema.GroupVersionResource, _ metav1.ListOptions) (*unstructured.UnstructuredList, error) {
	panic("implement me")
}

func (fake *WorkloadTest) GetPersistentVolumeClaim(_ context.Context, _, _, _ string) (*corev1.PersistentVolumeClaim, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreatePersistentVolumeClaim(_ context.Context, _, _ string, _ *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error) {
	panic("implement me")
}

func (fake *WorkloadTest) DeletePersistentVolumeClaim(_ context.Context, _, _, _ string) error {
	panic("implement me")
}

func (fake *WorkloadTest) DeletePersistentVolumeClaimSnapshot(_ context.Context, _, _, _ string) error {
	panic("implement me")
}

func (fake *WorkloadTest) UpdatePersistentVolumeClaimLabels(_ context.Context, _, _, _ string, _ []byte) (map[string]string, error) {
	panic("implement me")
}

func (fake *WorkloadTest) PatchPersistentVolumeClaim(_ context.Context, _, _, _ string, _ []byte, _ types.PatchType) (*corev1.PersistentVolumeClaim, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreateVolumeSnapshot(_ context.Context, _, _ string, _ *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error) {
	panic("implement me")
}

func (fake *WorkloadTest) UpdatePersistentVolumeClaim(_ context.Context, _, _ string, _ *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error) {
	panic("implement me")
}

func (fake *WorkloadTest) ListPersistentVolumes(_ context.Context, _ metav1.ListOptions) (*corev1.PersistentVolumeList, error) {
	panic("implement me")
}

func (fake *WorkloadTest) GetPersistentVolume(_ context.Context, _, _ string) (*corev1.PersistentVolume, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreatePersistentVolume(_ context.Context, _ string, _ *corev1.PersistentVolume) (*corev1.PersistentVolume, error) {
	panic("implement me")
}

func (fake *WorkloadTest) UpdatePersistentVolume(_ context.Context, _ string, _ *corev1.PersistentVolume) (*corev1.PersistentVolume, error) {
	panic("implement me")
}

func (fake *WorkloadTest) DeletePersistentVolume(_ context.Context, _, _ string) error {
	panic("implement me")
}

func (fake *WorkloadTest) ListStorageClass(_ context.Context, _ metav1.ListOptions) (*storagev1.StorageClassList, error) {
	panic("implement me")
}

func (fake *WorkloadTest) DeleteStorageClass(_ context.Context, _, _ string) error {
	panic("implement me")
}

func (fake *WorkloadTest) GetStorageClass(_ context.Context, _, _ string) (*storagev1.StorageClass, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreateStorageClass(_ context.Context, _ string, _ *storagev1.StorageClass) (*storagev1.StorageClass, error) {
	panic("implement me")
}

func (fake *WorkloadTest) UpdateStorageClass(_ context.Context, _ string, _ *storagev1.StorageClass) (*storagev1.StorageClass, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreatePod(_ context.Context, _, _ string, _ *corev1.Pod) (*corev1.Pod, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) UpdatePod(_ context.Context, _, _ string, _ *corev1.Pod) (*corev1.Pod, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) ListControllerRevisions(_ context.Context, _ metav1.ListOptions) (*appsv1.ControllerRevisionList, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) CreateClusterRoleBinding(ctx context.Context, cluster string, clusterRolebinding *rbacv1.ClusterRoleBinding) (*rbacv1.ClusterRoleBinding, error) {
	return fake._CreateClusterRolebinding(ctx, cluster, clusterRolebinding)
}

func (fake *WorkloadTest) CreateRoleBinding(ctx context.Context, cluster, nemaspece string, RoleBinding *rbacv1.RoleBinding) (*rbacv1.RoleBinding, error) {
	return fake._CreateRolebinding(ctx, cluster, nemaspece, RoleBinding)
}

func (fake *WorkloadTest) DeleteClusterRoleBinding(ctx context.Context, cluster, name string) error {
	return fake._DeleteClusterRolebinding(ctx, cluster, name)
}

func (fake *WorkloadTest) DeleteRoleBinding(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeleteRolebinding(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) ListClusterRoleBindings(ctx context.Context, listOptions metav1.ListOptions) (*rbacv1.ClusterRoleBindingList, error) {
	return fake._ListClusterRolebindings(ctx, listOptions)
}

func (fake *WorkloadTest) ListRoleBindings(ctx context.Context, listOptions metav1.ListOptions) (*rbacv1.RoleBindingList, error) {
	return fake._ListRolebindings(ctx, listOptions)
}

func (fake *WorkloadTest) ListReplicaSets(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.ReplicaSetList, error) {
	return fake._ListReplicaSets(ctx, listOptions)
}

func (fake *WorkloadTest) ListPods(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PodList, error) {
	return fake._ListPods(ctx, listOptions)
}

func (fake *WorkloadTest) ListEvents(ctx context.Context, listOptions metav1.ListOptions) (*corev1.EventList, error) {
	return fake._ListEvents(ctx, listOptions)
}

func (fake *WorkloadTest) PatchNode(_ context.Context, _, _ string, _ []byte) (*corev1.Node, error) {
	panic("implement me")
}

func (fake *WorkloadTest) GetNode(ctx context.Context, cluster, name string) (*corev1.Node, error) {
	return fake._GetNode(ctx, cluster, name)
}

func (fake *WorkloadTest) UpdateNode(ctx context.Context, cluster string, node *corev1.Node) (*corev1.Node, error) {
	return fake._UpdateNode(ctx, cluster, node)
}

func (fake *WorkloadTest) PutNodeLabels(ctx context.Context, clusterName, name string, loadBytes []byte) (map[string]string, error) {
	return fake._PutNodeLabels(ctx, clusterName, name, loadBytes)
}

func (fake *WorkloadTest) PutNodeTaints(ctx context.Context, clusterName, name string, loadBytes []byte) ([]corev1.Taint, error) {
	return fake._PutNodeTaints(ctx, clusterName, name, loadBytes)
}

func (fake *WorkloadTest) CordonNode(ctx context.Context, cluster, node string, loadBytes []byte) (*corev1.Node, error) {
	return fake._CordonNode(ctx, cluster, node, loadBytes)
}

func (fake *WorkloadTest) PatchDaemonSet(_ context.Context, _, _, _ string, _ types.PatchType, _ []byte) (*appsv1.DaemonSet, error) {
	panic("implement me")
}

func (fake *WorkloadTest) ListControllerRevisionsByOwnerID(_ context.Context, _, _, _ string, _ *util.QueryPage) ([]appsv1.ControllerRevision, error) {
	panic("implement me")
}

func (fake *WorkloadTest) PatchStatefulSet(_ context.Context, _, _, _ string, _ types.PatchType, _ []byte) (*appsv1.StatefulSet, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) CreateJob(_ context.Context, _, _ string, _ *batchv1.Job) (*batchv1.Job, error) {
	panic("implement me")
}

func (fake *WorkloadTest) UpdateJob(_ context.Context, _, _ string, _ *batchv1.Job) (*batchv1.Job, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreateDeployment(_ context.Context, _, _ string, _ *appsv1.Deployment) (*appsv1.Deployment, error) {
	panic("implement me")
}

func (fake *WorkloadTest) UpdateDeployment(_ context.Context, _, _ string, _ *appsv1.Deployment) (*appsv1.Deployment, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreateStatefulSet(_ context.Context, _, _ string, _ *appsv1.StatefulSet) (*appsv1.StatefulSet, error) {
	panic("implement me")
}

func (fake *WorkloadTest) UpdateStatefulSet(_ context.Context, _, _ string, _ *appsv1.StatefulSet) (*appsv1.StatefulSet, error) {
	panic("implement me")
}

func (fake *WorkloadTest) CreateDaemonSet(_ context.Context, _, _ string, _ *appsv1.DaemonSet) (*appsv1.DaemonSet, error) {
	panic("implement me")
}

func (fake *WorkloadTest) UpdateDaemonSet(_ context.Context, _, _ string, _ *appsv1.DaemonSet) (*appsv1.DaemonSet, error) {
	panic("implement me")
}

func (fake *WorkloadTest) PatchDeployment(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.Deployment, error) {
	return fake._PatchDeployment(ctx, cluster, namespace, name, patchType, patchData)
}

func (fake *WorkloadTest) DeleteNamespace(ctx context.Context, cluster, namespace string) error {
	return fake._DeleteNamespace(ctx, cluster, namespace)
}

func (fake *WorkloadTest) CreateNamespace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error) {
	return fake._CreateNamespace(ctx, cluster, namespace)
}

func (fake *WorkloadTest) WatchNamespace(ctx context.Context, cluster, namespace string) (*corev1.Namespace, error) {
	return fake._WatchNamespace(ctx, cluster, namespace)
}

func (fake *WorkloadTest) UpdateNameSpace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error) {
	return fake._UpdateNameSpace(ctx, cluster, namespace)
}

func (fake *WorkloadTest) PatchNameSpace(ctx context.Context, cluster, name string, patchType types.PatchType, patchData []byte) (*corev1.Namespace, error) {
	return fake._PatchNameSpace(ctx, cluster, name, patchType, patchData)
}

func (fake *WorkloadTest) CreateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error) {
	return fake._CreateResourceQuota(ctx, cluster, namespace, quota)
}

func (fake *WorkloadTest) UpdateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error) {
	return fake._UpdateResourceQuota(ctx, cluster, namespace, quota)
}

func (fake *WorkloadTest) GetLimitRange(ctx context.Context, cluster, namespace, name string) (*corev1.LimitRange, error) {
	return fake._GetLimitRange(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) CreateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error) {
	return fake._CreateLimitRange(ctx, cluster, namespace, limitrange)
}

func (fake *WorkloadTest) UpdateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error) {
	return fake._UpdateLimitRange(ctx, cluster, namespace, limitrange)
}

func (fake *WorkloadTest) DeleteLimitRange(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeleteLimitRange(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) GetCronJob(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
	return fake._GetCronJob(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) GetJob(ctx context.Context, cluster, namespace, name string) (*batchv1.Job, error) {
	return fake._GetJob(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) RestartJob(ctx context.Context, cluster, namespace, name, resourceVersion string) (*batchv1.Job, error) {
	return fake._RestartJob(ctx, cluster, namespace, name, resourceVersion)
}

func (fake *WorkloadTest) ListCustomResources(ctx context.Context, gvr schema.GroupVersionResource, listOptions metav1.ListOptions) (*unstructured.UnstructuredList, error) {
	return fake._ListCustomResources(ctx, gvr, listOptions)
}

func (fake *WorkloadTest) GetCustomResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource) (*unstructured.Unstructured, error) {
	return fake._GetCustomResource(ctx, cluster, namespace, name, gvr)
}

func (fake *WorkloadTest) CreateCustomResource(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return fake._CreateCustomResource(ctx, cluster, namespace, gvr, obj)
}

func (fake *WorkloadTest) UpdateCustomResource(ctx context.Context, cluster, namespace string, gvr schema.GroupVersionResource, obj *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return fake._UpdateCustomResource(ctx, cluster, namespace, gvr, obj)
}

func (fake *WorkloadTest) DeleteCustomResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource, p *metav1.DeletionPropagation) error {
	return fake._DeleteCustomResource(ctx, cluster, namespace, name, gvr, p)
}

func (fake *WorkloadTest) DeleteJob(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeleteJob(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) DeleteCronJob(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeleteCronJob(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) PatchCronJob(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*unstructured.Unstructured, error) {
	return fake._PatchCronJob(ctx, cluster, namespace, name, patchType, patchData)
}

func (fake *WorkloadTest) ListJobs(ctx context.Context, _ metav1.ListOptions) (*batchv1.JobList, error) {
	return fake._ListJobs(ctx, "", nil)
}

func (fake *WorkloadTest) ListCronJobs(ctx context.Context, _ metav1.ListOptions) (*batchv1.CronJobList, error) {
	return fake._ListCronJobs(ctx, "", nil)
}

func (fake *WorkloadTest) DeleteDeployment(_ context.Context, _, _, _ string) error {
	//  TODO implement me.
	panic("implement me")
}

func (fake *WorkloadTest) DeleteStatefulSet(ctx context.Context, cluster, namespace, name string) error {
	//  TODO implement me.
	panic("implement me")
}

func (fake *WorkloadTest) GetConfigMap(_ context.Context, _, _, _ string) (*corev1.ConfigMap, error) {
	//  TODO implement me.
	panic("implement me")
}

func (fake *WorkloadTest) CreateConfigMap(_ context.Context, _, _ string, _ *corev1.ConfigMap) (*corev1.ConfigMap, error) {
	//  TODO implement me.
	panic("implement me")
}

func (fake *WorkloadTest) UpdateConfigMap(_ context.Context, _, _ string, _ *corev1.ConfigMap) (*corev1.ConfigMap, error) {
	//  TODO implement me.
	panic("implement me")
}

func (fake *WorkloadTest) PatchConfigMap(ctx context.Context, cluster, namespace, name string) (*corev1.ConfigMap, error) {
	//  TODO implement me.
	panic("implement me")
}

func (fake *WorkloadTest) DeleteConfigMap(ctx context.Context, cluster, namespace, name string) error {
	//  TODO implement me.
	panic("implement me")
}

func (fake *WorkloadTest) ListClusterJobs(ctx context.Context, clusters, namespace string, queryPage *util.QueryPage) ([]batchv1.Job, error) {
	return fake._ListClusterJobs(ctx, clusters, namespace, queryPage)
}

func (fake *WorkloadTest) ListClusterCronJobs(ctx context.Context, clusters, namespace string, queryPage *util.QueryPage) ([]batchv1.CronJob, error) {
	return fake._ListClusterCronJobs(ctx, clusters, namespace, queryPage)
}

func (fake *WorkloadTest) ListAllCronJobs(ctx context.Context, clusters []string, namespace string, queryPage *util.QueryPage) ([]batchv1.CronJob, error) {
	return fake._ListAllCronJobs(ctx, clusters, namespace, queryPage)
}

func (fake *WorkloadTest) ListAllJobs(ctx context.Context, clusters []string, namespace string, queryPage *util.QueryPage) ([]batchv1.Job, error) {
	return fake._ListAllJobs(ctx, clusters, namespace, queryPage)
}

func (fake *WorkloadTest) ListPodsByJobName(ctx context.Context, clusters, namespace, job string, queryPage *util.QueryPage) ([]corev1.Pod, error) {
	return fake._ListPodsByJobName(ctx, clusters, namespace, job, queryPage)
}

func (fake *WorkloadTest) ListPersistentVolumeClaims(ctx context.Context, _ metav1.ListOptions) (*corev1.PersistentVolumeClaimList, error) {
	return fake._ListPersistentVolumeClaims(ctx, "", "")
}

func (fake *WorkloadTest) ListServices(ctx context.Context, listOptions metav1.ListOptions) (*corev1.ServiceList, error) {
	return fake._ListServices(ctx, listOptions)
}

func (fake *WorkloadTest) GetService(ctx context.Context, cluster, namespace, name string) (*corev1.Service, error) {
	return fake._GetService(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) CreateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error) {
	return fake._CreateService(ctx, cluster, namespace, service)
}

func (fake *WorkloadTest) UpdateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error) {
	return fake._UpdateService(ctx, cluster, namespace, service)
}

func (fake *WorkloadTest) DeleteService(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeleteService(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) ListIngresses(ctx context.Context, _ metav1.ListOptions) (*networkingv1.IngressList, error) {
	return fake._ListIngresses(ctx, nil, "", nil)
}

func (fake *WorkloadTest) GetIngress(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
	return fake._GetIngress(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) CreateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return fake._CreateIngress(ctx, cluster, namespace, ingress)
}

func (fake *WorkloadTest) UpdateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return fake._UpdateIngress(ctx, cluster, namespace, ingress)
}

func (fake *WorkloadTest) PatchIngress(ctx context.Context, cluster, namespace, name string) (*networkingv1.Ingress, error) {
	return fake._PatchIngress(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) DeleteIngress(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeleteIngress(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) GetNetworkPolicy(ctx context.Context, cluster, namespace, name string) (*networkingv1.NetworkPolicy, error) {
	return fake._GetNetworkPolicy(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) CreateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error) {
	return fake._CreateNetworkPolicy(ctx, cluster, namespace, networkpolicy)
}

func (fake *WorkloadTest) UpdateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error) {
	return fake._UpdateNetworkPolicy(ctx, cluster, namespace, networkpolicy)
}

func (fake *WorkloadTest) DeleteNetworkPolicy(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeleteNetworkPolicy(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) ListDeployments(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.DeploymentList, error) {
	return fake._ListDeployments(ctx, listOptions)
}

func (fake *WorkloadTest) GetPod(ctx context.Context, cluster, namespaceName, podName string) (*corev1.Pod, error) {
	return fake._GetPod(ctx, cluster, namespaceName, podName)
}

func (fake *WorkloadTest) ListPodsByDeploymentUIDQueryPage(ctx context.Context, cluster, namespace, deploymentUID string, queryPage *util.QueryPage) ([]corev1.Pod, error) {
	return fake._ListPodsByDeploymentUIDQueryPage(ctx, cluster, namespace, deploymentUID, queryPage)
}

func (fake *WorkloadTest) ListReplicaSetUIDsByDeploymentUID(ctx context.Context, cluster, namespace, deploymentUID string) ([]string, error) {
	return fake._ListReplicaSetUIDsByDeploymentUID(ctx, cluster, namespace, deploymentUID)
}

func (fake *WorkloadTest) ListReplicaSetsByOwnerID(ctx context.Context, cluster, namespace, deploymentUID string, _ *util.QueryPage) ([]appsv1.ReplicaSet, error) {
	return fake._ListReplicaSetsByDeploymentUID(ctx, cluster, namespace, deploymentUID)
}

func (fake *WorkloadTest) ListPodsUIDsByOwnerReferencesUIDs(ctx context.Context, cluster, namespace string, uids []string) ([]string, error) {
	return fake._ListPodsUIDsByOwnerReferencesUIDs(ctx, cluster, namespace, uids)
}

func (fake *WorkloadTest) ListEventsByUIDs(ctx context.Context, cluster []string, namespace string, uids []string, queryPage *util.QueryPage) ([]corev1.Event, error) {
	return fake._ListEventsByUIDs(ctx, cluster, namespace, uids, queryPage)
}

func (fake *WorkloadTest) ListPodsByOwnerUIDsQueryPage(ctx context.Context, cluster, namespace string, ownerUIDs []string, queryPage *util.QueryPage) ([]corev1.Pod, error) {
	return fake._ListPodsByOwnerUIDsQueryPage(ctx, cluster, namespace, ownerUIDs, queryPage)
}

func (fake *WorkloadTest) ListClusterCronJobsJob(ctx context.Context, cluster, nameSpace, job string, queryPage *util.QueryPage) ([]batchv1.Job, error) {
	return fake._ListClusterCronJobsJob(ctx, cluster, nameSpace, job, queryPage)
}

func (fake *WorkloadTest) ListPodsByOwnerReferencesUIDs(ctx context.Context, cluster, namespace string, uids []string) ([]corev1.Pod, error) {
	return fake._ListPodsByOwnerReferencesUIDs(ctx, cluster, namespace, uids)
}

func (fake *WorkloadTest) ListPodsByDeploymentUID(ctx context.Context, cluster, namespace, deploymentUID string) ([]corev1.Pod, error) {
	return fake._ListPodsByDeploymentUID(ctx, cluster, namespace, deploymentUID)
}

func (fake *WorkloadTest) GetDaemonSet(ctx context.Context, cluster, namespace, name string) (*appsv1.DaemonSet, error) {
	return fake._GetDaemonSet(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) GetStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error) {
	return fake._GetStatefulSet(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) GetDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error) {
	return fake._GetDeployment(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) ListNamespaces(ctx context.Context, _ metav1.ListOptions) (*corev1.NamespaceList, error) {
	return fake._ListNamespaces(ctx, nil, nil)
}

func (fake *WorkloadTest) GetNamespace(ctx context.Context, cluster, name string) (*corev1.Namespace, error) {
	return fake._GetNamespace(ctx, cluster, name)
}

func (fake *WorkloadTest) ListResourceQuotas(ctx context.Context, opts metav1.ListOptions) (*corev1.ResourceQuotaList, error) {
	return fake._ListResourceQuotas(ctx, opts)
}

func (fake *WorkloadTest) GetResourceQuota(ctx context.Context, cluster, namespace, name string) (*corev1.ResourceQuota, error) {
	return fake._GetResourceQuota(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) ListDaemonSets(ctx context.Context, _ metav1.ListOptions) (*appsv1.DaemonSetList, error) {
	return fake._ListDaemonSets(ctx, nil, "")
}

func (fake *WorkloadTest) ListStatefulSets(ctx context.Context, _ metav1.ListOptions) (*appsv1.StatefulSetList, error) {
	return fake._ListStatefulSets(ctx, nil, "")
}

func (fake *WorkloadTest) ListDaemonSetsByQueryPage(ctx context.Context, clusters []string, namespace string, queryPage *util.QueryPage) ([]appsv1.DaemonSet, error) {
	return fake._ListDaemonSetsByQueryPage(ctx, clusters, namespace, queryPage)
}

func (fake *WorkloadTest) ListStatefulSetsByQueryPage(ctx context.Context, clusters []string, namespace string, queryPage *util.QueryPage) ([]appsv1.StatefulSet, error) {
	return fake._ListStatefulSetsByQueryPage(ctx, clusters, namespace, queryPage)
}

func (fake *WorkloadTest) ListPodsByQueryPage(ctx context.Context, clusters []string, namespace string, queryPage *util.QueryPage) ([]corev1.Pod, error) {
	return fake._ListPodsByQueryPage(ctx, clusters, namespace, queryPage)
}

func (fake *WorkloadTest) ListPodsByFieldSelector(ctx context.Context, cluster, field string, values []string, queryPage *util.QueryPage) ([]corev1.Pod, error) {
	return fake._ListPodsByFieldSelector(ctx, cluster, field, values, queryPage)
}

func (fake *WorkloadTest) UpdateSecret(ctx context.Context, cluster string, secret *corev1.Secret) (*corev1.Secret, error) {
	return fake._UpdateSecret(ctx, cluster, secret)
}

func (fake *WorkloadTest) GetSecret(ctx context.Context, clusterName, namespace, name string) (*corev1.Secret, error) {
	return fake._GetSecret(ctx, clusterName, namespace, name)
}

func (fake *WorkloadTest) DeleteSecret(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeleteSecret(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) DeletePod(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeletePod(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) DeleteDaemonSet(ctx context.Context, cluster, namespace, name string) error {
	return fake._DeleteDaemonSet(ctx, cluster, namespace, name)
}

func (fake *WorkloadTest) CreateSecret(ctx context.Context, cluster, namespace string, secret *corev1.Secret) (*corev1.Secret, error) {
	return fake._CreateSecret(ctx, cluster, namespace, secret)
}

func (fake *WorkloadTest) GetHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) ListHorizontalPodAutoscaler(ctx context.Context, opts metav1.ListOptions) (*autoscalingv2.HorizontalPodAutoscalerList, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) CreateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) UpdateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	panic("unimplemented")
}

func (fake *WorkloadTest) DeleteHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) error {
	panic("unimplemented")
}

func (fake *WorkloadTest) FetchCollectionResource(ctx context.Context, name string, opts metav1.ListOptions, params map[string]string) (*clusterpediav1beta1.CollectionResource, error) {
	return fake._FetchCollectionResource(ctx, name, opts, params)
}

func TestGetDeployStatusCore(t *testing.T) {
	type args struct {
		deploy *appsv1.Deployment
	}
	tests := []struct {
		name string
		args args
		want constants.WorkloadState
	}{
		{
			name: "deployment DeletionTimestamp is not nil",
			args: args{
				deploy: &appsv1.Deployment{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{DeletionTimestamp: &metav1.Time{Time: time.Now()}},
					Spec:       appsv1.DeploymentSpec{},
					Status:     appsv1.DeploymentStatus{},
				},
			},
			want: constants.WorkloadDeleting,
		},
		{
			name: "deployment  is not paused",
			args: args{
				deploy: &appsv1.Deployment{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec: appsv1.DeploymentSpec{
						Paused: true,
					},
					Status: appsv1.DeploymentStatus{},
				},
			},
			want: constants.WorkloadWaiting,
		},
		{
			name: "deployment is running",
			args: args{
				deploy: &appsv1.Deployment{
					// ObjectMeta: metav1.ObjectMeta{DeletionTimestamp: &metav1.Time{Time: time.Now()}},
					Spec: appsv1.DeploymentSpec{},
					Status: appsv1.DeploymentStatus{
						Replicas:          2,
						ReadyReplicas:     2,
						AvailableReplicas: 2,
						Conditions: []appsv1.DeploymentCondition{
							{
								Type:   appsv1.DeploymentAvailable,
								Status: corev1.ConditionTrue,
							},
						},
					},
				},
			},
			want: constants.WorkloadRunning,
		},
		{
			name: "deployment stopped",
			args: args{
				deploy: &appsv1.Deployment{
					// ObjectMeta: metav1.ObjectMeta{DeletionTimestamp: &metav1.Time{Time: time.Now()}},
					Spec: appsv1.DeploymentSpec{},
					Status: appsv1.DeploymentStatus{
						Replicas:          0,
						ReadyReplicas:     0,
						AvailableReplicas: 0,
						Conditions: []appsv1.DeploymentCondition{
							{
								Type:   appsv1.DeploymentAvailable,
								Status: corev1.ConditionTrue,
							},
						},
					},
				},
			},
			want: constants.WorkloadStopped,
		},
		{
			name: "deployment unknown",
			args: args{
				deploy: &appsv1.Deployment{
					// ObjectMeta: metav1.ObjectMeta{DeletionTimestamp: &metav1.Time{Time: time.Now()}},
					Spec: appsv1.DeploymentSpec{},
					Status: appsv1.DeploymentStatus{
						Replicas:      2,
						ReadyReplicas: 1,
						Conditions: []appsv1.DeploymentCondition{
							{
								Type:   appsv1.DeploymentProgressing,
								Status: corev1.ConditionTrue,
							},
						},
					},
				},
			},
			want: constants.WorkloadWaiting,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetDeployStatusCore(tt.args.deploy); got != tt.want {
				t.Errorf("GetDeployStatusPre() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetStatefulStatusCore(t *testing.T) {
	replicaset1 := new(int32)
	*replicaset1 = 3
	replicaset2 := new(int32)
	*replicaset2 = 0
	type args struct {
		statefulSet *appsv1.StatefulSet
	}
	tests := []struct {
		name string
		args args
		want constants.WorkloadState
	}{
		{
			name: "statefulSet DeletionTimestamp is not nil",
			args: args{
				statefulSet: &appsv1.StatefulSet{
					ObjectMeta: metav1.ObjectMeta{
						DeletionTimestamp: &metav1.Time{Time: time.Now()},
					},
					Spec:   appsv1.StatefulSetSpec{},
					Status: appsv1.StatefulSetStatus{},
				},
			},
			want: "Deleting",
		},
		{
			name: "statefulSet collisionCount  is nil",
			args: args{
				statefulSet: &appsv1.StatefulSet{
					ObjectMeta: metav1.ObjectMeta{
						// DeletionTimestamp: &metav1.Time{Time: time.Now()},
					},
					Spec: appsv1.StatefulSetSpec{},
					Status: appsv1.StatefulSetStatus{
						CollisionCount: nil,
						Replicas:       3,
					},
				},
			},
			want: constants.WorkloadWaiting,
		},
		{
			name: "statefulSet collisionCount  is nil",
			args: args{
				statefulSet: &appsv1.StatefulSet{
					ObjectMeta: metav1.ObjectMeta{
						// DeletionTimestamp: &metav1.Time{Time: time.Now()},
					},
					Spec: appsv1.StatefulSetSpec{
						Replicas: replicaset1,
					},
					Status: appsv1.StatefulSetStatus{
						Replicas:          *replicaset1,
						AvailableReplicas: *replicaset1,
						ReadyReplicas:     *replicaset1,
					},
				},
			},
			want: constants.WorkloadRunning,
		},
		{
			name: "statefulSet is not ready",
			args: args{
				statefulSet: &appsv1.StatefulSet{
					ObjectMeta: metav1.ObjectMeta{
						// DeletionTimestamp: &metav1.Time{Time: time.Now()},
					},
					Spec: appsv1.StatefulSetSpec{
						Replicas: replicaset1,
					},
					Status: appsv1.StatefulSetStatus{
						Replicas:          *replicaset1,
						AvailableReplicas: 2,
						ReadyReplicas:     2,
					},
				},
			},
			want: constants.WorkloadNotReady,
		},
		{
			name: "statefulSet stopped",
			args: args{
				statefulSet: &appsv1.StatefulSet{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec: appsv1.StatefulSetSpec{
						Replicas: replicaset2,
					},
					Status: appsv1.StatefulSetStatus{
						CollisionCount: replicaset2,
						Replicas:       *replicaset2,
					},
				},
			},
			want: constants.WorkloadStopped,
		},
		{
			name: "statefulSet unknown",
			args: args{
				statefulSet: &appsv1.StatefulSet{
					TypeMeta:   metav1.TypeMeta{},
					ObjectMeta: metav1.ObjectMeta{},
					Spec:       appsv1.StatefulSetSpec{},
					Status: appsv1.StatefulSetStatus{
						Replicas: *replicaset1,
					},
				},
			},
			want: constants.WorkloadWaiting,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetStatefulStatusCore(tt.args.statefulSet); got != tt.want {
				t.Errorf("GetStatefulStatusPre() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestGetDaemonSetStatusCore(t *testing.T) {
	type args struct {
		daemonSet *appsv1.DaemonSet
	}
	tests := []struct {
		name string
		args args
		want constants.WorkloadState
	}{
		{
			name: "daemonSet is deleted",
			args: args{daemonSet: &appsv1.DaemonSet{
				ObjectMeta: metav1.ObjectMeta{
					DeletionTimestamp: &metav1.Time{Time: time.Now()},
				},
				Spec:   appsv1.DaemonSetSpec{},
				Status: appsv1.DaemonSetStatus{},
			}},
			want: constants.WorkloadDeleting,
		},
		{
			name: "daemonSet is not ready",
			args: args{daemonSet: &appsv1.DaemonSet{
				ObjectMeta: metav1.ObjectMeta{},
				Spec:       appsv1.DaemonSetSpec{},
				Status: appsv1.DaemonSetStatus{
					NumberUnavailable: 1,
				},
			}},
			want: constants.WorkloadNotReady,
		},
		{
			name: "daemonSet is running",
			args: args{daemonSet: &appsv1.DaemonSet{
				TypeMeta:   metav1.TypeMeta{},
				ObjectMeta: metav1.ObjectMeta{},
				Spec:       appsv1.DaemonSetSpec{},
				Status: appsv1.DaemonSetStatus{
					NumberAvailable:        1,
					DesiredNumberScheduled: 1,
					CurrentNumberScheduled: 1,
				},
			}},
			want: constants.WorkloadRunning,
		},
		{
			name: "daemonSet stopped",
			args: args{daemonSet: &appsv1.DaemonSet{
				TypeMeta:   metav1.TypeMeta{},
				ObjectMeta: metav1.ObjectMeta{},
				Spec:       appsv1.DaemonSetSpec{},
				Status: appsv1.DaemonSetStatus{
					NumberAvailable:        0,
					DesiredNumberScheduled: 0,
					CurrentNumberScheduled: 0,
				},
			}},
			want: constants.WorkloadStopped,
		},
		{
			name: "daemonSet unknown",
			args: args{daemonSet: &appsv1.DaemonSet{
				TypeMeta:   metav1.TypeMeta{},
				ObjectMeta: metav1.ObjectMeta{},
				Spec:       appsv1.DaemonSetSpec{},
				Status: appsv1.DaemonSetStatus{
					NumberAvailable:        1,
					DesiredNumberScheduled: 2,
					CurrentNumberScheduled: 1,
				},
			}},
			want: constants.WorkloadWaiting,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := GetDaemonSetStatusCore(tt.args.daemonSet); got != tt.want {
				t.Errorf("GetDaemonSetStatusPre() = %v, want %v", got, tt.want)
			}
		})
	}
}

//func TestWorkloadServices_ListDeployments(t *testing.T) {
//	tests := []struct {
//		name string
//		in   struct {
//			ctx       context.Context
//			cluster   []string
//			nameSpace []string
//		}
//		out struct {
//			res []batchv1.Job
//			err error
//		}
//	}{
//		{
//			name: "TestWorkloadServices_ListDeployments",
//			in: struct {
//				ctx       context.Context
//				cluster   []string
//				nameSpace []string
//			}{ctx: context.TODO(), cluster: []string{"test"}, nameSpace: []string{"test"}},
//			out: struct {
//				res []batchv1.Job
//				err error
//			}{res: nil, err: nil},
//		},
//	}
//	wt := WorkloadTest{}
//	wt._ListDeployments = func(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.DeploymentList, error) {
//		return &appsv1.DeploymentList{}, nil
//	}
//	ws := &WorkloadServices{
//		engine: &wt,
//	}
//	for _, v := range tests {
//		t.Run(v.name, func(t *testing.T) {
//			res, err := ws.ListDeployments(v.in.ctx, &util.ListOptions{})
//			if reflect.DeepEqual(res, v.out.res) && !errors.Is(err, v.out.err) {
//				t.Fail()
//			}
//		})
//	}
//}

func TestWorkloadServices_ListPodsContainers(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx       context.Context
			cluster   string
			nameSpace string
			podName   string
		}
		out struct {
			res []batchv1.Job
			err error
		}
	}{
		{
			name: "TestWorkloadServices_ListPodsContainers",
			in: struct {
				ctx       context.Context
				cluster   string
				nameSpace string
				podName   string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", podName: "test"},
			out: struct {
				res []batchv1.Job
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._GetPod = func(ctx context.Context, cluster, namespaceName, podName string) (*corev1.Pod, error) {
		return nil, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			res, err := ws.GetPod(v.in.ctx, v.in.cluster, v.in.nameSpace, v.in.podName)
			if reflect.DeepEqual(res, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

//func TestWorkloadServices_ListDaemonSets(t *testing.T) {
//	tests := []struct {
//		name string
//		in   struct {
//			ctx       context.Context
//			cluster   []string
//			nameSpace string
//		}
//		out struct {
//			res []batchv1.Job
//			err error
//		}
//	}{
//		{
//			name: "TestWorkloadServices_ListDaemonSets",
//			in: struct {
//				ctx       context.Context
//				cluster   []string
//				nameSpace string
//			}{ctx: context.TODO(), cluster: []string{"test"}, nameSpace: "test"},
//			out: struct {
//				res []batchv1.Job
//				err error
//			}{res: nil, err: nil},
//		},
//	}
//	wt := WorkloadTest{}
//	wt._ListDaemonSets = func(ctx context.Context, clusters []string, namespace string) (*appsv1.DaemonSetList, error) {
//		return &appsv1.DaemonSetList{}, nil
//	}
//	ws := &WorkloadServices{
//		engine: &wt,
//	}
//	for _, v := range tests {
//		t.Run(v.name, func(t *testing.T) {
//			res, err := ws.ListDaemonSets(v.in.ctx, &util.ListOptions{})
//			if reflect.DeepEqual(res, v.out.res) && err != v.out.err {
//				t.Fail()
//			}
//		})
//	}
//}

//func TestWorkloadServices_ListStatefulSets(t *testing.T) {
//	tests := []struct {
//		name string
//		in   struct {
//			ctx       context.Context
//			cluster   []string
//			nameSpace string
//		}
//		out struct {
//			res []batchv1.Job
//			err error
//		}
//	}{
//		{
//			name: "TestWorkloadServices_ListStatefulSets",
//			in: struct {
//				ctx       context.Context
//				cluster   []string
//				nameSpace string
//			}{ctx: context.TODO(), cluster: []string{"test"}, nameSpace: "test"},
//			out: struct {
//				res []batchv1.Job
//				err error
//			}{res: nil, err: nil},
//		},
//	}
//	wt := WorkloadTest{}
//	wt._ListStatefulSets = func(ctx context.Context, clusters []string, namespace string) (*appsv1.StatefulSetList, error) {
//		return &appsv1.StatefulSetList{}, nil
//	}
//	ws := &WorkloadServices{
//		engine: &wt,
//	}
//	for _, v := range tests {
//		t.Run(v.name, func(t *testing.T) {
//			res, err := ws.ListStatefulSets(v.in.ctx, &util.ListOptions{})
//			if reflect.DeepEqual(res, v.out.res) && err != v.out.err {
//				t.Fail()
//			}
//		})
//	}
//}

//func TestWorkloadServices_ListDeploymentsByQueryPage(t *testing.T) {
//	tests := []struct {
//		name string
//		in   struct {
//			ctx       context.Context
//			cluster   []string
//			nameSpace []string
//			queryPage *util.QueryPage
//		}
//		out struct {
//			res *appsv1.DeploymentList
//			err error
//		}
//	}{
//		{
//			name: "TestWorkloadServices_ListDeploymentsByQueryPage",
//			in: struct {
//				ctx       context.Context
//				cluster   []string
//				nameSpace []string
//				queryPage *util.QueryPage
//			}{ctx: context.TODO(), cluster: []string{"test"}, nameSpace: []string{"test"}, queryPage: &util.QueryPage{}},
//			out: struct {
//				res *appsv1.DeploymentList
//				err error
//			}{res: &appsv1.DeploymentList{}, err: nil},
//		},
//	}
//	wt := WorkloadTest{}
//	wt._ListDeployments = func(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.DeploymentList, error) {
//		return &appsv1.DeploymentList{}, nil
//	}
//	ws := &WorkloadServices{
//		engine: &wt,
//	}
//	for _, v := range tests {
//		t.Run(v.name, func(t *testing.T) {
//			_, err := ws.ListDeployments(v.in.ctx, &util.ListOptions{})
//			if err != v.out.err {
//				t.Fail()
//			}
//		})
//	}
//}

func TestWorkloadServices_GetDeployment(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx       context.Context
			cluster   string
			nameSpace string
			name      string
		}
		out struct {
			res *appsv1.Deployment
			err error
		}
	}{
		{
			name: "TestWorkloadServices_GetDeployment",
			in: struct {
				ctx       context.Context
				cluster   string
				nameSpace string
				name      string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", name: "test"},
			out: struct {
				res *appsv1.Deployment
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._GetDeployment = func(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error) {
		return nil, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			deployment, err := ws.GetDeployment(v.in.ctx, v.in.cluster, v.in.nameSpace, v.in.name)
			if reflect.DeepEqual(deployment, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

func TestWorkloadServices_GetStatefulSet(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx       context.Context
			cluster   string
			nameSpace string
			name      string
		}
		out struct {
			res []batchv1.Job
			err error
		}
	}{
		{
			name: "TestWorkloadServices_GetStatefulSet",
			in: struct {
				ctx       context.Context
				cluster   string
				nameSpace string
				name      string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", name: "test"},
			out: struct {
				res []batchv1.Job
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._GetStatefulSet = func(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error) {
		return nil, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			res, err := ws.GetStatefulSet(v.in.ctx, v.in.cluster, v.in.nameSpace, v.in.name)
			if reflect.DeepEqual(res, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

func TestWorkloadServices_GetDaemonSet(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx       context.Context
			cluster   string
			nameSpace string
			name      string
		}
		out struct {
			res *appsv1.DaemonSet
			err error
		}
	}{
		{
			name: "TestWorkloadServices_GetDaemonSet",
			in: struct {
				ctx       context.Context
				cluster   string
				nameSpace string
				name      string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", name: "test"},
			out: struct {
				res *appsv1.DaemonSet
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._GetDaemonSet = func(ctx context.Context, cluster, nameSpace, name string) (*appsv1.DaemonSet, error) {
		return nil, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			res, err := ws.GetDaemonSet(v.in.ctx, v.in.cluster, v.in.nameSpace, v.in.name)
			if reflect.DeepEqual(res, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

func TestWorkloadServices_ListDeploymentEvents(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx        context.Context
			cluster    string
			nameSpace  string
			deployName string
		}
		out struct {
			res []corev1.Event
			err error
		}
	}{
		{
			name: "TestWorkloadServices_ListDeploymentEvents",
			in: struct {
				ctx        context.Context
				cluster    string
				nameSpace  string
				deployName string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", deployName: "test"},
			out: struct {
				res []corev1.Event
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._GetDeployment = func(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error) {
		return &appsv1.Deployment{
			ObjectMeta: metav1.ObjectMeta{
				UID: "test",
			},
		}, nil
	}
	wt._ListReplicaSetUIDsByDeploymentUID = func(ctx context.Context, cluster, namespace, deploymentUID string) ([]string, error) {
		return []string{}, nil
	}
	wt._ListPodsUIDsByOwnerReferencesUIDs = func(ctx context.Context, cluster, namespace string, uids []string) ([]string, error) {
		return []string{}, nil
	}
	wt._ListEventsByUIDs = func(ctx context.Context, cluster []string, namespace string, uids []string, queryPage *util.QueryPage) ([]corev1.Event, error) {
		return nil, nil
	}
	wt._ListReplicaSets = func(ctx context.Context, listOptions metav1.ListOptions) (*appsv1.ReplicaSetList, error) {
		return &appsv1.ReplicaSetList{}, nil
	}
	wt._ListPods = func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PodList, error) {
		return &corev1.PodList{}, nil
	}
	wt._ListEvents = func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.EventList, error) {
		return &corev1.EventList{}, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			job, err := ws.ListEventsByDeployment(v.in.ctx, v.in.cluster, v.in.nameSpace, v.in.deployName, &util.QueryPage{})
			if reflect.DeepEqual(job, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

func TestWorkloadServices_ListStatefulSetEvents(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx       context.Context
			cluster   string
			nameSpace string
			name      string
		}
		out struct {
			res []corev1.Event
			err error
		}
	}{
		{
			name: "TestWorkloadServices_ListStatefulSetEvents",
			in: struct {
				ctx       context.Context
				cluster   string
				nameSpace string
				name      string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", name: "test"},
			out: struct {
				res []corev1.Event
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._GetStatefulSet = func(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error) {
		return &appsv1.StatefulSet{
			ObjectMeta: metav1.ObjectMeta{
				UID: "test",
			},
		}, nil
	}
	wt._ListPods = func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PodList, error) {
		return &corev1.PodList{}, nil
	}
	wt._ListEvents = func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.EventList, error) {
		return &corev1.EventList{}, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			job, err := ws.ListEventsByStatefulSet(v.in.ctx, v.in.cluster, v.in.nameSpace, v.in.name, &util.QueryPage{})
			if reflect.DeepEqual(job, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

func TestWorkloadServices_ListDaemonSetEvents(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx       context.Context
			cluster   string
			nameSpace string
			name      string
		}
		out struct {
			res []corev1.Event
			err error
		}
	}{
		{
			name: "TestWorkloadServices_ListStatefulSetEvents",
			in: struct {
				ctx       context.Context
				cluster   string
				nameSpace string
				name      string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", name: "test"},
			out: struct {
				res []corev1.Event
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._GetDaemonSet = func(ctx context.Context, cluster, namespace, name string) (*appsv1.DaemonSet, error) {
		return &appsv1.DaemonSet{
			ObjectMeta: metav1.ObjectMeta{
				UID: "test",
			},
		}, nil
	}
	wt._ListPods = func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.PodList, error) {
		return &corev1.PodList{}, nil
	}
	wt._ListEvents = func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.EventList, error) {
		return &corev1.EventList{}, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			events, err := ws.ListEventsByDaemonSet(v.in.ctx, v.in.cluster, v.in.nameSpace, v.in.name, &util.QueryPage{})
			if reflect.DeepEqual(events, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

func TestWorkloadServices_ListEventsByService(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx       context.Context
			cluster   string
			nameSpace string
			name      string
		}
		out struct {
			res []corev1.Event
			err error
		}
	}{
		{
			name: "TestWorkloadServices_ListStatefulSetEvents",
			in: struct {
				ctx       context.Context
				cluster   string
				nameSpace string
				name      string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", name: "test"},
			out: struct {
				res []corev1.Event
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._GetService = func(ctx context.Context, cluster, namespace, name string) (*corev1.Service, error) {
		return &corev1.Service{}, nil
	}
	wt._ListEvents = func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.EventList, error) {
		return &corev1.EventList{}, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			events, err := ws.ListEventsByService(v.in.ctx, v.in.cluster, v.in.nameSpace, v.in.name, &util.QueryPage{})
			if reflect.DeepEqual(events, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

func TestWorkloadServices_ListEvents(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx       context.Context
			cluster   string
			nameSpace string
			name      string
		}
		out struct {
			res []corev1.Event
			err error
		}
	}{
		{
			name: "TestWorkloadServices_ListStatefulSetEvents",
			in: struct {
				ctx       context.Context
				cluster   string
				nameSpace string
				name      string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", name: "test"},
			out: struct {
				res []corev1.Event
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._ListEvents = func(ctx context.Context, listOptions metav1.ListOptions) (*corev1.EventList, error) {
		return &corev1.EventList{}, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			events, err := ws.ListEvents(v.in.ctx, &util.ListOptions{})
			if reflect.DeepEqual(events, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

//func TestWorkloadServices_ListClusterJob(t *testing.T) {
//	tests := []struct {
//		name string
//		in   struct {
//			ctx       context.Context
//			cluster   string
//			nameSpace string
//			quertPage *util.QueryPage
//		}
//		out struct {
//			res []batchv1.Job
//			err error
//		}
//	}{
//		{
//			name: "TestWorkloadServices_ListClusterJob",
//			in: struct {
//				ctx       context.Context
//				cluster   string
//				nameSpace string
//				quertPage *util.QueryPage
//			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", quertPage: nil},
//			out: struct {
//				res []batchv1.Job
//				err error
//			}{res: nil, err: nil},
//		},
//	}
//	wt := WorkloadTest{}
//	wt._ListCronJobs = func(ctx context.Context, cluster string, queryPage *util.QueryPage) (*batchv1.CronJobList, error) {
//		return &batchv1.CronJobList{}, nil
//	}
//	ws := &WorkloadServices{
//		engine: &wt,
//	}
//	for i := 0; i < len(tests); i++ {
//		t.Run(tests[i].name, func(t *testing.T) {
//			job, err := ws.ListCronJobs(tests[i].in.ctx, &util.ListOptions{})
//			if reflect.DeepEqual(job, tests[i].out.res) && err != tests[i].out.err {
//				t.Fail()
//			}
//		})
//	}
//}

func TestWorkloadServices_ListClusterCronJobsJob(t *testing.T) {
	tests := []struct {
		name string
		in   struct {
			ctx       context.Context
			cluster   string
			nameSpace string
			jobName   string
		}
		out struct {
			res []batchv1.Job
			err error
		}
	}{
		{
			name: "TestWorkloadServices_ListClusterCronJobsJob",
			in: struct {
				ctx       context.Context
				cluster   string
				nameSpace string
				jobName   string
			}{ctx: context.TODO(), cluster: "test", nameSpace: "test", jobName: "test"},
			out: struct {
				res []batchv1.Job
				err error
			}{res: nil, err: nil},
		},
	}
	wt := WorkloadTest{}
	wt._ListClusterCronJobsJob = func(ctx context.Context, cluster, nameSpace, jobName string, queypage *util.QueryPage) ([]batchv1.Job, error) {
		return nil, nil
	}
	wt._ListJobs = func(ctx context.Context, cluster string, queryPage *util.QueryPage) (*batchv1.JobList, error) {
		return &batchv1.JobList{}, nil
	}
	wt._GetCronJob = func(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
		return &unstructured.Unstructured{}, nil
	}
	ws := &WorkloadServices{
		engine: &wt,
	}
	for _, v := range tests {
		t.Run(v.name, func(t *testing.T) {
			job, err := ws.ListJobsByCronJob(v.in.ctx, v.in.cluster, v.in.nameSpace, v.in.jobName, nil)
			if reflect.DeepEqual(job, v.out.res) && err != v.out.err {
				t.Fail()
			}
		})
	}
}

func TestClusterServices_GetNode(t *testing.T) {
	sch := clusterscheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &WorkloadServices{}
	mockClusterEngine := &WorkloadTest{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._GetNode = func(ctx context.Context, cluster, name string) (*corev1.Node, error) {
		return nil, nil
	}

	_, err := mockClusterService.GetNode(context.Background(), "cluster1", "foo")
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_PutNodeLabels(t *testing.T) {
	sch := clusterscheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &WorkloadServices{}
	mockClusterEngine := &WorkloadTest{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._PutNodeLabels = func(ctx context.Context, clusterName, name string, loadBytes []byte) (map[string]string, error) {
		return nil, nil
	}
	countryCapitalMap := map[string]string{"France": "Paris", "Italy": "Rome", "Japan": "Tokyo", "India": "New delhi"}
	_, err := mockClusterService.PutNodeLabels(context.Background(), "fqq", "dao", countryCapitalMap)
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_PutNodeTaints(t *testing.T) {
	sch := clusterscheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &WorkloadServices{}
	mockClusterEngine := &WorkloadTest{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._PutNodeTaints = func(ctx context.Context, clusterName, name string, loadBytes []byte) ([]corev1.Taint, error) {
		return nil, nil
	}
	taints := []*corev1.Taint{
		{
			Key:   "key",
			Value: "value",
		},
	}
	_, err := mockClusterService.PutNodeTaints(context.Background(), "fqq", "dao", taints)
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_CordonNode(t *testing.T) {
	sch := clusterscheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &WorkloadServices{}
	mockClusterEngine := &WorkloadTest{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._CordonNode = func(ctx context.Context, cluster, node string, loadBytes []byte) (*corev1.Node, error) {
		return nil, nil
	}

	_, err := mockClusterService.CordonNode(context.Background(), "fqq", "dao", false)
	if err != nil {
		t.Fail()
	}
}

func Test_equalIgnoreHash(t *testing.T) {
	type args struct {
		template1 *corev1.PodTemplateSpec
		template2 *corev1.PodTemplateSpec
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		{
			name: "test equal ingore hash",
			args: args{
				template1: &corev1.PodTemplateSpec{
					ObjectMeta: metav1.ObjectMeta{
						Name: "pod1",
					},
				},
				template2: &corev1.PodTemplateSpec{
					ObjectMeta: metav1.ObjectMeta{
						Name: "pod1",
					},
				},
			},
			want: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := equalIgnoreHash(tt.args.template1, tt.args.template2); got != tt.want {
				t.Errorf("equalIgnoreHash() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_getDeploymentPatch(t *testing.T) {
	patch, _ := json.Marshal([]interface{}{
		map[string]interface{}{
			"op":    "replace",
			"path":  "/spec/template",
			"value": &corev1.PodTemplateSpec{},
		},
		map[string]interface{}{
			"op":    "replace",
			"path":  "/metadata/annotations",
			"value": map[string]string{},
		},
	})
	type args struct {
		podTemplate *corev1.PodTemplateSpec
		annotations map[string]string
	}
	tests := []struct {
		name    string
		args    args
		want    types.PatchType
		want1   []byte
		wantErr bool
	}{
		{
			name: "test get deployment patch",
			args: args{
				podTemplate: &corev1.PodTemplateSpec{},
				annotations: map[string]string{},
			},
			want:    types.JSONPatchType,
			want1:   patch,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1, err := getDeploymentPatch(tt.args.podTemplate, tt.args.annotations)
			if (err != nil) != tt.wantErr {
				t.Errorf("getDeploymentPatch() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("getDeploymentPatch() got = %v, want %v", got, tt.want)
			}
			if !reflect.DeepEqual(got1, tt.want1) {
				t.Errorf("getDeploymentPatch() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

func TestWorkloadServices_GetNamespace(t *testing.T) {
	mockClusterService := &WorkloadServices{}
	mockClusterEngine := &WorkloadTest{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._GetNamespace = func(ctx context.Context, cluster, name string) (*corev1.Namespace, error) {
		return nil, nil
	}
	type fields struct {
		engine       engine.Workload
		customEngine engine.CustomClient
	}
	type args struct {
		ctx     context.Context
		cluster string
		name    string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.Namespace
		wantErr bool
	}{
		{
			name: "test get namespace",
			fields: fields{
				engine:       mockClusterEngine,
				customEngine: nil,
			},
			args:    args{},
			want:    nil,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ws := &WorkloadServices{
				engine:       tt.fields.engine,
				customEngine: tt.fields.customEngine,
			}
			got, err := ws.GetNamespace(tt.args.ctx, tt.args.cluster, tt.args.name)
			if (err != nil) != tt.wantErr {
				t.Errorf("WorkloadServices.GetNamespace() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("WorkloadServices.GetNamespace() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestWorkloadServices_RestartJob(t *testing.T) {
	ctx := context.WithValue(context.Background(), constants.LoadResourceSchemaKey, constants.MemberCluster)

	c := engine.NewFakeAddonClusterClient()
	client, err := c.GetClient("cluster")
	assert.NoError(t, err)

	job, err := client.BatchV1().Jobs("ns").Create(context.Background(), &batchv1.Job{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: "ns",
			Name:      "job",
			Annotations: map[string]string{
				"revisions": "",
			},
			Labels: map[string]string{},
		},
		Spec: batchv1.JobSpec{
			Selector: &metav1.LabelSelector{},
			Template: corev1.PodTemplateSpec{},
		},
	}, metav1.CreateOptions{})
	assert.NoError(t, err)

	type fields struct {
		engine       engine.Workload
		customEngine engine.CustomClient
	}
	type args struct {
		ctx             context.Context
		cluster         string
		namespace       string
		name            string
		resourceVersion string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *batchv1.Job
		wantErr bool
	}{
		{
			name: "job not exist, restart failed",
			fields: fields{
				engine: engine.NewFakeWorkloadEngine(engine.NewFakeAddonClusterClient()),
			},
			args: args{
				ctx:             ctx,
				cluster:         "cluster",
				namespace:       "ns",
				name:            "not-exist-job",
				resourceVersion: "1",
			},
			want:    nil,
			wantErr: true,
		},
		{
			name: "restart job successfully",
			fields: fields{
				engine: engine.NewFakeWorkloadEngine(c),
			},
			args: args{
				ctx:             ctx,
				cluster:         "cluster",
				namespace:       job.Namespace,
				name:            job.Name,
				resourceVersion: job.ResourceVersion,
			},
			want:    job,
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ws := &WorkloadServices{
				engine:       tt.fields.engine,
				customEngine: tt.fields.customEngine,
			}
			got, err := ws.RestartJob(tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.name, tt.args.resourceVersion)
			if (err != nil) != tt.wantErr {
				t.Errorf("RestartJob() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			assert.Equal(t, got, tt.want)
		})
	}
}

func TestWorkloadServices_UpdateCustomResourceDefinition(t *testing.T) {
	unstructuredCrd, err := helper.ConvertToUnstructured(&apiextensionsv1.CustomResourceDefinition{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Crd",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: "mycrd",
		},
		Spec: apiextensionsv1.CustomResourceDefinitionSpec{
			Group: "",
			Names: apiextensionsv1.CustomResourceDefinitionNames{
				Plural:   "crds",
				Singular: "crd",
				Kind:     "Crd",
				ListKind: "CrdList",
			},
			Scope: apiextensionsv1.ClusterScoped,
			Versions: []apiextensionsv1.CustomResourceDefinitionVersion{
				{
					Name:    "mycrd",
					Served:  true,
					Storage: true,
				},
			},
		},
	})
	assert.NoError(t, err)

	c := engine.NewFakeAddonClusterClient()
	we := &engine.WorkloadEngine{}
	we.SetClientSet(c)

	type fields struct {
		engine       engine.Workload
		customEngine engine.CustomClient
	}
	type args struct {
		ctx     context.Context
		cluster string
		obj     *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *apiextensionsv1.CustomResourceDefinition
		wantErr bool
	}{
		{
			name: "crd not exist, update failed",
			fields: fields{
				engine: we,
			},
			args: args{
				ctx:     context.TODO(),
				cluster: "cluster",
				obj:     unstructuredCrd,
			},
			want:    nil,
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ws := &WorkloadServices{
				engine:       tt.fields.engine,
				customEngine: tt.fields.customEngine,
			}
			got, err := ws.UpdateCustomResourceDefinition(tt.args.ctx, tt.args.cluster, tt.args.obj)
			if (err != nil) != tt.wantErr {
				t.Errorf("UpdateCustomResourceDefinition() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("UpdateCustomResourceDefinition() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestWorkloadServices_CreateCustomResourceDefinition(t *testing.T) {
	unstructuredCrd, err := helper.ConvertToUnstructured(&apiextensionsv1.CustomResourceDefinition{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Crd",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: "mycrd",
		},
		Spec: apiextensionsv1.CustomResourceDefinitionSpec{
			Group: "",
			Names: apiextensionsv1.CustomResourceDefinitionNames{
				Plural:   "crds",
				Singular: "crd",
				Kind:     "Crd",
				ListKind: "CrdList",
			},
			Scope: apiextensionsv1.ClusterScoped,
			Versions: []apiextensionsv1.CustomResourceDefinitionVersion{
				{
					Name:    "mycrd",
					Served:  true,
					Storage: true,
				},
			},
		},
	})
	assert.NoError(t, err)

	cc := engine.NewFakeAddonClusterClient()
	we := &engine.WorkloadEngine{}
	we.SetClientSet(cc)

	crd := &apiextensionsv1.CustomResourceDefinition{}
	assert.NoError(t, runtime.DefaultUnstructuredConverter.FromUnstructured(unstructuredCrd.UnstructuredContent(), crd))

	type fields struct {
		engine       engine.Workload
		customEngine engine.CustomClient
	}
	type args struct {
		ctx     context.Context
		cluster string
		obj     *unstructured.Unstructured
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *apiextensionsv1.CustomResourceDefinition
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "resources not exist, create successfully",
			fields: fields{
				engine: we,
			},
			args: args{
				ctx:     context.TODO(),
				cluster: "cluster",
				obj:     unstructuredCrd,
			},
			want:    crd,
			wantErr: assert.NoError,
		},
		{
			name: "resources has already exist, create successfully",
			fields: fields{
				engine: we,
			},
			args: args{
				ctx:     context.TODO(),
				cluster: "cluster",
				obj:     unstructuredCrd,
			},
			want:    nil,
			wantErr: assert.Error,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ws := &WorkloadServices{
				engine:       tt.fields.engine,
				customEngine: tt.fields.customEngine,
			}
			got, err := ws.CreateCustomResourceDefinition(tt.args.ctx, tt.args.cluster, tt.args.obj)
			if !tt.wantErr(t, err, fmt.Sprintf("CreateCustomResourceDefinition(%v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.obj)) {
				return
			}
			assert.Equalf(t, tt.want, got, "CreateCustomResourceDefinition(%v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.obj)
		})
	}
}

func TestWorkloadServices_EnsureNamespace(t *testing.T) {
	ctx := context.WithValue(context.Background(), constants.LoadResourceSchemaKey, constants.MemberCluster)

	c := engine.NewFakeAddonClusterClient()
	client, err := c.GetClient("cluster")
	assert.NoError(t, err)

	ns := &corev1.Namespace{
		TypeMeta: metav1.TypeMeta{},
		ObjectMeta: metav1.ObjectMeta{
			Name: "ns",
		},
		Spec:   corev1.NamespaceSpec{},
		Status: corev1.NamespaceStatus{},
	}

	ns, err = client.CoreV1().Namespaces().Create(ctx, ns, metav1.CreateOptions{})
	assert.NoError(t, err)

	type fields struct {
		engine       engine.Workload
		customEngine engine.CustomClient
	}
	type args struct {
		ctx       context.Context
		cluster   string
		namespace string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *corev1.Namespace
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "ns already exists",
			fields: fields{
				engine: engine.NewFakeWorkloadEngine(c),
			},
			args: args{
				ctx:       ctx,
				cluster:   "cluster",
				namespace: "ns",
			},
			want:    ns,
			wantErr: assert.NoError,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ws := &WorkloadServices{
				engine:       tt.fields.engine,
				customEngine: tt.fields.customEngine,
			}
			got, err := ws.EnsureNamespace(tt.args.ctx, tt.args.cluster, tt.args.namespace)
			if !tt.wantErr(t, err, fmt.Sprintf("EnsureNamespace(%v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.namespace)) {
				return
			}
			assert.Equalf(t, tt.want, got, "EnsureNamespace(%v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.namespace)
		})
	}
}

func TestWorkloadServices_UpdateNodeAnnotations(t *testing.T) {
	ctx := context.WithValue(context.Background(), constants.LoadResourceSchemaKey, constants.MemberCluster)

	c := engine.NewFakeAddonClusterClient()
	client, err := c.GetClient("cluster")
	assert.NoError(t, err)

	node := &corev1.Node{
		TypeMeta: metav1.TypeMeta{},
		ObjectMeta: metav1.ObjectMeta{
			Name:        "node",
			Annotations: map[string]string{},
		},
	}

	node, err = client.CoreV1().Nodes().Create(ctx, node, metav1.CreateOptions{})
	assert.NoError(t, err)
	assert.NotEmpty(t, node)

	type fields struct {
		engine       engine.Workload
		customEngine engine.CustomClient
	}
	type args struct {
		ctx         context.Context
		cluster     string
		node        string
		annotations map[string]string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    map[string]string
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "node not exists, patch failed",
			fields: fields{
				engine: engine.NewFakeWorkloadEngine(engine.NewFakeAddonClusterClient()),
			},
			args: args{
				ctx:         ctx,
				cluster:     "cluster",
				node:        "not-exist-node",
				annotations: map[string]string{},
			},
			want:    nil,
			wantErr: assert.Error,
		},
		{
			name: "node exists, patch successfully",
			fields: fields{
				engine: engine.NewFakeWorkloadEngine(c),
			},
			args: args{
				ctx:     ctx,
				cluster: "cluster",
				node:    node.Name,
				annotations: map[string]string{
					"foo": "bar",
				},
			},
			want: map[string]string{
				"foo": "bar",
			},
			wantErr: assert.NoError,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ws := &WorkloadServices{
				engine:       tt.fields.engine,
				customEngine: tt.fields.customEngine,
			}
			got, err := ws.UpdateNodeAnnotations(tt.args.ctx, tt.args.cluster, tt.args.node, tt.args.annotations)
			if !tt.wantErr(t, err, fmt.Sprintf("UpdateNodeAnnotations(%v, %v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.node, tt.args.annotations)) {
				return
			}
			assert.Equalf(t, tt.want, got, "UpdateNodeAnnotations(%v, %v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.node, tt.args.annotations)
		})
	}
}

func TestWorkloadServices_ResumeDeployment(t *testing.T) {
	ctx := context.WithValue(context.Background(), constants.LoadResourceSchemaKey, constants.MemberCluster)

	c := engine.NewFakeAddonClusterClient()
	client, err := c.GetClient("cluster")
	assert.NoError(t, err)

	deploy1 := &appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "deploy1",
			Namespace: "ns",
		},
		Spec: appsv1.DeploymentSpec{
			Paused: false,
		},
	}

	_, err = client.AppsV1().Deployments(deploy1.Namespace).Create(ctx, deploy1, metav1.CreateOptions{})
	assert.NoError(t, err)

	deploy2 := &appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "deploy2",
			Namespace: "ns",
		},
		Spec: appsv1.DeploymentSpec{
			Paused: true,
		},
	}

	_, err = client.AppsV1().Deployments(deploy2.Namespace).Create(ctx, deploy2, metav1.CreateOptions{})
	assert.NoError(t, err)

	type fields struct {
		engine       engine.Workload
		customEngine engine.CustomClient
	}
	type args struct {
		ctx       context.Context
		cluster   string
		namespace string
		name      string
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    *appsv1.Deployment
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "deployment is not paused, resume failed",
			fields: fields{
				engine: engine.NewFakeWorkloadEngine(c),
			},
			args: args{
				ctx:       ctx,
				cluster:   "cluster",
				namespace: deploy1.Namespace,
				name:      deploy1.Name,
			},
			want:    nil,
			wantErr: assert.Error,
		},
		{
			name: "deployment is paused, resume successfully",
			fields: fields{
				engine: engine.NewFakeWorkloadEngine(c),
			},
			args: args{
				ctx:       ctx,
				cluster:   "cluster",
				namespace: deploy2.Namespace,
				name:      deploy2.Name,
			},
			want:    deploy2,
			wantErr: assert.NoError,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ws := &WorkloadServices{
				engine:       tt.fields.engine,
				customEngine: tt.fields.customEngine,
			}
			_, err := ws.ResumeDeployment(tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.name)
			if !tt.wantErr(t, err, fmt.Sprintf("ResumeDeployment(%v, %v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.name)) {
				return
			}
			if err != nil {
				return
			}
		})
	}
}

func TestWorkloadServices_DeleteCustomResourceDefinition(t *testing.T) {
	ctrl := gomock.NewController(t)
	w := engine.NewMockWorkload(ctrl)
	type args struct {
		ctx     context.Context
		cluster string
		name    string
	}
	tests := []struct {
		name    string
		args    args
		prepare func()
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "TestWorkloadServices_DeleteCustomResourceDefinition it should work normally",
			args: args{
				ctx:     context.TODO(),
				cluster: "test",
				name:    "test",
			},
			prepare: func() {
				w.EXPECT().DeleteCustomResource(gomock.Any(), "test", "", "test", constants.CustomResourceDefinitionGVR, nil).Return(nil)
			},
			wantErr: assert.NoError,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.prepare()
			ws := &WorkloadServices{
				engine: w,
			}
			tt.wantErr(t, ws.DeleteCustomResourceDefinition(tt.args.ctx, tt.args.cluster, tt.args.name), fmt.Sprintf("DeleteCustomResourceDefinition(%v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.name))
		})
	}
}

func TestWorkloadServices_DeleteCustomResource(t *testing.T) {
	ctrl := gomock.NewController(t)
	w := engine.NewMockWorkload(ctrl)
	p := metav1.DeletePropagationOrphan
	type args struct {
		ctx         context.Context
		cluster     string
		namespace   string
		name        string
		group       string
		version     string
		resource    string
		propagation *metav1.DeletionPropagation
	}
	tests := []struct {
		name    string
		args    args
		prepare func()
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "TestWorkloadServices_DeleteCustomResource it should work normally",
			args: args{
				ctx:         context.TODO(),
				cluster:     "test-cluster",
				namespace:   "test-namespace",
				name:        "test",
				group:       "test-group",
				version:     "test-version",
				resource:    "test-resource",
				propagation: &p,
			},
			prepare: func() {
				w.EXPECT().
					DeleteCustomResource(gomock.Any(), "test-cluster", "test-namespace", "test", gomock.Any(), gomock.Any()).
					Return(nil)
			},
			wantErr: assert.NoError,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.prepare()
			ws := &WorkloadServices{
				engine: w,
			}
			tt.wantErr(t, ws.DeleteCustomResource(tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.name, tt.args.group, tt.args.version, tt.args.resource, tt.args.propagation), fmt.Sprintf("DeleteCustomResource(%v, %v, %v, %v, %v, %v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.name, tt.args.group, tt.args.version, tt.args.resource, tt.args.propagation))
		})
	}
}

func TestWorkloadServices_GetAPIResourceList(t *testing.T) {
	ctrl := gomock.NewController(t)
	e := engine.NewMockWorkload(ctrl)
	type args struct {
		ctx     context.Context
		cluster string
	}
	tests := []struct {
		name    string
		args    args
		prepare func()
		want    []*metav1.APIResourceList
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "TestWorkloadServices_GetAPIResourceList it should work normally",
			args: args{
				ctx:     context.TODO(),
				cluster: "test",
			},
			prepare: func() {
				// sometimes using null pointers better reflects test results.
				e.EXPECT().GetAPIResourceList(gomock.Any(), "test").Return(nil, nil)
			},
			want:    nil,
			wantErr: assert.NoError,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.prepare()
			ws := &WorkloadServices{
				engine: e,
			}
			got, err := ws.GetAPIResourceList(tt.args.ctx, tt.args.cluster)
			if !tt.wantErr(t, err, fmt.Sprintf("GetAPIResourceList(%v, %v)", tt.args.ctx, tt.args.cluster)) {
				return
			}
			assert.Equalf(t, tt.want, got, "GetAPIResourceList(%v, %v)", tt.args.ctx, tt.args.cluster)
		})
	}
}

func TestWorkloadServices_GetNode(t *testing.T) {
	ctrl := gomock.NewController(t)
	e := engine.NewMockWorkload(ctrl)
	type args struct {
		ctx     context.Context
		cluster string
		name    string
	}
	tests := []struct {
		name    string
		args    args
		prepare func()
		want    *corev1.Node
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "TestWorkloadServices_GetNode it should work normally",
			args: args{
				ctx:     context.TODO(),
				cluster: "test-cluster",
				name:    "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(&corev1.Node{}, nil)
			},
			want:    &corev1.Node{},
			wantErr: assert.NoError,
		},
		{
			name: "TestWorkloadServices_GetNode while engine return error",
			args: args{
				ctx:     context.TODO(),
				cluster: "test-cluster",
				name:    "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(nil, fmt.Errorf("test error"))
			},
			want:    nil,
			wantErr: assert.Error,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.prepare()
			ws := &WorkloadServices{
				engine: e,
			}
			got, err := ws.GetNode(tt.args.ctx, tt.args.cluster, tt.args.name)
			if !tt.wantErr(t, err, fmt.Sprintf("GetNode(%v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.name)) {
				return
			}
			assert.Equalf(t, tt.want, got, "GetNode(%v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.name)
		})
	}
}

func TestWorkloadServices_UnbindNodeToNamespace(t *testing.T) {
	ctrl := gomock.NewController(t)
	e := engine.NewMockWorkload(ctrl)
	c := engine.NewMockCustomClient(ctrl)
	type args struct {
		ctx       context.Context
		cluster   string
		namespace string
		nodeName  string
	}
	tests := []struct {
		name    string
		args    args
		prepare func()
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "TestWorkloadServices_UnbindNodeToNamespace it should work normally",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodeName:  "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"node.kpanda.io/exclusive-namespace": "test-namespace",
							"test":                               "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "ExclusiveNamespace",
							},
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				c.EXPECT().ListNodes(gomock.Any(), gomock.Any()).Return(&corev1.NodeList{}, nil)
				e.EXPECT().GetNamespace(gomock.Any(), "test-cluster", "test-namespace").Return(&corev1.Namespace{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test-namespace",
						Namespace: "test-namespace",
						Annotations: map[string]string{
							"test": "test",
							"scheduler.alpha.kubernetes.io/defaultTolerations": "test",
							"scheduler.alpha.kubernetes.io/node-selector":      "test",
						},
					},
				}, nil)
				e.EXPECT().UpdateNode(gomock.Any(), "test-cluster", &corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test": "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
						},
					},
				})
				e.EXPECT().UpdateNameSpace(gomock.Any(), "test-cluster", &corev1.Namespace{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test-namespace",
						Namespace: "test-namespace",
						Annotations: map[string]string{
							"test": "test",
						},
					},
				})
			},
			wantErr: assert.NoError,
		},
		{
			name: "TestWorkloadServices_UnbindNodeToNamespace while get node failed",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodeName:  "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(nil, fmt.Errorf("test error"))
			},
			wantErr: assert.Error,
		},
		{
			name: "TestWorkloadServices_UnbindNodeToNamespace while list node failed",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodeName:  "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"node.kpanda.io/exclusive-namespace": "test-namespace",
							"test":                               "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "ExclusiveNamespace",
							},
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				c.EXPECT().ListNodes(gomock.Any(), gomock.Any()).Return(nil, fmt.Errorf("test error"))
			},
			wantErr: assert.Error,
		},
		{
			name: "TestWorkloadServices_UnbindNodeToNamespace get namespace failed",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodeName:  "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"node.kpanda.io/exclusive-namespace": "test-namespace",
							"test":                               "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "ExclusiveNamespace",
							},
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				c.EXPECT().ListNodes(gomock.Any(), gomock.Any()).Return(&corev1.NodeList{}, nil)
				e.EXPECT().GetNamespace(gomock.Any(), "test-cluster", "test-namespace").Return(nil, fmt.Errorf("test error"))
			},
			wantErr: assert.Error,
		},
		{
			name: "TestWorkloadServices_UnbindNodeToNamespace get namespace failed",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodeName:  "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test": "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "ExclusiveNamespace",
							},
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				c.EXPECT().ListNodes(gomock.Any(), gomock.Any()).Return(&corev1.NodeList{}, nil)
				e.EXPECT().GetNamespace(gomock.Any(), "test-cluster", "test-namespace").Return(&corev1.Namespace{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test-namespace",
						Namespace: "test-namespace",
						Annotations: map[string]string{
							"test": "test",
							"scheduler.alpha.kubernetes.io/defaultTolerations": "test",
							"scheduler.alpha.kubernetes.io/node-selector":      "test",
						},
					},
				}, nil)
			},
			wantErr: assert.Error,
		},
		{
			name: "TestWorkloadServices_UnbindNodeToNamespace while update node failed",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodeName:  "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"node.kpanda.io/exclusive-namespace": "test-namespace",
							"test":                               "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "ExclusiveNamespace",
							},
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				c.EXPECT().ListNodes(gomock.Any(), gomock.Any()).Return(&corev1.NodeList{}, nil)
				e.EXPECT().GetNamespace(gomock.Any(), "test-cluster", "test-namespace").Return(&corev1.Namespace{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test-namespace",
						Namespace: "test-namespace",
						Annotations: map[string]string{
							"test": "test",
							"scheduler.alpha.kubernetes.io/defaultTolerations": "test",
							"scheduler.alpha.kubernetes.io/node-selector":      "test",
						},
					},
				}, nil)
				e.EXPECT().UpdateNode(gomock.Any(), "test-cluster", &corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test": "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
						},
					},
				}).Return(nil, fmt.Errorf("test error"))
			},
			wantErr: assert.Error,
		},
		{
			name: "TestWorkloadServices_UnbindNodeToNamespace while annotations is do not have target string",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodeName:  "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"node.kpanda.io/exclusive-namespace": "test-namespace",
							"test":                               "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "ExclusiveNamespace",
							},
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				c.EXPECT().ListNodes(gomock.Any(), gomock.Any()).Return(&corev1.NodeList{}, nil)
				e.EXPECT().GetNamespace(gomock.Any(), "test-cluster", "test-namespace").Return(&corev1.Namespace{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test-namespace",
						Namespace: "test-namespace",
						Annotations: map[string]string{
							"test": "test",
						},
					},
				}, nil)
				e.EXPECT().UpdateNode(gomock.Any(), "test-cluster", &corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test": "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
						},
					},
				})
			},
			wantErr: assert.NoError,
		},
		{
			name: "TestWorkloadServices_UnbindNodeToNamespace while annotations is nil",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodeName:  "test",
			},
			prepare: func() {
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"node.kpanda.io/exclusive-namespace": "test-namespace",
							"test":                               "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "ExclusiveNamespace",
							},
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				c.EXPECT().ListNodes(gomock.Any(), gomock.Any()).Return(&corev1.NodeList{}, nil)
				e.EXPECT().GetNamespace(gomock.Any(), "test-cluster", "test-namespace").Return(&corev1.Namespace{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test-namespace",
						Namespace: "test-namespace",
					},
				}, nil)
				e.EXPECT().UpdateNode(gomock.Any(), "test-cluster", &corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test": "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
						},
					},
				})
			},
			wantErr: assert.NoError,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.prepare()
			ws := &WorkloadServices{
				engine:       e,
				customEngine: c,
			}
			tt.wantErr(t, ws.UnbindNodeToNamespace(tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.nodeName), fmt.Sprintf("UnbindNodeToNamespace(%v, %v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.nodeName))
		})
	}
}

func TestWorkloadServices_BatchBindNodeToNamespace(t *testing.T) {
	ctrl := gomock.NewController(t)
	e := engine.NewMockWorkload(ctrl)
	c := engine.NewMockCustomClient(ctrl)
	type args struct {
		ctx       context.Context
		cluster   string
		namespace string
		nodes     []string
	}
	tests := []struct {
		name    string
		args    args
		prepare func()
		want    *kpandacorev1alpha1.BatchBindNodeToNamespaceResponse
		wantErr assert.ErrorAssertionFunc
	}{
		{
			name: "TestWorkloadServices_BatchBindNodeToNamespace it should work normally",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodes:     []string{"test1", "test2", "test3"},
			},
			prepare: func() {
				e.EXPECT().GetNamespace(gomock.Any(), "test-cluster", "test-namespace").Return(&corev1.Namespace{
					ObjectMeta: metav1.ObjectMeta{
						Namespace: "test-namespace",
						Name:      "test-namespace",
					},
				}, nil)
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test1").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test1",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test": "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				e.EXPECT().UpdateNode(gomock.Any(), "test-cluster", &corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test1",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test":                                   "test",
							constants.ExclusiveNamespaceNodeLabelKey: "test-namespace",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
							{
								Key:    constants.ExclusiveNamespaceTaintKey,
								Value:  "test-namespace",
								Effect: corev1.TaintEffectNoSchedule,
							},
						},
					},
				}).Return(nil, nil)
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test2").Return(nil, fmt.Errorf("test error"))
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test3").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test3",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test": "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				e.EXPECT().UpdateNode(gomock.Any(), "test-cluster", &corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test3",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test":                                   "test",
							constants.ExclusiveNamespaceNodeLabelKey: "test-namespace",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
							{
								Key:    constants.ExclusiveNamespaceTaintKey,
								Value:  "test-namespace",
								Effect: corev1.TaintEffectNoSchedule,
							},
						},
					},
				}).Return(nil, fmt.Errorf("test error"))
				e.EXPECT().UpdateNameSpace(gomock.Any(), "test-cluster", gomock.Any()).Return(nil, nil)
			},
			want: &kpandacorev1alpha1.BatchBindNodeToNamespaceResponse{
				SuccessfulResults: []*kpandacorev1alpha1.BindNodeToNamespaceResult{
					{
						NodeName: "test1",
					},
				},
				FailedResults: []*kpandacorev1alpha1.BindNodeToNamespaceResult{
					{
						NodeName: "test2",
						Error:    "test error",
					},
					{
						NodeName: "test3",
						Error:    "test error",
					},
				},
			},
			wantErr: assert.NoError,
		},
		{
			name: "TestWorkloadServices_BatchBindNodeToNamespace it should work normally",
			args: args{
				ctx:       context.TODO(),
				cluster:   "test-cluster",
				namespace: "test-namespace",
				nodes:     []string{"test1", "test2", "test3"},
			},
			prepare: func() {
				e.EXPECT().GetNamespace(gomock.Any(), "test-cluster", "test-namespace").Return(&corev1.Namespace{
					ObjectMeta: metav1.ObjectMeta{
						Namespace: "test-namespace",
						Name:      "test-namespace",
					},
				}, nil)
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test1").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test1",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test": "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				e.EXPECT().UpdateNode(gomock.Any(), "test-cluster", &corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test1",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test":                                   "test",
							constants.ExclusiveNamespaceNodeLabelKey: "test-namespace",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
							{
								Key:    constants.ExclusiveNamespaceTaintKey,
								Value:  "test-namespace",
								Effect: corev1.TaintEffectNoSchedule,
							},
						},
					},
				}).Return(nil, nil)
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test2").Return(nil, fmt.Errorf("test error"))
				e.EXPECT().GetNode(gomock.Any(), "test-cluster", "test3").Return(&corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test3",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test": "test",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
						},
					},
				}, nil)
				e.EXPECT().UpdateNode(gomock.Any(), "test-cluster", &corev1.Node{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test3",
						Namespace: "test-namespace",
						Labels: map[string]string{
							"test":                                   "test",
							constants.ExclusiveNamespaceNodeLabelKey: "test-namespace",
						},
					},
					Spec: corev1.NodeSpec{
						Taints: []corev1.Taint{
							{
								Key: "test other key",
							},
							{
								Key:    constants.ExclusiveNamespaceTaintKey,
								Value:  "test-namespace",
								Effect: corev1.TaintEffectNoSchedule,
							},
						},
					},
				}).Return(nil, fmt.Errorf("test error"))
				e.EXPECT().UpdateNameSpace(gomock.Any(), "test-cluster", gomock.Any()).Return(nil, fmt.Errorf("test error"))
			},
			want: &kpandacorev1alpha1.BatchBindNodeToNamespaceResponse{
				SuccessfulResults: []*kpandacorev1alpha1.BindNodeToNamespaceResult{
					{
						NodeName: "test1",
					},
				},
				FailedResults: []*kpandacorev1alpha1.BindNodeToNamespaceResult{
					{
						NodeName: "test2",
						Error:    "test error",
					},
					{
						NodeName: "test3",
						Error:    "test error",
					},
				},
				NsError: "test error",
			},
			wantErr: assert.NoError,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.prepare()
			ws := &WorkloadServices{
				engine:       e,
				customEngine: c,
			}
			got, err := ws.BatchBindNodeToNamespace(tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.nodes)
			if !tt.wantErr(t, err, fmt.Sprintf("BatchBindNodeToNamespace(%v, %v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.nodes)) {
				return
			}
			assert.Equalf(t, tt.want, got, "BatchBindNodeToNamespace(%v, %v, %v, %v)", tt.args.ctx, tt.args.cluster, tt.args.namespace, tt.args.nodes)
		})
	}
}
