package workloads

import (
	"context"
	"fmt"
	"reflect"
	"strings"
	"time"

	clusterpediav1beta1 "github.com/clusterpedia-io/api/clusterpedia/v1beta1"
	"github.com/clusterpedia-io/client-go/tools/builder"
	apivolumesnapshotv1 "github.com/kubernetes-csi/external-snapshotter/client/v4/apis/volumesnapshot/v1"
	metallbv1beta1 "go.universe.tf/metallb/api/v1beta1"
	"golang.org/x/sync/errgroup"
	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	storagev1 "k8s.io/api/storage/v1"
	apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	apiequality "k8s.io/apimachinery/pkg/api/equality"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/labels"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apimachinery/pkg/util/json"
	"k8s.io/apimachinery/pkg/util/mergepatch"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/apimachinery/pkg/util/strategicpatch"
	"k8s.io/apimachinery/pkg/watch"
	"k8s.io/klog/v2"
	deploymentutil "k8s.io/kubectl/pkg/util/deployment"
	cmapi "k8s.io/metrics/pkg/apis/custom_metrics/v1beta2"

	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/engine"
	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
	"github.com/daocloud/dsp-appserver/pkg/util/contextutil"
	"github.com/daocloud/dsp-appserver/pkg/util/helper"
	"github.com/daocloud/dsp-appserver/pkg/util/maputil"
)

var (
	annotationsToSkip = map[string]bool{
		corev1.LastAppliedConfigAnnotation:       true,
		deploymentutil.RevisionAnnotation:        true,
		deploymentutil.RevisionHistoryAnnotation: true,
		deploymentutil.DesiredReplicasAnnotation: true,
		deploymentutil.MaxReplicasAnnotation:     true,
		appsv1.DeprecatedRollbackTo:              true,
	}

	// preconditions defines fields that cannot be modified for patch json.
	preconditions = []mergepatch.PreconditionFunc{
		mergepatch.RequireMetadataKeyUnchanged("name"),
		mergepatch.RequireKeyUnchanged("managedFields"),
	}
)

//go:generate mockgen -source=workload.go -destination fake_workloads_gen.go -package workloads
type Service interface {
	GetAPIResourceList(ctx context.Context, cluster string) ([]*metav1.APIResourceList, error)

	GetNode(ctx context.Context, cluster, name string) (*corev1.Node, error)
	UpdateNode(ctx context.Context, cluster string, node *corev1.Node) (*corev1.Node, error)
	ListPodsByNode(ctx context.Context, cluster, node string, queryPage *util.QueryPage) ([]corev1.Pod, error)
	PutNodeLabels(ctx context.Context, clusterName, name string, labels map[string]string) (map[string]string, error)
	PutNodeTaints(ctx context.Context, clusterName, name string, taints []*corev1.Taint) ([]corev1.Taint, error)
	UpdateNodeAnnotations(ctx context.Context, cluster, node string, annotations map[string]string) (map[string]string, error)
	CordonNode(ctx context.Context, cluster, node string, unschedulable bool) (*corev1.Node, error)
	UnbindNodeToNamespace(ctx context.Context, cluster, namespace, node string) error

	GetNamespace(ctx context.Context, cluster, name string) (*corev1.Namespace, error)

	ListResourceQuotas(ctx context.Context, listOptions *util.ListOptions) (*corev1.ResourceQuotaList, error)
	GetResourceQuota(ctx context.Context, cluster, namespace, name string) (*corev1.ResourceQuota, error)
	CreateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error)
	UpdateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error)

	ListLimitRanges(ctx context.Context, listOptions *util.ListOptions) (*corev1.LimitRangeList, error)
	GetLimitRange(ctx context.Context, cluster, namespace, name string) (*corev1.LimitRange, error)
	CreateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error)
	UpdateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error)
	DeleteLimitRange(ctx context.Context, cluster, namespace, name string) error

	GetDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error)
	CreateDeployment(ctx context.Context, cluster, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error)
	UpdateDeployment(ctx context.Context, cluster, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error)
	CreateOrUpdateDeployment(ctx context.Context, cluster, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error)
	PatchDeployment(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.Deployment, error)
	PatchStatefulSet(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.StatefulSet, error)
	PatchDaemonSet(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.DaemonSet, error)

	DeleteDeployment(ctx context.Context, cluster, namespace, name string) error
	ListPodsByDeployment(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error)
	GetPod(ctx context.Context, cluster, namespaceName, podName string) (*corev1.Pod, error)
	CreatePod(ctx context.Context, cluster, namespace string, pod *corev1.Pod) (*corev1.Pod, error)
	UpdatePod(ctx context.Context, cluster, namespace string, pod *corev1.Pod) (*corev1.Pod, error)
	GetStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error)
	UpdateStatefulSet(ctx context.Context, cluster, namespace string, sts *appsv1.StatefulSet) (*appsv1.StatefulSet, error)

	GetReplicaSet(ctx context.Context, cluster, ns, name string) (*appsv1.ReplicaSet, error)
	UpdateReplicaSet(ctx context.Context, cluster, namespace string, rs *appsv1.ReplicaSet) (*appsv1.ReplicaSet, error)
	DeleteReplicaSet(ctx context.Context, cluster, namespace, name string) error

	ListNodes(ctx context.Context, listOptions *util.ListOptions) (*corev1.NodeList, error)
	ListNamespaces(ctx context.Context, listOptions *util.ListOptions) (*corev1.NamespaceList, error)
	ListDeployments(ctx context.Context, listOptions *util.ListOptions) (*appsv1.DeploymentList, error)

	ListDaemonSets(ctx context.Context, listOptions *util.ListOptions) (*appsv1.DaemonSetList, error)
	ListStatefulSets(ctx context.Context, listOptions *util.ListOptions) (*appsv1.StatefulSetList, error)
	ListPods(ctx context.Context, listOptions *util.ListOptions) (*corev1.PodList, error)
	ListConfigMaps(ctx context.Context, listOptions *util.ListOptions) (*corev1.ConfigMapList, error)
	ListServices(ctx context.Context, listOptions *util.ListOptions) (*corev1.ServiceList, error)
	ListSecrets(ctx context.Context, listOptions *util.ListOptions) (*corev1.SecretList, error)

	ListEvents(ctx context.Context, listOptions *util.ListOptions) (*corev1.EventList, error)
	ListPersistentVolumeClaims(ctx context.Context, listOptions *util.ListOptions) (*corev1.PersistentVolumeClaimList, error)

	ListCronJobs(ctx context.Context, listOptions *util.ListOptions) (*batchv1.CronJobList, error)
	ListJobs(ctx context.Context, listOptions *util.ListOptions) (*batchv1.JobList, error)
	RestartJob(ctx context.Context, cluster, namespace, name, resourceVersion string) (*batchv1.Job, error)

	CreateStatefulSet(ctx context.Context, cluster, namespace string, sts *appsv1.StatefulSet) (*appsv1.StatefulSet, error)
	CreateDaemonSet(ctx context.Context, cluster, namespace string, ds *appsv1.DaemonSet) (*appsv1.DaemonSet, error)
	GetDaemonSet(ctx context.Context, cluster, namespace, name string) (*appsv1.DaemonSet, error)
	UpdateDaemonSet(ctx context.Context, cluster, namespace string, ds *appsv1.DaemonSet) (*appsv1.DaemonSet, error)
	DeleteStatefulSet(ctx context.Context, cluster, namespace, name string) error
	ListReplicaSets(ctx context.Context, listOptions *util.ListOptions) (*appsv1.ReplicaSetList, error)
	ListReplicaSetsByDeployment(ctx context.Context, cluster, namespace, deployment string, queryPage *util.QueryPage) (*appsv1.ReplicaSetList, error)
	ListRevisionsByStatefulSet(ctx context.Context, cluster, namespace, statefulset string, queryPage *util.QueryPage) (*appsv1.ControllerRevisionList, error)
	ListRevisionsByDaemonSet(ctx context.Context, cluster, namespace, daemonSet string, queryPage *util.QueryPage) (*appsv1.ControllerRevisionList, error)

	ListEventsByDeployment(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByStatefulSet(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByDaemonSet(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByPod(ctx context.Context, cluster, namespace, pod string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByService(ctx context.Context, cluster, namespace, service string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByIngress(ctx context.Context, cluster, namespace, ingress string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByJob(ctx context.Context, cluster, namespace, job string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByCronJob(ctx context.Context, cluster, namespace, cronJob string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, hpa string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByReplicaSet(ctx context.Context, cluster, namespace, replicaSet string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByPersistentVolumeClaim(ctx context.Context, cluster, namespace, replicaSet string, queryPage *util.QueryPage) (*corev1.EventList, error)
	ListEventsByGroupVersionResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource, queryPage *util.QueryPage) (*corev1.EventList, error)

	ListJobsByCronJob(ctx context.Context, cluster, namespace, jobName string, queryPage *util.QueryPage) (*batchv1.JobList, error)
	ListPodsByStatefulSet(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error)
	ListPodsByDamonSet(ctx context.Context, cluster, namespace, workloadName string, queryPage *util.QueryPage) (*corev1.PodList, error)
	ListPodsByNetworkPolicy(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error)
	ListPodsByReplicaSet(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error)

	GetService(ctx context.Context, cluster, namespace, name string) (*corev1.Service, error)
	ListPodsByService(ctx context.Context, cluster, namespace, serviceName string, queryPage *util.QueryPage) (*corev1.PodList, error)
	CreateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error)
	UpdateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error)
	DeleteService(ctx context.Context, cluster, namespace, name string) error
	ListIngresses(ctx context.Context, listOptions *util.ListOptions) (*networkingv1.IngressList, error)
	ListMetallbIPAddressPools(ctx context.Context, listOptions *util.ListOptions) (*metallbv1beta1.IPAddressPoolList, error)
	GetIngress(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error)
	CreateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error)
	UpdateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error)
	PatchIngress(ctx context.Context, cluster, namespace, name string) (*networkingv1.Ingress, error)
	DeleteIngress(ctx context.Context, cluster, namespace, name string) error
	ListNetworkPolicies(ctx context.Context, listOptions *util.ListOptions) (*networkingv1.NetworkPolicyList, error)
	GetNetworkPolicy(ctx context.Context, cluster, namespace, name string) (*networkingv1.NetworkPolicy, error)
	CreateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error)
	UpdateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error)
	DeleteNetworkPolicy(ctx context.Context, cluster, namespace, name string) error
	ListIngressClasses(ctx context.Context, listOptions *util.ListOptions) (*networkingv1.IngressClassList, error)

	GetPersistentVolumeClaim(ctx context.Context, cluster, namespace, name string) (*corev1.PersistentVolumeClaim, error)
	ListServicesByDeployment(ctx context.Context, cluster, namespace, kindName, name string) ([]corev1.Service, error)
	ListServicesByStatefulSet(ctx context.Context, cluster, namespace, kindName, name string) ([]corev1.Service, error)
	ListServicesByDaemonSet(ctx context.Context, cluster, namespace, kindName, name string) ([]corev1.Service, error)
	ListCustomResourceDefinitions(ctx context.Context, cluster string, queryPage *util.QueryPage) ([]apiextensionsv1.CustomResourceDefinition, error)
	ListCustomResourceDefinitionsGroups(ctx context.Context, cluster string) ([]string, error)
	GetCustomResourceDefinition(ctx context.Context, cluster, name string) (*apiextensionsv1.CustomResourceDefinition, error)
	CreateCustomResourceDefinition(ctx context.Context, cluster string, obj *unstructured.Unstructured) (*apiextensionsv1.CustomResourceDefinition, error)
	UpdateCustomResourceDefinition(ctx context.Context, cluster string, obj *unstructured.Unstructured) (*apiextensionsv1.CustomResourceDefinition, error)
	DeleteCustomResourceDefinition(ctx context.Context, cluster, name string) error
	ListCustomResources(ctx context.Context, cluster, namespace, group, version, resource string, queryPage *util.QueryPage) (*unstructured.UnstructuredList, error)
	GetCustomResource(ctx context.Context, cluster, namespace, name, group, version, resource string) (*unstructured.Unstructured, error)
	CreateCustomResource(ctx context.Context, cluster, namespace, group, version, resource string, obj *unstructured.Unstructured) (*unstructured.Unstructured, error)
	UpdateCustomResource(ctx context.Context, cluster, namespace, group, version, resource string, obj *unstructured.Unstructured) (*unstructured.Unstructured, error)
	UpdateCustomResourceStatus(ctx context.Context, cluster, namespace, group, version, resource string, obj *unstructured.Unstructured) (*unstructured.Unstructured, error)
	PatchCustomResource(ctx context.Context, cluster, namespace, name, group, version, resource string, pt types.PatchType, data []byte, subResources ...string) (*unstructured.Unstructured, error)
	DeleteCustomResource(ctx context.Context, cluster, namespace, name, group, version, resource string, propagation *metav1.DeletionPropagation) error
	ListPodsByJob(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error)
	GetSecret(ctx context.Context, cluster, namespace, name string) (*corev1.Secret, error)
	UpdateSecret(ctx context.Context, cluster string, secret *corev1.Secret) (*corev1.Secret, error)
	DeleteSecret(ctx context.Context, cluster, namespace, name string) error
	CreateSecret(ctx context.Context, cluster, namespace string, secret *corev1.Secret) (*corev1.Secret, error)
	CreateOrUpdateSecret(ctx context.Context, cluster, namespace string, secret *corev1.Secret) (*corev1.Secret, error)
	GetConfigMap(ctx context.Context, cluster, namespace, name string) (*corev1.ConfigMap, error)
	CreateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error)
	UpdateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error)
	CreateOrUpdateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error)
	PatchConfigMap(ctx context.Context, cluster, namespace, name string) (*corev1.ConfigMap, error)
	DeleteConfigMap(ctx context.Context, cluster, namespace, name string) error
	DeleteJob(ctx context.Context, cluster, namespace, name string) error
	DeleteCronJob(ctx context.Context, cluster, namespace, name string) error
	DeletePod(ctx context.Context, cluster, namespace, name string) error
	DeleteDaemonSet(ctx context.Context, cluster, namespace, name string) error
	CreateCronJob(ctx context.Context, cluster, namespace string, cronJob *unstructured.Unstructured) (*unstructured.Unstructured, error)
	GetCronJob(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error)
	UpdateCronJob(ctx context.Context, cluster, namespace string, cronJob *unstructured.Unstructured) (*unstructured.Unstructured, error)
	PauseCronJob(ctx context.Context, cluster, namespace, name string, paused bool) (*unstructured.Unstructured, error)
	CreateJob(ctx context.Context, cluster, namespace string, job *batchv1.Job) (*batchv1.Job, error)
	GetJob(ctx context.Context, cluster, namespace, name string) (*batchv1.Job, error)
	UpdateJob(ctx context.Context, cluster, namespace string, job *batchv1.Job) (*batchv1.Job, error)
	EnsureNamespace(ctx context.Context, cluster, namespace string) (*corev1.Namespace, error)
	DeleteNamespace(ctx context.Context, cluster, namespace string) error
	CreateNamespace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error)
	UpdateNameSpace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error)
	PatchNameSpace(ctx context.Context, cluster, name string, patchType types.PatchType, patchData []byte) (*corev1.Namespace, error)

	CreatePersistentVolumeClaim(ctx context.Context, cluster, namespace string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error)
	DeletePersistentVolumeClaim(ctx context.Context, cluster, name, namespaces string) error
	ScalePersistentVolumeClaim(ctx context.Context, cluster, namespaces string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error)
	UpdatePersistentVolumeClaim(ctx context.Context, cluster, namespace string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error)
	PatchPersistentVolumeClaimLabels(ctx context.Context, cluster, name, namespaces string, labels map[string]string) (*corev1.PersistentVolumeClaim, error)
	PatchPersistentVolumeClaimCapacity(ctx context.Context, cluster, name, namespaces, capacity string) (*corev1.PersistentVolumeClaim, error)
	PatchPersistentVolumeClaimAnnotations(ctx context.Context, cluster, name, namespaces string, annotations map[string]string) (*corev1.PersistentVolumeClaim, error)
	DeletePersistentVolumeClaimSnapshot(ctx context.Context, cluster, namespaces, name string) error
	ListPersistentVolumes(ctx context.Context, listOptions *util.ListOptions) (*corev1.PersistentVolumeList, error)
	GetPersistentVolume(ctx context.Context, cluster, name string) (*corev1.PersistentVolume, error)
	CreatePersistentVolume(ctx context.Context, cluster string, persistentvolume *corev1.PersistentVolume) (*corev1.PersistentVolume, error)
	UpdatePersistentVolume(ctx context.Context, cluster string, persistentvolume *corev1.PersistentVolume) (*corev1.PersistentVolume, error)
	DeletePersistentVolume(ctx context.Context, cluster, name string) error

	PauseDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error)
	ResumeDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error)
	RestartDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error)
	StartDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error)
	StopDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error)
	RollbackDeployment(ctx context.Context, cluster, namespace, name string, revision int64) (*appsv1.Deployment, error)

	StartStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error)
	StopStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error)
	RestartStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error)
	RollbackStatefulSet(ctx context.Context, cluster, namespace, name string, revision int64) (*appsv1.StatefulSet, error)

	RestartDaemonSet(ctx context.Context, cluster, namespace, name string) (*appsv1.DaemonSet, error)
	RollbackDaemonSet(ctx context.Context, cluster, namespace, name string, revision int64) (*appsv1.DaemonSet, error)

	GetHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error)
	CreateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error)
	UpdateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error)
	DeleteHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) error

	ListCustomMetricSummary(ctx context.Context, cluster, kind string) ([]string, error)
	ListMetricValues(ctx context.Context, cluster, namespace, kind, kindName, metric string) (*cmapi.MetricValueList, error)

	ListStorageClass(ctx context.Context, listOptions *util.ListOptions) (*storagev1.StorageClassList, error)
	DeleteStorageClass(ctx context.Context, cluster, name string) error
	GetStorageClass(ctx context.Context, cluster, name string) (*storagev1.StorageClass, error)
	CreateStorageClass(ctx context.Context, cluster string, storageClass *storagev1.StorageClass) (*storagev1.StorageClass, error)
	UpdateStorageClass(ctx context.Context, cluster string, storageClass *storagev1.StorageClass) (*storagev1.StorageClass, error)
	CreateVolumeSnapshot(ctx context.Context, cluster, namespace string, volumeSnapshot *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error)
	GetVolumeSnapshot(ctx context.Context, cluster, namespace, name string) (*apivolumesnapshotv1.VolumeSnapshot, error)
	UpdateVolumeSnapshot(ctx context.Context, cluster, namespace string, pvc *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error)
	ListVolumeSnapshots(ctx context.Context, listOptions *util.ListOptions) (*apivolumesnapshotv1.VolumeSnapshotList, error)

	CreateServiceAccount(ctx context.Context, cluster, namespace string, sa *corev1.ServiceAccount) (*corev1.ServiceAccount, error)
	GetServiceAccount(ctx context.Context, cluster, namespace, name string) (*corev1.ServiceAccount, error)
	WatchServiceAccount(ctx context.Context, cluster, namespace string, opts metav1.ListOptions) (watch.Interface, error)
	ListServiceAccounts(ctx context.Context, listOptions *util.ListOptions) (*corev1.ServiceAccountList, error)
	DeleteServiceAccount(ctx context.Context, cluster, namespace, name string) error
	UpdateServiceAccount(ctx context.Context, cluster, namespace string, service *corev1.ServiceAccount) (*corev1.ServiceAccount, error)

	WatchPod(ctx context.Context, cluster, namespace string, opts metav1.ListOptions) (watch.Interface, error)

	FetchCollectionResourceByResources(ctx context.Context, listOptions *util.ListOptions, resources []string) (*clusterpediav1beta1.CollectionResource, error)
}

var _ Service = new(WorkloadServices)

type WorkloadServices struct {
	engine       engine.Workload
	customEngine engine.CustomClient
}

func NewWorkloadServices(kpandaFactory informers.SharedInformerFactory, clientFactory pedia.Clients, clusterClient clusterclient.ClusterClients) (*WorkloadServices, error) {
	we, err := engine.NewWorkloadEngine(kpandaFactory, clientFactory, clusterClient)
	if err != nil {
		return nil, err
	}
	ce, err := engine.NewCustomEngine(clientFactory)
	if err != nil {
		return nil, err
	}
	return &WorkloadServices{engine: we, customEngine: ce}, nil
}

func (ws *WorkloadServices) GetAPIResourceList(ctx context.Context, cluster string) ([]*metav1.APIResourceList, error) {
	return ws.engine.GetAPIResourceList(ctx, cluster)
}

func (ws *WorkloadServices) ListNodes(ctx context.Context, listOptions *util.ListOptions) (*corev1.NodeList, error) {
	list, err := ws.customEngine.ListNodes(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetNode(ctx context.Context, cluster, name string) (*corev1.Node, error) {
	node, err := ws.engine.GetNode(ctx, cluster, name)
	if err != nil {
		return nil, err
	}
	return node, nil
}

func (ws *WorkloadServices) UpdateNode(ctx context.Context, cluster string, node *corev1.Node) (*corev1.Node, error) {
	return ws.engine.UpdateNode(ctx, cluster, node)
}

func (ws *WorkloadServices) ListPodsByNode(ctx context.Context, cluster, node string, queryPage *util.QueryPage) ([]corev1.Pod, error) {
	return ws.engine.ListPodsByFieldSelector(ctx, cluster, "spec.nodeName", []string{node}, queryPage)
}

func (ws *WorkloadServices) PutNodeLabels(ctx context.Context, clusterName, name string, labels map[string]string) (map[string]string, error) {
	loadBytes, _ := util.LabelsConvert(labels)
	nodeLabels, err := ws.engine.PutNodeLabels(ctx, clusterName, name, loadBytes)
	if err != nil {
		return nil, err
	}
	return nodeLabels, nil
}

func (ws *WorkloadServices) PutNodeTaints(ctx context.Context, clusterName, name string, taints []*corev1.Taint) ([]corev1.Taint, error) {
	LoadBytes, _ := util.NodeTaintsConvert(taints)
	nodeTaints, err := ws.engine.PutNodeTaints(ctx, clusterName, name, LoadBytes)
	if err != nil {
		return nil, err
	}
	return nodeTaints, nil
}

func (ws *WorkloadServices) UpdateNodeAnnotations(ctx context.Context, cluster, node string, annotations map[string]string) (map[string]string, error) {
	loadBytes, _ := util.AnnotationsConvert(annotations)
	patchedNode, err := ws.engine.PatchNode(ctx, cluster, node, loadBytes)
	if err != nil {
		return nil, err
	}
	return patchedNode.GetAnnotations(), nil
}

func (ws *WorkloadServices) CordonNode(ctx context.Context, cluster, node string, unschedulable bool) (*corev1.Node, error) {
	LoadBytes, _ := util.NodeScheduleConvert(unschedulable)
	return ws.engine.CordonNode(ctx, cluster, node, LoadBytes)
}

func (ws *WorkloadServices) UnbindNodeToNamespace(ctx context.Context, cluster, namespace, nodeName string) error {
	node, err := ws.engine.GetNode(ctx, cluster, nodeName)
	if err != nil {
		return err
	}

	nodeList, err := ws.ListNodes(ctx, &util.ListOptions{
		QueryPage: &util.QueryPage{
			PageSize: -1,
			Labels:   makeExclusiveNamespaceNodeLabelSelector(namespace),
		},
		Scope: util.Scope{util.Cluster(cluster): {}},
	})
	if err != nil {
		return err
	}

	ns, err := ws.engine.GetNamespace(ctx, cluster, namespace)
	if err != nil {
		return err
	}

	if getExclusiveNamespace(node.Labels) != namespace {
		return fmt.Errorf("node %s has not bound to namespace %s", node.Name, namespace)
	}

	delete(node.Labels, constants.ExclusiveNamespaceNodeLabelKey)
	node.Spec.Taints = deleteTaint(node.Spec.Taints)

	_, err = ws.engine.UpdateNode(ctx, cluster, node)
	if err != nil {
		return err
	}

	annos := ns.Annotations
	if len(nodeList.Items) > 1 || annos == nil {
		return nil
	}

	if annos[constants.NSDefaultTolerations] != "" ||
		annos[constants.NamespaceNodeSelector] != "" {
		delete(annos, constants.NSDefaultTolerations)
		delete(annos, constants.NamespaceNodeSelector)
		ns.Annotations = annos
		_, err = ws.engine.UpdateNameSpace(ctx, cluster, ns)
		return err
	}

	return nil
}

func (ws *WorkloadServices) bindNamespaceForNode(ctx context.Context, cluster, ns string, node *corev1.Node) error {
	copyNode := node.DeepCopy()
	copyNode.Labels = labels.Merge(copyNode.Labels, makeExclusiveNamespaceNodeLabelSelector(ns))
	copyNode.Spec.Taints = updateOrAppendTaint(copyNode.Spec.Taints, ns)
	if apiequality.Semantic.DeepEqual(copyNode, node) {
		return nil
	}

	_, err := ws.engine.UpdateNode(ctx, cluster, copyNode)
	return err
}

func makeExclusiveNamespaceNodeLabelSelector(ns string) map[string]string {
	return map[string]string{constants.ExclusiveNamespaceNodeLabelKey: ns}
}

func getExclusiveNamespace(labels map[string]string) string {
	return labels[constants.ExclusiveNamespaceNodeLabelKey]
}

func deleteTaint(taints []corev1.Taint) []corev1.Taint {
	for i := 0; i < len(taints); i++ {
		if taints[i].Key == constants.ExclusiveNamespaceTaintKey {
			taints = append(taints[:i], taints[i+1:]...)
			i--
		}
	}
	return taints
}

func makeExclusiveNamespaceTaint(ns string) corev1.Taint {
	return corev1.Taint{
		Key:    constants.ExclusiveNamespaceTaintKey,
		Value:  ns,
		Effect: corev1.TaintEffectNoSchedule,
	}
}

func makeExclusiveNamespaceToleration(ns string) []corev1.Toleration {
	return []corev1.Toleration{
		{
			Key:      constants.ExclusiveNamespaceTaintKey,
			Value:    ns,
			Effect:   corev1.TaintEffectNoSchedule,
			Operator: corev1.TolerationOpEqual,
		},
	}
}

func updateOrAppendTaint(taints []corev1.Taint, ns string) []corev1.Taint {
	t := makeExclusiveNamespaceTaint(ns)

	for i, taint := range taints {
		if taint.Key == constants.ExclusiveNamespaceTaintKey {
			taints[i] = t
			return taints
		}
	}

	taints = append(taints, t)
	return taints
}

func (ws *WorkloadServices) EnsureNamespace(ctx context.Context, cluster, namespace string) (*corev1.Namespace, error) {
	targetNamespace := &corev1.Namespace{
		ObjectMeta: metav1.ObjectMeta{
			Name: namespace,
		},
	}

	ctx = contextutil.WithUser(ctx, nil)
	_, err := ws.CreateNamespace(ctx, cluster, targetNamespace)
	if err != nil {
		if !apierrors.IsAlreadyExists(err) {
			return nil, err
		}
		return ws.engine.GetNamespace(ctx, cluster, namespace)
	}

	return ws.engine.WatchNamespace(ctx, cluster, namespace)
}

func (ws *WorkloadServices) DeleteNamespace(ctx context.Context, cluster, namespace string) error {
	return ws.engine.DeleteNamespace(ctx, cluster, namespace)
}

func (ws *WorkloadServices) CreateNamespace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error) {
	return ws.engine.CreateNamespace(ctx, cluster, namespace)
}

func (ws *WorkloadServices) UpdateNameSpace(ctx context.Context, cluster string, namespace *corev1.Namespace) (*corev1.Namespace, error) {
	return ws.engine.UpdateNameSpace(ctx, cluster, namespace)
}

func (ws *WorkloadServices) PatchNameSpace(ctx context.Context, cluster, name string, patchType types.PatchType, patchData []byte) (*corev1.Namespace, error) {
	return ws.engine.PatchNameSpace(ctx, cluster, name, patchType, patchData)
}

func (ws *WorkloadServices) ListConfigMaps(ctx context.Context, listOptions *util.ListOptions) (*corev1.ConfigMapList, error) {
	list, err := ws.customEngine.ListConfigMaps(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetConfigMap(ctx context.Context, cluster, namespace, name string) (*corev1.ConfigMap, error) {
	return ws.engine.GetConfigMap(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) CreateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error) {
	return ws.engine.CreateConfigMap(ctx, cluster, namespace, configmap)
}

func (ws *WorkloadServices) UpdateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error) {
	return ws.engine.UpdateConfigMap(ctx, cluster, namespace, configmap)
}

func (ws *WorkloadServices) PatchConfigMap(ctx context.Context, cluster, namespace, name string) (*corev1.ConfigMap, error) {
	//  TODO implement me.
	panic("implement me")
}

func (ws *WorkloadServices) CreateCronJob(ctx context.Context, cluster, namespace string, cronJob *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return ws.engine.CreateCronJob(ctx, cluster, namespace, cronJob)
}

func (ws *WorkloadServices) GetCronJob(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
	return ws.engine.GetCronJob(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) UpdateCronJob(ctx context.Context, cluster, namespace string, cronJob *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return ws.engine.UpdateCronJob(ctx, cluster, namespace, cronJob)
}

func (ws *WorkloadServices) CreateJob(ctx context.Context, cluster, namespace string, job *batchv1.Job) (*batchv1.Job, error) {
	return ws.engine.CreateJob(ctx, cluster, namespace, job)
}

func (ws *WorkloadServices) GetJob(ctx context.Context, cluster, namespace, name string) (*batchv1.Job, error) {
	return ws.engine.GetJob(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) UpdateJob(ctx context.Context, cluster, namespace string, job *batchv1.Job) (*batchv1.Job, error) {
	return ws.engine.UpdateJob(ctx, cluster, namespace, job)
}

func (ws *WorkloadServices) DeleteConfigMap(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteConfigMap(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) DeleteDeployment(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteDeployment(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) PauseDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error) {
	deployment, err := ws.engine.GetDeployment(ctx, cluster, namespace, name)
	if err != nil {
		return &appsv1.Deployment{}, err
	}
	if deployment.Spec.Paused {
		return &appsv1.Deployment{}, fmt.Errorf("deployments.apps %s is already paused", name)
	}
	data := map[string]interface{}{
		"spec": map[string]interface{}{
			"paused": true,
		},
	}
	patchData, err := json.Marshal(data)
	if err != nil {
		return &appsv1.Deployment{}, err
	}
	return ws.engine.PatchDeployment(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) ResumeDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error) {
	deployment, err := ws.engine.GetDeployment(ctx, cluster, namespace, name)
	if err != nil {
		return &appsv1.Deployment{}, err
	}
	if !deployment.Spec.Paused {
		return &appsv1.Deployment{}, fmt.Errorf("deployments.apps %s is not paused", name)
	}
	data := map[string]interface{}{
		"spec": map[string]interface{}{
			"paused": false,
		},
	}
	patchData, err := json.Marshal(data)
	if err != nil {
		return &appsv1.Deployment{}, err
	}
	return ws.engine.PatchDeployment(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) RestartDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error) {
	patchData, err := util.GenRestartPatchData(time.Now().Unix())
	if err != nil {
		return nil, err
	}
	return ws.engine.PatchDeployment(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) StartDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error) {
	deploy, err := ws.engine.GetDeployment(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}

	patchData, err := util.GenStartPatchData(deploy.GetAnnotations())
	if err != nil {
		return nil, err
	}

	return ws.engine.PatchDeployment(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) StopDeployment(ctx context.Context, cluster, namespace, name string) (*appsv1.Deployment, error) {
	deploy, err := ws.engine.GetDeployment(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}

	patchData, err := util.GenStopPatchData(deploy.Spec.Replicas)
	if err != nil {
		return nil, err
	}

	return ws.engine.PatchDeployment(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

// equalIgnoreHash returns true if two given podTemplateSpec are equal, ignoring the diff in value of Labels[pod-template-hash]
// We ignore pod-template-hash because:
//  1. The hash result would be different upon podTemplateSpec API changes
//     (e.g. the addition of a new field will cause the hash code to change)
//  2. The deployment template won't have hash labels.
func equalIgnoreHash(template1, template2 *corev1.PodTemplateSpec) bool {
	t1Copy := template1.DeepCopy()
	t2Copy := template2.DeepCopy()
	// Remove hash labels from template.Labels before comparing
	delete(t1Copy.Labels, appsv1.DefaultDeploymentUniqueLabelKey)
	delete(t2Copy.Labels, appsv1.DefaultDeploymentUniqueLabelKey)
	return apiequality.Semantic.DeepEqual(t1Copy, t2Copy)
}

// getPatch returns a patch that can be applied to restore a Deployment to a
// previous version. If the returned error is nil the patch is valid.
func getDeploymentPatch(podTemplate *corev1.PodTemplateSpec, annotations map[string]string) (types.PatchType, []byte, error) {
	// Create a patch of the Deployment that replaces spec.template
	patch, err := json.Marshal([]interface{}{
		map[string]interface{}{
			"op":    "replace",
			"path":  "/spec/template",
			"value": podTemplate,
		},
		map[string]interface{}{
			"op":    "replace",
			"path":  "/metadata/annotations",
			"value": annotations,
		},
	})
	return types.JSONPatchType, patch, err
}

func (ws *WorkloadServices) RollbackDeployment(ctx context.Context, cluster, namespace, name string, revision int64) (*appsv1.Deployment, error) {
	deployment, err := ws.engine.GetDeployment(ctx, cluster, namespace, name)
	if err != nil {
		return &appsv1.Deployment{}, err
	}
	rsOpts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: nil, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(deployment.UID)).Options()
	rsList, err := ws.engine.ListReplicaSets(ctx, rsOpts)
	if err != nil {
		return &appsv1.Deployment{}, err
	}
	replicaSet := appsv1.ReplicaSet{}
	for _, rs := range rsList.Items {
		rv := util.FetchReplicaSetRevision(rs.Annotations)
		if rv == revision {
			replicaSet = rs
			break
		}
	}
	if replicaSet.Name == "" {
		return nil, fmt.Errorf("revision %d not found", revision)
	}

	// Skip if the revision already matches current Deployment
	if equalIgnoreHash(&replicaSet.Spec.Template, &deployment.Spec.Template) {
		return nil, fmt.Errorf("%s (current template already matches revision %d)", "skipped rollback", revision)
	}

	// remove hash label before patching back into the deployment
	delete(replicaSet.Spec.Template.Labels, appsv1.DefaultDeploymentUniqueLabelKey)

	// compute deployment annotations
	annotations := map[string]string{}
	for k := range annotationsToSkip {
		if v, ok := deployment.Annotations[k]; ok {
			annotations[k] = v
		}
	}
	for k, v := range replicaSet.Annotations {
		if !annotationsToSkip[k] {
			annotations[k] = v
		}
	}

	// make patch to restore
	patchType, patch, err := getDeploymentPatch(&replicaSet.Spec.Template, annotations)
	if err != nil {
		return nil, fmt.Errorf("failed restoring revision %d: %v", revision, err)
	}

	return ws.engine.PatchDeployment(ctx, cluster, namespace, name, patchType, patch)
}

func (ws *WorkloadServices) RestartStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error) {
	patchData, err := util.GenRestartPatchData(time.Now().Unix())
	if err != nil {
		return nil, err
	}
	return ws.PatchStatefulSet(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) StartStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error) {
	sts, err := ws.engine.GetStatefulSet(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}

	patchData, err := util.GenStartPatchData(sts.GetAnnotations())
	if err != nil {
		return nil, err
	}

	return ws.engine.PatchStatefulSet(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) StopStatefulSet(ctx context.Context, cluster, namespace, name string) (*appsv1.StatefulSet, error) {
	sts, err := ws.engine.GetStatefulSet(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}

	patchData, err := util.GenStopPatchData(sts.Spec.Replicas)
	if err != nil {
		return nil, err
	}

	return ws.engine.PatchStatefulSet(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) RollbackStatefulSet(ctx context.Context, cluster, namespace, name string, revision int64) (*appsv1.StatefulSet, error) {
	sts, err := ws.engine.GetStatefulSet(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}
	crOpts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: nil, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(sts.UID)).Options()
	revisions, err := ws.engine.ListControllerRevisions(ctx, crOpts)
	if err != nil {
		return nil, err
	}
	var controllerRevision appsv1.ControllerRevision
	for _, r := range revisions.Items {
		if r.Revision == revision {
			controllerRevision = r
			break
		}
	}
	if controllerRevision.Name == "" {
		return nil, fmt.Errorf("revision %d not found", revision)
	}
	patchData, err := json.Marshal(controllerRevision.Data)
	if err != nil {
		return nil, err
	}
	return ws.engine.PatchStatefulSet(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) RestartDaemonSet(ctx context.Context, cluster, namespace, name string) (*appsv1.DaemonSet, error) {
	patchData, err := util.GenRestartPatchData(time.Now().Unix())
	if err != nil {
		return nil, err
	}
	return ws.PatchDaemonSet(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) RollbackDaemonSet(ctx context.Context, cluster, namespace, name string, revision int64) (*appsv1.DaemonSet, error) {
	ds, err := ws.engine.GetDaemonSet(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}
	crOpts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: nil, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(ds.UID)).Options()
	revisions, err := ws.engine.ListControllerRevisions(ctx, crOpts)
	if err != nil {
		return nil, err
	}
	var controllerRevision appsv1.ControllerRevision
	for _, r := range revisions.Items {
		if r.Revision == revision {
			controllerRevision = r
			break
		}
	}
	if controllerRevision.Name == "" {
		return nil, fmt.Errorf("revision %d not found", revision)
	}
	patchData, err := json.Marshal(controllerRevision.Data)
	if err != nil {
		return nil, err
	}
	return ws.engine.PatchDaemonSet(ctx, cluster, namespace, name, types.StrategicMergePatchType, patchData)
}

func (ws *WorkloadServices) DeleteStatefulSet(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteStatefulSet(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) ListCustomResourceDefinitions(ctx context.Context, cluster string, queryPage *util.QueryPage) ([]apiextensionsv1.CustomResourceDefinition, error) {
	list := &apiextensionsv1.CustomResourceDefinitionList{}
	listOptions := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {}}}).Options()
	unStructObjList, err := ws.engine.ListCustomResources(ctx, constants.CustomResourceDefinitionGVR, listOptions)
	if err != nil {
		return nil, err
	}
	err = runtime.DefaultUnstructuredConverter.FromUnstructured(unStructObjList.UnstructuredContent(), list)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetRemainingItemCount())
	return list.Items, nil
}

func (ws *WorkloadServices) ListCustomResourceDefinitionsGroups(ctx context.Context, cluster string) ([]string, error) {
	crdList, err := ws.customEngine.ListCustomResources(ctx, constants.CustomResourceDefinitionGVR, &util.ListOptions{
		QueryPage: &util.QueryPage{
			PageSize: -1,
			Params:   map[util.SearchParam]interface{}{util.SearchParamOnlyMetadata: true},
		},
		Scope: util.Scope{util.Cluster(cluster): {}},
	})
	if err != nil {
		return nil, err
	}

	groups := sets.NewString()
	for _, crd := range crdList.Items {
		// the name of crd is resources.group
		names := strings.SplitN(crd.GetName(), ".", 2)
		if len(names) == 2 {
			groups.Insert(names[1])
		}
	}
	return groups.List(), nil
}

func (ws *WorkloadServices) GetCustomResourceDefinition(ctx context.Context, cluster, name string) (*apiextensionsv1.CustomResourceDefinition, error) {
	crd := &apiextensionsv1.CustomResourceDefinition{}
	unStructObj, err := ws.engine.GetCustomResource(ctx, cluster, "", name, constants.CustomResourceDefinitionGVR)
	if err != nil {
		return nil, err
	}
	err = runtime.DefaultUnstructuredConverter.FromUnstructured(unStructObj.UnstructuredContent(), crd)
	if err != nil {
		return nil, err
	}
	return crd, nil
}

func (ws *WorkloadServices) CreateCustomResourceDefinition(ctx context.Context, cluster string, obj *unstructured.Unstructured) (*apiextensionsv1.CustomResourceDefinition, error) {
	crd := &apiextensionsv1.CustomResourceDefinition{}
	unStructObj, err := ws.engine.CreateCustomResource(ctx, cluster, "", constants.CustomResourceDefinitionGVR, obj)
	if err != nil {
		return nil, err
	}
	err = runtime.DefaultUnstructuredConverter.FromUnstructured(unStructObj.UnstructuredContent(), crd)
	if err != nil {
		return nil, err
	}
	return crd, nil
}

func (ws *WorkloadServices) UpdateCustomResourceDefinition(ctx context.Context, cluster string, obj *unstructured.Unstructured) (*apiextensionsv1.CustomResourceDefinition, error) {
	crd := &apiextensionsv1.CustomResourceDefinition{}
	unStructObj, err := ws.engine.UpdateCustomResource(ctx, cluster, "", constants.CustomResourceDefinitionGVR, obj)
	if err != nil {
		return nil, err
	}
	err = runtime.DefaultUnstructuredConverter.FromUnstructured(unStructObj.UnstructuredContent(), crd)
	if err != nil {
		return nil, err
	}
	return crd, nil
}

func (ws *WorkloadServices) DeleteCustomResourceDefinition(ctx context.Context, cluster, name string) error {
	return ws.engine.DeleteCustomResource(ctx, cluster, "", name, constants.CustomResourceDefinitionGVR, nil)
}

func (ws *WorkloadServices) ListCustomResources(ctx context.Context, cluster, namespace, group, version, resource string, queryPage *util.QueryPage) (*unstructured.UnstructuredList, error) {
	gvr := schema.GroupVersionResource{Group: group, Version: version, Resource: resource}
	listOptions := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).Options()
	list, err := ws.engine.ListCustomResources(ctx, gvr, listOptions)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) GetCustomResource(ctx context.Context, cluster, namespace, name, group, version, resource string) (*unstructured.Unstructured, error) {
	gvr := schema.GroupVersionResource{Group: group, Version: version, Resource: resource}
	return ws.engine.GetCustomResource(ctx, cluster, namespace, name, gvr)
}

func (ws *WorkloadServices) CreateCustomResource(ctx context.Context, cluster, namespace, group, version, resource string, obj *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	gvr := schema.GroupVersionResource{Group: group, Version: version, Resource: resource}
	return ws.engine.CreateCustomResource(ctx, cluster, namespace, gvr, obj)
}

func (ws *WorkloadServices) UpdateCustomResource(ctx context.Context, cluster, namespace, group, version, resource string, obj *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	gvr := schema.GroupVersionResource{Group: group, Version: version, Resource: resource}
	return ws.engine.UpdateCustomResource(ctx, cluster, namespace, gvr, obj)
}

func (ws *WorkloadServices) UpdateCustomResourceStatus(ctx context.Context, cluster, namespace, group, version, resource string, obj *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	gvr := schema.GroupVersionResource{Group: group, Version: version, Resource: resource}
	return ws.engine.UpdateCustomResourceStatus(ctx, cluster, namespace, gvr, obj)
}

func (ws *WorkloadServices) PatchCustomResource(ctx context.Context, cluster, namespace, name, group, version, resource string, pt types.PatchType, data []byte, subResources ...string) (*unstructured.Unstructured, error) {
	gvr := schema.GroupVersionResource{Group: group, Version: version, Resource: resource}
	return ws.engine.PatchCustomResource(ctx, cluster, namespace, name, gvr, pt, data, subResources...)
}

func (ws *WorkloadServices) DeleteCustomResource(ctx context.Context, cluster, namespace, name, group, version, resource string, propagation *metav1.DeletionPropagation) error {
	gvr := schema.GroupVersionResource{Group: group, Version: version, Resource: resource}
	return ws.engine.DeleteCustomResource(ctx, cluster, namespace, name, gvr, propagation)
}

func (ws *WorkloadServices) ListJobs(ctx context.Context, listOptions *util.ListOptions) (*batchv1.JobList, error) {
	list, err := ws.customEngine.ListJobs(ctx, listOptions)
	if err != nil {
		return nil, err
	}

	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListJobsByCronJob(ctx context.Context, cluster, namespace, cronJobName string, queryPage *util.QueryPage) (*batchv1.JobList, error) {
	cj, err := ws.engine.GetCronJob(ctx, cluster, namespace, cronJobName)
	if err != nil {
		return nil, err
	}
	listOptions := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(cj.GetUID())).Options()
	list, err := ws.engine.ListJobs(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListCronJobs(ctx context.Context, listOptions *util.ListOptions) (*batchv1.CronJobList, error) {
	list, err := ws.customEngine.ListCronJobs(ctx, listOptions)
	if err != nil {
		return nil, err
	}

	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) PauseCronJob(ctx context.Context, cluster, namespace, name string, paused bool) (*unstructured.Unstructured, error) {
	ctx = context.WithValue(ctx, constants.LoadResourceSchemaKey, constants.MemberCluster)
	data := map[string]interface{}{
		"spec": map[string]interface{}{
			"suspend": paused,
		},
	}
	patchData, err := json.Marshal(data)
	if err != nil {
		return nil, err
	}
	return ws.engine.PatchCronJob(ctx, cluster, namespace, name, types.MergePatchType, patchData)
}

func (ws *WorkloadServices) ListPodsByJob(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error) {
	job, err := ws.engine.GetJob(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(job.UID)).Options()
	list, err := ws.engine.ListPods(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) ListNamespaces(ctx context.Context, listOptions *util.ListOptions) (*corev1.NamespaceList, error) {
	list, err := ws.customEngine.ListNamespaces(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetNamespace(ctx context.Context, cluster, name string) (*corev1.Namespace, error) {
	return ws.engine.GetNamespace(ctx, cluster, name)
}

func (ws *WorkloadServices) ListResourceQuotas(ctx context.Context, listOptions *util.ListOptions) (*corev1.ResourceQuotaList, error) {
	list, err := ws.engine.ListResourceQuotas(ctx, util.BuildSingleClusterListOptions(listOptions).Options())
	if err != nil {
		return nil, err
	}

	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetResourceQuota(ctx context.Context, cluster, namespace, name string) (*corev1.ResourceQuota, error) {
	return ws.engine.GetResourceQuota(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) CreateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error) {
	return ws.engine.CreateResourceQuota(ctx, cluster, namespace, quota)
}

func (ws *WorkloadServices) UpdateResourceQuota(ctx context.Context, cluster, namespace string, quota *corev1.ResourceQuota) (*corev1.ResourceQuota, error) {
	return ws.engine.UpdateResourceQuota(ctx, cluster, namespace, quota)
}

func (ws *WorkloadServices) ListLimitRanges(ctx context.Context, listOptions *util.ListOptions) (*corev1.LimitRangeList, error) {
	list, err := ws.customEngine.ListLimitRanges(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetLimitRange(ctx context.Context, cluster, namespace, name string) (*corev1.LimitRange, error) {
	return ws.engine.GetLimitRange(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) CreateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error) {
	return ws.engine.CreateLimitRange(ctx, cluster, namespace, limitrange)
}

func (ws *WorkloadServices) UpdateLimitRange(ctx context.Context, cluster, namespace string, limitrange *corev1.LimitRange) (*corev1.LimitRange, error) {
	return ws.engine.UpdateLimitRange(ctx, cluster, namespace, limitrange)
}

func (ws *WorkloadServices) DeleteLimitRange(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteLimitRange(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) GetPod(ctx context.Context, clusterName, namespaceName, podName string) (*corev1.Pod, error) {
	return ws.engine.GetPod(ctx, clusterName, namespaceName, podName)
}

func (ws *WorkloadServices) GetReplicaSet(ctx context.Context, cluster, ns, name string) (*appsv1.ReplicaSet, error) {
	return ws.engine.GetReplicaSet(ctx, cluster, ns, name)
}

func (ws *WorkloadServices) UpdateReplicaSet(ctx context.Context, cluster, namespace string, rs *appsv1.ReplicaSet) (*appsv1.ReplicaSet, error) {
	return ws.engine.UpdateReplicaSet(ctx, cluster, namespace, rs)
}

func (ws *WorkloadServices) DeleteReplicaSet(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteReplicaSet(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) ListDaemonSets(ctx context.Context, listOptions *util.ListOptions) (*appsv1.DaemonSetList, error) {
	list, err := ws.customEngine.ListDaemonSets(ctx, listOptions)
	if err != nil {
		return nil, err
	}

	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListStatefulSets(ctx context.Context, listOptions *util.ListOptions) (*appsv1.StatefulSetList, error) {
	list, err := ws.customEngine.ListStatefulSets(ctx, listOptions)
	if err != nil {
		return nil, err
	}

	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListDeployments(ctx context.Context, listOptions *util.ListOptions) (*appsv1.DeploymentList, error) {
	list, err := ws.customEngine.ListDeployments(ctx, listOptions)
	if err != nil {
		return nil, err
	}

	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListPods(ctx context.Context, listOptions *util.ListOptions) (*corev1.PodList, error) {
	var (
		list *corev1.PodList
		err  error
	)
	if len(listOptions.Scope) > 1 {
		list, err = ws.customEngine.ListPods(ctx, listOptions)
	} else {
		list, err = ws.engine.ListPods(ctx, util.BuildSingleClusterListOptions(listOptions).Options())
	}
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListServiceAccounts(ctx context.Context, listOptions *util.ListOptions) (*corev1.ServiceAccountList, error) {
	var (
		list *corev1.ServiceAccountList
		err  error
	)
	list, err = ws.engine.ListServiceAccounts(ctx, util.BuildSingleClusterListOptions(listOptions).Options())
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) CreatePod(ctx context.Context, cluster, namespace string, pod *corev1.Pod) (*corev1.Pod, error) {
	return ws.engine.CreatePod(ctx, cluster, namespace, pod)
}

func (ws *WorkloadServices) UpdatePod(ctx context.Context, cluster, namespace string, pod *corev1.Pod) (*corev1.Pod, error) {
	return ws.engine.UpdatePod(ctx, cluster, namespace, pod)
}

func (ws *WorkloadServices) CreateDeployment(ctx context.Context, cluster, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error) {
	return ws.engine.CreateDeployment(ctx, cluster, namespace, deploy)
}

func (ws *WorkloadServices) GetDeployment(ctx context.Context, clusterName, namespace, name string) (*appsv1.Deployment, error) {
	return ws.engine.GetDeployment(ctx, clusterName, namespace, name)
}

func (ws *WorkloadServices) UpdateDeployment(ctx context.Context, clusterName, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error) {
	return ws.engine.UpdateDeployment(ctx, clusterName, namespace, deploy)
}

func (ws *WorkloadServices) PatchDeployment(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.Deployment, error) {
	return ws.engine.PatchDeployment(ctx, cluster, namespace, name, patchType, patchData)
}

func (ws *WorkloadServices) PatchStatefulSet(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.StatefulSet, error) {
	return ws.engine.PatchStatefulSet(ctx, cluster, namespace, name, patchType, patchData)
}

func (ws *WorkloadServices) PatchDaemonSet(ctx context.Context, cluster, namespace, name string, patchType types.PatchType, patchData []byte) (*appsv1.DaemonSet, error) {
	return ws.engine.PatchDaemonSet(ctx, cluster, namespace, name, patchType, patchData)
}

func (ws *WorkloadServices) CreateStatefulSet(ctx context.Context, cluster, namespace string, sts *appsv1.StatefulSet) (*appsv1.StatefulSet, error) {
	return ws.engine.CreateStatefulSet(ctx, cluster, namespace, sts)
}

func (ws *WorkloadServices) GetStatefulSet(ctx context.Context, clusterName, namespace, name string) (*appsv1.StatefulSet, error) {
	return ws.engine.GetStatefulSet(ctx, clusterName, namespace, name)
}

func (ws *WorkloadServices) UpdateStatefulSet(ctx context.Context, clusterName, namespace string, sts *appsv1.StatefulSet) (*appsv1.StatefulSet, error) {
	older, err := ws.engine.GetStatefulSet(ctx, clusterName, namespace, sts.GetName())
	if err != nil {
		return nil, err
	}
	olderJs, err := helper.EncodeToJSON(older)
	if err != nil {
		return nil, err
	}

	newer := sts.DeepCopy()
	newerJs, err := helper.EncodeToJSON(newer)
	if err != nil {
		return nil, err
	}

	// Short-circuit if the json is unchanged.
	if reflect.DeepEqual(olderJs, newerJs) {
		return nil, nil
	}

	patchBytes, err := strategicpatch.CreateTwoWayMergePatch(olderJs, newerJs, &appsv1.StatefulSet{}, preconditions...)
	if err != nil {
		return nil, err
	}
	klog.V(5).Infof("The patch json of statefulset %s is %s", sts.GetName(), string(patchBytes))

	return ws.engine.PatchStatefulSet(ctx, clusterName, namespace, sts.GetName(), types.StrategicMergePatchType, patchBytes)
}

func (ws *WorkloadServices) CreateDaemonSet(ctx context.Context, cluster, namespace string, ds *appsv1.DaemonSet) (*appsv1.DaemonSet, error) {
	return ws.engine.CreateDaemonSet(ctx, cluster, namespace, ds)
}

func (ws *WorkloadServices) GetDaemonSet(ctx context.Context, clusterName, namespace, name string) (*appsv1.DaemonSet, error) {
	return ws.engine.GetDaemonSet(ctx, clusterName, namespace, name)
}

func (ws *WorkloadServices) UpdateDaemonSet(ctx context.Context, clusterName, namespace string, ds *appsv1.DaemonSet) (*appsv1.DaemonSet, error) {
	return ws.engine.UpdateDaemonSet(ctx, clusterName, namespace, ds)
}

func (ws *WorkloadServices) ListReplicaSetsByDeployment(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*appsv1.ReplicaSetList, error) {
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerName(name).Options()
	list, err := ws.engine.ListReplicaSets(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListRevisionsByStatefulSet(ctx context.Context, cluster, namespace, statefulset string, queryPage *util.QueryPage) (*appsv1.ControllerRevisionList, error) {
	sts, err := ws.engine.GetStatefulSet(ctx, cluster, namespace, statefulset)
	if err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(sts.UID)).Options()
	list, err := ws.engine.ListControllerRevisions(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) ListRevisionsByDaemonSet(ctx context.Context, cluster, namespace, daemonSet string, queryPage *util.QueryPage) (*appsv1.ControllerRevisionList, error) {
	ds, err := ws.engine.GetDaemonSet(ctx, cluster, namespace, daemonSet)
	if err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(ds.UID)).Options()
	list, err := ws.engine.ListControllerRevisions(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) ListPodsByDeployment(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error) {
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerSeniority(1).OwnerName(name).Options()
	list, err := ws.engine.ListPods(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) ListPodsByStatefulSet(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error) {
	statefulSet, err := ws.engine.GetStatefulSet(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(statefulSet.UID)).Options()
	list, err := ws.engine.ListPods(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) ListPodsByDamonSet(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error) {
	statefulSet, err := ws.engine.GetDaemonSet(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(statefulSet.UID)).Options()
	list, err := ws.engine.ListPods(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) ListPodsByNetworkPolicy(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error) {
	networkPolicy, err := ws.engine.GetNetworkPolicy(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}

	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).Options()
	if opts.LabelSelector == "" {
		opts.LabelSelector = metav1.FormatLabelSelector(&networkPolicy.Spec.PodSelector)
	} else {
		opts.LabelSelector = opts.LabelSelector + "," + metav1.FormatLabelSelector(&networkPolicy.Spec.PodSelector)
	}
	list, err := ws.engine.ListPods(ctx, opts)
	if err != nil {
		return nil, err
	}

	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) ListPodsByReplicaSet(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error) {
	replicaSet, err := ws.engine.GetReplicaSet(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(replicaSet.UID)).Options()
	list, err := ws.engine.ListPods(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) ListServices(ctx context.Context, listOptions *util.ListOptions) (*corev1.ServiceList, error) {
	list, err := ws.customEngine.ListServices(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetService(ctx context.Context, cluster, namespace, name string) (*corev1.Service, error) {
	return ws.engine.GetService(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) ListPodsByService(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.PodList, error) {
	service, err := ws.engine.GetService(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}

	if len(service.Spec.Selector) == 0 {
		return &corev1.PodList{}, nil
	}

	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}})
	for k, v := range service.Spec.Selector {
		opts = opts.LabelSelector(k, []string{v})
	}
	list, err := ws.engine.ListPods(ctx, opts.Options())
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) ListEventsByService(ctx context.Context, cluster, namespace, service string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	svc, err := ws.engine.GetService(ctx, cluster, namespace, service)
	if err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).FieldSelector("involvedObject.uid", []string{string(svc.UID)}).Options()
	list, err := ws.engine.ListEvents(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) CreateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error) {
	return ws.engine.CreateService(ctx, cluster, namespace, service)
}

func (ws *WorkloadServices) UpdateService(ctx context.Context, cluster, namespace string, service *corev1.Service) (*corev1.Service, error) {
	return ws.engine.UpdateService(ctx, cluster, namespace, service)
}

func (ws *WorkloadServices) UpdateServiceAccount(ctx context.Context, cluster, namespace string, service *corev1.ServiceAccount) (*corev1.ServiceAccount, error) {
	return ws.engine.UpdateServiceAccount(ctx, cluster, namespace, service)
}

func (ws *WorkloadServices) DeleteService(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteService(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) ListServicesByDeployment(ctx context.Context, cluster, namespace, deployment, name string) ([]corev1.Service, error) {
	deploy, err := ws.engine.GetDeployment(ctx, cluster, namespace, deployment)
	if err != nil {
		return nil, err
	}
	serviceList, err := ws.ListServices(ctx, &util.ListOptions{
		QueryPage: &util.QueryPage{
			PageSize: util.MaxPageSize,
			Name:     name,
		},
		Scope: util.Scope{
			util.Cluster(cluster): {namespace},
		},
	})
	if err != nil {
		return nil, err
	}
	services := make([]corev1.Service, 0)
	for _, service := range serviceList.Items {
		if service.Spec.Selector != nil && maputil.ContainsMap(deploy.Spec.Template.Labels, service.Spec.Selector) {
			services = append(services, service)
		}
	}
	return services, nil
}

func (ws *WorkloadServices) ListServicesByStatefulSet(ctx context.Context, cluster, namespace, statefulSet, name string) ([]corev1.Service, error) {
	ss, err := ws.engine.GetStatefulSet(ctx, cluster, namespace, statefulSet)
	if err != nil {
		return nil, err
	}
	serviceList, err := ws.ListServices(ctx, &util.ListOptions{
		QueryPage: &util.QueryPage{
			PageSize: util.MaxPageSize,
			Name:     name,
		},
		Scope: util.Scope{
			util.Cluster(cluster): {namespace},
		},
	})
	if err != nil {
		return nil, err
	}
	services := make([]corev1.Service, 0)
	for _, service := range serviceList.Items {
		if service.Spec.Selector != nil && maputil.ContainsMap(ss.Spec.Template.Labels, service.Spec.Selector) {
			services = append(services, service)
		}
	}
	return services, nil
}

func (ws *WorkloadServices) ListServicesByDaemonSet(ctx context.Context, cluster, namespace, daemonSet, name string) ([]corev1.Service, error) {
	ds, err := ws.engine.GetDaemonSet(ctx, cluster, namespace, daemonSet)
	if err != nil {
		return nil, err
	}
	serviceList, err := ws.ListServices(ctx, &util.ListOptions{
		QueryPage: &util.QueryPage{
			PageSize: util.MaxPageSize,
			Name:     name,
		},
		Scope: util.Scope{
			util.Cluster(cluster): {namespace},
		},
	})
	if err != nil {
		return nil, err
	}
	services := make([]corev1.Service, 0)
	for _, service := range serviceList.Items {
		if service.Spec.Selector != nil && maputil.ContainsMap(ds.Spec.Template.Labels, service.Spec.Selector) {
			services = append(services, service)
		}
	}
	return services, nil
}

func (ws *WorkloadServices) ListMetallbIPAddressPools(ctx context.Context, listOptions *util.ListOptions) (*metallbv1beta1.IPAddressPoolList, error) {
	unstructuredList, err := ws.engine.ListCustomResources(ctx, constants.MetaLlbGVR, util.BuildSingleClusterListOptions(listOptions).Options())
	if err != nil {
		return nil, err
	}

	opsList := &metallbv1beta1.IPAddressPoolList{}
	err = runtime.DefaultUnstructuredConverter.FromUnstructured(unstructuredList.UnstructuredContent(), opsList)
	if err != nil {
		return nil, err
	}

	listOptions.QueryPage.SetTotalByRemainCount(int32(len(opsList.Items)), opsList.GetRemainingItemCount())
	return opsList, nil
}

func (ws *WorkloadServices) ListIngresses(ctx context.Context, listOptions *util.ListOptions) (*networkingv1.IngressList, error) {
	list, err := ws.customEngine.ListIngresses(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetIngress(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
	return ws.engine.GetIngress(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) ListEventsByIngress(ctx context.Context, cluster, namespace, ingress string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	ing, err := ws.engine.GetIngress(ctx, cluster, namespace, ingress)
	if err != nil {
		return nil, err
	}

	opts := util.BuildSingleClusterListOptions(&util.ListOptions{
		QueryPage: queryPage,
		Scope:     map[util.Cluster]util.Namespaces{util.Cluster(cluster): {namespace}},
	}).FieldSelector("involvedObject.uid", []string{string(ing.GetUID())}).Options()

	list, err := ws.engine.ListEvents(ctx, opts)
	if err != nil {
		return nil, err
	}

	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) CreateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return ws.engine.CreateIngress(ctx, cluster, namespace, ingress)
}

func (ws *WorkloadServices) UpdateIngress(ctx context.Context, cluster, namespace string, ingress *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return ws.engine.UpdateIngress(ctx, cluster, namespace, ingress)
}

func (ws *WorkloadServices) PatchIngress(ctx context.Context, cluster, namespace, name string) (*networkingv1.Ingress, error) {
	//  TODO implement me.
	panic("implement me")
}

func (ws *WorkloadServices) DeleteIngress(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteIngress(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) ListNetworkPolicies(ctx context.Context, listOptions *util.ListOptions) (*networkingv1.NetworkPolicyList, error) {
	list, err := ws.customEngine.ListNetworkPolicies(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetNetworkPolicy(ctx context.Context, cluster, namespace, name string) (*networkingv1.NetworkPolicy, error) {
	return ws.engine.GetNetworkPolicy(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) CreateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error) {
	return ws.engine.CreateNetworkPolicy(ctx, cluster, namespace, networkpolicy)
}

func (ws *WorkloadServices) UpdateNetworkPolicy(ctx context.Context, cluster, namespace string, networkpolicy *networkingv1.NetworkPolicy) (*networkingv1.NetworkPolicy, error) {
	return ws.engine.UpdateNetworkPolicy(ctx, cluster, namespace, networkpolicy)
}

func (ws *WorkloadServices) DeleteNetworkPolicy(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteNetworkPolicy(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) ListIngressClasses(ctx context.Context, listOptions *util.ListOptions) (*networkingv1.IngressClassList, error) {
	return ws.engine.ListIngressClasses(ctx, util.BuildSingleClusterListOptions(listOptions).Options())
}

func (ws *WorkloadServices) ListPersistentVolumeClaims(ctx context.Context, listOptions *util.ListOptions) (*corev1.PersistentVolumeClaimList, error) {
	list, err := ws.customEngine.ListPersistentVolumeClaims(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetPersistentVolumeClaim(ctx context.Context, cluster, namespace, name string) (*corev1.PersistentVolumeClaim, error) {
	return ws.engine.GetPersistentVolumeClaim(ctx, cluster, namespace, name)
}

// GetDeployStatusCore gets deployment status(Deleting, Stopped, Running) from deploy.
func GetDeployStatusCore(deploy *appsv1.Deployment) constants.WorkloadState {
	if deploy.DeletionTimestamp != nil {
		return constants.WorkloadDeleting
	}

	// Check if the deployment status is Running or Stopped.
	for _, condition := range deploy.Status.Conditions {
		if condition.Type == appsv1.DeploymentAvailable {
			if condition.Status == corev1.ConditionTrue {
				if deploy.Status.Replicas == deploy.Status.ReadyReplicas && deploy.Status.Replicas == deploy.Status.AvailableReplicas {
					if deploy.Status.ReadyReplicas > 0 {
						return constants.WorkloadRunning
					}
					return constants.WorkloadStopped
				}
			}
			return constants.WorkloadNotReady
		}
	}
	return constants.WorkloadWaiting
}

func GetStatefulStatusCore(statefulSet *appsv1.StatefulSet) constants.WorkloadState {
	if statefulSet.DeletionTimestamp != nil {
		return constants.WorkloadDeleting
	}

	if statefulSet.Status.Replicas == 0 {
		return constants.WorkloadStopped
	}

	// Check if the statefulSet status is running and equal to expectation.
	if statefulSet.Spec.Replicas != nil {
		if statefulSet.Status.ReadyReplicas == statefulSet.Status.Replicas && *statefulSet.Spec.Replicas == statefulSet.Status.Replicas {
			return constants.WorkloadRunning
		}
		return constants.WorkloadNotReady
	}

	return constants.WorkloadWaiting
}

func GetDaemonSetStatusCore(daemonSet *appsv1.DaemonSet) constants.WorkloadState {
	if daemonSet.DeletionTimestamp != nil {
		return constants.WorkloadDeleting
	}

	if daemonSet.Status.NumberUnavailable > 0 {
		return constants.WorkloadNotReady
	}

	// Check if the daemonSet status is running and equal to expectation.
	if daemonSet.Status.NumberAvailable > 0 {
		if daemonSet.Status.NumberAvailable == daemonSet.Status.DesiredNumberScheduled && daemonSet.Status.NumberAvailable == daemonSet.Status.CurrentNumberScheduled {
			return constants.WorkloadRunning
		}
	}

	if daemonSet.Status.DesiredNumberScheduled == 0 {
		return constants.WorkloadStopped
	}

	return constants.WorkloadWaiting
}

func (ws *WorkloadServices) ListEvents(ctx context.Context, listOptions *util.ListOptions) (*corev1.EventList, error) {
	list, err := ws.engine.ListEvents(ctx, util.BuildSingleClusterListOptions(listOptions).Options())
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByDeployment(ctx context.Context, cluster, namespace, deployName string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	wg := errgroup.Group{}
	uids := make([]string, 0)
	// About 150ms per request.
	wg.Go(func() error {
		deploy, err := ws.engine.GetDeployment(ctx, cluster, namespace, deployName)
		if err != nil {
			return err
		}
		listRsOptions := builder.ListOptionsBuilder().Clusters(cluster).Namespaces(namespace).OwnerUID(string(deploy.UID)).Options()
		rsList, err := ws.engine.ListReplicaSets(ctx, listRsOptions)
		if err != nil {
			return err
		}
		rsUIDs := make([]string, 0, len(rsList.Items))
		for _, rs := range rsList.Items {
			rsUIDs = append(rsUIDs, string(rs.UID))
		}

		listPodsOptions := builder.ListOptionsBuilder().Clusters(cluster).Namespaces(namespace).OwnerUID(string(deploy.UID)).OwnerSeniority(1).Options()

		podList, err := ws.engine.ListPods(ctx, listPodsOptions)
		if err != nil {
			return err
		}
		podUIDs := make([]string, 0, len(podList.Items))
		for _, pod := range podList.Items {
			podUIDs = append(podUIDs, string(pod.UID))
		}

		uids = append(uids, string(deploy.UID))
		uids = append(uids, rsUIDs...)
		uids = append(uids, podUIDs...)
		return nil
	})

	if err := wg.Wait(); err != nil {
		return nil, err
	}

	listEventsOptions := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).FieldSelector("involvedObject.uid", uids).Options()
	list, err := ws.engine.ListEvents(ctx, listEventsOptions)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByStatefulSet(ctx context.Context, cluster, namespace, statefulSet string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	wg := errgroup.Group{}
	uids := make([]string, 0)
	wg.Go(func() error {
		sts, err := ws.engine.GetStatefulSet(ctx, cluster, namespace, statefulSet)
		if err != nil {
			return err
		}
		listPodsOptions := builder.ListOptionsBuilder().Clusters(cluster).Namespaces(namespace).OwnerUID(string(sts.UID)).Options()
		podList, err := ws.engine.ListPods(ctx, listPodsOptions)
		if err != nil {
			return err
		}
		uids = append(uids, string(sts.UID))
		for _, pod := range podList.Items {
			uids = append(uids, string(pod.UID))
		}
		return nil
	})

	if err := wg.Wait(); err != nil {
		return nil, err
	}

	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).FieldSelector("involvedObject.uid", uids).Options()
	list, err := ws.engine.ListEvents(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByDaemonSet(ctx context.Context, cluster, namespace, daemonSet string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	wg := errgroup.Group{}
	uids := make([]string, 0)
	wg.Go(func() error {
		ds, err := ws.engine.GetDaemonSet(ctx, cluster, namespace, daemonSet)
		if err != nil {
			return err
		}
		listPodsOptions := builder.ListOptionsBuilder().Clusters(cluster).Namespaces(namespace).OwnerUID(string(ds.UID)).Options()
		podList, err := ws.engine.ListPods(ctx, listPodsOptions)
		if err != nil {
			return err
		}
		uids = append(uids, string(ds.UID))
		for _, pod := range podList.Items {
			uids = append(uids, string(pod.UID))
		}
		return nil
	})

	if err := wg.Wait(); err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).FieldSelector("involvedObject.uid", uids).Options()
	list, err := ws.engine.ListEvents(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByPod(ctx context.Context, cluster, namespace, pod string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	po, err := ws.engine.GetPod(ctx, cluster, namespace, pod)
	if err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{
		QueryPage: queryPage,
		Scope:     map[util.Cluster]util.Namespaces{util.Cluster(cluster): {namespace}},
	}).FieldSelector("involvedObject.uid", []string{string(po.UID)}).Options()
	list, err := ws.engine.ListEvents(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByJob(ctx context.Context, cluster, namespace, job string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	wg := errgroup.Group{}
	uids := make([]string, 0)
	wg.Go(func() error {
		targetJob, err := ws.engine.GetJob(ctx, cluster, namespace, job)
		if err != nil {
			return err
		}
		listPodsOptions := builder.ListOptionsBuilder().Clusters(cluster).Namespaces(namespace).OwnerUID(string(targetJob.UID)).Options()
		podList, err := ws.engine.ListPods(ctx, listPodsOptions)
		if err != nil {
			return err
		}
		uids = append(uids, string(targetJob.UID))
		for _, pod := range podList.Items {
			uids = append(uids, string(pod.UID))
		}
		return nil
	})

	if err := wg.Wait(); err != nil {
		return nil, err
	}
	opts := util.BuildSingleClusterListOptions(&util.ListOptions{
		QueryPage: queryPage,
		Scope:     map[util.Cluster]util.Namespaces{util.Cluster(cluster): {namespace}},
	},
	).FieldSelector("involvedObject.uid", uids).Options()

	list, err := ws.engine.ListEvents(ctx, opts)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByCronJob(ctx context.Context, cluster, namespace, cronJob string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	wg := errgroup.Group{}
	uids := make([]string, 0)
	wg.Go(func() error {
		cj, err := ws.engine.GetCronJob(ctx, cluster, namespace, cronJob)
		if err != nil {
			return err
		}
		listJobOptions := builder.ListOptionsBuilder().Clusters(cluster).Namespaces(namespace).OwnerUID(string(cj.GetUID())).Options()
		jobList, err := ws.engine.ListJobs(ctx, listJobOptions)
		if err != nil {
			return err
		}
		jobUIDs := make([]string, 0, len(jobList.Items))
		for _, rs := range jobList.Items {
			jobUIDs = append(jobUIDs, string(rs.UID))
		}

		listPodsOptions := builder.ListOptionsBuilder().Clusters(cluster).Namespaces(namespace).OwnerUID(string(cj.GetUID())).OwnerSeniority(1).Options()

		podList, err := ws.engine.ListPods(ctx, listPodsOptions)
		if err != nil {
			return err
		}
		podUIDs := make([]string, 0, len(podList.Items))
		for _, pod := range podList.Items {
			podUIDs = append(podUIDs, string(pod.UID))
		}

		uids = append(uids, string(cj.GetUID()))
		uids = append(uids, jobUIDs...)
		uids = append(uids, podUIDs...)
		return nil
	})

	if err := wg.Wait(); err != nil {
		return nil, err
	}
	listEventsOptions := util.BuildSingleClusterListOptions(&util.ListOptions{
		QueryPage: queryPage,
		Scope:     map[util.Cluster]util.Namespaces{util.Cluster(cluster): {namespace}},
	},
	).FieldSelector("involvedObject.uid", uids).Options()
	list, err := ws.engine.ListEvents(ctx, listEventsOptions)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	hpa, err := ws.engine.GetHorizontalPodAutoscaler(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}
	listEventsOptions := util.BuildSingleClusterListOptions(&util.ListOptions{
		QueryPage: queryPage,
		Scope:     map[util.Cluster]util.Namespaces{util.Cluster(cluster): {namespace}},
	},
	).FieldSelector("involvedObject.uid", []string{string(hpa.GetUID())}).Options()
	list, err := ws.engine.ListEvents(ctx, listEventsOptions)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByReplicaSet(ctx context.Context, cluster, namespace, replicaSet string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	rs, err := ws.engine.GetReplicaSet(ctx, cluster, namespace, replicaSet)
	if err != nil {
		return nil, err
	}

	maxQueryPage := util.NewPage([]util.QueryPageSelect{util.CommonPageOpts(1, -1, "", "")})
	listPodsOptions := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: maxQueryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).OwnerUID(string(rs.UID)).Options()
	podList, err := ws.engine.ListPods(ctx, listPodsOptions)
	if err != nil {
		return nil, err
	}

	uids := make([]string, 0)
	uids = append(uids, string(rs.UID))
	for _, pod := range podList.Items {
		uids = append(uids, string(pod.UID))
	}

	listEventsOptions := util.BuildSingleClusterListOptions(&util.ListOptions{QueryPage: queryPage, Scope: util.Scope{util.Cluster(cluster): {namespace}}}).FieldSelector("involvedObject.uid", uids).Options()
	list, err := ws.engine.ListEvents(ctx, listEventsOptions)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByPersistentVolumeClaim(ctx context.Context, cluster, namespace, name string, queryPage *util.QueryPage) (*corev1.EventList, error) {
	pvc, err := ws.engine.GetPersistentVolumeClaim(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}
	listEventsOptions := util.BuildSingleClusterListOptions(&util.ListOptions{
		QueryPage: queryPage,
		Scope:     map[util.Cluster]util.Namespaces{util.Cluster(cluster): {namespace}},
	},
	).FieldSelector("involvedObject.uid", []string{string(pvc.GetUID())}).Options()
	list, err := ws.engine.ListEvents(ctx, listEventsOptions)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) ListEventsByGroupVersionResource(ctx context.Context, cluster, namespace, name string, gvr schema.GroupVersionResource, queryPage *util.QueryPage) (*corev1.EventList, error) {
	resources, err := ws.engine.GetCustomResource(ctx, cluster, namespace, name, gvr)
	if err != nil {
		return nil, err
	}

	listEventsOptions := util.BuildSingleClusterListOptions(&util.ListOptions{
		QueryPage: queryPage,
		Scope:     map[util.Cluster]util.Namespaces{util.Cluster(cluster): {namespace}},
	},
	).FieldSelector("involvedObject.uid", []string{string(resources.GetUID())}).Options()
	list, err := ws.engine.ListEvents(ctx, listEventsOptions)
	if err != nil {
		return nil, err
	}
	queryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) GetSecret(ctx context.Context, clusterName, namespace, name string) (*corev1.Secret, error) {
	return ws.engine.GetSecret(ctx, clusterName, namespace, name)
}

func (ws *WorkloadServices) UpdateSecret(ctx context.Context, clusterName string, secret *corev1.Secret) (*corev1.Secret, error) {
	return ws.engine.UpdateSecret(ctx, clusterName, secret)
}

func (ws *WorkloadServices) DeleteSecret(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteSecret(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) ListSecrets(ctx context.Context, listOptions *util.ListOptions) (*corev1.SecretList, error) {
	list, err := ws.customEngine.ListSecrets(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) CreateSecret(ctx context.Context, cluster, namespace string, secret *corev1.Secret) (*corev1.Secret, error) {
	return ws.engine.CreateSecret(ctx, cluster, namespace, secret)
}

func (ws *WorkloadServices) DeleteJob(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteJob(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) RestartJob(ctx context.Context, cluster, namespace, name, resourceVersion string) (*batchv1.Job, error) {
	job, err := ws.engine.GetJob(ctx, cluster, namespace, name)
	if err != nil {
		return nil, err
	}
	// if resourceVersion not match then can't restart and return error
	if job.GetObjectMeta().GetResourceVersion() != resourceVersion {
		return nil, fmt.Errorf("please apply your changes to the latest version and try again")
	}
	newJob := job.DeepCopy()
	newJob.ResourceVersion = ""
	newJob.Annotations["revisions"] = strings.Replace(job.Annotations["revisions"], "running", "unfinished", -1)

	delete(newJob.Spec.Selector.MatchLabels, "controller-uid")
	delete(newJob.Spec.Template.ObjectMeta.Labels, "controller-uid")

	err = ws.engine.DeleteJob(ctx, cluster, namespace, name)
	if err != nil {
		klog.ErrorS(err, "failed to restart the job", "cluster", cluster, "namespace", namespace, "jobName", name)
		return nil, fmt.Errorf("failed to restart the job %s", name)
	}
	for i := 0; i < 3; i++ {
		job, err = ws.engine.CreateJob(ctx, cluster, namespace, newJob)
		if err != nil {
			time.Sleep(time.Second)
			continue
		}
		break
	}
	if err != nil {
		klog.ErrorS(err, "failed to restart the job", "cluster", cluster, "namespace", namespace, "jobName", name)
		return nil, fmt.Errorf("failed to restart the job %s", name)
	}
	return job, nil
}

func (ws *WorkloadServices) DeleteCronJob(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteCronJob(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) DeletePod(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeletePod(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) DeleteServiceAccount(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteServiceAccount(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) DeleteDaemonSet(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteDaemonSet(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) CreatePersistentVolumeClaim(ctx context.Context, cluster, namespace string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error) {
	return ws.engine.CreatePersistentVolumeClaim(ctx, cluster, namespace, pvc)
}

func (ws *WorkloadServices) DeletePersistentVolumeClaim(ctx context.Context, cluster, name, namespaces string) error {
	return ws.engine.DeletePersistentVolumeClaim(ctx, cluster, name, namespaces)
}

func (ws *WorkloadServices) DeletePersistentVolumeClaimSnapshot(ctx context.Context, cluster, namespaces, name string) error {
	return ws.engine.DeletePersistentVolumeClaimSnapshot(ctx, cluster, namespaces, name)
}

func (ws *WorkloadServices) PatchPersistentVolumeClaimAnnotations(ctx context.Context, cluster, name, namespaces string, annotations map[string]string) (*corev1.PersistentVolumeClaim, error) {
	loadBytes, _ := util.AnnotationsConvert(annotations)
	jsonType := types.JSONPatchType
	patchedPVC, err := ws.engine.PatchPersistentVolumeClaim(ctx, cluster, name, namespaces, loadBytes, jsonType)
	if err != nil {
		return nil, err
	}
	return patchedPVC, nil
}

func (ws *WorkloadServices) PatchPersistentVolumeClaimLabels(ctx context.Context, cluster, name, namespaces string, labels map[string]string) (*corev1.PersistentVolumeClaim, error) {
	loadBytes, _ := util.LabelsConvert(labels)
	jsonType := types.JSONPatchType
	patchedPVC, err := ws.engine.PatchPersistentVolumeClaim(ctx, cluster, name, namespaces, loadBytes, jsonType)
	if err != nil {
		return nil, err
	}
	return patchedPVC, nil
}

func (ws *WorkloadServices) PatchPersistentVolumeClaimCapacity(ctx context.Context, cluster, name, namespaces, capacity string) (*corev1.PersistentVolumeClaim, error) {
	loadBytes, _ := util.PersistentVolumeClaimCapacityConvert(capacity)
	jsonType := types.JSONPatchType
	patchedPVC, err := ws.engine.PatchPersistentVolumeClaim(ctx, cluster, name, namespaces, loadBytes, jsonType)
	if err != nil {
		return nil, err
	}
	return patchedPVC, nil
}

func (ws *WorkloadServices) ScalePersistentVolumeClaim(ctx context.Context, cluster, namespaces string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error) {
	return ws.engine.CreatePersistentVolumeClaim(ctx, cluster, namespaces, pvc)
}

func (ws *WorkloadServices) ListPersistentVolumes(ctx context.Context, listOptions *util.ListOptions) (*corev1.PersistentVolumeList, error) {
	list, err := ws.engine.ListPersistentVolumes(ctx, util.BuildSingleClusterListOptions(listOptions).Options())
	if err != nil {
		return nil, err
	}

	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetListMeta().GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) GetPersistentVolume(ctx context.Context, cluster, name string) (*corev1.PersistentVolume, error) {
	return ws.engine.GetPersistentVolume(ctx, cluster, name)
}

func (ws *WorkloadServices) CreatePersistentVolume(ctx context.Context, cluster string, persistentvolume *corev1.PersistentVolume) (*corev1.PersistentVolume, error) {
	return ws.engine.CreatePersistentVolume(ctx, cluster, persistentvolume)
}

func (ws *WorkloadServices) UpdatePersistentVolume(ctx context.Context, cluster string, persistentvolume *corev1.PersistentVolume) (*corev1.PersistentVolume, error) {
	return ws.engine.UpdatePersistentVolume(ctx, cluster, persistentvolume)
}

func (ws *WorkloadServices) DeletePersistentVolume(ctx context.Context, cluster, name string) error {
	return ws.engine.DeletePersistentVolume(ctx, cluster, name)
}

func (ws *WorkloadServices) ListStorageClass(ctx context.Context, listOptions *util.ListOptions) (*storagev1.StorageClassList, error) {
	list, err := ws.customEngine.ListStorageClass(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) DeleteStorageClass(ctx context.Context, cluster, name string) error {
	return ws.engine.DeleteStorageClass(ctx, cluster, name)
}

func (ws *WorkloadServices) GetStorageClass(ctx context.Context, cluster, name string) (*storagev1.StorageClass, error) {
	return ws.engine.GetStorageClass(ctx, cluster, name)
}

func (ws *WorkloadServices) CreateStorageClass(ctx context.Context, cluster string, storageClass *storagev1.StorageClass) (*storagev1.StorageClass, error) {
	return ws.engine.CreateStorageClass(ctx, cluster, storageClass)
}

func (ws *WorkloadServices) UpdateStorageClass(ctx context.Context, cluster string, storageClass *storagev1.StorageClass) (*storagev1.StorageClass, error) {
	return ws.engine.UpdateStorageClass(ctx, cluster, storageClass)
}

func (ws *WorkloadServices) UpdatePersistentVolumeClaim(ctx context.Context, cluster, namespace string, pvc *corev1.PersistentVolumeClaim) (*corev1.PersistentVolumeClaim, error) {
	return ws.engine.UpdatePersistentVolumeClaim(ctx, cluster, namespace, pvc)
}

func (ws *WorkloadServices) GetHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) (*unstructured.Unstructured, error) {
	return ws.engine.GetHorizontalPodAutoscaler(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) CreateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return ws.engine.CreateHorizontalPodAutoscaler(ctx, cluster, namespace, hpa)
}

func (ws *WorkloadServices) UpdateHorizontalPodAutoscaler(ctx context.Context, cluster, namespace string, hpa *unstructured.Unstructured) (*unstructured.Unstructured, error) {
	return ws.engine.UpdateHorizontalPodAutoscaler(ctx, cluster, namespace, hpa)
}

func (ws *WorkloadServices) DeleteHorizontalPodAutoscaler(ctx context.Context, cluster, namespace, name string) error {
	return ws.engine.DeleteHorizontalPodAutoscaler(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) ListCustomMetricSummary(ctx context.Context, cluster, kind string) ([]string, error) {
	apiResourceList := &metav1.APIResourceList{}
	err := ws.engine.RESTGetInto(ctx, cluster, "/apis/custom.metrics.k8s.io/v1beta1", map[string]string{}, apiResourceList)
	if err != nil {
		return nil, err
	}

	kind = strings.ToLower(kind) + "s"
	metrics := make([]string, 0, len(apiResourceList.APIResources))
	for _, apiResource := range apiResourceList.APIResources {
		if strings.HasPrefix(apiResource.Name, kind+"/") {
			metric := strings.SplitN(apiResource.Name, "/", 2)
			if len(metric) == 2 {
				metrics = append(metrics, metric[1])
			}
		}
	}
	return metrics, nil
}

func (ws *WorkloadServices) ListMetricValues(ctx context.Context, cluster, namespace, kind, kindName, metricName string) (*cmapi.MetricValueList, error) {
	var (
		deployment *appsv1.Deployment
		service    *corev1.Service
		list       *cmapi.MetricValueList
		err        error
	)
	switch kind {
	case constants.KindPod:
		deployment, err = ws.engine.GetDeployment(ctx, cluster, namespace, kindName)
		if err != nil {
			return nil, err
		}

		list, err = ws.engine.ListMetricValues(ctx, cluster, namespace, schema.GroupKind{Group: corev1.SchemeGroupVersion.Group, Kind: "Pod"}, labels.SelectorFromSet(deployment.Spec.Template.ObjectMeta.Labels), metricName, labels.NewSelector())
	case constants.KindService:
		service, err = ws.engine.GetService(ctx, cluster, namespace, kindName)
		if err != nil {
			return nil, err
		}

		list, err = ws.engine.ListMetricValues(ctx, cluster, namespace, schema.GroupKind{Group: corev1.SchemeGroupVersion.Group, Kind: "Service"}, labels.SelectorFromSet(service.Labels), metricName, labels.NewSelector())
	}

	if err != nil {
		return nil, err
	}

	if list == nil || len(list.Items) == 0 {
		return nil, apierrors.NewNotFound(cmapi.Resource("metrics"), metricName)
	}
	return list, nil
}

func (ws *WorkloadServices) CreateVolumeSnapshot(ctx context.Context, cluster, namespace string, volumeSnapshot *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error) {
	return ws.engine.CreateVolumeSnapshot(ctx, cluster, namespace, volumeSnapshot)
}

func (ws *WorkloadServices) GetVolumeSnapshot(ctx context.Context, cluster, namespace, name string) (*apivolumesnapshotv1.VolumeSnapshot, error) {
	VolumeSnapshot := &apivolumesnapshotv1.VolumeSnapshot{}
	unStructObjGet, err := ws.engine.GetCustomResource(ctx, cluster, namespace, name, constants.VolumeSnapshotsGVR)
	if err != nil {
		return nil, err
	}
	err = runtime.DefaultUnstructuredConverter.FromUnstructured(unStructObjGet.UnstructuredContent(), VolumeSnapshot)
	if err != nil {
		return nil, err
	}
	return VolumeSnapshot, nil
}

func (ws *WorkloadServices) UpdateVolumeSnapshot(ctx context.Context, cluster, namespace string, volumeSnapshot *apivolumesnapshotv1.VolumeSnapshot) (*apivolumesnapshotv1.VolumeSnapshot, error) {
	return ws.engine.UpdateVolumeSnapshot(ctx, cluster, namespace, volumeSnapshot)
}

func (ws *WorkloadServices) ListVolumeSnapshots(ctx context.Context, listOptions *util.ListOptions) (*apivolumesnapshotv1.VolumeSnapshotList, error) {
	unStructObjList, err := ws.customEngine.ListCustomResources(ctx, constants.VolumeSnapshotsGVR, listOptions)
	if err != nil {
		return nil, err
	}

	list := &apivolumesnapshotv1.VolumeSnapshotList{}
	err = runtime.DefaultUnstructuredConverter.FromUnstructured(unStructObjList.UnstructuredContent(), list)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.GetRemainingItemCount())
	return list, nil
}

func (ws *WorkloadServices) CreateServiceAccount(ctx context.Context, cluster, namespace string, sa *corev1.ServiceAccount) (*corev1.ServiceAccount, error) {
	return ws.engine.CreateServiceAccount(ctx, cluster, namespace, sa)
}

func (ws *WorkloadServices) GetServiceAccount(ctx context.Context, cluster, namespace, name string) (*corev1.ServiceAccount, error) {
	return ws.engine.GetServiceAccount(ctx, cluster, namespace, name)
}

func (ws *WorkloadServices) WatchServiceAccount(ctx context.Context, cluster, namespace string, opts metav1.ListOptions) (watch.Interface, error) {
	return ws.engine.WatchServiceAccount(ctx, cluster, namespace, opts)
}

func (ws *WorkloadServices) WatchPod(ctx context.Context, cluster, namespace string, opts metav1.ListOptions) (watch.Interface, error) {
	return ws.engine.WatchPod(ctx, cluster, namespace, opts)
}

func (ws *WorkloadServices) FetchCollectionResourceByResources(ctx context.Context, listOptions *util.ListOptions, resources []string) (*clusterpediav1beta1.CollectionResource, error) {
	return ws.engine.FetchCollectionResource(ctx, "any", util.BuildSingleClusterListOptions(listOptions).Options(), map[string]string{"resources": strings.Join(resources, ",")})
}

func (ws *WorkloadServices) ListReplicaSets(ctx context.Context, listOptions *util.ListOptions) (*appsv1.ReplicaSetList, error) {
	var (
		list *appsv1.ReplicaSetList
		err  error
	)
	if len(listOptions.Scope) > 1 {
		list, err = ws.customEngine.ListReplicaSets(ctx, listOptions)
	} else {
		list, err = ws.engine.ListReplicaSets(ctx, util.BuildSingleClusterListOptions(listOptions).Options())
	}
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (ws *WorkloadServices) CreateOrUpdateDeployment(ctx context.Context, cluster, namespace string, deploy *appsv1.Deployment) (*appsv1.Deployment, error) {
	ctx = context.WithValue(ctx, constants.LoadResourceSchemaKey, constants.MemberCluster)
	newDeploy, err := ws.GetDeployment(ctx, cluster, namespace, deploy.Name)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return ws.CreateDeployment(ctx, cluster, namespace, deploy)
		}
		return nil, err
	}
	deploy.ResourceVersion = newDeploy.ResourceVersion
	return ws.UpdateDeployment(ctx, cluster, namespace, deploy)
}

func (ws *WorkloadServices) CreateOrUpdateSecret(ctx context.Context, cluster, namespace string, secret *corev1.Secret) (*corev1.Secret, error) {
	ctx = context.WithValue(ctx, constants.LoadResourceSchemaKey, constants.MemberCluster)
	newSecret, err := ws.GetSecret(ctx, cluster, namespace, secret.Name)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return ws.CreateSecret(ctx, cluster, namespace, secret)
		}
		return nil, err
	}

	secret.ResourceVersion = newSecret.ResourceVersion
	return ws.UpdateSecret(ctx, cluster, secret)
}

func (ws *WorkloadServices) CreateOrUpdateConfigMap(ctx context.Context, cluster, namespace string, configmap *corev1.ConfigMap) (*corev1.ConfigMap, error) {
	ctx = context.WithValue(ctx, constants.LoadResourceSchemaKey, constants.MemberCluster)
	newConfigMap, err := ws.GetConfigMap(ctx, cluster, namespace, configmap.Name)
	if err != nil {
		if apierrors.IsNotFound(err) {
			return ws.CreateConfigMap(ctx, cluster, namespace, configmap)
		}
		return nil, err
	}

	configmap.ResourceVersion = newConfigMap.ResourceVersion
	return ws.UpdateConfigMap(ctx, cluster, namespace, configmap)
}
