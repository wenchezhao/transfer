package clusters

import (
	"context"
	"errors"
	"fmt"
	"net/http/httptest"
	"reflect"
	"testing"
	"time"

	pediaclient "github.com/clusterpedia-io/client-go/client"
	pediadynamic "github.com/clusterpedia-io/client-go/dynamic"
	fakeapiserver "github.com/clusterpedia-io/fake-apiserver/apiserver"
	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	certificatesv1 "k8s.io/api/certificates/v1"
	corev1 "k8s.io/api/core/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apiserver/pkg/authentication/user"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/rest"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"

	"github.com/clusterpedia-io/fake-apiserver/storage/memory"
	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/engine"
	"github.com/daocloud/dsp-appserver/pkg/services/workloads"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/contextutil"
)

type MockClusterEngine struct {
	_GetCluster                                     func(ctx context.Context, clusterName string) (*clusterv1alpha1.Cluster, error)
	_ExistSecret                                    func(ctx context.Context, namespace, secretName string) (bool, error)
	_ExistCluster                                   func(ctx context.Context, name string) (exist bool)
	_UpdateClusters                                 func(ctx context.Context, targetCluster *clusterv1alpha1.Cluster) (result *clusterv1alpha1.Cluster, err error)
	_EditClusterLabels                              func(ctx context.Context, clusterName string, LoadBytes []byte) (labels map[string]string, err error)
	_CreateClusters                                 func(ctx context.Context, targetCluster *clusterv1alpha1.Cluster) (result *clusterv1alpha1.Cluster, err error)
	_GetSecretInfo                                  func(ctx context.Context, clusterID string) (secretName, secretNamespace string, err error)
	_DeleteCluster                                  func(ctx context.Context, clusterName string) error
	_DeleteClusterSecret                            func(secretNamespace, secretName string) error
	_GetSecret                                      func(ctx context.Context, clusterName string) (secretName, secretNamespace string, err error)
	_GetClusterByKubeSystemID                       func(ctx context.Context, kubeSystemID string) (result *clusterv1alpha1.Cluster, err error)
	_GetClusterCerts                                func(ctx context.Context, clusterName string, ignoreTLS bool) (*rest.Config, *clientcmdapi.Config, error)
	_CreateCertificateSigningRequests               func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error)
	_ApproveCertificateSigningRequests              func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error
	_DeleteCertificateSigningRequests               func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error
	_GetClusterSecretKubeConfig                     func(ctx context.Context, cluster *clusterv1alpha1.Cluster) (*rest.Config, error)
	_GetCertificateSigningRequests                  func(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error)
	_ListCluster                                    func(ctx context.Context, options *util.ListOptions) (*clusterv1alpha1.ClusterList, error)
	_GetCurrentUserNameAndGroup                     func(ctx context.Context) (string, []string, error)
	_CreateOpenAPIClusterCertWithCluster            func(ctx context.Context, cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration) (string, error)
	_CreateOpenAPIClusterCertWithClusterByCNAndOrgs func(ctx context.Context, cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration, CN string, Orgs []string, useEgress bool) (string, error)
}

func (*MockClusterEngine) ListClusters(_ context.Context, _ metav1.ListOptions) (*clusterv1alpha1.ClusterList, error) {
	panic("unimplemented")
}

func (fake *MockClusterEngine) ListDeployments(_ context.Context, _ *util.ListOptions) (*appsv1.DeploymentList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListStatefulSets(_ context.Context, _ *util.ListOptions) (*appsv1.StatefulSetList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListDaemonSets(_ context.Context, _ *util.ListOptions) (*appsv1.DaemonSetList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListPods(_ context.Context, _ *util.ListOptions) (*corev1.PodList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListJobs(_ context.Context, _ *util.ListOptions) (*batchv1.JobList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListCronJobs(_ context.Context, _ *util.ListOptions) (*batchv1.CronJobList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListRoleBindings(_ context.Context, _ *util.ListOptions) (*rbacv1.RoleBindingList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListClusterRoleBindings(_ context.Context, _ *util.ListOptions) (*rbacv1.ClusterRoleBindingList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListNamespaces(_ context.Context, _ *util.ListOptions) (*corev1.NamespaceList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListNodes(_ context.Context, _ *util.ListOptions) (*corev1.NodeList, error) {
	panic("implement me")
}

func (fake *MockClusterEngine) ListCluster(ctx context.Context, options *util.ListOptions) (*clusterv1alpha1.ClusterList, error) {
	return fake._ListCluster(ctx, options)
}

func (fake *MockClusterEngine) CreateOpenAPIClusterCertWithCluster(ctx context.Context, cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration) (string, error) {
	return fake._CreateOpenAPIClusterCertWithCluster(ctx, cluster, expirationDuration)
}

var _ engine.Cluster = &MockClusterEngine{}

func (fake *MockClusterEngine) CreateOpenAPIClusterCertWithClusterByCNAndOrgs(ctx context.Context, cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration, CN string, Orgs []string, useEgress bool) (string, error) {
	return fake._CreateOpenAPIClusterCertWithClusterByCNAndOrgs(ctx, cluster, expirationDuration, CN, Orgs, useEgress)
}

func (fake *MockClusterEngine) GetCluster(ctx context.Context, clusterName string) (*clusterv1alpha1.Cluster, error) {
	return fake._GetCluster(ctx, clusterName)
}

func (fake *MockClusterEngine) CreateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster) (result *clusterv1alpha1.Cluster, err error) {
	return fake._CreateClusters(ctx, targetCluster)
}

func (fake *MockClusterEngine) ExistSecret(ctx context.Context, namespace, secretName string) (bool, error) {
	return fake._ExistSecret(ctx, namespace, secretName)
}

func (fake *MockClusterEngine) ExistCluster(ctx context.Context, name string) (exist bool) {
	return fake._ExistCluster(ctx, name)
}

func (fake *MockClusterEngine) UpdateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster) (result *clusterv1alpha1.Cluster, err error) {
	return fake._UpdateClusters(ctx, targetCluster)
}

func (fake *MockClusterEngine) EditClusterLabels(ctx context.Context, clusterName string, LoadBytes []byte) (labels map[string]string, err error) {
	return fake._EditClusterLabels(ctx, clusterName, LoadBytes)
}

func (fake *MockClusterEngine) GetSecretInfo(ctx context.Context, clusterID string) (secretName, secretNamespace string, err error) {
	return fake._GetSecretInfo(ctx, clusterID)
}

func (fake *MockClusterEngine) GetSecret(ctx context.Context, clusterID string) (secretName, secretNamespace string, err error) {
	return fake._GetSecret(ctx, clusterID)
}

func (fake *MockClusterEngine) DeleteCluster(ctx context.Context, clusterName string) error {
	return fake._DeleteCluster(ctx, clusterName)
}

func (fake *MockClusterEngine) DeleteClusterSecret(secretNamespace, secretName string) error {
	return fake._DeleteClusterSecret(secretNamespace, secretName)
}

func (fake *MockClusterEngine) GetClusterByKubeSystemID(ctx context.Context, kubeSystemID string) (result *clusterv1alpha1.Cluster, err error) {
	return fake._GetClusterByKubeSystemID(ctx, kubeSystemID)
}

func (fake *MockClusterEngine) GetClusterCerts(ctx context.Context, clusterName string, ignoreTLS bool) (*rest.Config, *clientcmdapi.Config, error) {
	return fake._GetClusterCerts(ctx, clusterName, ignoreTLS)
}

func (fake *MockClusterEngine) CreateCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error) {
	return fake._CreateCertificateSigningRequests(ctx, cluster, request)
}

func (fake *MockClusterEngine) ApproveCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
	return fake._ApproveCertificateSigningRequests(ctx, cluster, request)
}

func (fake *MockClusterEngine) DeleteCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
	return fake._DeleteCertificateSigningRequests(ctx, cluster, request)
}

func (fake *MockClusterEngine) GetClusterSecretKubeConfig(ctx context.Context, cluster *clusterv1alpha1.Cluster) (*rest.Config, error) {
	return fake._GetClusterSecretKubeConfig(ctx, cluster)
}

func (fake *MockClusterEngine) GetCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error) {
	return fake._GetCertificateSigningRequests(ctx, cluster, csrName)
}

func (fake *MockClusterEngine) GetGlobalClusterKubeSystemID(ctx context.Context) (string, error) {
	panic("unimplemented")
}

func (fake *MockClusterEngine) GetCurrentUserNameAndGroup(ctx context.Context) (string, []string, error) {
	return fake._GetCurrentUserNameAndGroup(ctx)
}

func Test_GetCluster(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	client := fake.NewClientBuilder().WithScheme(sch).WithRuntimeObjects(&clusterv1alpha1.Cluster{}).Build()
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	requestName := "cluster-1"
	key := types.NamespacedName{
		Name: requestName,
	}
	mockClusterEngine._GetCluster = func(ctx context.Context, clusterName string) (*clusterv1alpha1.Cluster, error) {
		var targetCluster *clusterv1alpha1.Cluster
		client.Get(ctx, key, targetCluster)
		return targetCluster, nil
	}
	mockClusterService.engine = mockClusterEngine
	result := &clusterv1alpha1.Cluster{
		TypeMeta:   metav1.TypeMeta{Kind: clusterv1alpha1.ResourceKindCluster, APIVersion: clusterv1alpha1.GroupVersion.String()},
		ObjectMeta: metav1.ObjectMeta{},
		Spec:       clusterv1alpha1.ClusterSpec{},
	}
	targetCluster := &clusterv1alpha1.Cluster{
		ObjectMeta: metav1.ObjectMeta{Name: requestName},
	}
	client.Create(context.Background(), targetCluster)
	_, _ = mockClusterService.GetCluster(context.Background(), requestName)
	client.Get(context.Background(), key, result)
	if result.ObjectMeta.Name != requestName {
		t.Fail()
	}

	mockClusterEngine._GetCluster = func(ctx context.Context, clusterName string) (*clusterv1alpha1.Cluster, error) {
		return nil, fmt.Errorf("error")
	}
	_, err := mockClusterService.GetCluster(context.Background(), requestName)
	if err == nil {
		t.Fail()
	}
}

func TestClusterServices_EditClusterLabels(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._EditClusterLabels = func(ctx context.Context, clusterName string, LoadBytes []byte) (labels map[string]string, err error) {
		return nil, nil
	}
	_, err := mockClusterService.EditClusterLabels(context.Background(), "cluster-foo", map[string]string{"lableKey1": "labelValue1", "lableKey2": "labelValue2"})
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_DeleteClusterAllLabels(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._EditClusterLabels = func(ctx context.Context, clusterName string, LoadBytes []byte) (labels map[string]string, err error) {
		return nil, nil
	}
	err := mockClusterService.DeleteClusterAllLabels(context.Background(), "cluster-foo")
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_DeleteCluster(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._DeleteCluster = func(ctx context.Context, clusterName string) error {
		return nil
	}
	err := mockClusterService.DeleteCluster(context.Background(), "cluster-foo")
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_GetClusterByKubeSystemID(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._GetClusterByKubeSystemID = func(ctx context.Context, kubeSystemID string) (result *clusterv1alpha1.Cluster, err error) {
		return nil, nil
	}

	_, err := mockClusterService.GetClusterByKubeSystemID(context.Background(), "fqq")
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_CreateCertificateSigningRequests(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._CreateCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error) {
		return nil, nil
	}

	_, err := mockClusterService.CreateCertificateSigningRequests(context.Background(), nil, nil)
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_ApproveCertificateSigningRequests(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._ApproveCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
		return nil
	}

	err := mockClusterService.ApproveCertificateSigningRequests(context.Background(), nil, nil)
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_DeleteCertificateSigningRequests(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._DeleteCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
		return nil
	}

	err := mockClusterService.DeleteCertificateSigningRequests(context.Background(), nil, nil)
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_GetCertificateSigningRequests(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._GetCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error) {
		return nil, nil
	}

	_, err := mockClusterService.GetCertificateSigningRequests(context.Background(), nil, "cluster")
	if err != nil {
		t.Fail()
	}
}

func TestClusterServices_GetClusterCerts(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._GetClusterCerts = func(ctx context.Context, clusterName string, ignoreTLS bool) (*rest.Config, *clientcmdapi.Config, error) {
		return nil, nil, nil
	}

	_, _, err := mockClusterService.GetClusterCerts(context.Background(), "cluster1", true)
	if err != nil {
		t.Fail()
	}
}

func Test_CreateCSR(t *testing.T) {
	cluster := &clusterv1alpha1.Cluster{}
	if _, _, _, err := CreateCSR(cluster, 600, "my-cn", []string{"my-group"}); err != nil {
		t.Fail()
	}
}

func Test_CreateCSRConfig(t *testing.T) {
	if result := CreateCSRConfig("my-cn", []string{"my-group"}); result == nil {
		t.Fail()
	}
}

func Test_parseKubeConfigSecret(t *testing.T) {
	type args struct {
		secret  *corev1.Secret
		cluster *clusterv1alpha1.Cluster
	}
	tests := []struct {
		name  string
		args  args
		want  bool
		want1 bool
	}{
		{
			name: "test secret nil",
			args: args{
				secret: nil,
			},
			want:  true,
			want1: true,
		},

		{
			name: "test secret exit",
			args: args{
				secret: &corev1.Secret{
					Data: map[string][]byte{
						"kubeconfig": []byte("dsad"),
					},
				},
			},
			want:  true,
			want1: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, got1 := parseKubeConfigSecret(tt.args.secret, tt.args.cluster)
			if got != tt.want {
				t.Errorf("parseKubeConfigSecret() got = %v, want %v", got, tt.want)
			}
			if got1 != tt.want1 {
				t.Errorf("parseKubeConfigSecret() got1 = %v, want %v", got1, tt.want1)
			}
		})
	}
}

// func Test_CreateOpenAPIClusterCertWithClusterByCNAndOrgs(t *testing.T) {
// 	cluster := clusterv1alpha1.Cluster{
// 		ObjectMeta: metav1.ObjectMeta{
// 			Name: "foo",
// 		},
// 		Status: clusterv1alpha1.ClusterStatus{
// 			ProxyURL: "dsad",
// 		},
// 	}

// 	mockClusterService := &ClusterServices{}
// 	mockClusterEngine := &MockClusterEngine{}
// 	mockClusterService.engine = mockClusterEngine
// 	mockClusterEngine._CreateOpenAPIClusterCertWithClusterByCNAndOrgs = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration, CN string, Orgs []string, useEgress bool) (string, error) {
// 		return "", nil
// 	}
// 	mockClusterEngine._CreateCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error) {
// 		return nil, nil
// 	}
// 	mockClusterEngine._ApproveCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
// 		return nil
// 	}
// 	mockClusterEngine._GetCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error) {
// 		c := &certificatesv1.CertificateSigningRequest{
// 			Status: certificatesv1.CertificateSigningRequestStatus{
// 				Certificate: []byte("dawdd"),
// 			},
// 		}
// 		return c, nil
// 	}
// 	mockClusterEngine._DeleteCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
// 		return nil
// 	}

// 	// CreateCertificateSigningRequests err
// 	mockClusterEngine._CreateCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error) {
// 		return nil, errors.New("err")
// 	}
// 	_, err := mockClusterService.CreateOpenAPIClusterCertWithClusterByCNAndOrgs(context.Background(), &cluster, 213, "dasd", []string{"dasd"}, false)
// 	if !reflect.DeepEqual(err, errors.New("err")) {
// 		fmt.Println(err)
// 		t.Fail()
// 	}

// 	// ApproveCertificateSigningRequests err
// 	mockClusterEngine._CreateCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error) {
// 		return nil, nil
// 	}
// 	mockClusterEngine._ApproveCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
// 		return errors.New("err")
// 	}
// 	_, err = mockClusterService.CreateOpenAPIClusterCertWithClusterByCNAndOrgs(context.Background(), &cluster, 213, "dasd", []string{"dasd"}, false)
// 	if !reflect.DeepEqual(err, errors.New("err")) {
// 		fmt.Println(err)
// 		t.Fail()
// 	}

// 	// GetCertificateSigningRequests err
// 	mockClusterEngine._CreateCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error) {
// 		return nil, nil
// 	}
// 	mockClusterEngine._ApproveCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
// 		return nil
// 	}

// 	mockClusterEngine._GetCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error) {
// 		c := &certificatesv1.CertificateSigningRequest{
// 			Status: certificatesv1.CertificateSigningRequestStatus{
// 				Certificate: []byte("dawdd"),
// 			},
// 		}
// 		return c, nil
// 	}
// 	_, err = mockClusterService.CreateOpenAPIClusterCertWithClusterByCNAndOrgs(context.Background(), &cluster, 213, "dasd", []string{"dasd"}, false)
// 	if !reflect.DeepEqual(err, errors.New("err")) {
// 		fmt.Println(err)
// 		t.Fail()
// 	}

// 	// GetCertificateSigningRequests err len = 0
// 	mockClusterEngine._CreateCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error) {
// 		return nil, nil
// 	}
// 	mockClusterEngine._ApproveCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
// 		return nil
// 	}
// 	mockClusterEngine._GetCertificateSigningRequests = func(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error) {
// 		c := &certificatesv1.CertificateSigningRequest{
// 			Status: certificatesv1.CertificateSigningRequestStatus{},
// 		}
// 		return c, nil
// 	}
// 	_, err = mockClusterService.CreateOpenAPIClusterCertWithClusterByCNAndOrgs(context.Background(), &cluster, 213, "dasd", []string{"dasd"}, false)
// 	if !reflect.DeepEqual(err, errors.New("CertificateSigningRequests  has been approved but no cert data in status ,please try again")) {
// 		fmt.Println(err)
// 		t.Fail()
// 	}
// }

func TestGetCurrentUserNameAndGroup(t *testing.T) {
	sch := scheme.Scheme
	if err := clusterv1alpha1.AddToScheme(sch); err != nil {
		t.Fatalf("unable add APIs to scheme: %v", err)
	}
	mockClusterService := &ClusterServices{}
	mockClusterEngine := &MockClusterEngine{}
	mockClusterService.engine = mockClusterEngine
	mockClusterEngine._GetCurrentUserNameAndGroup = func(ctx context.Context) (string, []string, error) {
		return "da", []string{"da"}, nil
	}

	ctx := contextutil.WithUser(context.Background(), &user.DefaultInfo{})
	_, _, err := mockClusterService.GetCurrentUserNameAndGroup(ctx)
	if err != nil {
		t.Fatal("expect nil")
	}

	_, _, err = mockClusterService.GetCurrentUserNameAndGroup(context.TODO())
	if !reflect.DeepEqual(err, errors.New("user info is null")) {
		t.Fail()
	}
}

func InitFake() (*memory.FakeStorageFactory, *httptest.Server) {
	storage := memory.NewFakeStorageFactory()
	server, _ := fakeapiserver.NewFakeApiserver(storage)
	return storage, server
}

func TestClusterServices_checkEgressReady(t *testing.T) {
	storage, server := InitFake()
	defer server.Close()
	storage.Create(context.Background(), constants.GlobalCluster, &corev1.Secret{
		TypeMeta: metav1.TypeMeta{
			Kind:       "Service",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      "secret2",
			Namespace: "ns1",
		},
	})
	cs, _ := pediaclient.NewForConfig(&rest.Config{Host: server.URL})
	dyn, _ := pediadynamic.NewForConfig(&rest.Config{Host: server.URL})
	clientFactory := engine.NewFakeClientFactory(storage, server, cs, dyn)
	clusterClient := engine.NewFakeClusterClient(server, false)
	svc, err := workloads.NewWorkloadServices(nil, clientFactory, clusterClient)
	if err != nil {
		t.Fatal(err)
	}
	type fields struct {
		engine       engine.Cluster
		service      workloads.Service
		customEngine engine.CustomClient
	}
	type args struct {
		ctx     context.Context
		cluster *clusterv1alpha1.Cluster
	}
	tests := []struct {
		name   string
		fields fields
		args   args
		want   bool
	}{
		{
			name: "secret not exists",
			fields: fields{
				engine:       nil,
				service:      svc,
				customEngine: nil,
			},
			args: args{
				ctx: context.Background(),
				cluster: &clusterv1alpha1.Cluster{
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace: "ns1",
							Name:      "secret1",
						},
					},
				},
			},
			want: false,
		},
		{
			name: "kubeconfig not exists",
			fields: fields{
				engine:       nil,
				service:      svc,
				customEngine: nil,
			},
			args: args{
				ctx: context.Background(),
				cluster: &clusterv1alpha1.Cluster{
					Spec: clusterv1alpha1.ClusterSpec{
						SecretRef: &clusterv1alpha1.LocalSecretReference{
							Namespace: "ns1",
							Name:      "secret2",
						},
					},
				},
			},
			want: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c := &ClusterServices{
				engine:       tt.fields.engine,
				service:      tt.fields.service,
				customEngine: tt.fields.customEngine,
			}
			if got := c.checkEgressReady(tt.args.ctx, tt.args.cluster); got != tt.want {
				t.Errorf("ClusterServices.checkEgressReady() = %v, want %v", got, tt.want)
			}
		})
	}
}
