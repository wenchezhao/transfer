package clusters

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"errors"
	"fmt"
	"strings"
	"time"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	certificatesv1 "k8s.io/api/certificates/v1"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/equality"
	apierrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apiserver/pkg/authentication/user"
	client "k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
	certutil "k8s.io/client-go/util/cert"
	"k8s.io/klog/v2"

	clusterv1alpha1 "github.com/daocloud/dsp-appserver/api/crd/apis/cluster/v1alpha1"
	informers "github.com/daocloud/dsp-appserver/api/crd/client/informers/externalversions"
	"github.com/daocloud/dsp-appserver/pkg/certs"
	kubeclient "github.com/daocloud/dsp-appserver/pkg/client/kube"
	"github.com/daocloud/dsp-appserver/pkg/constants"
	"github.com/daocloud/dsp-appserver/pkg/engine"
	pedia "github.com/daocloud/dsp-appserver/pkg/engine/clusterpedia"
	"github.com/daocloud/dsp-appserver/pkg/services/workloads"
	"github.com/daocloud/dsp-appserver/pkg/util"
	"github.com/daocloud/dsp-appserver/pkg/util/clusterclient"
	"github.com/daocloud/dsp-appserver/pkg/util/contextutil"
)

var defaultClusterAdminCertExpirationDuration = 24 * time.Hour * 365 * 10

type Services interface {
	ListClusters(ctx context.Context, listOptions *util.ListOptions) (*clusterv1alpha1.ClusterList, error)
	GetCluster(ctx context.Context, clusterName string) (*clusterv1alpha1.Cluster, error)
	CreateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster, kubeconfigStr string) (result *clusterv1alpha1.Cluster, err error)
	ValidKubeConfigIsAdmin(ctx context.Context, config *rest.Config) (string, error)
	UpdateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster, kubeconfigStr string) (result *clusterv1alpha1.Cluster, err error)
	EditClusterLabels(ctx context.Context, clusterName string, clusterLabels map[string]string) (clusterLabelsRes map[string]string, err error)
	DeleteClusterAllLabels(ctx context.Context, clusterName string) error
	DeleteCluster(ctx context.Context, clusterName string) error
	GetClusterByKubeSystemID(ctx context.Context, kubeSystemID string) (result *clusterv1alpha1.Cluster, err error)
	GetClusterCerts(ctx context.Context, clusterName string, ignoreTLS bool) (*rest.Config, *clientcmdapi.Config, error)
	CreateCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error)
	ApproveCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error
	DeleteCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error
	GetCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error)
	CreateOpenAPIClusterCertWithCluster(ctx context.Context, cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration) (string, error)
	CreateOpenAPIClusterCertWithClusterByCNAndOrgs(ctx context.Context, cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration, CN string, Orgs []string, useEgress bool) (string, error)
	GetOrCreateClusterAdminCert(ctx context.Context, cluster *clusterv1alpha1.Cluster) (string, error)
	GetCurrentUserNameAndGroup(ctx context.Context) (string, []string, error)
	GetGlobalClusterKubeSystemID(ctx context.Context) (string, error)
}

type ClusterServices struct {
	engine       engine.Cluster
	service      workloads.Service
	customEngine engine.CustomClient
}

func NewClusterServices(client kubeclient.Client, pclient pedia.Clients, factory informers.SharedInformerFactory, clusterClient clusterclient.ClusterClients) *ClusterServices {
	workloadService, _ := workloads.NewWorkloadServices(factory, pclient, clusterClient)
	ce, _ := engine.NewCustomEngine(pclient)
	return &ClusterServices{
		engine:       engine.NewClusterEngine(client, pclient, factory, clusterClient),
		service:      workloadService,
		customEngine: ce,
	}
}

func (c *ClusterServices) ListClusters(ctx context.Context, listOptions *util.ListOptions) (*clusterv1alpha1.ClusterList, error) {
	list, err := c.customEngine.ListClusters(ctx, listOptions)
	if err != nil {
		return nil, err
	}
	listOptions.QueryPage.SetTotalByRemainCount(int32(len(list.Items)), list.RemainingItemCount)
	return list, nil
}

func (c *ClusterServices) GetCluster(ctx context.Context, clusterName string) (*clusterv1alpha1.Cluster, error) {
	cluster, err := c.engine.GetCluster(ctx, clusterName)
	if err != nil {
		klog.Error(err)
		return nil, err
	}

	return cluster, nil
}

func (c *ClusterServices) GetClusterCerts(ctx context.Context, clusterName string, ignoreTLS bool) (*rest.Config, *clientcmdapi.Config, error) {
	return c.engine.GetClusterCerts(ctx, clusterName, ignoreTLS)
}

func (c *ClusterServices) createOrUpdateSecret(ctx context.Context, cluster string, secret *corev1.Secret) (*corev1.Secret, error) {
	current, err := c.service.GetSecret(ctx, cluster, secret.Namespace, secret.Name)
	if err != nil {
		if !apierrors.IsNotFound(err) {
			return nil, err
		}
		return c.service.CreateSecret(ctx, cluster, secret.Namespace, secret)
	}

	if !equality.Semantic.DeepEqual(secret.Data, current.Data) {
		return c.service.UpdateSecret(ctx, cluster, secret)
	}
	return current, nil
}

func (c *ClusterServices) CreateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster, kubeconfigStr string) (*clusterv1alpha1.Cluster, error) {
	if c.engine.ExistCluster(ctx, targetCluster.Name) {
		return nil, status.Errorf(codes.AlreadyExists, "cluster %v already exists", targetCluster.Name)
	}

	secret := &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      targetCluster.Name + "-secret",
			Namespace: util.GetCurrentNSOrDefault(),
		},
		Data: map[string][]byte{"kubeconfig": util.StringToBytes(kubeconfigStr)},
	}

	secret, err := c.createOrUpdateSecret(ctx, constants.GlobalCluster, secret)
	if err != nil {
		return nil, err
	}

	targetCluster.Spec.SecretRef = &clusterv1alpha1.LocalSecretReference{
		Namespace:       secret.ObjectMeta.Namespace,
		Name:            secret.ObjectMeta.Name,
		ResourceVersion: secret.ResourceVersion,
	}
	result, err := c.engine.CreateClusters(ctx, targetCluster)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (c *ClusterServices) ValidKubeConfigIsAdmin(ctx context.Context, clusterConfig *rest.Config) (string, error) {
	clisentset, err := client.NewForConfig(clusterConfig)
	if err != nil {
		err = fmt.Errorf("validKubeConfig %v", err)
		return "", err
	}
	return clusterclient.GetKubeSystemID(ctx, clisentset.CoreV1().Namespaces())
}

func (c *ClusterServices) UpdateClusters(ctx context.Context, targetCluster *clusterv1alpha1.Cluster, clusterConfig string) (*clusterv1alpha1.Cluster, error) {
	secretName := targetCluster.Name + "-secret"
	ns := util.GetCurrentNSOrDefault()
	secret := &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      secretName,
			Namespace: ns,
		},
		Data: map[string][]byte{"kubeconfig": []byte(clusterConfig)},
	}
	secret, err := c.createOrUpdateSecret(ctx, constants.GlobalCluster, secret)
	if err != nil {
		return nil, err
	}

	targetCluster.Spec.SecretRef = &clusterv1alpha1.LocalSecretReference{
		Namespace:       secret.GetNamespace(),
		Name:            secret.GetName(),
		ResourceVersion: secret.GetResourceVersion(),
	}
	result, err := c.engine.UpdateClusters(ctx, targetCluster)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (c *ClusterServices) EditClusterLabels(ctx context.Context, clusterName string, clusterLabels map[string]string) (map[string]string, error) {
	LoadBytes, _ := util.LabelsConvert(clusterLabels)
	labels, err := c.engine.EditClusterLabels(ctx, clusterName, LoadBytes)
	if err != nil {
		return nil, err
	}
	return labels, nil
}

// DeleteClusterAllLabels k8s delete labels by get value nil to delete key.
func (c *ClusterServices) DeleteClusterAllLabels(ctx context.Context, clusterName string) error {
	LoadBytes, _ := util.LabelsConvert(nil)
	_, err := c.engine.EditClusterLabels(ctx, clusterName, LoadBytes)
	return err
}

func (c *ClusterServices) DeleteCluster(ctx context.Context, clusterName string) error {
	return c.engine.DeleteCluster(ctx, clusterName)
}

func (c *ClusterServices) GetClusterByKubeSystemID(ctx context.Context, kubeSystemID string) (*clusterv1alpha1.Cluster, error) {
	return c.engine.GetClusterByKubeSystemID(ctx, kubeSystemID)
}

func (c *ClusterServices) CreateCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) (*certificatesv1.CertificateSigningRequest, error) {
	return c.engine.CreateCertificateSigningRequests(ctx, cluster, request)
}

func (c *ClusterServices) ApproveCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
	return c.engine.ApproveCertificateSigningRequests(ctx, cluster, request)
}

func (c *ClusterServices) DeleteCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, request *certificatesv1.CertificateSigningRequest) error {
	return c.engine.DeleteCertificateSigningRequests(ctx, cluster, request)
}

func (c *ClusterServices) GetCertificateSigningRequests(ctx context.Context, cluster *clusterv1alpha1.Cluster, csrName string) (*certificatesv1.CertificateSigningRequest, error) {
	return c.engine.GetCertificateSigningRequests(ctx, cluster, csrName)
}

func (c *ClusterServices) CreateOpenAPIClusterCertWithCluster(ctx context.Context, cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration) (string, error) {
	// --cluster-signing-duration && ExpirationSeconds
	// todo Compatibility Issues
	// csr feature start with k8s 1.19
	// ExpirationSeconds works with k8s 1.22 and above
	// must not use system:masters
	CN, Orgs, err := c.GetCurrentUserNameAndGroup(ctx)
	if err != nil {
		return "", err
	}
	return c.CreateOpenAPIClusterCertWithClusterByCNAndOrgs(ctx, cluster, expirationDuration, CN, Orgs, false)
}

func (c *ClusterServices) CreateOpenAPIClusterCertWithClusterByCNAndOrgs(ctx context.Context, cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration, CN string, Orgs []string, useEgress bool) (string, error) {
	certificateSigningRequest, _, key, err := CreateCSR(cluster, expirationDuration, CN, Orgs)
	if err != nil {
		return "", err
	}

	if _, err := c.CreateCertificateSigningRequests(ctx, cluster, certificateSigningRequest); err != nil {
		return "", err
	}

	if err := c.ApproveCertificateSigningRequests(ctx, cluster, certificateSigningRequest); err != nil {
		return "", err
	}
	time.Sleep(time.Millisecond * 300) // need wait for a duration or maybe get the empty cert from csr

	csr, err := c.GetCertificateSigningRequests(ctx, cluster, certificateSigningRequest.Name)
	if err != nil {
		return "", err
	}

	if len(csr.Status.Certificate) == 0 {
		c.DeleteCertificateSigningRequests(ctx, cluster, certificateSigningRequest) // clean this csr instance
		return "", fmt.Errorf("CertificateSigningRequests %s has been approved but no cert data in status ,please check the status of kube-controller-manager and try again later", certificateSigningRequest.Name)
	}

	cert := csr.Status.Certificate
	if err := c.DeleteCertificateSigningRequests(ctx, cluster, certificateSigningRequest); err != nil {
		return "", err
	}
	// secretConfig, err := c.services.GetClusterSecretKubeConfig(ctx, cluster)
	// caData := secretConfig.CAData
	template := constants.KubeConfDefaultWithoutTLSVerifyTemplate
	server := cluster.Spec.APIEndpoint

	_, rawConfig, err := c.engine.GetClusterCerts(ctx, cluster.Name, false)
	if err != nil {
		return "", err
	}
	configCurrentContext := rawConfig.CurrentContext
	configContexts := rawConfig.Contexts
	currentContext, ok := configContexts[configCurrentContext]
	if !ok {
		return "", errors.New("get cluster current context config failed")
	}

	if useEgress && len(cluster.Status.ProxyURL) != 0 {
		server = cluster.Status.ProxyURL
	}

	userRole := "kpanda-grpc-admin"

	userInfo, _ := contextutil.ParseUserInfoFromCtx(ctx)
	if userInfo != nil {
		userRole = userInfo.GetName()
	}
	configUserName := fmt.Sprintf("%s-%s@%s", constants.Kubernetes, userRole, currentContext.Cluster)
	kubeConfigForOpenAPI := fmt.Sprintf(template, server, currentContext.Cluster, currentContext.Cluster, userRole, configUserName, configUserName, userRole, base64.StdEncoding.EncodeToString(cert), base64.StdEncoding.EncodeToString(key))
	return base64.StdEncoding.EncodeToString([]byte(kubeConfigForOpenAPI)), nil
}

func (c *ClusterServices) GetOrCreateClusterAdminCert(ctx context.Context, cluster *clusterv1alpha1.Cluster) (string, error) {
	if !c.checkEgressReady(ctx, cluster) {
		return "", status.Errorf(codes.Internal, "cluster %s has not initialized successfully, please try get again later.", cluster.Name)
	}
	globalClusterKubeSystemID, err := c.GetGlobalClusterKubeSystemID(ctx)
	if err != nil || globalClusterKubeSystemID == "" {
		return "", status.Errorf(codes.Internal, "global cluster has not initialized successfully, please try get agagin later. Error info: %v", err)
	}

	ns := util.GetCurrentNSOrDefault()
	secretName := fmt.Sprintf("%s-%s-kubeconfig", cluster.Name, cluster.Status.KubeSystemID)
	secret, err := c.service.GetSecret(ctx, cluster.Name, ns, secretName)
	if err != nil && !apierrors.IsNotFound(err) {
		return "", status.Errorf(codes.Internal, "failed to get kubeconfig: %v", err)
	}

	var config string
	needToCreateCsr, needToUpdateSecret := parseKubeConfigSecret(secret, cluster)

	if needToCreateCsr {
		CN := fmt.Sprintf(constants.BuiltInAdminName, globalClusterKubeSystemID)
		config, err = c.CreateOpenAPIClusterCertWithClusterByCNAndOrgs(ctx, cluster, defaultClusterAdminCertExpirationDuration, CN, []string{}, true)
		if err != nil {
			return "", status.Errorf(codes.Internal, "failed to create kubeconfig: %v", err)
		}
	} else if !needToUpdateSecret {
		return base64.StdEncoding.EncodeToString(secret.Data["kubeconfig"]), nil
	}

	if secret == nil {
		kubeconfigDecodeBytes, _ := base64.StdEncoding.DecodeString(config)
		secret = &corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{
				Name:            secretName,
				Namespace:       ns,
				OwnerReferences: []metav1.OwnerReference{*metav1.NewControllerRef(cluster, clusterv1alpha1.SchemeGroupVersion.WithKind(clusterv1alpha1.ResourceKindCluster))},
			},
			Data: map[string][]byte{
				"kubeconfig": kubeconfigDecodeBytes,
			},
		}
		_, err := c.service.CreateSecret(ctx, cluster.Name, ns, secret)
		if err != nil {
			klog.V(3).ErrorS(err, "failed to create secret for kpanda-admin")
		}
		return config, nil
	} else if needToUpdateSecret {
		if needToCreateCsr {
			kubeconfigDecodeBytes, _ := base64.StdEncoding.DecodeString(config)
			secret.Data["kubeconfig"] = kubeconfigDecodeBytes
		}
		_, err := c.service.UpdateSecret(ctx, cluster.Name, secret)
		if err != nil {
			klog.V(3).ErrorS(err, "failed to update secret for kpanda-admin cert")
		}
		return base64.StdEncoding.EncodeToString(secret.Data["kubeconfig"]), nil
	}
	return config, nil
}

func (c *ClusterServices) checkEgressReady(ctx context.Context, cluster *clusterv1alpha1.Cluster) bool {
	secret, err := c.service.GetSecret(ctx, constants.GlobalCluster, cluster.Spec.SecretRef.Namespace, cluster.Spec.SecretRef.Name)
	if err != nil {
		return false
	}
	kubeconfigBytes := secret.Data["kubeconfig"]
	clientConfig, err := clientcmd.NewClientConfigFromBytes(kubeconfigBytes)
	if err != nil {
		return false
	}
	restConfig, err := clientConfig.ClientConfig()
	if err != nil {
		return false
	}
	if restConfig.Host != cluster.Status.ProxyURL {
		return false
	}
	return true
}

// parseKubeConfigSecret returns whether need to create csr and update secret.
func parseKubeConfigSecret(secret *corev1.Secret, cluster *clusterv1alpha1.Cluster) (bool, bool) {
	if secret == nil || secret.Data["kubeconfig"] == nil {
		return true, true
	}

	kubeconfigBytes := secret.Data["kubeconfig"]
	clientConfig, err := clientcmd.NewClientConfigFromBytes(kubeconfigBytes)
	if err != nil {
		return true, true
	}
	restConfig, err := clientConfig.ClientConfig()
	if err != nil {
		return true, true
	}
	if restConfig.Host != cluster.Status.ProxyURL {
		kubeconfigBytes = []byte(strings.Replace(string(kubeconfigBytes), restConfig.Host, cluster.Status.ProxyURL, -1))
		secret.Data["kubeconfig"] = kubeconfigBytes
		return false, true
	}
	return false, false
}

func CreateCSRConfig(CN string, Organizations []string) *certutil.Config {
	certConfig := certutil.Config{
		CommonName:   CN,
		Organization: Organizations,
		AltNames:     certutil.AltNames{},
		Usages:       []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth},
	}
	return &certConfig
}

func CreateCSR(cluster *clusterv1alpha1.Cluster, expirationDuration time.Duration, CN string, Organizations []string) (*certificatesv1.CertificateSigningRequest, []byte, []byte, error) {
	certConfig := CreateCSRConfig(CN, Organizations)
	x509csr, x509key, err := certs.GenX509CertificateRequestAndKey(certConfig)
	if err != nil {
		return nil, nil, nil, err
	}
	var csrBuffer, keyBuffer bytes.Buffer
	if err = pem.Encode(&keyBuffer, &pem.Block{Type: "PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(x509key)}); err != nil {
		klog.Errorln(err)
		return nil, nil, nil, err
	}

	var csrBytes []byte
	if csrBytes, err = x509.CreateCertificateRequest(rand.Reader, x509csr, x509key); err != nil {
		klog.Errorln(err)
		return nil, nil, nil, err
	}

	if err = pem.Encode(&csrBuffer, &pem.Block{Type: "CERTIFICATE REQUEST", Bytes: csrBytes}); err != nil {
		klog.Errorln(err)
		return nil, nil, nil, err
	}

	csr := csrBuffer.Bytes()
	key := keyBuffer.Bytes()

	// Since we are using go1.16 under development, a compatible way is appreciate
	// once we decide to migrate to go1.17+, the expression can be replaced with `time.Now().UnixMilli()`
	// ref: https://github.com/golang/go/issues/44196
	csrName := fmt.Sprintf("%s-csr-%d", cluster.Name, time.Now().UnixNano()/1e6)
	expSeconds := int32(expirationDuration.Seconds())
	k8sCSR := &certificatesv1.CertificateSigningRequest{
		TypeMeta: metav1.TypeMeta{
			Kind:       "CertificateSigningRequest",
			APIVersion: "certificates.k8s.io/v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: csrName,
		},
		Spec: certificatesv1.CertificateSigningRequestSpec{
			Request:           csr,
			SignerName:        certificatesv1.KubeAPIServerClientSignerName,
			Usages:            []certificatesv1.KeyUsage{certificatesv1.UsageKeyEncipherment, certificatesv1.UsageClientAuth, certificatesv1.UsageDigitalSignature},
			ExpirationSeconds: &expSeconds,
			Username:          cluster.Name,
			Groups:            []string{user.AllAuthenticated},
		},
	}
	return k8sCSR, csr, key, nil
}

func (c *ClusterServices) GetCurrentUserNameAndGroup(ctx context.Context) (string, []string, error) {
	userInfo, err := contextutil.ParseUserInfoFromCtx(ctx)
	if err != nil {
		return "", nil, err
	}
	return userInfo.GetName(), userInfo.GetGroups(), nil
}

func (c *ClusterServices) GetGlobalClusterKubeSystemID(ctx context.Context) (string, error) {
	return c.engine.GetGlobalClusterKubeSystemID(ctx)
}
