package kube

import (
	"context"
	"io"

	v1 "k8s.io/api/core/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/kubernetes/scheme"
)

func openStream(client kubernetes.Interface, namespace, podID string, logOptions *v1.PodLogOptions) (io.ReadCloser, error) {
	return client.CoreV1().RESTClient().Get().
		Namespace(namespace).
		Name(podID).
		Resource("pods").
		SubResource("log").
		VersionedParams(logOptions, scheme.ParameterCodec).
		Stream(context.TODO())
}

func StreamLogs(client kubernetes.Interface, namespace, pod, container string) (io.ReadCloser, error) {
	var tailLines int64 = 1000
	logOptions := &v1.PodLogOptions{
		Container:  container,
		Follow:     true,
		Timestamps: false,
		TailLines:  &tailLines,
	}

	readCloser, err := openStream(client, namespace, pod, logOptions)

	if err != nil {
		return nil, err
	}

	return readCloser, nil
}
