package kube

import (
	"context"
	"fmt"

	apps "k8s.io/api/apps/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	deploymentutil "k8s.io/kubectl/pkg/util/deployment"
	sliceutil "k8s.io/kubectl/pkg/util/slice"
)

func ViewHistoryForDeployment(client kubernetes.Interface, namespace, name string) (*apps.ReplicaSetList, error) {
	versionedClient := client.AppsV1()
	deployment, err := versionedClient.Deployments(namespace).Get(context.TODO(), name, metav1.GetOptions{})
	if err != nil {
		return nil, fmt.Errorf("failed to retrieve deployment %s: %v", name, err)
	}
	_, allOldRSs, newRS, err := deploymentutil.GetAllReplicaSets(deployment, versionedClient)
	if err != nil {
		return nil, fmt.Errorf("failed to retrieve replica sets from deployment %s: %v", name, err)
	}
	allRSs := allOldRSs
	if newRS != nil {
		allRSs = append(allRSs, newRS)
	}

	historyMapping := make(map[int64]*apps.ReplicaSet)
	for _, rs := range allRSs {
		v, err := deploymentutil.Revision(rs)
		if err != nil {
			continue
		}
		historyMapping[v] = rs
	}

	// Sort the revisionToChangeCause map by revision
	revisions := make([]int64, 0, len(historyMapping))
	for r := range historyMapping {
		revisions = append(revisions, r)
	}
	sliceutil.SortInts64(revisions)

	history := &apps.ReplicaSetList{
		TypeMeta: metav1.TypeMeta{
			APIVersion: "v1",
			Kind:       "List",
		},
	}
	history.Items = make([]apps.ReplicaSet, 0, len(historyMapping))
	for i := len(revisions) - 1; i >= 0; i-- {
		history.Items = append(history.Items, *historyMapping[revisions[i]])
	}
	return history, nil
}
