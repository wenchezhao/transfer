# 代码层级说明

目前的代码层级目录如下，依然使用 [gin](https://github.com/gin-gonic/gin) 框架, 在gin中注册模块 handler, handler 对象携带模块调用底层的 service，
service 调用 engine 的客户端操作底层数据资源
+ hander 主要处理业务逻辑
+ service 提供为 handler 可调用的接口定义
+ engine 为 service 提供底层数据操作能力

![img_1.png](img.png)

## 如何增加一个中间件

在 PrepareRun 中可以增加平台所需要的中间件，通知注册API，目前主要氛围两类API

+ baseAPI 主要包含健康检查，metrics接口
+ coreAPI 主要包含平台的核心API，需要权限访问控制
+ proxyAPi 包含需要代理的APi，后续需要实现

```go
func (s *APIServer) PrepareRun(ctx context.Context) error {
	if !s.Cfg.Debug {
		gin.SetMode(gin.ReleaseMode)
	}
	if s.Cfg.Debug {
		// 打印body
		s.Engine.Use(RequestLoggerMiddleware)
	}

	// TODO: add middleware here

	s.RegisterBaseAPI()

	return s.RegisterCoreAPI()
}
```

## 如果增加一个模块

### 实现 handler
如果需要增加一个模块，需要在 /pkg/handlers 下实现如下模块

```shell
.
├── app
│ ├── application.go
│ └── handler.go
└── cloudshell
  ├── cloudshell.go
  └── handler.go
```

如cloudshell模块，需要实现预定义的接口，这里需要根据模块的需求，创建 service

```go
var log = logi.Log.Sugar()

type CloudshellHandler interface {
	GetCloudshell(c *gin.Context)
	CreateCloudshell(c *gin.Context)
}

type CloudshellImp struct {
	Service cloudshell.Services
}

func NewCloudShellHandler(kubeclient kubeclient.Client, pclient pedia.Clients, factory informers.SharedInformerFactory, clusterClient clusterclient.ClusterClients) (CloudshellHandler, error) {
	cloudshellclient, err := cloudshellclient.NewForConfig(kubeclient.Config())
	if err != nil {
		return nil, err
	}

	service, err := cloudshell.NewCloudshellServices(cloudshellclient, kubeclient, pclient, factory, clusterClient)
	if err != nil {
		return nil, err
	}
	return &CloudshellImp{Service: service}, nil
}
```

### 注册路由

所有的路由注册统一放到 `pkg/apiserver/register.go` 中, 需要在register.go中实现注册函数

```go

func RegisterCloudshellHandler(router *gin.RouterGroup, kubeclient kubeclient.Client, factory informers.SharedInformerFactory, clusterClient clusterclient.ClusterClients) error {
	handler, err := cloudshell.NewCloudShellHandler(kubeclient, pedia.NewClients(), factory, clusterClient)
	if err != nil {
		return err
	}
	router.GET("/v1/cluster/:clusters/namespaces/:namespace/cloudshell", handler.GetCloudshell)
	router.POST("/v1/cluster/:clusters/namespaces/:namespace/cloudshell", handler.CreateCloudshell)

	return nil
}

// TODO: register other handler here

```

在 RegisterCoreAPI 中调用注册函数

```go
func (s *APIServer) RegisterCoreAPI() error {
	// enable basic auth
	router := s.Engine.Group("/", gin.BasicAuth(gin.Accounts{
		s.Cfg.BasicAuthUser: s.Cfg.BasicAuthPassword,
	}))

	// register cloudshell handler
	err := RegisterCloudshellHandler(router, s.KubernetesClient, s.InformerFactory, s.ClusterClient)
	if err != nil {
		return err
    }
}
```