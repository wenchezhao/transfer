### 获取resourcequota

##### 请求

GET /v1/namespaces/{namespace}/resourcequota

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### 查询参数

|  参数名  |         描述         |
| :------: | :------------------: |
| Clusters | 可用区唯一标识(列表) |

> 备注：默认获取dsp-quota-default的resourcequota数据，默认使用管理员账号进行，不考察用户权限查询到的cpu默认m为单位，3200相当于3200相当于3200m=3.2core，memory和storage默认以DecimalExponent格式，11e9=11*10^9=11G

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
[
    {
        "dce": {
            "kind": "ResourceQuota",
            "apiVersion": "v1",
            "metadata": {
                "name": "dsp-quota-default",
                "namespace": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999/resourcequotas/dsp-quota-default",
                "uid": "0ece1d29-f2d6-45cb-a511-1911130b0c33",
                "resourceVersion": "198820444",
                "creationTimestamp": "2021-07-28T11:58:25Z"
            },
            "spec": {
                "hard": {
                    "limits.cpu": "0",
                    "limits.memory": "0",
                    "requests.storage": "0"
                },
                "scopes": [
                    "NotBestEffort"
                ]
            },
            "status": {
                "hard": {
                    "limits.cpu": "0",
                    "limits.memory": "0",
                    "requests.storage": "0"
                },
                "used": {
                    "limits.cpu": "0",
                    "limits.memory": "0",
                    "requests.storage": "0"
                }
            }
        }
    },
    {
        "ocp": {
            "kind": "ResourceQuota",
            "apiVersion": "v1",
            "metadata": {
                "name": "dsp-quota-default",
                "namespace": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999/resourcequotas/dsp-quota-default",
                "uid": "1c85b328-ef9b-11eb-ae3c-005056b4411b",
                "resourceVersion": "28491763",
                "creationTimestamp": "2021-07-28T11:58:24Z"
            },
            "spec": {
                "hard": {
                    "limits.cpu": "0",
                    "limits.memory": "0",
                    "requests.storage": "0"
                },
                "scopes": [
                    "NotBestEffort"
                ]
            },
            "status": {
                "hard": {
                    "limits.cpu": "0",
                    "limits.memory": "0",
                    "requests.storage": "0"
                },
                "used": {
                    "limits.cpu": "0",
                    "limits.memory": "0",
                    "requests.storage": "0"
                }
            }
        }
    }
]
```


### 更新resourcequota

##### 请求

PUT /v1/namespaces/{namespace}/resourcequota

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |


> 备注：默认更新dsp-quota-default的resourcequota数据，默认使用管理员账号进行，不考察用户权限cpu默认以m为单位，3200相当于3200m=3.2core

##### 请求体参数

```json
{
	"kind": "ResourceQuota",
	"apiVersion": "v1",
	"metadata": {
		"name": "dsp-quota-default"
	},
	"spec": {
		"hard": {
			"limits.cpu": "3200",
			"limits.memory": "11G",
			"requests.storage": "10G"
		},
		"scopes": [
			"NotBestEffort"
		]
	}
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 获取特定ns多个集群资源使用情况

##### 请求

GET /v1/namespaces/{namespace}/resourcequotatotal

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### 查询参数

|  参数名  |      描述      |
| :------: | :------------: |
| clusters | 可用区标识列表 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "test": {
        "cpuUsed": 0,
      	"cpuTotal": 0,
      	"memoryUsed": 0,
      	"memoryTotal": 0,
      	"storageUsed": 0,
      	"storageTotal": 0
    }
}
```

