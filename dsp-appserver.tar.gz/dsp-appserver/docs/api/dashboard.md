## 获取集群资源概览

#### 请求

GET-/v1/dashboard/clustercount

#### 查询参数

| Parameter | Description |
| :-------: | :---------: |
| clusters  | 集群ID列表  |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "k8s": { // 集群编码
        "allocatableCpuTotal": 96000, // CPU总量
        "allocatableMemTotal": 189332451328, // 内存总量
        "cpuLimits": 112161,  //CPU限制值
        "cpuRequests": 45762,  //CPU请求值
        "ephemeralAllocatableStorageTotal": 1447869370433, // 存储总量
        "ephemeralStorageLimits": 0, // 存储限制值
        "ephemeralStorageRequests": 0, // 存储请你去值
        "memoryLimits": 153389433416, // 内存限制值
        "memoryRequests": 77414835272, // 内存请求值
		"pvTotal": 453423523452,//存储值，单位为字节
        "workerCpuTaint": 0, // 特定CPU使用
        "workerCpuTotal": 0, // 普通CPU使用
        "workerMemoryTaint": 0, //特定内存使用
        "workerMemoryTotal": 0, // 普通内存使用
        "workerNodeNotReady": 0, // 未就绪节点数
        "workerNodeTaint": 0, // 有污点节点数
        "workerNodeTotal": 0 // 工作节点总数
    }
}
```

## 获取资源数量统计值

#### 请求

GET-/v1/dashboard/resourcescount

#### 查询参数

| Parameter  | Description  |
| :--------: | :----------: |
| namespaces | 命名空间列表 |
|  clusters  |  集群ID列表  |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "k8s": {
        "yorktest": {
            "deployments": {
                "notReadList": [],
                "readyList": [
                    "test"
                ]
            },
            "pods": {
                "notReadList": [],
                "readyList": []
            },
            "statefulsets": {
                "notReadyList": [],
                "readyList": []
            }
        }
    }
}
```

## 获取资源配额统计值

#### 请求

GET-/v1/dashboard/quotacount

#### 查询参数

| Parameter  | Description  |
| :--------: | :----------: |
| namespaces | 命名空间列表 |
|  clusters  |  集群ID列表  |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "k8s": {
        "0617": {
            "cpuTotal": 2000,
            "cpuUsed": 0,
            "memoryTotal": 2147483648,
            "memoryUsed": 0,
            "storageTotal": 2147483648,
            "storageUsed": 0
        }
    }
}
```

## 获取容器组状态值----废弃

#### 请求

GET-/v1/dashboard/podcount

#### 查询参数

| Parameter  | Description  |
| :--------: | :----------: |
| namespaces | 命名空间列表 |
|  clusters  |  集群ID列表  |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "k8s": {
        "chaoyue": {
            "running": 1,
            "total": 1
        }
    }
}
```

