## Pod

### 获取 Pod 列表

##### Http Request

GET /v1/namespaces/{namespace}/pods

##### Path Parameters

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |

##### Query Parameters

|   Parameter   |                    Description                    |
| :-----------: | :-----------------------------------------------: |
|     zone      |     可用区唯一标识，当为空时，表示默认可用区      |
| labelSelector | 标签选择器，默认选中所有pod。使用示例 k1=v1,k2=v2 |

##### Response
| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "v1",
            "kind": "Pod",
            "metadata": {
                "creationTimestamp": "2019-04-11T23:07:52Z",
                "generateName": "nginx-847fbcddc8-",
                "labels": {
                    "pod-template-hash": "847fbcddc8",
                    "run": "nginx"
                },
                "name": "nginx-847fbcddc8-6qtmp",
                "namespace": "easyops",
                "ownerReferences": [
                    {
                        "apiVersion": "apps/v1",
                        "blockOwnerDeletion": true,
                        "controller": true,
                        "kind": "ReplicaSet",
                        "name": "nginx-847fbcddc8",
                        "uid": "a24a4d1f-5cae-11e9-ada9-005056a117fe"
                    }
                ],
                "resourceVersion": "6964558",
                "selfLink": "/api/v1/namespaces/easyops/pods/nginx-847fbcddc8-6qtmp",
                "uid": "a24c91b9-5cae-11e9-ada9-005056a117fe"
            },
            "spec": {
                "containers": [
                    {
                        "image": "nginx",
                        "imagePullPolicy": "Always",
                        "name": "nginx",
                        "ports": [
                            {
                                "containerPort": 80,
                                "protocol": "TCP"
                            }
                        ],
                        "resources": {},
                        "terminationMessagePath": "/dev/termination-log",
                        "terminationMessagePolicy": "File",
                        "volumeMounts": [
                            {
                                "mountPath": "/demo",
                                "name": "demo"
                            },
                            {
                                "mountPath": "/var/run/secrets/kubernetes.io/serviceaccount",
                                "name": "nginx-token-6gjgr",
                                "readOnly": true
                            }
                        ]
                    }
                ],
                "dnsPolicy": "ClusterFirst",
                "enableServiceLinks": true,
                "nodeName": "192-168-2-79",
                "priority": 0,
                "restartPolicy": "Always",
                "schedulerName": "default-scheduler",
                "securityContext": {},
                "serviceAccount": "nginx",
                "serviceAccountName": "nginx",
                "terminationGracePeriodSeconds": 30,
                "tolerations": [
                    {
                        "effect": "NoExecute",
                        "key": "node.kubernetes.io/not-ready",
                        "operator": "Exists",
                        "tolerationSeconds": 300
                    },
                    {
                        "effect": "NoExecute",
                        "key": "node.kubernetes.io/unreachable",
                        "operator": "Exists",
                        "tolerationSeconds": 300
                    }
                ],
                "volumes": [
                    {
                        "emptyDir": {},
                        "name": "demo"
                    },
                    {
                        "name": "nginx-token-6gjgr",
                        "secret": {
                            "defaultMode": 420,
                            "secretName": "nginx-token-6gjgr"
                        }
                    }
                ]
            },
            "status": {
                "conditions": [
                    {
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-04-11T23:07:52Z",
                        "status": "True",
                        "type": "Initialized"
                    },
                    {
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-04-11T23:07:56Z",
                        "status": "True",
                        "type": "Ready"
                    },
                    {
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-04-11T23:07:56Z",
                        "status": "True",
                        "type": "ContainersReady"
                    },
                    {
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-04-11T23:07:52Z",
                        "status": "True",
                        "type": "PodScheduled"
                    }
                ],
                "containerStatuses": [
                    {
                        "containerID": "containerd://1fcc01696c9112a3cabf113e648697d6da7967091bab7bdd8c69e73728522cad",
                        "image": "docker.io/library/nginx:latest",
                        "imageID": "docker.io/library/nginx@sha256:e7ce2459f2518e9ad4e357c2f837bbbbdfdea0046c160b08564ee44fc4a505bb",
                        "lastState": {},
                        "name": "nginx",
                        "ready": true,
                        "restartCount": 0,
                        "state": {
                            "running": {
                                "startedAt": "2019-04-11T23:07:56Z"
                            }
                        }
                    }
                ],
                "hostIP": "192.168.2.79",
                "phase": "Running",
                "podIP": "10.244.39.29",
                "qosClass": "BestEffort",
                "startTime": "2019-04-11T23:07:52Z"
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 获取 Pod

##### Http Request

GET /v1/namespaces/{namespace}/pods/{name}

##### Path Parameters

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |
|   name    |  pod的名字  |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区唯一标识，当为空时，表示默认可用区 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```shell
{
    "apiVersion": "v1",
    "kind": "Pod",
    "metadata": {
        "creationTimestamp": "2019-04-11T23:07:52Z",
        "generateName": "nginx-847fbcddc8-",
        "labels": {
            "pod-template-hash": "847fbcddc8",
            "run": "nginx"
        },
        "name": "nginx-847fbcddc8-6qtmp",
        "namespace": "easyops",
        "ownerReferences": [
            {
                "apiVersion": "apps/v1",
                "blockOwnerDeletion": true,
                "controller": true,
                "kind": "ReplicaSet",
                "name": "nginx-847fbcddc8",
                "uid": "a24a4d1f-5cae-11e9-ada9-005056a117fe"
            }
        ],
        "resourceVersion": "6964558",
        "selfLink": "/api/v1/namespaces/easyops/pods/nginx-847fbcddc8-6qtmp",
        "uid": "a24c91b9-5cae-11e9-ada9-005056a117fe"
    },
    "spec": {
        "containers": [
            {
                "image": "nginx",
                "imagePullPolicy": "Always",
                "name": "nginx",
                "ports": [
                    {
                        "containerPort": 80,
                        "protocol": "TCP"
                    }
                ],
                "resources": {},
                "terminationMessagePath": "/dev/termination-log",
                "terminationMessagePolicy": "File",
                "volumeMounts": [
                    {
                        "mountPath": "/demo",
                        "name": "demo"
                    },
                    {
                        "mountPath": "/var/run/secrets/kubernetes.io/serviceaccount",
                        "name": "nginx-token-6gjgr",
                        "readOnly": true
                    }
                ]
            }
        ],
        "dnsPolicy": "ClusterFirst",
        "enableServiceLinks": true,
        "nodeName": "192-168-2-79",
        "priority": 0,
        "restartPolicy": "Always",
        "schedulerName": "default-scheduler",
        "securityContext": {},
        "serviceAccount": "nginx",
        "serviceAccountName": "nginx",
        "terminationGracePeriodSeconds": 30,
        "tolerations": [
            {
                "effect": "NoExecute",
                "key": "node.kubernetes.io/not-ready",
                "operator": "Exists",
                "tolerationSeconds": 300
            },
            {
                "effect": "NoExecute",
                "key": "node.kubernetes.io/unreachable",
                "operator": "Exists",
                "tolerationSeconds": 300
            }
        ],
        "volumes": [
            {
                "emptyDir": {},
                "name": "demo"
            },
            {
                "name": "nginx-token-6gjgr",
                "secret": {
                    "defaultMode": 420,
                    "secretName": "nginx-token-6gjgr"
                }
            }
        ]
    },
    "status": {
        "conditions": [
            {
                "lastProbeTime": null,
                "lastTransitionTime": "2019-04-11T23:07:52Z",
                "status": "True",
                "type": "Initialized"
            },
            {
                "lastProbeTime": null,
                "lastTransitionTime": "2019-04-11T23:07:56Z",
                "status": "True",
                "type": "Ready"
            },
            {
                "lastProbeTime": null,
                "lastTransitionTime": "2019-04-11T23:07:56Z",
                "status": "True",
                "type": "ContainersReady"
            },
            {
                "lastProbeTime": null,
                "lastTransitionTime": "2019-04-11T23:07:52Z",
                "status": "True",
                "type": "PodScheduled"
            }
        ],
        "containerStatuses": [
            {
                "containerID": "containerd://1fcc01696c9112a3cabf113e648697d6da7967091bab7bdd8c69e73728522cad",
                "image": "docker.io/library/nginx:latest",
                "imageID": "docker.io/library/nginx@sha256:e7ce2459f2518e9ad4e357c2f837bbbbdfdea0046c160b08564ee44fc4a505bb",
                "lastState": {},
                "name": "nginx",
                "ready": true,
                "restartCount": 0,
                "state": {
                    "running": {
                        "startedAt": "2019-04-11T23:07:56Z"
                    }
                }
            }
        ],
        "hostIP": "192.168.2.79",
        "phase": "Running",
        "podIP": "10.244.39.29",
        "qosClass": "BestEffort",
        "startTime": "2019-04-11T23:07:52Z"
    }
}
```

### 获取pod下的event事件列表

##### 请求

GET /v1/namespaces/{namespace}/pods/{name}/events

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|   name    |      pod的名称       |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "v1",
            "count": 63892,
            "eventTime": null,
            "firstTimestamp": "2019-04-29T09:03:32Z",
            "involvedObject": {
                "apiVersion": "v1",
                "kind": "PersistentVolumeClaim",
                "name": "demo11",
                "namespace": "daocloudcsp",
                "resourceVersion": "9191134",
                "uid": "aa188578-6a5d-11e9-83af-005056b595d6"
            },
            "kind": "Event",
            "lastTimestamp": "2019-05-10T02:43:36Z",
            "message": "no persistent volumes available for this claim and no storage class is set",
            "metadata": {
                "creationTimestamp": "2019-04-29T09:03:32Z",
                "name": "demo11.1599e686d3613168",
                "namespace": "daocloudcsp",
                "resourceVersion": "11618906",
                "selfLink": "/api/v1/namespaces/daocloudcsp/events/demo11.1599e686d3613168",
                "uid": "aa195fa5-6a5d-11e9-83af-005056b595d6"
            },
            "reason": "FailedBinding",
            "reportingComponent": "",
            "reportingInstance": "",
            "source": {
                "component": "persistentvolume-controller"
            },
            "type": "Normal"
        },
        {
            "apiVersion": "v1",
            "count": 130843,
            "eventTime": null,
            "firstTimestamp": "2019-04-18T02:59:24Z",
            "involvedObject": {
                "apiVersion": "v1",
                "kind": "PersistentVolumeClaim",
                "name": "sss",
                "namespace": "daocloudcsp",
                "resourceVersion": "7097245",
                "uid": "f90b0c74-6185-11e9-83af-005056b595d6"
            },
            "kind": "Event",
            "lastTimestamp": "2019-05-10T02:39:36Z",
            "message": "no persistent volumes available for this claim and no storage class is set",
            "metadata": {
                "creationTimestamp": "2019-04-18T02:59:24Z",
                "name": "sss.15967245ab178e56",
                "namespace": "daocloudcsp",
                "resourceVersion": "11618098",
                "selfLink": "/api/v1/namespaces/daocloudcsp/events/sss.15967245ab178e56",
                "uid": "f90ec963-6185-11e9-83af-005056b595d6"
            },
            "reason": "FailedBinding",
            "reportingComponent": "",
            "reportingInstance": "",
            "source": {
                "component": "persistentvolume-controller"
            },
            "type": "Normal"
        },
        {
            "apiVersion": "v1",
            "count": 449,
            "eventTime": null,
            "firstTimestamp": "2019-05-08T05:43:05Z",
            "involvedObject": {
                "apiVersion": "apps/v1",
                "kind": "ReplicaSet",
                "name": "yxltest-c7c9d98df",
                "namespace": "daocloudcsp",
                "resourceVersion": "11104002",
                "uid": "26f406bc-7154-11e9-83af-005056b595d6"
            },
            "kind": "Event",
            "lastTimestamp": "2019-05-10T02:42:50Z",
            "message": "Error creating: pods \"yxltest-c7c9d98df-\" is forbidden: unable to validate against any security context constraint: [capabilities.add: Invalid value: \"NET_BIND_SERVICE\": capability may not be added capabilities.add: Invalid value: \"NET_BIND_SERVICE\": capability may not be added]",
            "metadata": {
                "creationTimestamp": "2019-05-08T05:43:05Z",
                "name": "yxltest-c7c9d98df.159c9ecf99ecbde3",
                "namespace": "daocloudcsp",
                "resourceVersion": "11618731",
                "selfLink": "/api/v1/namespaces/daocloudcsp/events/yxltest-c7c9d98df.159c9ecf99ecbde3",
                "uid": "26f6f966-7154-11e9-83af-005056b595d6"
            },
            "reason": "FailedCreate",
            "reportingComponent": "",
            "reportingInstance": "",
            "source": {
                "component": "replicaset-controller"
            },
            "type": "Warning"
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    
```

### 删除 Pod

##### Http Request

DELETE /v1/namespaces/{namespace}/pods/{name}

##### Path Parameters

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |
|   name    |  pod的名字  |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区唯一标识，当为空时，表示默认可用区 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json

```
### 删除 Pod 列表

##### Http Request

DELETE /v1/namespaces/{namespace}/pods

##### Path Parameters

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |
|   name    |  pod的名字  |

##### Query Parameters

|   Parameter   |                         Description                          |
| :-----------: | :----------------------------------------------------------: |
|     zone      |           可用区唯一标识，当为空时，表示默认可用区           |
| labelSelector | 由键值对组成的字符串，例如 k1=v2,k2=v2。被标签选中的POD将被删除。 |
|     names     | 由一组pod的名字组成的字符串，例如 foo,bar。被同名的pod将被删除。 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json

```

### 获取Pod的终端

##### 1. 请求

GET   /v1/namespaces/{namespace}/pods/{pod}/shell/{container}

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|    pod    |      pod的名称       |
| container |       容器名称       |
|           |                      |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |
| shell  |   可选值为 "bash", "sh", "powershell", "cmd"   |


##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "id": "d32637d9b514922cf70b1c3c4c4bdc52"
}
```
##### 2. 请求

GET  /api/sockjs/*

```
ref sockjs 标准接口 https://github.com/sockjs/sockjs-client
```

### 从容器里下载文件

##### 请求

GET  /v1/namespaces/{namespace}/pods/{name}/download

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|   name    |      pod的名称       |

##### 查询参数

|    参数名     |                      描述                       |
| :-----------: | :---------------------------------------------: |
|     zone      | 可用区的唯一标识，当其值为空时，表示默认可用区  |
| containerName | 容器名称，当其值为空时，默认选择POD的第一个容器 |
|     path      |             要下载的容器内文件路径              |


##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{} // 文件流
```

## Container

### 获取容器日志(仅实时日志）

##### 请求

GET /v1/namespaces/{namespace}/pods/{name}/log

##### 路径参数

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |
|   name    |  pod的名字  |

##### 查询参数

| Parameter |                         Description                          |
| :-------: | :----------------------------------------------------------: |
|   zone    |           可用区唯一标识，当为空时，表示默认可用区           |
| container |        容器的名称，当pod内容器的个数为1时，其值可为空        |
|  follow   | 可选值为true和false，默认值为false。当其值为false时，直接返回所有日志；当其值为true时，升级http为websock，通过websock传输数据，由客户端负责维持连接状态。 |
|           |                                                              |

##### 响应

````
2019-04-10T06:38:50.587Z [INFO] CoreDNS-1.2.6
2019-04-10T06:38:50.587Z [INFO] linux/amd64, go1.11.2, 756749c
CoreDNS-1.2.6
linux/amd64, go1.11.2, 756749c
 [INFO] plugin/reload: Running configuration MD5 = f65c4821c8a9b7b5eb30fa4fbc167769
 [ERROR] plugin/errors: 2 97278698732240836.2098020197164707773. HINFO: unreachable backend: read udp 10.244.39.30:55056->114.114.114.114:53: i/o timeout
 [ERROR] plugin/errors: 2 97278698732240836.2098020197164707773. HINFO: unreachable backend: read udp 10.244.39.30:51065->114.114.114.114:53: i/o timeout
...
````

