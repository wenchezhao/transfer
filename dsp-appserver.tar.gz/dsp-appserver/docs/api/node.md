## 节点驱逐

#### 请求

PUT-/v1/nodes/:node/drain

#### 路径参数

| Parameter | Description |
| :-------: | :---------: |
|   node    |  节点名称   |

#### 请求头参数

| Parameter |  Description   |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

## 节点暂停调度和继续调度

#### 请求

PUT-/v1/nodes/:node/cordonoruncordon

#### 路径参数

| Parameter | Description |
| :-------: | :---------: |
|   node    |  节点名称   |

#### 请求头参数

| Parameter |  Description   |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

#### 查询参数

|   Parameter   |         Description          |
| :-----------: | :--------------------------: |
| unschedulable | true 暂停调度 false 继续调度 |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

