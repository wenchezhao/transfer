```
所有接口 header需要传递 clusterID 代表是访问的哪个集群

ip池列表

{{server_addr}}/v1/dce/pools?namespace=123
参数 namespace : string
方法: GET
返回json:
{
    "items": [
        {
            "name": "name1",
            "displayVlan": 4095,
            "totalIpNumber": 3,
            "idleIpNumber": 1,
            "conflictIpNumber": 2,
            "SubnetName": "subnet1",
            "ruleLen": 0
        },
        {
            "name": "name2",
            "displayVlan": 4095,
            "totalIpNumber": 3,
            "idleIpNumber": 1,
            "conflictIpNumber": 2,
            "SubnetName": "subnet1",
            "ruleLen": 1
        }
    ]
}
​


ip池详情

{{server_addr}}/v1/dce/pools/:pool?namespace=123
参数 namespace : string
方法: GET
返回json:
{
    "name": "name1",
    "Subnet": "vlan0",
    "defaultRouteV4": "10.6.0.1",
    "DisplayVlan": 4095,
    "ips": [
        {
            "ip": "10.6.0.12",
            "mac": "F8:C5:0A:06:00:0C",
            "ruleName": "",
            "status": "未连接",
            "pod": ""
        },
        {
            "ip": "10.6.0.19",
            "mac": "F8:C5:0A:06:00:0C",
            "ruleName": "rule-2",
            "status": "已连接",
            "pod": "pod-123-xas-s"
        }
    ]
}


ip 规则列表

{{server_addr}}/v1/dce/rules?namespace=123
参数 namespace : string
方法: GET
返回json:
  {
    "items": [
        {
            "name": "name1",
            "describe": "dsec1",
            "ipNum": 1,
            "poolName": "pool1"
        },
        {
            "name": "name2",
            "describe": "dsec2",
            "ipNum": 1,
            "poolName": "pool1"
        }
    ]
}
ip规则详情

{{server_addr}}/v1/dce/rules/:rule?namespace=123&poolName=pool1
参数 namespace : string
参数 poolName : string
方法: GET
返回json:
 {
    "name": [
        {
            "ip": "172.168.1.3",
            "status": "已连接"
        },
        {
            "ip": "172.168.1.8",
            "status": "未连接"
        }
    ]
}
ip规则-删除

{{server_addr}}/v1/dce/rules/:rule?namespace=123&poolName=pool1
参数 namespace : string
参数 poolName : string
方法: DELETE
​
​
返回json:
{
  "code":200,
  "message":"success"
}
ip规则-创建

{{server_addr}}/v1/dce/rules?namespace=123
参数 namespace : string
方法: POST
body json
 {
     "name": "name1",
     "description": "desc1",
     "ipList": []string{"192.168.10.1","192.168.10.2",},
     "poolName": "pool1",
     "subnet": "subnet1",
     "subnetName": "subnetName1"
}
​
​
返回json:
{
  "code":200,
  "message":"success"
}


子网信息

{{server_addr}}/v1/dce/subnet?namespace=123&name=xxx
参数 namespace : string  不可与name同时使用
参数 name : string       不可与namespace同时使用
方法: GET
​
​
返回json:
{
    "apiVersion": "parcel.dce.daocloud.io/v1beta1",
    "items": [
        {
            "ArpingIp": "",
            "AvailableNodes": {
                "dce-10-6-105-114": "10.6.105.114",
                "dce-10-6-105-115": "10.6.105.115"
            },
            "DefaultRouteV4": "10.6.0.1",
            "DefaultRouteV6": "FD00:6::1",
            "DisplayVlan": 4095,
            "Pools": [
                {
                    "ConflictIpNumber": 0,
                    "DisplayVlan": 4095,
                    "IdleIpNumber": 7,
                    "IpList": [
                        "10.6.111.2",
                        "10.6.111.3",
                        "10.6.111.4",
                        "10.6.111.5",
                        "10.6.111.6",
                        "10.6.111.7",
                        "10.6.111.8"
                    ],
                    "IpRuleNumber": 0,
                    "Namespace": "vlan",
                    "PoolName": "vlan0-vlan",
                    "SubnetName": "vlan0",
                    "TotalIpNumber": 7,
                    "Working": false,
                    "defaultRouteV4": "10.6.0.1",
                    "defaultRouteV6": "",
                    "route": []
                },
                {
                    "ConflictIpNumber": 0,
                    "DisplayVlan": 4095,
                    "IdleIpNumber": 2,
                    "IpList": [
                        "10.6.130.170",
                        "10.6.130.171"
                    ],
                    "IpRuleNumber": 0,
                    "Namespace": "",
                    "PoolName": "vlan0-",
                    "SubnetName": "vlan0",
                    "TotalIpNumber": 2,
                    "Working": false,
                    "defaultRouteV4": "10.6.0.1",
                    "defaultRouteV6": "FD00:6::1",
                    "route": []
                }
            ],
            "PrefixMac": "F8:C5",
            "PrefixV6": "FD00:6::/64",
            "Route": [],
            "apiVersion": "parcel.dce.daocloud.io/v1beta1",
            "kind": "OvsSubnet",
            "metadata": {
                "name": "vlan0",
                "namespace": ""
            },
            "subnet": "10.6.0.0/16"
        },
        {
            "ArpingIp": "",
            "AvailableNodes": {},
            "DefaultRouteV4": "10.6.130.1",
            "DefaultRouteV6": "",
            "DisplayVlan": 4095,
            "Pools": [],
            "PrefixMac": "F8:C5",
            "PrefixV6": "",
            "Route": [],
            "apiVersion": "parcel.dce.daocloud.io/v1beta1",
            "kind": "OvsSubnet",
            "metadata": {
                "name": "vlantest",
                "namespace": ""
            },
            "subnet": "10.6.130.0/24"
        }
    ],
    "kind": "OvsSubnetList",
    "metadata": {
        "name": "",
        "namespace": ""
    }
}


ip池-创建

{{server_addr}}/v1/dce/pools?namespace=123
参数 namespace : string
方法: POST
body json
{   // 注意，不需要传递name ， name会自动根据 子网和命名空间生成
    "defaultRouteV4": "10.6.0.1", //IPV4默认路由
    "defaultRouteV6": "",  //IPV6默认路由
    "route": [], //可为空字符串数组，其他路由规则
    "subnetName": "vlan0", //子网名
    "v4MapV6": ["10.6.105.70>fd00:6::1111"] 
      // IP池中IPV4与IPV6的对应关系，单栈"10.6.105.30>" ， 需要在ip后面拼一个 ">"符号
                                  双栈"10.6.105.30>fd00:6::691e" ， 需要在ip后面拼 “>”加子网列表返回的  defaultRouteV6字段
}
​
​
返回json:
{
  "code":200,
  "message":"success"
}


ip池-删除

{{server_addr}}/v1/dce/pools/:pool?namespace=123
参数 namespace : string
方法: DELETE
​
返回json:
{
  "code":200,
  "message":"success"
}
```