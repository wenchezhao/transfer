### 获取满足Prometheus RuleNamespaceSelector 条件的命名空间的名称列表

##### Request

GET /v1/prometheus/rulenamespaces

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |


##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
["openshift-monitoring"]
```

### 获取PrometheusRule列表

##### Request

GET /v1/namespaces/:namespace/prometheusrules

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |


##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "monitoring.coreos.com/v1",
            "kind": "PrometheusRule",
            "metadata": {
                "creationTimestamp": "2021-07-22T08:56:29Z",
                "name": "prometheus-k8s-rules",
                "namespace": "openshift-monitoring",
                "labels": {
                    "prometheus": "k8s",
                    "role": "alert-rules"
                },
                "resourceVersion": "235552472",
                "selfLink": "/api/v1/namespaces/openshift-monitoring/prometheusrules/prometheus-k8s-rules",
                "uid": "095d0b16-05d5-4258-94f8-1037e85411ad"
            },
            "spec": {
                "groups": [
                    {
                        "name": "k8s.rules",
                        "rules": [
                            {
                                "expr": "sum(rate(container_cpu_usage_seconds_total{job=\"kubelet\", image!=\"\", container_name!=\"\"}[5m])) by (namespace)\n",
                                "record": "namespace:container_cpu_usage_seconds_total:sum_rate"
                            }
                        ]
                    },
                    {
                        "name": "kubernetes-absent",
                        "rules": [
                            {
                                "alert": "AlertmangerDown",
                                "annotations": {
                                    "message": "Alertmanager has disappeared from Prometheus target discovery."
                                },
                                "expr": "absent(up{job=\"alertmanager-main\"} == 1)\n",
                                "for": "15m",
                                "labels": {
                                    "serverity": "critical"
                                }
                            }
                        ]
                    }
                ]
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "314466926",
        "selfLink": "/api/v1/namespaces/openshift-monitoring/prometheusrules"
    }
}
```

### 获取m某个PrometheusRule

##### Request

GET /v1/namespaces/:namespace/prometheusrules/:name

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | 资源名称 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "monitoring.coreos.com/v1",
    "kind": "PrometheusRule",
    "metadata": {
        "creationTimestamp": "2021-07-22T08:56:29Z",
        "name": "prometheus-k8s-rules",
        "namespace": "openshift-monitoring",
        "labels": {
            "prometheus": "k8s",
            "role": "alert-rules"
        },
        "resourceVersion": "235552472",
        "selfLink": "/api/v1/namespaces/openshift-monitoring/prometheusrules/prometheus-k8s-rules",
        "uid": "095d0b16-05d5-4258-94f8-1037e85411ad"
    },
    "spec": {
        "groups": [
            {
                "name": "k8s.rules",
                "rules": [
                    {
                        "expr": "sum(rate(container_cpu_usage_seconds_total{job=\"kubelet\", image!=\"\", container_name!=\"\"}[5m])) by (namespace)\n",
                        "record": "namespace:container_cpu_usage_seconds_total:sum_rate"
                    }
                ]
            },
            {
                "name": "kubernetes-absent",
                "rules": [
                    {
                        "alert": "AlertmangerDown",
                        "annotations": {
                            "message": "Alertmanager has disappeared from Prometheus target discovery."
                        },
                        "expr": "absent(up{job=\"alertmanager-main\"} == 1)\n",
                        "for": "15m",
                        "labels": {
                            "serverity": "critical"
                        }
                    }
                ]
            }
        ]
    }
}
```

### 创建PrometheusRule

##### Request

POST /v1/namespaces/:namespace/prometheusrules

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### Body

```json
{
    "apiVersion": "monitoring.coreos.com/v1",
    "kind": "PrometheusRule",
    "metadata": {
        "name": "prometheus-k8s-rules",
        "namespace": "openshift-monitoring",
        "labels": {
            "prometheus": "k8s",
            "role": "alert-rules"
        }
    },
    "spec": {
        "groups": [
            {
                "name": "k8s.rules",
                "rules": [
                    {
                        "expr": "sum(rate(container_cpu_usage_seconds_total{job=\"kubelet\", image!=\"\", container_name!=\"\"}[5m])) by (namespace)\n",
                        "record": "namespace:container_cpu_usage_seconds_total:sum_rate"
                    }
                ]
            },
            {
                "name": "kubernetes-absent",
                "rules": [
                    {
                        "alert": "AlertmangerDown",
                        "annotations": {
                            "message": "Alertmanager has disappeared from Prometheus target discovery."
                        },
                        "expr": "absent(up{job=\"alertmanager-main\"} == 1)\n",
                        "for": "15m",
                        "labels": {
                            "serverity": "critical"
                        }
                    }
                ]
            }
        ]
    }
}
```

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "monitoring.coreos.com/v1",
    "kind": "PrometheusRule",
    "metadata": {
        "creationTimestamp": "2021-07-22T08:56:29Z",
        "name": "prometheus-k8s-rules",
        "namespace": "openshift-monitoring",
        "labels": {
            "prometheus": "k8s",
            "role": "alert-rules"
        },
        "resourceVersion": "235552472",
        "selfLink": "/api/v1/namespaces/openshift-monitoring/prometheusrules/prometheus-k8s-rules",
        "uid": "095d0b16-05d5-4258-94f8-1037e85411ad"
    },
    "spec": {
        "groups": [
            {
                "name": "k8s.rules",
                "rules": [
                    {
                        "expr": "sum(rate(container_cpu_usage_seconds_total{job=\"kubelet\", image!=\"\", container_name!=\"\"}[5m])) by (namespace)\n",
                        "record": "namespace:container_cpu_usage_seconds_total:sum_rate"
                    }
                ]
            },
            {
                "name": "kubernetes-absent",
                "rules": [
                    {
                        "alert": "AlertmangerDown",
                        "annotations": {
                            "message": "Alertmanager has disappeared from Prometheus target discovery."
                        },
                        "expr": "absent(up{job=\"alertmanager-main\"} == 1)\n",
                        "for": "15m",
                        "labels": {
                            "serverity": "critical"
                        }
                    }
                ]
            }
        ]
    }
}
```

### 更新PrometheusRule

##### Request

PUT "/v1/namespaces/:namespace/prometheusrules/:name

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | 资源名称 |

##### Body

```json
{
    "apiVersion": "monitoring.coreos.com/v1",
    "kind": "PrometheusRule",
    "metadata": {
        "creationTimestamp": "2021-07-22T08:56:29Z",
        "name": "prometheus-k8s-rules",
        "namespace": "openshift-monitoring",
        "labels": {
            "prometheus": "k8s",
            "role": "alert-rules"
        },
        "resourceVersion": "235552472",
        "selfLink": "/api/v1/namespaces/openshift-monitoring/prometheusrules/prometheus-k8s-rules",
        "uid": "095d0b16-05d5-4258-94f8-1037e85411ad"
    },
    "spec": {
        "groups": [
            {
                "name": "k8s.rules",
                "rules": [
                    {
                        "expr": "sum(rate(container_cpu_usage_seconds_total{job=\"kubelet\", image!=\"\", container_name!=\"\"}[5m])) by (namespace)\n",
                        "record": "namespace:container_cpu_usage_seconds_total:sum_rate"
                    }
                ]
            },
            {
                "name": "kubernetes-absent",
                "rules": [
                    {
                        "alert": "AlertmangerDown",
                        "annotations": {
                            "message": "Alertmanager has disappeared from Prometheus target discovery."
                        },
                        "expr": "absent(up{job=\"alertmanager-main\"} == 1)\n",
                        "for": "15m",
                        "labels": {
                            "serverity": "critical"
                        }
                    }
                ]
            }
        ]
    }
}
```

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "monitoring.coreos.com/v1",
    "kind": "PrometheusRule",
    "metadata": {
        "creationTimestamp": "2021-07-22T08:56:29Z",
        "name": "prometheus-k8s-rules",
        "namespace": "openshift-monitoring",
        "labels": {
            "prometheus": "k8s",
            "role": "alert-rules"
        },
        "resourceVersion": "235552472",
        "selfLink": "/api/v1/namespaces/openshift-monitoring/prometheusrules/prometheus-k8s-rules",
        "uid": "095d0b16-05d5-4258-94f8-1037e85411ad"
    },
    "spec": {
        "groups": [
            {
                "name": "k8s.rules",
                "rules": [
                    {
                        "expr": "sum(rate(container_cpu_usage_seconds_total{job=\"kubelet\", image!=\"\", container_name!=\"\"}[5m])) by (namespace)\n",
                        "record": "namespace:container_cpu_usage_seconds_total:sum_rate"
                    }
                ]
            },
            {
                "name": "kubernetes-absent",
                "rules": [
                    {
                        "alert": "AlertmangerDown",
                        "annotations": {
                            "message": "Alertmanager has disappeared from Prometheus target discovery."
                        },
                        "expr": "absent(up{job=\"alertmanager-main\"} == 1)\n",
                        "for": "15m",
                        "labels": {
                            "serverity": "critical"
                        }
                    }
                ]
            }
        ]
    }
}
```

### 删除PrometheusRule

##### Request

DELETE /v1/namespaces/:namespace/prometheusrules/:name

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | 资源名称 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

