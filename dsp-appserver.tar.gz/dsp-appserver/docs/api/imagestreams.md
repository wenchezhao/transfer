### 删除 imagestream

##### 请求

DELETE /v1/namespaces/{namespace}/imagestreams/{name}

##### 路径参数

| Parameter |    Description    |
| :-------: | :---------------: |
| namespace |     命名空间      |
|   name    | imagestream的名称 |

##### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
|   zone    | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

