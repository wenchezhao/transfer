## cluster

### 获取集群版本信息

#### 请求

POST-/v1/cluster/version

#### 查询参数

|  参数名   |       描述       |
| :-------: | :--------------: |
| clusterID | 可用区的唯一标识 |

#### 请求体

```json
{"clusterUrl":"","certificateAuthorityData":"","clientCertificateData":"","clientKeyData":""}
```

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```
{
    "type": "K8S",
    "info": {
        "major": "1",
        "minor": "15",
        "gitVersion": "v1.15.4",
        "gitCommit": "67d2fcf276fcd9cf743ad4be9a9ef5828adc082f",
        "gitTreeState": "clean",
        "buildDate": "2019-09-18T14:41:55Z",
        "goVersion": "go1.12.9",
        "compiler": "gc",
        "platform": "linux/amd64"
    }
}
```

### 获取集群概览信息

#### 请求

GET-/v1/cluster/overview

#### 查询参数

|  参数名   |       描述       |
| :-------: | :--------------: |
| clusterID | 可用区的唯一标识 |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "cpu": {
        "taint": 0,
        "total": 71500
    },
    "memory": {
        "taint": 0,
        "total": 156073795584
    },
    "node": {
        "notReady": 0,
        "taint": 0,
        "total": 5
    }
}
```

### 获取集群组件部署状态信息

#### 请求

GET-/v1/cluster/componentstatus

##### 路径参数

无

##### 请求头参数

| 参数名 | 描述  |
| --- | --- |
| clusterID | 可用区唯一标识 请求 |

#### 请求体

无

#### 响应

| Code | Description |
| --- | --- |
| 200 | OK  |

```json
{
    "alertmanager-fingerprint-webhook": "InProgress",
    "grafana": "Ready",
    "resources-counter-controller": "InProgress"
}
```


 

