### 创建路由

##### 请求

##### POST /v1/namespaces/{namespace}/routes

##### 路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### 查询参数

| 参数名 |                    描述                    |
| :----: | :----------------------------------------: |
|  zone  | 可用区唯一标识，当zone为空时表示默认可用区 |

##### 请求体参数

- 普通

```json
{
    "apiVersion": "route.openshift.io/v1", // 路由的API版本
    "kind": "Route", // 资源对象类型
    "metadata": {
        "labels": {
            "app": "dsp-yfopen"
        },
        "name": "dsp-yfopen",
        "namespace": "daocloudcsp",
    },
    "spec": {
        "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net", // 域名
        "to": { // 后端服务
            "kind": "Service", // 固定值
            "name": "dsp-yfopen", // 当前命名空间下的服务名
            "weight": 100 // 当不存在alternateBackends时，该值无用
        },
        "wildcardPolicy": "None"
    }
}
```

- 多版本蓝绿发布带TLS认证(根据我和晓东的了解，生产环境很少有使用多于2个版本的蓝绿)

```
{
    "apiVersion": "route.openshift.io/v1", // 路由的API版本
    "kind": "Route", // 资源对象类型
    "metadata": {
        "labels": {
            "app": "game2048"
        },
        "name": "demo",
        "namespace": "default",
    },
    "spec": {
        "alternateBackends": [ // 当需要按权重分配流量时，需要填写该字段
            {
                "kind": "Service", // 固定值 
                "name": "game2048-test", // 当前命名空间下的服务名
                "weight": 1 // 定义 该服务在总服务（alternateBackends + to ）的权重
            },
            {
                "kind": "Service", // 固定值 
                "name": "email-broker", // 当前命名空间下的服务名
                "weight": 1 // 定义 该服务在总服务（alternateBackends + to ）的权重
            }
        ],
        "host": "demo", // 定义访问域名
        "path": "/dsds", // 定义访问路径
        "port": {
            "targetPort": "80-tcp" // 服务端口
        },
        "tls": { // 配置路由的TLS证书，其值为证书内容
            "caCertificate": "-----BEGIN CERTIFICATE-----\nMIICzTCCAbWgAwIBAgIQRsrdx5MMtSHKfNlyX7JIizANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBAxDjAMBgNVBAoTBWRpanVuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC\nAQEAnub3vKSOBy/+8tPwRj0R2IuaccgeUABetDV3Mjlq8274kQJQ+u1g/aa6d0HD\nz6ZL7FsyKhKLonRw4fgR6htMWMuDt6AvxdSlnIRbllT3A+sLTvUpGAs5ooDPEB1o\nUGZyVSE8QvVPBAj+2yyrBLjkvJ7Yxk0hWRI9XPxAJNTjAmOO+wzU0Pxu14eiY0I8\n9B2KfKtUYM7gQMkqy7CW8YdJo5ra2yn498+r6YKscAPVXmsmhjxqVa59cLjA+iav\ngpmeKwcRI47YE69+h1tLqc6qDQmcdkxQ+OJgnIt6WosFvuEPyCgPxtSlLb2gw1j9\n6LrEgZUkId+I8Zb5TPdmj+2FNwIDAQABoyMwITAOBgNVHQ8BAf8EBAMCAqwwDwYD\nVR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAYBBT1uqQpnbjH67HoVW7\nVAHaCB1SSh+2tdVoJFvcl8h/GHzD2VWXI2Wy3WPpODklDVNw9NkKm4HmjY0sqc6X\nU2TpZVUGNLFIGyu16+5T+NiVLX0YoMxoMQzexT9nuz302mIoLoq7xj9+P+S9z3sq\nvZfuYFT0stwkmKANqzfggdMH9lienntUT361l9P9lYNj9ZmQqSnrFcOIdhdHYWlB\nciUzv7lotf84omzfQmfdbslBPEqSgtG6AyylZ7esjGrsM2JusK1nnOidi0bpRagU\ntFLC421NxD6Mi6tv25Tlh7Vt1T7QnBjeErWJ8JVrpc1r0OHN6Ia+PnwcAmBkZtYe\nJw==\n-----END CERTIFICATE-----\n",
            "certificate": "-----BEGIN CERTIFICATE-----\nMIIC6zCCAdOgAwIBAgIQOECWN0TcC2lxCzXuoLKChTANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBwxGjAYBgNVBAoMEWRpanVuLjxib290c3RyYXA+MIIBIjANBgkqhkiG9w0BAQEF\nAAOCAQ8AMIIBCgKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB\n+qp36lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8u\nbJTnTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA\n1OCw2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xu\nUjJwfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeft\nbauY6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABozUwMzAOBgNVHQ8B\nAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwIwDAYDVR0TAQH/BAIwADANBgkq\nhkiG9w0BAQsFAAOCAQEAFie0nDiWP3Pa3x+tntWAnfX1id6ne6xmr1cwvO7AeiX2\nQ9sxCguOQq/96dJzYoyGZQwoBmwuv77PpPq9Do01xGJzyk4PWIjNADRT4ik/NSZp\npYYtDrxe8gJDJNaNR33cgDQkrj+cfqPqdyJaK5EsgPCZqDxJla4Koabn4Ws8PzA/\nVW7M1niv3mUqv7m8HeG4YO62yEcjoDxYVTzdPnHmqUDqYSJhFVcnRhkv8Ox4+b1l\nfiswT+YivqPM3R64OXtAbi2ZTor7knbQclddnSIQXte2/GbDwi2BzvktnbAXepiI\n83waIT9IpAdHffuefGaYFkgMd2Af1om4pwLbE66+fA==\n-----END CERTIFICATE-----\n",
            "key": "-----BEGIN RSA PRIVATE KEY-----\nMIIEpQIBAAKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB+qp3\n6lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8ubJTn\nTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA1OCw\n2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xuUjJw\nfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeftbauY\n6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABAoIBAQCNJv7gv0qjsNEf\nCPeegJoMwyxYQfjPFgGa12lIdp2D+43SHbhUS2Oo+Tq88ZdmKE53KJRGW0gzBAc0\nfKxJvT+1OJHSz5qjtdlv8lk1xtCvWiuRH3I1RQDeUXjaK7m0MKmo+w1O6+Fh5ENa\ngAxuyIRwgos+6JOHJny50tHM+0EfKCzSpz/ck+2E1u7vB6uOCBaXO2xhPICNDYNF\nUNQG6PcQmiJDgSiaqNBvzZkR+7nXvo6CAaogpCXQUBxAlP+ry66mjxz61Hc/9QKM\nY7/lbl7+yt1YKVW61wquhFAeLM1AjAxJRTdvgstbczYxdLQbv85nxbXXbZZszny5\nfkkoWvAVAoGBANw4WCJ0I749RjlUSeJVkA1Mci1/yQEeNH+2r0Lh2SSE3cyWbFqG\nDazUb+OxXnuzItCPmctv1zKRPYQ5F8qKdyqefr5Np24YtaAx2p6I8S2RqdavReRs\nzJmJWgH1zR+QpDkVj4Z9RQv7iMWXOAbZQVRyTgsHdkYcnv8JfTWJPJ7PAoGBAN2/\nnH3sD6FPV3dhTvsVBM87CucHx1vQjaKo0U2ZRd1YLN2bT75Qzv3VVmRN9U94u4WG\n7DgyH+IGECkspOhZJq0WPphdWKdVhxb/sHudsrCFqDMWqD/mdjvYrTk9hUEhDo1a\nQsM0NP5VQOddWkMQhozwl69VRSkpEKd5ThTRqev7AoGBAMFDpX1fJXswNS/c3BaI\n9qnlHBL4IUQc6P/oKHlu0W0uOaTxolfza47wxN0zbPLsbDJSxCr4lQho1G701/9F\nc31wqVSDu9twTf0vo2gcUGSogD/LhHAKV6irFNXBjOoVuznpxRLHX1A7yHV315CT\nG7VrtzgQrWisd5DlGABi11ObAoGBAL0DNKsI6hG/hXiWkzHlqqHRW+utb7rNO80o\nRK/2M90F6chDOGeqjaVDkU4SPUUuTfj1FqiX4SFRtbjC+xWp2BO1YEmTV5vahTmP\nXKkhtExOwR4689Lz6Ff+yzh9PfZT7QmDpGCrQXiAxr/vjJ6ZmXbNJR4oerko7a8y\n8OFCDaq9AoGAE35E+Un/UiBpEIquB4jV0GBpH2GapWpqR1wOPEQxNDhcRD2MDK7p\n7rCxOQHIXpVmYd0sWywmqT0W4YSHHXcvFt+RnbAeXR5qJalZNCI6Rs0VeCS8YzCZ\nthKNQfMe+D/xLRHmfQ+/IfH7PjE5SUIahECq4kYGr42UvABfMcCUfMI=\n-----END RSA PRIVATE KEY-----\n",
            "termination": "edge"
        },
        "to": { // 后端服务
            "kind": "Service", // 固定值
            "name": "game2048", // 当前命名空间下的服务名
            "weight": 1 // 当不存在alternateBackends时，该值无用
        }
    }
}
```



##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "route.openshift.io/v1",
    "kind": "Route",
    "metadata": {
        "creationTimestamp": "2019-04-17T05:51:41Z",
        "labels": {
            "app": "dsp-yfopen"
        },
        "name": "dsp-yfopen",
        "namespace": "daocloudcsp",
        "resourceVersion": "6961941",
        "selfLink": "/apis/route.openshift.io/v1/namespaces/daocloudcsp/routes/dsp-yfopen",
        "uid": "dfe43cc1-60d4-11e9-83af-005056b595d6"
    },
    "spec": {
        "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
        "tls": {
            "caCertificate": "-----BEGIN CERTIFICATE-----\nMIICzTCCAbWgAwIBAgIQRsrdx5MMtSHKfNlyX7JIizANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBAxDjAMBgNVBAoTBWRpanVuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC\nAQEAnub3vKSOBy/+8tPwRj0R2IuaccgeUABetDV3Mjlq8274kQJQ+u1g/aa6d0HD\nz6ZL7FsyKhKLonRw4fgR6htMWMuDt6AvxdSlnIRbllT3A+sLTvUpGAs5ooDPEB1o\nUGZyVSE8QvVPBAj+2yyrBLjkvJ7Yxk0hWRI9XPxAJNTjAmOO+wzU0Pxu14eiY0I8\n9B2KfKtUYM7gQMkqy7CW8YdJo5ra2yn498+r6YKscAPVXmsmhjxqVa59cLjA+iav\ngpmeKwcRI47YE69+h1tLqc6qDQmcdkxQ+OJgnIt6WosFvuEPyCgPxtSlLb2gw1j9\n6LrEgZUkId+I8Zb5TPdmj+2FNwIDAQABoyMwITAOBgNVHQ8BAf8EBAMCAqwwDwYD\nVR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAYBBT1uqQpnbjH67HoVW7\nVAHaCB1SSh+2tdVoJFvcl8h/GHzD2VWXI2Wy3WPpODklDVNw9NkKm4HmjY0sqc6X\nU2TpZVUGNLFIGyu16+5T+NiVLX0YoMxoMQzexT9nuz302mIoLoq7xj9+P+S9z3sq\nvZfuYFT0stwkmKANqzfggdMH9lienntUT361l9P9lYNj9ZmQqSnrFcOIdhdHYWlB\nciUzv7lotf84omzfQmfdbslBPEqSgtG6AyylZ7esjGrsM2JusK1nnOidi0bpRagU\ntFLC421NxD6Mi6tv25Tlh7Vt1T7QnBjeErWJ8JVrpc1r0OHN6Ia+PnwcAmBkZtYe\nJw==\n-----END CERTIFICATE-----\n",
            "certificate": "-----BEGIN CERTIFICATE-----\nMIIC6zCCAdOgAwIBAgIQOECWN0TcC2lxCzXuoLKChTANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBwxGjAYBgNVBAoMEWRpanVuLjxib290c3RyYXA+MIIBIjANBgkqhkiG9w0BAQEF\nAAOCAQ8AMIIBCgKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB\n+qp36lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8u\nbJTnTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA\n1OCw2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xu\nUjJwfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeft\nbauY6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABozUwMzAOBgNVHQ8B\nAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwIwDAYDVR0TAQH/BAIwADANBgkq\nhkiG9w0BAQsFAAOCAQEAFie0nDiWP3Pa3x+tntWAnfX1id6ne6xmr1cwvO7AeiX2\nQ9sxCguOQq/96dJzYoyGZQwoBmwuv77PpPq9Do01xGJzyk4PWIjNADRT4ik/NSZp\npYYtDrxe8gJDJNaNR33cgDQkrj+cfqPqdyJaK5EsgPCZqDxJla4Koabn4Ws8PzA/\nVW7M1niv3mUqv7m8HeG4YO62yEcjoDxYVTzdPnHmqUDqYSJhFVcnRhkv8Ox4+b1l\nfiswT+YivqPM3R64OXtAbi2ZTor7knbQclddnSIQXte2/GbDwi2BzvktnbAXepiI\n83waIT9IpAdHffuefGaYFkgMd2Af1om4pwLbE66+fA==\n-----END CERTIFICATE-----\n",
            "key": "-----BEGIN RSA PRIVATE KEY-----\nMIIEpQIBAAKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB+qp3\n6lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8ubJTn\nTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA1OCw\n2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xuUjJw\nfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeftbauY\n6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABAoIBAQCNJv7gv0qjsNEf\nCPeegJoMwyxYQfjPFgGa12lIdp2D+43SHbhUS2Oo+Tq88ZdmKE53KJRGW0gzBAc0\nfKxJvT+1OJHSz5qjtdlv8lk1xtCvWiuRH3I1RQDeUXjaK7m0MKmo+w1O6+Fh5ENa\ngAxuyIRwgos+6JOHJny50tHM+0EfKCzSpz/ck+2E1u7vB6uOCBaXO2xhPICNDYNF\nUNQG6PcQmiJDgSiaqNBvzZkR+7nXvo6CAaogpCXQUBxAlP+ry66mjxz61Hc/9QKM\nY7/lbl7+yt1YKVW61wquhFAeLM1AjAxJRTdvgstbczYxdLQbv85nxbXXbZZszny5\nfkkoWvAVAoGBANw4WCJ0I749RjlUSeJVkA1Mci1/yQEeNH+2r0Lh2SSE3cyWbFqG\nDazUb+OxXnuzItCPmctv1zKRPYQ5F8qKdyqefr5Np24YtaAx2p6I8S2RqdavReRs\nzJmJWgH1zR+QpDkVj4Z9RQv7iMWXOAbZQVRyTgsHdkYcnv8JfTWJPJ7PAoGBAN2/\nnH3sD6FPV3dhTvsVBM87CucHx1vQjaKo0U2ZRd1YLN2bT75Qzv3VVmRN9U94u4WG\n7DgyH+IGECkspOhZJq0WPphdWKdVhxb/sHudsrCFqDMWqD/mdjvYrTk9hUEhDo1a\nQsM0NP5VQOddWkMQhozwl69VRSkpEKd5ThTRqev7AoGBAMFDpX1fJXswNS/c3BaI\n9qnlHBL4IUQc6P/oKHlu0W0uOaTxolfza47wxN0zbPLsbDJSxCr4lQho1G701/9F\nc31wqVSDu9twTf0vo2gcUGSogD/LhHAKV6irFNXBjOoVuznpxRLHX1A7yHV315CT\nG7VrtzgQrWisd5DlGABi11ObAoGBAL0DNKsI6hG/hXiWkzHlqqHRW+utb7rNO80o\nRK/2M90F6chDOGeqjaVDkU4SPUUuTfj1FqiX4SFRtbjC+xWp2BO1YEmTV5vahTmP\nXKkhtExOwR4689Lz6Ff+yzh9PfZT7QmDpGCrQXiAxr/vjJ6ZmXbNJR4oerko7a8y\n8OFCDaq9AoGAE35E+Un/UiBpEIquB4jV0GBpH2GapWpqR1wOPEQxNDhcRD2MDK7p\n7rCxOQHIXpVmYd0sWywmqT0W4YSHHXcvFt+RnbAeXR5qJalZNCI6Rs0VeCS8YzCZ\nthKNQfMe+D/xLRHmfQ+/IfH7PjE5SUIahECq4kYGr42UvABfMcCUfMI=\n-----END RSA PRIVATE KEY-----\n",
            "termination": "edge"
        },
        "to": {
            "kind": "Service",
            "name": "dsp-yfopen",
            "weight": 100
        },
        "wildcardPolicy": "None"
    },
    "status": {
        "ingress": [
            {
                "conditions": [
                    {
                        "lastTransitionTime": "2019-04-17T05:51:41Z",
                        "status": "True",
                        "type": "Admitted"
                    }
                ],
                "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
                "routerName": "router",
                "wildcardPolicy": "None"
            }
        ]
    }
}
```

### 更新路由

##### 请求 

##### PUT /v1/namespaces/{namespace}/routes

##### 路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### 查询参数

| 参数名 |                    描述                    |
| :----: | :----------------------------------------: |
|  zone  | 可用区唯一标识，当zone为空时表示默认可用区 |

##### 请求体参数

```json
{
    "apiVersion": "route.openshift.io/v1",
    "kind": "Route",
    "metadata": {
        "creationTimestamp": "2019-04-17T05:51:41Z",
        "labels": {
            "app": "dsp-yfopen"
        },
        "name": "dsp-yfopen",
        "namespace": "daocloudcsp",
        "resourceVersion": "6961941",
        "selfLink": "/apis/route.openshift.io/v1/namespaces/daocloudcsp/routes/dsp-yfopen",
        "uid": "dfe43cc1-60d4-11e9-83af-005056b595d6"
    },
    "spec": {
        "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
        "tls": {
            "caCertificate": "-----BEGIN CERTIFICATE-----\nMIICzTCCAbWgAwIBAgIQRsrdx5MMtSHKfNlyX7JIizANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBAxDjAMBgNVBAoTBWRpanVuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC\nAQEAnub3vKSOBy/+8tPwRj0R2IuaccgeUABetDV3Mjlq8274kQJQ+u1g/aa6d0HD\nz6ZL7FsyKhKLonRw4fgR6htMWMuDt6AvxdSlnIRbllT3A+sLTvUpGAs5ooDPEB1o\nUGZyVSE8QvVPBAj+2yyrBLjkvJ7Yxk0hWRI9XPxAJNTjAmOO+wzU0Pxu14eiY0I8\n9B2KfKtUYM7gQMkqy7CW8YdJo5ra2yn498+r6YKscAPVXmsmhjxqVa59cLjA+iav\ngpmeKwcRI47YE69+h1tLqc6qDQmcdkxQ+OJgnIt6WosFvuEPyCgPxtSlLb2gw1j9\n6LrEgZUkId+I8Zb5TPdmj+2FNwIDAQABoyMwITAOBgNVHQ8BAf8EBAMCAqwwDwYD\nVR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAYBBT1uqQpnbjH67HoVW7\nVAHaCB1SSh+2tdVoJFvcl8h/GHzD2VWXI2Wy3WPpODklDVNw9NkKm4HmjY0sqc6X\nU2TpZVUGNLFIGyu16+5T+NiVLX0YoMxoMQzexT9nuz302mIoLoq7xj9+P+S9z3sq\nvZfuYFT0stwkmKANqzfggdMH9lienntUT361l9P9lYNj9ZmQqSnrFcOIdhdHYWlB\nciUzv7lotf84omzfQmfdbslBPEqSgtG6AyylZ7esjGrsM2JusK1nnOidi0bpRagU\ntFLC421NxD6Mi6tv25Tlh7Vt1T7QnBjeErWJ8JVrpc1r0OHN6Ia+PnwcAmBkZtYe\nJw==\n-----END CERTIFICATE-----\n",
            "certificate": "-----BEGIN CERTIFICATE-----\nMIIC6zCCAdOgAwIBAgIQOECWN0TcC2lxCzXuoLKChTANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBwxGjAYBgNVBAoMEWRpanVuLjxib290c3RyYXA+MIIBIjANBgkqhkiG9w0BAQEF\nAAOCAQ8AMIIBCgKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB\n+qp36lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8u\nbJTnTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA\n1OCw2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xu\nUjJwfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeft\nbauY6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABozUwMzAOBgNVHQ8B\nAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwIwDAYDVR0TAQH/BAIwADANBgkq\nhkiG9w0BAQsFAAOCAQEAFie0nDiWP3Pa3x+tntWAnfX1id6ne6xmr1cwvO7AeiX2\nQ9sxCguOQq/96dJzYoyGZQwoBmwuv77PpPq9Do01xGJzyk4PWIjNADRT4ik/NSZp\npYYtDrxe8gJDJNaNR33cgDQkrj+cfqPqdyJaK5EsgPCZqDxJla4Koabn4Ws8PzA/\nVW7M1niv3mUqv7m8HeG4YO62yEcjoDxYVTzdPnHmqUDqYSJhFVcnRhkv8Ox4+b1l\nfiswT+YivqPM3R64OXtAbi2ZTor7knbQclddnSIQXte2/GbDwi2BzvktnbAXepiI\n83waIT9IpAdHffuefGaYFkgMd2Af1om4pwLbE66+fA==\n-----END CERTIFICATE-----\n",
            "key": "-----BEGIN RSA PRIVATE KEY-----\nMIIEpQIBAAKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB+qp3\n6lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8ubJTn\nTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA1OCw\n2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xuUjJw\nfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeftbauY\n6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABAoIBAQCNJv7gv0qjsNEf\nCPeegJoMwyxYQfjPFgGa12lIdp2D+43SHbhUS2Oo+Tq88ZdmKE53KJRGW0gzBAc0\nfKxJvT+1OJHSz5qjtdlv8lk1xtCvWiuRH3I1RQDeUXjaK7m0MKmo+w1O6+Fh5ENa\ngAxuyIRwgos+6JOHJny50tHM+0EfKCzSpz/ck+2E1u7vB6uOCBaXO2xhPICNDYNF\nUNQG6PcQmiJDgSiaqNBvzZkR+7nXvo6CAaogpCXQUBxAlP+ry66mjxz61Hc/9QKM\nY7/lbl7+yt1YKVW61wquhFAeLM1AjAxJRTdvgstbczYxdLQbv85nxbXXbZZszny5\nfkkoWvAVAoGBANw4WCJ0I749RjlUSeJVkA1Mci1/yQEeNH+2r0Lh2SSE3cyWbFqG\nDazUb+OxXnuzItCPmctv1zKRPYQ5F8qKdyqefr5Np24YtaAx2p6I8S2RqdavReRs\nzJmJWgH1zR+QpDkVj4Z9RQv7iMWXOAbZQVRyTgsHdkYcnv8JfTWJPJ7PAoGBAN2/\nnH3sD6FPV3dhTvsVBM87CucHx1vQjaKo0U2ZRd1YLN2bT75Qzv3VVmRN9U94u4WG\n7DgyH+IGECkspOhZJq0WPphdWKdVhxb/sHudsrCFqDMWqD/mdjvYrTk9hUEhDo1a\nQsM0NP5VQOddWkMQhozwl69VRSkpEKd5ThTRqev7AoGBAMFDpX1fJXswNS/c3BaI\n9qnlHBL4IUQc6P/oKHlu0W0uOaTxolfza47wxN0zbPLsbDJSxCr4lQho1G701/9F\nc31wqVSDu9twTf0vo2gcUGSogD/LhHAKV6irFNXBjOoVuznpxRLHX1A7yHV315CT\nG7VrtzgQrWisd5DlGABi11ObAoGBAL0DNKsI6hG/hXiWkzHlqqHRW+utb7rNO80o\nRK/2M90F6chDOGeqjaVDkU4SPUUuTfj1FqiX4SFRtbjC+xWp2BO1YEmTV5vahTmP\nXKkhtExOwR4689Lz6Ff+yzh9PfZT7QmDpGCrQXiAxr/vjJ6ZmXbNJR4oerko7a8y\n8OFCDaq9AoGAE35E+Un/UiBpEIquB4jV0GBpH2GapWpqR1wOPEQxNDhcRD2MDK7p\n7rCxOQHIXpVmYd0sWywmqT0W4YSHHXcvFt+RnbAeXR5qJalZNCI6Rs0VeCS8YzCZ\nthKNQfMe+D/xLRHmfQ+/IfH7PjE5SUIahECq4kYGr42UvABfMcCUfMI=\n-----END RSA PRIVATE KEY-----\n",
            "termination": "edge"
        },
        "to": {
            "kind": "Service",
            "name": "dsp-yfopen",
            "weight": 100
        },
        "wildcardPolicy": "None"
    },
    "status": {
        "ingress": [
            {
                "conditions": [
                    {
                        "lastTransitionTime": "2019-04-17T05:51:41Z",
                        "status": "True",
                        "type": "Admitted"
                    }
                ],
                "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
                "routerName": "router",
                "wildcardPolicy": "None"
            }
        ]
    }
}
```



##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "route.openshift.io/v1",
    "kind": "Route",
    "metadata": {
        "creationTimestamp": "2019-04-17T05:51:41Z",
        "labels": {
            "app": "dsp-yfopen"
        },
        "name": "dsp-yfopen",
        "namespace": "daocloudcsp",
        "resourceVersion": "6961941",
        "selfLink": "/apis/route.openshift.io/v1/namespaces/daocloudcsp/routes/dsp-yfopen",
        "uid": "dfe43cc1-60d4-11e9-83af-005056b595d6"
    },
    "spec": {
        "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
        "tls": {
            "caCertificate": "-----BEGIN CERTIFICATE-----\nMIICzTCCAbWgAwIBAgIQRsrdx5MMtSHKfNlyX7JIizANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBAxDjAMBgNVBAoTBWRpanVuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC\nAQEAnub3vKSOBy/+8tPwRj0R2IuaccgeUABetDV3Mjlq8274kQJQ+u1g/aa6d0HD\nz6ZL7FsyKhKLonRw4fgR6htMWMuDt6AvxdSlnIRbllT3A+sLTvUpGAs5ooDPEB1o\nUGZyVSE8QvVPBAj+2yyrBLjkvJ7Yxk0hWRI9XPxAJNTjAmOO+wzU0Pxu14eiY0I8\n9B2KfKtUYM7gQMkqy7CW8YdJo5ra2yn498+r6YKscAPVXmsmhjxqVa59cLjA+iav\ngpmeKwcRI47YE69+h1tLqc6qDQmcdkxQ+OJgnIt6WosFvuEPyCgPxtSlLb2gw1j9\n6LrEgZUkId+I8Zb5TPdmj+2FNwIDAQABoyMwITAOBgNVHQ8BAf8EBAMCAqwwDwYD\nVR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAYBBT1uqQpnbjH67HoVW7\nVAHaCB1SSh+2tdVoJFvcl8h/GHzD2VWXI2Wy3WPpODklDVNw9NkKm4HmjY0sqc6X\nU2TpZVUGNLFIGyu16+5T+NiVLX0YoMxoMQzexT9nuz302mIoLoq7xj9+P+S9z3sq\nvZfuYFT0stwkmKANqzfggdMH9lienntUT361l9P9lYNj9ZmQqSnrFcOIdhdHYWlB\nciUzv7lotf84omzfQmfdbslBPEqSgtG6AyylZ7esjGrsM2JusK1nnOidi0bpRagU\ntFLC421NxD6Mi6tv25Tlh7Vt1T7QnBjeErWJ8JVrpc1r0OHN6Ia+PnwcAmBkZtYe\nJw==\n-----END CERTIFICATE-----\n",
            "certificate": "-----BEGIN CERTIFICATE-----\nMIIC6zCCAdOgAwIBAgIQOECWN0TcC2lxCzXuoLKChTANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBwxGjAYBgNVBAoMEWRpanVuLjxib290c3RyYXA+MIIBIjANBgkqhkiG9w0BAQEF\nAAOCAQ8AMIIBCgKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB\n+qp36lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8u\nbJTnTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA\n1OCw2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xu\nUjJwfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeft\nbauY6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABozUwMzAOBgNVHQ8B\nAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwIwDAYDVR0TAQH/BAIwADANBgkq\nhkiG9w0BAQsFAAOCAQEAFie0nDiWP3Pa3x+tntWAnfX1id6ne6xmr1cwvO7AeiX2\nQ9sxCguOQq/96dJzYoyGZQwoBmwuv77PpPq9Do01xGJzyk4PWIjNADRT4ik/NSZp\npYYtDrxe8gJDJNaNR33cgDQkrj+cfqPqdyJaK5EsgPCZqDxJla4Koabn4Ws8PzA/\nVW7M1niv3mUqv7m8HeG4YO62yEcjoDxYVTzdPnHmqUDqYSJhFVcnRhkv8Ox4+b1l\nfiswT+YivqPM3R64OXtAbi2ZTor7knbQclddnSIQXte2/GbDwi2BzvktnbAXepiI\n83waIT9IpAdHffuefGaYFkgMd2Af1om4pwLbE66+fA==\n-----END CERTIFICATE-----\n",
            "key": "-----BEGIN RSA PRIVATE KEY-----\nMIIEpQIBAAKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB+qp3\n6lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8ubJTn\nTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA1OCw\n2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xuUjJw\nfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeftbauY\n6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABAoIBAQCNJv7gv0qjsNEf\nCPeegJoMwyxYQfjPFgGa12lIdp2D+43SHbhUS2Oo+Tq88ZdmKE53KJRGW0gzBAc0\nfKxJvT+1OJHSz5qjtdlv8lk1xtCvWiuRH3I1RQDeUXjaK7m0MKmo+w1O6+Fh5ENa\ngAxuyIRwgos+6JOHJny50tHM+0EfKCzSpz/ck+2E1u7vB6uOCBaXO2xhPICNDYNF\nUNQG6PcQmiJDgSiaqNBvzZkR+7nXvo6CAaogpCXQUBxAlP+ry66mjxz61Hc/9QKM\nY7/lbl7+yt1YKVW61wquhFAeLM1AjAxJRTdvgstbczYxdLQbv85nxbXXbZZszny5\nfkkoWvAVAoGBANw4WCJ0I749RjlUSeJVkA1Mci1/yQEeNH+2r0Lh2SSE3cyWbFqG\nDazUb+OxXnuzItCPmctv1zKRPYQ5F8qKdyqefr5Np24YtaAx2p6I8S2RqdavReRs\nzJmJWgH1zR+QpDkVj4Z9RQv7iMWXOAbZQVRyTgsHdkYcnv8JfTWJPJ7PAoGBAN2/\nnH3sD6FPV3dhTvsVBM87CucHx1vQjaKo0U2ZRd1YLN2bT75Qzv3VVmRN9U94u4WG\n7DgyH+IGECkspOhZJq0WPphdWKdVhxb/sHudsrCFqDMWqD/mdjvYrTk9hUEhDo1a\nQsM0NP5VQOddWkMQhozwl69VRSkpEKd5ThTRqev7AoGBAMFDpX1fJXswNS/c3BaI\n9qnlHBL4IUQc6P/oKHlu0W0uOaTxolfza47wxN0zbPLsbDJSxCr4lQho1G701/9F\nc31wqVSDu9twTf0vo2gcUGSogD/LhHAKV6irFNXBjOoVuznpxRLHX1A7yHV315CT\nG7VrtzgQrWisd5DlGABi11ObAoGBAL0DNKsI6hG/hXiWkzHlqqHRW+utb7rNO80o\nRK/2M90F6chDOGeqjaVDkU4SPUUuTfj1FqiX4SFRtbjC+xWp2BO1YEmTV5vahTmP\nXKkhtExOwR4689Lz6Ff+yzh9PfZT7QmDpGCrQXiAxr/vjJ6ZmXbNJR4oerko7a8y\n8OFCDaq9AoGAE35E+Un/UiBpEIquB4jV0GBpH2GapWpqR1wOPEQxNDhcRD2MDK7p\n7rCxOQHIXpVmYd0sWywmqT0W4YSHHXcvFt+RnbAeXR5qJalZNCI6Rs0VeCS8YzCZ\nthKNQfMe+D/xLRHmfQ+/IfH7PjE5SUIahECq4kYGr42UvABfMcCUfMI=\n-----END RSA PRIVATE KEY-----\n",
            "termination": "edge"
        },
        "to": {
            "kind": "Service",
            "name": "dsp-yfopen",
            "weight": 100
        },
        "wildcardPolicy": "None"
    },
    "status": {
        "ingress": [
            {
                "conditions": [
                    {
                        "lastTransitionTime": "2019-04-17T05:51:41Z",
                        "status": "True",
                        "type": "Admitted"
                    }
                ],
                "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
                "routerName": "router",
                "wildcardPolicy": "None"
            }
        ]
    }
}
```

### 获取路由

##### 请求 

##### GET /v1/namespaces/{namespace}/routes/{name}

##### 路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | 路由名称 |

##### 查询参数

| 参数名 |                    描述                    |
| :----: | :----------------------------------------: |
|  zone  | 可用区唯一标识，当zone为空时表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "route.openshift.io/v1",
    "kind": "Route",
    "metadata": {
        "creationTimestamp": "2019-04-17T05:51:41Z",
        "labels": {
            "app": "dsp-yfopen"
        },
        "name": "dsp-yfopen",
        "namespace": "daocloudcsp",
        "resourceVersion": "6961941",
        "selfLink": "/apis/route.openshift.io/v1/namespaces/daocloudcsp/routes/dsp-yfopen",
        "uid": "dfe43cc1-60d4-11e9-83af-005056b595d6"
    },
    "spec": {
        "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
        "tls": {
            "caCertificate": "-----BEGIN CERTIFICATE-----\nMIICzTCCAbWgAwIBAgIQRsrdx5MMtSHKfNlyX7JIizANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBAxDjAMBgNVBAoTBWRpanVuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC\nAQEAnub3vKSOBy/+8tPwRj0R2IuaccgeUABetDV3Mjlq8274kQJQ+u1g/aa6d0HD\nz6ZL7FsyKhKLonRw4fgR6htMWMuDt6AvxdSlnIRbllT3A+sLTvUpGAs5ooDPEB1o\nUGZyVSE8QvVPBAj+2yyrBLjkvJ7Yxk0hWRI9XPxAJNTjAmOO+wzU0Pxu14eiY0I8\n9B2KfKtUYM7gQMkqy7CW8YdJo5ra2yn498+r6YKscAPVXmsmhjxqVa59cLjA+iav\ngpmeKwcRI47YE69+h1tLqc6qDQmcdkxQ+OJgnIt6WosFvuEPyCgPxtSlLb2gw1j9\n6LrEgZUkId+I8Zb5TPdmj+2FNwIDAQABoyMwITAOBgNVHQ8BAf8EBAMCAqwwDwYD\nVR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAYBBT1uqQpnbjH67HoVW7\nVAHaCB1SSh+2tdVoJFvcl8h/GHzD2VWXI2Wy3WPpODklDVNw9NkKm4HmjY0sqc6X\nU2TpZVUGNLFIGyu16+5T+NiVLX0YoMxoMQzexT9nuz302mIoLoq7xj9+P+S9z3sq\nvZfuYFT0stwkmKANqzfggdMH9lienntUT361l9P9lYNj9ZmQqSnrFcOIdhdHYWlB\nciUzv7lotf84omzfQmfdbslBPEqSgtG6AyylZ7esjGrsM2JusK1nnOidi0bpRagU\ntFLC421NxD6Mi6tv25Tlh7Vt1T7QnBjeErWJ8JVrpc1r0OHN6Ia+PnwcAmBkZtYe\nJw==\n-----END CERTIFICATE-----\n",
            "certificate": "-----BEGIN CERTIFICATE-----\nMIIC6zCCAdOgAwIBAgIQOECWN0TcC2lxCzXuoLKChTANBgkqhkiG9w0BAQsFADAQ\nMQ4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBwxGjAYBgNVBAoMEWRpanVuLjxib290c3RyYXA+MIIBIjANBgkqhkiG9w0BAQEF\nAAOCAQ8AMIIBCgKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB\n+qp36lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8u\nbJTnTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA\n1OCw2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xu\nUjJwfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeft\nbauY6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABozUwMzAOBgNVHQ8B\nAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwIwDAYDVR0TAQH/BAIwADANBgkq\nhkiG9w0BAQsFAAOCAQEAFie0nDiWP3Pa3x+tntWAnfX1id6ne6xmr1cwvO7AeiX2\nQ9sxCguOQq/96dJzYoyGZQwoBmwuv77PpPq9Do01xGJzyk4PWIjNADRT4ik/NSZp\npYYtDrxe8gJDJNaNR33cgDQkrj+cfqPqdyJaK5EsgPCZqDxJla4Koabn4Ws8PzA/\nVW7M1niv3mUqv7m8HeG4YO62yEcjoDxYVTzdPnHmqUDqYSJhFVcnRhkv8Ox4+b1l\nfiswT+YivqPM3R64OXtAbi2ZTor7knbQclddnSIQXte2/GbDwi2BzvktnbAXepiI\n83waIT9IpAdHffuefGaYFkgMd2Af1om4pwLbE66+fA==\n-----END CERTIFICATE-----\n",
            "key": "-----BEGIN RSA PRIVATE KEY-----\nMIIEpQIBAAKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB+qp3\n6lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8ubJTn\nTcfFGuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA1OCw\n2FN64HvyReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xuUjJw\nfuNrQHW96de/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeftbauY\n6CwtB+e0kjApjlQpnthZZnVJta1rlnlQCd659QIDAQABAoIBAQCNJv7gv0qjsNEf\nCPeegJoMwyxYQfjPFgGa12lIdp2D+43SHbhUS2Oo+Tq88ZdmKE53KJRGW0gzBAc0\nfKxJvT+1OJHSz5qjtdlv8lk1xtCvWiuRH3I1RQDeUXjaK7m0MKmo+w1O6+Fh5ENa\ngAxuyIRwgos+6JOHJny50tHM+0EfKCzSpz/ck+2E1u7vB6uOCBaXO2xhPICNDYNF\nUNQG6PcQmiJDgSiaqNBvzZkR+7nXvo6CAaogpCXQUBxAlP+ry66mjxz61Hc/9QKM\nY7/lbl7+yt1YKVW61wquhFAeLM1AjAxJRTdvgstbczYxdLQbv85nxbXXbZZszny5\nfkkoWvAVAoGBANw4WCJ0I749RjlUSeJVkA1Mci1/yQEeNH+2r0Lh2SSE3cyWbFqG\nDazUb+OxXnuzItCPmctv1zKRPYQ5F8qKdyqefr5Np24YtaAx2p6I8S2RqdavReRs\nzJmJWgH1zR+QpDkVj4Z9RQv7iMWXOAbZQVRyTgsHdkYcnv8JfTWJPJ7PAoGBAN2/\nnH3sD6FPV3dhTvsVBM87CucHx1vQjaKo0U2ZRd1YLN2bT75Qzv3VVmRN9U94u4WG\n7DgyH+IGECkspOhZJq0WPphdWKdVhxb/sHudsrCFqDMWqD/mdjvYrTk9hUEhDo1a\nQsM0NP5VQOddWkMQhozwl69VRSkpEKd5ThTRqev7AoGBAMFDpX1fJXswNS/c3BaI\n9qnlHBL4IUQc6P/oKHlu0W0uOaTxolfza47wxN0zbPLsbDJSxCr4lQho1G701/9F\nc31wqVSDu9twTf0vo2gcUGSogD/LhHAKV6irFNXBjOoVuznpxRLHX1A7yHV315CT\nG7VrtzgQrWisd5DlGABi11ObAoGBAL0DNKsI6hG/hXiWkzHlqqHRW+utb7rNO80o\nRK/2M90F6chDOGeqjaVDkU4SPUUuTfj1FqiX4SFRtbjC+xWp2BO1YEmTV5vahTmP\nXKkhtExOwR4689Lz6Ff+yzh9PfZT7QmDpGCrQXiAxr/vjJ6ZmXbNJR4oerko7a8y\n8OFCDaq9AoGAE35E+Un/UiBpEIquB4jV0GBpH2GapWpqR1wOPEQxNDhcRD2MDK7p\n7rCxOQHIXpVmYd0sWywmqT0W4YSHHXcvFt+RnbAeXR5qJalZNCI6Rs0VeCS8YzCZ\nthKNQfMe+D/xLRHmfQ+/IfH7PjE5SUIahECq4kYGr42UvABfMcCUfMI=\n-----END RSA PRIVATE KEY-----\n",
            "termination": "edge"
        },
        "to": {
            "kind": "Service",
            "name": "dsp-yfopen",
            "weight": 100
        },
        "wildcardPolicy": "None"
    },
    "status": {
        "ingress": [
            {
                "conditions": [
                    {
                        "lastTransitionTime": "2019-04-17T05:51:41Z",
                        "status": "True",
                        "type": "Admitted"
                    }
                ],
                "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
                "routerName": "router",
                "wildcardPolicy": "None"
            }
        ]
    }
}
```

### 获取路由的Pods列表

##### 请求 

##### GET /v1/namespaces/{namespace}/routes/{name}/pods

##### 路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | 路由名称 |

##### 查询参数

| 参数名 |                    描述                    |
| :----: | :----------------------------------------: |
|  zone  | 可用区唯一标识，当zone为空时表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
[
    {
        "kind": "Pod",
        "apiVersion": "v1",
        "metadata": {
            "name": "kubernetes-dashboard-88ffc9487-ptjhw",
            "generateName": "kubernetes-dashboard-88ffc9487-",
            "namespace": "kube-system",
            "selfLink": "/api/v1/namespaces/kube-system/pods/kubernetes-dashboard-88ffc9487-ptjhw",
            "uid": "c5e0e27b-eee4-4dce-a6fc-f5e392dd1b1e",
            "resourceVersion": "3600",
            "creationTimestamp": "2019-08-15T08:04:01Z",
            "labels": {
                "k8s-app": "kubernetes-dashboard",
                "pod-template-hash": "88ffc9487"
            },
            "annotations": {
                "cni.projectcalico.org/podIP": "10.244.174.193/32"
            },
            "ownerReferences": [
                {
                    "apiVersion": "apps/v1",
                    "kind": "ReplicaSet",
                    "name": "kubernetes-dashboard-88ffc9487",
                    "uid": "3335fe93-8c13-4913-84a8-cfa7fdb992f8",
                    "controller": true,
                    "blockOwnerDeletion": true
                }
            ]
        },
        "spec": {
            "volumes": [
                {
                    "name": "kubernetes-dashboard-certs",
                    "secret": {
                        "secretName": "kubernetes-dashboard-certs",
                        "defaultMode": 420
                    }
                },
                {
                    "name": "tmp-volume",
                    "emptyDir": {}
                },
                {
                    "name": "kubernetes-dashboard-token-dd8r6",
                    "secret": {
                        "secretName": "kubernetes-dashboard-token-dd8r6",
                        "defaultMode": 420
                    }
                }
            ],
            "containers": [
                {
                    "name": "kubernetes-dashboard",
                    "image": "harbor.k8s.dsp.local/k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1",
                    "args": [
                        "--auto-generate-certificates"
                    ],
                    "ports": [
                        {
                            "containerPort": 8443,
                            "protocol": "TCP"
                        }
                    ],
                    "resources": {},
                    "volumeMounts": [
                        {
                            "name": "kubernetes-dashboard-certs",
                            "mountPath": "/certs"
                        },
                        {
                            "name": "tmp-volume",
                            "mountPath": "/tmp"
                        },
                        {
                            "name": "kubernetes-dashboard-token-dd8r6",
                            "readOnly": true,
                            "mountPath": "/var/run/secrets/kubernetes.io/serviceaccount"
                        }
                    ],
                    "livenessProbe": {
                        "httpGet": {
                            "path": "/",
                            "port": 8443,
                            "scheme": "HTTPS"
                        },
                        "initialDelaySeconds": 30,
                        "timeoutSeconds": 30,
                        "periodSeconds": 10,
                        "successThreshold": 1,
                        "failureThreshold": 3
                    },
                    "terminationMessagePath": "/dev/termination-log",
                    "terminationMessagePolicy": "File",
                    "imagePullPolicy": "IfNotPresent"
                }
            ],
            "restartPolicy": "Always",
            "terminationGracePeriodSeconds": 30,
            "dnsPolicy": "ClusterFirst",
            "serviceAccountName": "kubernetes-dashboard",
            "serviceAccount": "kubernetes-dashboard",
            "nodeName": "k8s-node-03.k8s.dsp.local",
            "securityContext": {},
            "schedulerName": "default-scheduler",
            "tolerations": [
                {
                    "key": "node-role.kubernetes.io/master",
                    "effect": "NoSchedule"
                },
                {
                    "key": "node.kubernetes.io/not-ready",
                    "operator": "Exists",
                    "effect": "NoExecute",
                    "tolerationSeconds": 300
                },
                {
                    "key": "node.kubernetes.io/unreachable",
                    "operator": "Exists",
                    "effect": "NoExecute",
                    "tolerationSeconds": 300
                }
            ],
            "priority": 0
        },
        "status": {
            "phase": "Running",
            "conditions": [
                {
                    "type": "Initialized",
                    "status": "True",
                    "lastProbeTime": null,
                    "lastTransitionTime": "2019-08-15T08:04:01Z"
                },
                {
                    "type": "Ready",
                    "status": "True",
                    "lastProbeTime": null,
                    "lastTransitionTime": "2019-08-15T08:04:06Z"
                },
                {
                    "type": "ContainersReady",
                    "status": "True",
                    "lastProbeTime": null,
                    "lastTransitionTime": "2019-08-15T08:04:06Z"
                },
                {
                    "type": "PodScheduled",
                    "status": "True",
                    "lastProbeTime": null,
                    "lastTransitionTime": "2019-08-15T08:04:01Z"
                }
            ],
            "hostIP": "192.168.120.12",
            "podIP": "10.244.174.193",
            "startTime": "2019-08-15T08:04:01Z",
            "containerStatuses": [
                {
                    "name": "kubernetes-dashboard",
                    "state": {
                        "running": {
                            "startedAt": "2019-08-15T08:04:06Z"
                        }
                    },
                    "lastState": {},
                    "ready": true,
                    "restartCount": 0,
                    "image": "harbor.k8s.dsp.local/k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1",
                    "imageID": "docker-pullable://harbor.k8s.dsp.local/k8s.gcr.io/kubernetes-dashboard-amd64@sha256:0ae6b69432e78069c5ce2bcde0fe409c5c4d6f0f4d9cd50a17974fea38898747",
                    "containerID": "docker://3306343b232ea7717fbbae45f5774b78b5fa67792e927921cbc2133bbb4e152c"
                }
            ],
            "qosClass": "BestEffort"
        }
    }
]
```

### 获取路由列表

##### 请求 

##### GET /v1/namespaces/{namespace}/routes

##### 路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### 查询参数

| 参数名 |                    描述                    |
| :----: | :----------------------------------------: |
|  zone  | 可用区唯一标识，当zone为空时表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "route.openshift.io/v1",
            "kind": "Route",
            "metadata": {
                "annotations": {
                    "kubectl.kubernetes.io/last-applied-configuration": "{\"apiVersion\":\"route.openshift.io/v1\",\"kind\":\"Route\",\"metadata\":{\"annotations\":{\"openshift.io/host.generated\":\"true\"},\"labels\":{\"app\":\"dsp-yfopen\"},\"name\":\"dsp-yfopen\",\"namespace\":\"daocloudcsp\"},\"spec\":{\"host\":\"yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net\",\"to\":{\"kind\":\"Service\",\"name\":\"dsp-yfopen\",\"weight\":100},\"wildcardPolicy\":\"None\"}}\n",
                    "openshift.io/host.generated": "true"
                },
                "creationTimestamp": "2019-04-17T05:51:41Z",
                "labels": {
                    "app": "dsp-yfopen"
                },
                "name": "dsp-yfopen",
                "namespace": "daocloudcsp",
                "resourceVersion": "6961941",
                "selfLink": "/apis/route.openshift.io/v1/namespaces/daocloudcsp/routes/dsp-yfopen",
                "uid": "dfe43cc1-60d4-11e9-83af-005056b595d6"
            },
            "spec": {
                "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
                "to": {
                    "kind": "Service",
                    "name": "dsp-yfopen",
                    "weight": 100
                },
                "wildcardPolicy": "None"
            },
            "status": {
                "ingress": [
                    {
                        "conditions": [
                            {
                                "lastTransitionTime": "2019-04-17T05:51:41Z",
                                "status": "True",
                                "type": "Admitted"
                            }
                        ],
                        "host": "yfdsp-open-daocloudcsp.ruyiyundev01.jqpreh.c.saic-gm.net",
                        "routerName": "router",
                        "wildcardPolicy": "None"
                    }
                ]
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 删除路由

##### 请求

DELETE /v1/namespaces/{namespace}/routes/{name}

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | 路由名称 |

##### 查询参数

| 参数名 |                    描述                    |
| :----: | :----------------------------------------: |
|  zone  | 可用区唯一标识，当zone为空时表示默认可用区 |

响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```