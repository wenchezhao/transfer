### list api-resources

##### Request

GET /v1/apiresources

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |


##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
 [ // 与应用相关的kubernetes或openshift资源对象集合
     {}
 ]
```

### list otherResources

##### Request

GET "/v1/namespaces/:namespace/otherresources

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### Query

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|  gvr   | {"group": "", "version": "v1", "resource": "serviceaccounts"} |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "v1",
            "imagePullSecrets": [
                {
                    "name": "default-harbor-pull-secret"
                }
            ],
            "kind": "ServiceAccount",
            "metadata": {
                "creationTimestamp": "2021-07-22T08:56:29Z",
                "name": "default",
                "namespace": "12321",
                "resourceVersion": "235552472",
                "selfLink": "/api/v1/namespaces/12321/serviceaccounts/default",
                "uid": "095d0b16-05d5-4258-94f8-1037e85411ad"
            },
            "secrets": [
                {
                    "name": "default-token-7fbhx"
                }
            ]
        }
    ],
    "kind": "ServiceAccountList",
    "metadata": {
        "resourceVersion": "314466926",
        "selfLink": "/api/v1/namespaces/12321/serviceaccounts"
    }
}
```

### get otherResources

##### Request

GET "/v1/namespaces/:namespace/otherresources/:name

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | 资源名称 |

##### Query

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|  gvr   | {"group": "", "version": "v1", "resource": "serviceaccounts"} |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "imagePullSecrets": [
        {
            "name": "default-harbor-pull-secret"
        }
    ],
    "kind": "ServiceAccount",
    "metadata": {
        "creationTimestamp": "2021-07-22T08:56:29Z",
        "name": "default",
        "namespace": "12321",
        "resourceVersion": "235552472",
        "selfLink": "/api/v1/namespaces/12321/serviceaccounts/default",
        "uid": "095d0b16-05d5-4258-94f8-1037e85411ad"
    },
    "secrets": [
        {
            "name": "default-token-7fbhx"
        }
    ]
}
```

### create otherResources

##### Request

POST "/v1/namespaces/:namespace/otherresources

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### Query

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|  gvr   | {"group": "", "version": "v1", "resource": "serviceaccounts"} |

##### Body

```json
{
    "apiVersion": "v1",
    "imagePullSecrets": [
        {
            "name": "default-harbor-pull-secret"
        }
    ],
    "kind": "ServiceAccount",
    "metadata": {
        "name": "default333",
        "namespace": "12321",
    },
    "secrets": [
        {
            "name": "default-token-7fbhx"
        }
    ]
}
```

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "imagePullSecrets": [
        {
            "name": "default-harbor-pull-secret"
        }
    ],
    "kind": "ServiceAccount",
    "metadata": {
        "creationTimestamp": "2021-11-09T07:22:39Z",
        "name": "default333",
        "namespace": "12321",
        "resourceVersion": "314473111",
        "selfLink": "/api/v1/namespaces/12321/serviceaccounts/default333",
        "uid": "9de810bc-d9aa-4d22-bb68-8dae94018dda"
    },
    "secrets": [
        {
            "name": "default-token-7fbhx"
        }
    ]
}
```

### update otherResources

##### Request

PUT "/v1/namespaces/:namespace/otherresources/:name

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | 资源名称 |

##### Query

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|  gvr   | {"group": "", "version": "v1", "resource": "serviceaccounts"} |

##### Body

```json
{
    "apiVersion": "v1",
    "imagePullSecrets": [
        {
            "name": "default-harbor-pull-secret"
        }
    ],
    "kind": "ServiceAccount",
    "metadata": {
        "name": "default333",
        "namespace": "12321",
      	"labels":{
          "aaa":"bbb"
        }
    },
    "secrets": [
        {
            "name": "default-token-7fbhx"
        }
    ]
}
```

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "imagePullSecrets": [
        {
            "name": "default-harbor-pull-secret"
        }
    ],
    "kind": "ServiceAccount",
    "metadata": {
        "creationTimestamp": "2021-11-09T07:22:39Z",
        "labels": {
            "aaa": "bbb"
        },
        "name": "default333",
        "namespace": "12321",
        "resourceVersion": "314474248",
        "selfLink": "/api/v1/namespaces/12321/serviceaccounts/default333",
        "uid": "9de810bc-d9aa-4d22-bb68-8dae94018dda"
    },
    "secrets": [
        {
            "name": "default-token-7fbhx"
        }
    ]
}
```

### delete otherResources

##### Request

DELETE "/v1/namespaces/:namespace/otherresources/:name

##### Header

|   参数名   |              描述              |
| :--------: | :----------------------------: |
| clusterID  |        可用区的唯一标识        |
| basic auth | username: admin password:admin |

##### Path

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | 资源名称 |

##### Query

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|  gvr   | {"group": "", "version": "v1", "resource": "serviceaccounts"} |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

