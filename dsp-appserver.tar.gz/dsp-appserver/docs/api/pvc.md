### 获取PVC列表

##### 请求

GET /v1/namespaces/{namespace}/persistentvolumeclaims

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### 查询参数

|    参数名     |                        描述                        |
| :-----------: | :------------------------------------------------: |
|   clusterID   |                   可用区唯一标识                   |
| labelSelector | 标签选择器，默认选中所有的pvc。使用示例k1=v1,k2=v2 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "v1",
            "kind": "PersistentVolumeClaim",
            "metadata": {
                "annotations": {
                    "pv.kubernetes.io/bind-completed": "yes",
                    "pv.kubernetes.io/bound-by-controller": "yes",
                    "volume.beta.kubernetes.io/storage-provisioner": "isilon"
                },
                "creationTimestamp": "2019-03-05T09:15:19Z",
                "finalizers": [
                    "kubernetes.io/pvc-protection"
                ],
                "name": "demo",
                "namespace": "demo",
                "resourceVersion": "3395138",
                "selfLink": "/api/v1/namespaces/demo/persistentvolumeclaims/demo",
                "uid": "325f8a4f-3f27-11e9-af7a-005056a117fe"
            },
            "spec": {
                "accessModes": [
                    "ReadWriteOnce"
                ],
                "dataSource": null,
                "resources": {
                    "requests": {
                        "storage": "1Gi"
                    }
                },
                "storageClassName": "nfs",
                "volumeMode": "Filesystem",
                "volumeName": "pvc-325f8a4f-3f27-11e9-af7a-005056a117fe"
            },
            "status": {
                "accessModes": [
                    "ReadWriteOnce"
                ],
                "capacity": {
                    "storage": "1Gi"
                },
                "phase": "Bound"
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 获取PVC

##### 请求

GET /v1/namespaces/{namespace}/persistentvolumeclaims/{name}

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | PVC名称  |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "kind": "PersistentVolumeClaim",
    "metadata": {
        "annotations": {
            "pv.kubernetes.io/bind-completed": "yes",
            "pv.kubernetes.io/bound-by-controller": "yes",
            "volume.beta.kubernetes.io/storage-provisioner": "isilon"
        },
        "creationTimestamp": "2019-03-05T09:15:19Z",
        "finalizers": [
            "kubernetes.io/pvc-protection"
        ],
        "name": "demo",
        "namespace": "demo",
        "resourceVersion": "3395138",
        "selfLink": "/api/v1/namespaces/demo/persistentvolumeclaims/demo",
        "uid": "325f8a4f-3f27-11e9-af7a-005056a117fe"
    },
    "spec": {
        "accessModes": [
            "ReadWriteOnce"
        ],
        "dataSource": null,
        "resources": {
            "requests": {
                "storage": "1Gi"
            }
        },
        "storageClassName": "nfs",
        "volumeMode": "Filesystem",
        "volumeName": "pvc-325f8a4f-3f27-11e9-af7a-005056a117fe"
    },
    "status": {
        "accessModes": [
            "ReadWriteOnce"
        ],
        "capacity": {
            "storage": "1Gi"
        },
        "phase": "Bound"
    }
}
```

### 创建PVC

##### 请求

POST /v1/namespaces/{namespace}/persistentvolumeclaims

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |

##### 查询参数

| 参数名 |                    描述                    |
| :----: | :----------------------------------------: |
|  zone  | 可用区唯一标识，当zone为空时表示默认可用区 |

##### 请求体参数

```json
{
    "apiVersion": "v1",
    "kind": "PersistentVolumeClaim",
    "metadata": {
        "name": "demo",
        "namespace": "demo",
    },
    "spec": {
        "accessModes": [
            "ReadWriteOnce"
        ],
        "dataSource": null,
        "resources": {
            "requests": {
                "storage": "1Gi"
            }
        },
        "volumeMode": "Filesystem",
        "volumeName": "pvc-325f8a4f-3f27-11e9-af7a-005056a117fe"
    }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "kind": "PersistentVolumeClaim",
    "metadata": {
        "annotations": {
            "pv.kubernetes.io/bind-completed": "yes",
            "pv.kubernetes.io/bound-by-controller": "yes",
            "volume.beta.kubernetes.io/storage-provisioner": "isilon"
        },
        "creationTimestamp": "2019-03-05T09:15:19Z",
        "finalizers": [
            "kubernetes.io/pvc-protection"
        ],
        "name": "demo",
        "namespace": "demo",
        "resourceVersion": "3395138",
        "selfLink": "/api/v1/namespaces/demo/persistentvolumeclaims/demo",
        "uid": "325f8a4f-3f27-11e9-af7a-005056a117fe"
    },
    "spec": {
        "accessModes": [
            "ReadWriteOnce"
        ],
        "dataSource": null,
        "resources": {
            "requests": {
                "storage": "1Gi"
            }
        },
        "storageClassName": "isilon",
        "volumeMode": "Filesystem",
        "volumeName": "pvc-325f8a4f-3f27-11e9-af7a-005056a117fe"
    },
    "status": {
        "accessModes": [
            "ReadWriteOnce"
        ],
        "capacity": {
            "storage": "1Gi"
        },
        "phase": "Bound"
    }
}
```

### 更新PVC

##### 请求

PUT /v1/namespaces/{namespace}/persistentvolumeclaims/{name}

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | PVC名称  |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### 请求体

```json
{
  "kind": "PersistentVolumeClaim",
  "apiVersion": "v1",
  "metadata": {
    "name": "erererer-zookeeper01-kafka-data",
    "namespace": "youdi-test-dce",
    "selfLink": "/api/v1/namespaces/youdi-test-dce/persistentvolumeclaims/erererer-zookeeper01-kafka-data",
    "uid": "0af5cca1-f2a5-4857-99aa-283092eabcfe",
    "resourceVersion": "104711837",
    "creationTimestamp": "2021-04-15T02:58:57Z",
    "labels": {
      "servicebroker/instance": "aa0ed1ac8-27ec-4c0a-a625-1c0b1872140c",
      "servicebroker/name": "erererer"
    },
    "annotations": {
      "pv.kubernetes.io/bind-completed": "yes",
      "pv.kubernetes.io/bound-by-controller": "yes",
      "volume.beta.kubernetes.io/storage-provisioner": "dsp.dc/ifs"
    },
    "finalizers": [
      "kubernetes.io/pvc-protection"
    ]
  },
  "spec": {
    "accessModes": [
      "ReadWriteOnce"
    ],
    "resources": {
      "requests": {
        "storage": "2Gi"
      }
    },
    "volumeName": "pvc-0af5cca1-f2a5-4857-99aa-283092eabcfe",
    "storageClassName": "managed-nfs-storage",
    "volumeMode": "Filesystem"
  },
  "status": {
    "phase": "Bound",
    "accessModes": [
      "ReadWriteOnce"
    ],
    "capacity": {
      "storage": "2Gi"
    }
  }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "PersistentVolumeClaim",
    "apiVersion": "v1",
    "metadata": {
        "name": "erererer-zookeeper01-kafka-data",
        "namespace": "youdi-test-dce",
        "selfLink": "/api/v1/namespaces/youdi-test-dce/persistentvolumeclaims/erererer-zookeeper01-kafka-data",
        "uid": "0af5cca1-f2a5-4857-99aa-283092eabcfe",
        "resourceVersion": "221055612",
        "creationTimestamp": "2021-04-15T02:58:57Z",
        "labels": {
            "servicebroker/instance": "aa0ed1ac8-27ec-4c0a-a625-1c0b1872140c",
            "servicebroker/name": "erererer"
        },
        "annotations": {
            "pv.kubernetes.io/bind-completed": "yes",
            "pv.kubernetes.io/bound-by-controller": "yes",
            "volume.beta.kubernetes.io/storage-provisioner": "dsp.dc/ifs"
        },
        "finalizers": [
            "kubernetes.io/pvc-protection"
        ]
    },
    "spec": {
        "accessModes": [
            "ReadWriteOnce"
        ],
        "resources": {
            "requests": {
                "storage": "2Gi"
            }
        },
        "volumeName": "pvc-0af5cca1-f2a5-4857-99aa-283092eabcfe",
        "storageClassName": "managed-nfs-storage",
        "volumeMode": "Filesystem"
    },
    "status": {
        "phase": "Bound",
        "accessModes": [
            "ReadWriteOnce"
        ],
        "capacity": {
            "storage": "2Gi"
        }
    }
}
```

### 删除PVC

##### 请求

DELETE /v1/namespaces/{namespace}/persistentvolumeclaims/{name}

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | PVC名称  |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 获取使用PVC的资源对象引用列表

目前仅会查询Deployment, StatusfulSet, DaemonSet CronJob这四类资源。

##### 请求

GET /v1/namespaces/{namespace}/persistentvolumeclaims/{name}/objrefs

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | PVC名称  |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
[
    {
        "apiVersion": "extensions/v1beta1",
        "kind": "Deployment",
        "namespace": "dsp-system",
        "name": "mysql",
        "resourceVersion": "681676",
        "uid": "0c266300-c256-11e9-84d7-005056b4d66c"
    }
]
```

### PVC 事件列表

##### 请求

GET /v1/namespaces/{namespace}/persistentvolumeclaims/{name}/events

##### 路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | PVC名称  |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "List",
    "apiVersion": "v1",
    "metadata": {
        "selfLink": "/api/v1/events",
        "resourceVersion": "221310346"
    },
    "items": []
}
```

### PVC 容器组列表

##### 请求

GET /v1/namespaces/{namespace}/persistentvolumeclaims/{name}/pods

##### 路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | PVC名称  |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "List",
    "apiVersion": "v1",
    "metadata": {},
    "items": [
        {
            "kind": "Pod",
            "apiVersion": "v1",
            "metadata": {
                "name": "task-pv-pod",
                "namespace": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999/pods/task-pv-pod",
                "uid": "0f5784b7-f0e1-421d-9679-487f50bb29b6",
                "resourceVersion": "221438956",
                "creationTimestamp": "2021-08-09T06:37:47Z",
                "annotations": {
                    "cni.projectcalico.org/ipv4pools": "[\"default-ipv4-ippool\"]",
                }
            },
            "spec": {
                "volumes": [
                    {
                        "name": "task-pv-storage",
                        "persistentVolumeClaim": {
                            "claimName": "task-pv-claim"
                        }
                    },
                    {
                        "name": "default-token-m67mt",
                        "secret": {
                            "secretName": "default-token-m67mt",
                            "defaultMode": 420
                        }
                    }
                ],
                "containers": [
                    {
                        "name": "task-pv-container",
                        "image": "nginx",
                        "ports": [
                            {
                                "name": "http-server",
                                "containerPort": 80,
                                "protocol": "TCP"
                            }
                        ],
                        "resources": {
                            "limits": {
                                "cpu": "128m",
                                "memory": "78643200"
                            },
                            "requests": {
                                "cpu": "64m",
                                "memory": "26214400"
                            }
                        },
                        "volumeMounts": [
                            {
                                "name": "task-pv-storage",
                                "mountPath": "/usr/share/nginx/html"
                            },
                            {
                                "name": "default-token-m67mt",
                                "readOnly": true,
                                "mountPath": "/var/run/secrets/kubernetes.io/serviceaccount"
                            }
                        ],
                        "terminationMessagePath": "/dev/termination-log",
                        "terminationMessagePolicy": "File",
                        "imagePullPolicy": "Always"
                    }
                ],
                "restartPolicy": "Always",
                "terminationGracePeriodSeconds": 30,
                "dnsPolicy": "ClusterFirst",
                "serviceAccountName": "default",
                "serviceAccount": "default",
                "nodeName": "dce-10-23-3-12",
                "securityContext": {},
                "schedulerName": "default-scheduler",
                "tolerations": [
                    {
                        "key": "node.kubernetes.io/not-ready",
                        "operator": "Exists",
                        "effect": "NoExecute",
                        "tolerationSeconds": 300
                    },
                    {
                        "key": "node.kubernetes.io/unreachable",
                        "operator": "Exists",
                        "effect": "NoExecute",
                        "tolerationSeconds": 300
                    }
                ],
                "priority": 0,
                "enableServiceLinks": true
            },
            "status": {
                "phase": "Pending",
                "conditions": [
                    {
                        "type": "Initialized",
                        "status": "True",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2021-08-09T06:37:47Z"
                    },
                    {
                        "type": "Ready",
                        "status": "False",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2021-08-09T06:37:47Z",
                        "reason": "ContainersNotReady",
                        "message": "containers with unready status: [task-pv-container]"
                    },
                    {
                        "type": "ContainersReady",
                        "status": "False",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2021-08-09T06:37:47Z",
                        "reason": "ContainersNotReady",
                        "message": "containers with unready status: [task-pv-container]"
                    },
                    {
                        "type": "PodScheduled",
                        "status": "True",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2021-08-09T06:37:47Z"
                    }
                ],
                "hostIP": "10.23.3.12",
                "podIP": "172.29.87.120",
                "podIPs": [
                    {
                        "ip": "172.29.87.120"
                    }
                ],
                "startTime": "2021-08-09T06:37:47Z",
                "containerStatuses": [
                    {
                        "name": "task-pv-container",
                        "state": {
                            "waiting": {
                                "reason": "ImagePullBackOff",
                                "message": "Back-off pulling image \"nginx\""
                            }
                        },
                        "lastState": {},
                        "ready": false,
                        "restartCount": 0,
                        "image": "nginx",
                        "imageID": "",
                        "started": false
                    }
                ],
                "qosClass": "Burstable"
            }
        }
    ]
}
```

