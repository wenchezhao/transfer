## Cronjob

### 获取cronjob列表

#### 请求

GET-/v1/namespaces/{namespace}/cronjobs

#### 路径参数

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |

#### 查询参数

|   Parameter   |                      Description                       |
| :-----------: | :----------------------------------------------------: |
|   clusterID   |                     可用区唯一标识                     |
| labelSelector | 标签选择器，默认选中所有的cronjob。使用示例k1=v1,k2=v2 |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "List",
    "apiVersion": "v1",
    "metadata": {
        "selfLink": "/apis/batch/v1beta1/namespaces/yorktest999/cronjobs",
        "resourceVersion": "194290722"
    },
    "items": [
        {
            "kind": "CronJob",
            "apiVersion": "batch/v1beta1",
            "metadata": {
                "name": "hello",
                "namespace": "yorktest999",
                "selfLink": "/apis/batch/v1beta1/namespaces/yorktest999/cronjobs/hello",
                "uid": "b014018e-c873-4b61-b751-861c2008d2e2",
                "resourceVersion": "194290333",
                "creationTimestamp": "2021-07-26T05:46:11Z",
                "annotations": {
                    "kubectl.kubernetes.io/last-applied-configuration": "{\"apiVersion\":\"batch/v1beta1\",\"kind\":\"CronJob\",\"metadata\":{\"annotations\":{},\"name\":\"hello\",\"namespace\":\"yorktest999\"},\"spec\":{\"jobTemplate\":{\"spec\":{\"template\":{\"spec\":{\"containers\":[{\"args\":[\"/bin/sh\",\"-c\",\"date; echo Hello from the Kubernetes cluster\"],\"image\":\"busybox\",\"name\":\"hello\"}],\"restartPolicy\":\"OnFailure\"}}}},\"schedule\":\"*/1 * * * *\"}}\n"
                }
            },
            "spec": {
                "schedule": "*/1 * * * *",
                "concurrencyPolicy": "Allow",
                "suspend": false,
                "jobTemplate": {
                    "metadata": {
                        "creationTimestamp": null
                    },
                    "spec": {
                        "template": {
                            "metadata": {
                                "creationTimestamp": null
                            },
                            "spec": {
                                "containers": [
                                    {
                                        "name": "hello",
                                        "image": "busybox",
                                        "args": [
                                            "/bin/sh",
                                            "-c",
                                            "date; echo Hello from the Kubernetes cluster"
                                        ],
                                        "resources": {},
                                        "terminationMessagePath": "/dev/termination-log",
                                        "terminationMessagePolicy": "File",
                                        "imagePullPolicy": "Always"
                                    }
                                ],
                                "restartPolicy": "OnFailure",
                                "terminationGracePeriodSeconds": 30,
                                "dnsPolicy": "ClusterFirst",
                                "securityContext": {},
                                "schedulerName": "default-scheduler"
                            }
                        }
                    }
                },
                "successfulJobsHistoryLimit": 3,
                "failedJobsHistoryLimit": 1
            },
            "status": {}
        }
    ]
}
```

### 创建cronjob

#### 请求

POST-/v1/namespaces/{namespace}/cronjobs

#### 路径参数

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |

#### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

#### 请求体

```json
{
  "kind": "CronJob",
  "apiVersion": "batch/v1beta1",
  "metadata": {
    "name": "hello1",
    "namespace": "yorktest999",
  },
  "spec": {
    "schedule": "*/1 * * * *",
    "concurrencyPolicy": "Allow",
    "suspend": false,
    "jobTemplate": {
      "metadata": {
        "creationTimestamp": null
      },
      "spec": {
        "template": {
          "metadata": {
            "creationTimestamp": null
          },
          "spec": {
            "containers": [
              {
                "name": "hello",
                "image": "busybox",
                "args": [
                  "/bin/sh",
                  "-c",
                  "date; echo Hello from the Kubernetes cluster"
                ],
                "resources": {},
                "terminationMessagePath": "/dev/termination-log",
                "terminationMessagePolicy": "File",
                "imagePullPolicy": "Always"
              }
            ],
            "restartPolicy": "OnFailure",
            "terminationGracePeriodSeconds": 30,
            "dnsPolicy": "ClusterFirst",
            "securityContext": {},
            "schedulerName": "default-scheduler"
          }
        }
      }
    },
    "successfulJobsHistoryLimit": 3,
    "failedJobsHistoryLimit": 1
  },
  "status": {}
}
```

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 获取cronjob详情

#### 请求

GET-/v1/namespaces/{namespace}/cronjobs/{name}

#### 路径参数

| Parameter |  Description  |
| :-------: | :-----------: |
| namespace |   命名空间    |
|   name    | cronjob的名字 |

#### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "CronJob",
    "apiVersion": "batch/v1beta1",
    "metadata": {
        "name": "hello1",
        "namespace": "yorktest999",
        "selfLink": "/apis/batch/v1beta1/namespaces/yorktest999/cronjobs/hello1",
        "uid": "ea46ce58-cb68-4337-94d1-9286a28c4b25",
        "resourceVersion": "194301642",
        "creationTimestamp": "2021-07-26T05:50:42Z",
        "annotations": {
            "kubectl.kubernetes.io/last-applied-configuration": "{\"apiVersion\":\"batch/v1beta1\",\"kind\":\"CronJob\",\"metadata\":{\"annotations\":{},\"name\":\"hello\",\"namespace\":\"yorktest999\"},\"spec\":{\"jobTemplate\":{\"spec\":{\"template\":{\"spec\":{\"containers\":[{\"args\":[\"/bin/sh\",\"-c\",\"date; echo Hello from the Kubernetes cluster\"],\"image\":\"busybox\",\"name\":\"hello\"}],\"restartPolicy\":\"OnFailure\"}}}},\"schedule\":\"*/1 * * * *\"}}\n"
        }
    },
    "spec": {
        "schedule": "*/1 * * * *",
        "concurrencyPolicy": "Allow",
        "suspend": false,
        "jobTemplate": {
            "metadata": {
                "creationTimestamp": null
            },
            "spec": {
                "template": {
                    "metadata": {
                        "creationTimestamp": null
                    },
                    "spec": {
                        "containers": [
                            {
                                "name": "hello",
                                "image": "busybox",
                                "args": [
                                    "/bin/sh",
                                    "-c",
                                    "date; echo Hello from the Kubernetes cluster"
                                ],
                                "resources": {},
                                "terminationMessagePath": "/dev/termination-log",
                                "terminationMessagePolicy": "File",
                                "imagePullPolicy": "Always"
                            }
                        ],
                        "restartPolicy": "OnFailure",
                        "terminationGracePeriodSeconds": 30,
                        "dnsPolicy": "ClusterFirst",
                        "securityContext": {},
                        "schedulerName": "default-scheduler"
                    }
                }
            }
        },
        "successfulJobsHistoryLimit": 3,
        "failedJobsHistoryLimit": 1
    },
    "status": {
        "active": [
            {
                "kind": "Job",
                "namespace": "yorktest999",
                "name": "hello1-1627278660",
                "uid": "5871e006-47e8-40bc-9202-7293a7e941ad",
                "apiVersion": "batch/v1",
                "resourceVersion": "194297460"
            },
            {
                "kind": "Job",
                "namespace": "yorktest999",
                "name": "hello1-1627278720",
                "uid": "1a10d66f-3fbc-43ae-be4c-4d49891fb161",
                "apiVersion": "batch/v1",
                "resourceVersion": "194298890"
            },
            {
                "kind": "Job",
                "namespace": "yorktest999",
                "name": "hello1-1627278780",
                "uid": "f4a24063-196b-4bb5-a35e-d1947ebcc572",
                "apiVersion": "batch/v1",
                "resourceVersion": "194300380"
            },
            {
                "kind": "Job",
                "namespace": "yorktest999",
                "name": "hello1-1627278840",
                "uid": "0c059dc3-3e15-4c88-ad33-c937b65df3dd",
                "apiVersion": "batch/v1",
                "resourceVersion": "194301640"
            }
        ],
        "lastScheduleTime": "2021-07-26T05:54:00Z"
    }
}
```

### 修改CronJob

#### 请求

PUT-/v1/namespaces/{namespace}/cronjobs/{name}

#### 路径参数

| Parameter |  Description  |
| :-------: | :-----------: |
| namespace |   命名空间    |
|   name    | cronjob的名字 |

#### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

#### 请求体

```json
{
    "kind": "CronJob",
    "apiVersion": "batch/v1beta1",
    "metadata": {
        "name": "hello1",
        "namespace": "yorktest999",
        "labels": {
            "aa":"bb"
        }
    },
    "spec": {
        "schedule": "*/10 * * * *",
        "concurrencyPolicy": "Allow",
        "suspend": false,
        "jobTemplate": {
            "metadata": {
                "creationTimestamp": null
            },
            "spec": {
                "template": {
                    "metadata": {
                        "creationTimestamp": null
                    },
                    "spec": {
                        "containers": [
                            {
                                "name": "hello",
                                "image": "busybox",
                                "args": [
                                    "/bin/sh",
                                    "-c",
                                    "date; echo Hello from the Kubernetes cluster"
                                ],
                                "resources": {},
                                "terminationMessagePath": "/dev/termination-log",
                                "terminationMessagePolicy": "File",
                                "imagePullPolicy": "Always"
                            }
                        ],
                        "restartPolicy": "OnFailure",
                        "terminationGracePeriodSeconds": 30,
                        "dnsPolicy": "ClusterFirst",
                        "securityContext": {},
                        "schedulerName": "default-scheduler"
                    }
                }
            }
        }
    }
}
```

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "metadata": {
        "name": "hello1",
        "namespace": "yorktest999",
        "selfLink": "/apis/batch/v1beta1/namespaces/yorktest999/cronjobs/hello1",
        "uid": "5c4dfdd0-1e74-42f2-a24a-8dec85f67751",
        "resourceVersion": "227389561",
        "creationTimestamp": "2021-08-12T07:35:52Z",
        "labels": {
            "aa": "bb"
        }
    },
    "spec": {
        "schedule": "*/10 * * * *",
        "concurrencyPolicy": "Allow",
        "suspend": false,
        "jobTemplate": {
            "metadata": {
                "creationTimestamp": null
            },
            "spec": {
                "template": {
                    "metadata": {
                        "creationTimestamp": null
                    },
                    "spec": {
                        "containers": [
                            {
                                "name": "hello",
                                "image": "busybox",
                                "args": [
                                    "/bin/sh",
                                    "-c",
                                    "date; echo Hello from the Kubernetes cluster"
                                ],
                                "resources": {},
                                "terminationMessagePath": "/dev/termination-log",
                                "terminationMessagePolicy": "File",
                                "imagePullPolicy": "Always"
                            }
                        ],
                        "restartPolicy": "OnFailure",
                        "terminationGracePeriodSeconds": 30,
                        "dnsPolicy": "ClusterFirst",
                        "securityContext": {},
                        "schedulerName": "default-scheduler"
                    }
                }
            }
        },
        "successfulJobsHistoryLimit": 3,
        "failedJobsHistoryLimit": 1
    },
    "status": {}
}
```

### 获取cronjob事件列表

#### 请求

GET-/v1/namespaces/{namespace}/cronjobs/{name}/evnets

#### 路径参数

| Parameter |  Description  |
| :-------: | :-----------: |
| namespace |   命名空间    |
|   Name    | cronjob的名字 |

#### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "metadata": {
        "selfLink": "/api/v1/namespaces/yorktest999/events",
        "resourceVersion": "194305896"
    },
    "items": [
        {
            "metadata": {
                "name": "hello1.16954153b47522a2",
                "namespace": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999/events/hello1.16954153b47522a2",
                "uid": "5a126b30-e80f-4175-ac25-e4e7fdba9727",
                "resourceVersion": "194297461",
                "creationTimestamp": "2021-07-26T05:51:08Z"
            },
            "involvedObject": {
                "kind": "CronJob",
                "namespace": "yorktest999",
                "name": "hello1",
                "uid": "ea46ce58-cb68-4337-94d1-9286a28c4b25",
                "apiVersion": "batch/v1beta1",
                "resourceVersion": "194296809"
            },
            "reason": "SuccessfulCreate",
            "message": "Created job hello1-1627278660",
            "source": {
                "component": "cronjob-controller"
            },
            "firstTimestamp": "2021-07-26T05:51:08Z",
            "lastTimestamp": "2021-07-26T05:51:08Z",
            "count": 1,
            "type": "Normal",
            "eventTime": null,
            "reportingComponent": "",
            "reportingInstance": ""
        },
        {
            "metadata": {
                "name": "hello1.16954161dfc0631e",
                "namespace": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999/events/hello1.16954161dfc0631e",
                "uid": "8c42da0b-4ada-4aa5-bc73-16be994dd0b1",
                "resourceVersion": "194298894",
                "creationTimestamp": "2021-07-26T05:52:08Z"
            },
            "involvedObject": {
                "kind": "CronJob",
                "namespace": "yorktest999",
                "name": "hello1",
                "uid": "ea46ce58-cb68-4337-94d1-9286a28c4b25",
                "apiVersion": "batch/v1beta1",
                "resourceVersion": "194297462"
            },
            "reason": "SuccessfulCreate",
            "message": "Created job hello1-1627278720",
            "source": {
                "component": "cronjob-controller"
            },
            "firstTimestamp": "2021-07-26T05:52:08Z",
            "lastTimestamp": "2021-07-26T05:52:08Z",
            "count": 1,
            "type": "Normal",
            "eventTime": null,
            "reportingComponent": "",
            "reportingInstance": ""
        },
        {
            "metadata": {
                "name": "hello1.169541700553620a",
                "namespace": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999/events/hello1.169541700553620a",
                "uid": "3280aa46-9bbe-411a-9c61-67c8c983d873",
                "resourceVersion": "194300383",
                "creationTimestamp": "2021-07-26T05:53:09Z"
            },
            "involvedObject": {
                "kind": "CronJob",
                "namespace": "yorktest999",
                "name": "hello1",
                "uid": "ea46ce58-cb68-4337-94d1-9286a28c4b25",
                "apiVersion": "batch/v1beta1",
                "resourceVersion": "194298892"
            },
            "reason": "SuccessfulCreate",
            "message": "Created job hello1-1627278780",
            "source": {
                "component": "cronjob-controller"
            },
            "firstTimestamp": "2021-07-26T05:53:09Z",
            "lastTimestamp": "2021-07-26T05:53:09Z",
            "count": 1,
            "type": "Normal",
            "eventTime": null,
            "reportingComponent": "",
            "reportingInstance": ""
        },
        {
            "metadata": {
                "name": "hello1.1695417bd95e29ec",
                "namespace": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999/events/hello1.1695417bd95e29ec",
                "uid": "a337eae7-0242-4d0d-b74d-005be4762aad",
                "resourceVersion": "194301643",
                "creationTimestamp": "2021-07-26T05:54:00Z"
            },
            "involvedObject": {
                "kind": "CronJob",
                "namespace": "yorktest999",
                "name": "hello1",
                "uid": "ea46ce58-cb68-4337-94d1-9286a28c4b25",
                "apiVersion": "batch/v1beta1",
                "resourceVersion": "194300381"
            },
            "reason": "SuccessfulCreate",
            "message": "Created job hello1-1627278840",
            "source": {
                "component": "cronjob-controller"
            },
            "firstTimestamp": "2021-07-26T05:54:00Z",
            "lastTimestamp": "2021-07-26T05:54:00Z",
            "count": 1,
            "type": "Normal",
            "eventTime": null,
            "reportingComponent": "",
            "reportingInstance": ""
        },
        {
            "metadata": {
                "name": "hello1.1695418a08aef6d7",
                "namespace": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999/events/hello1.1695418a08aef6d7",
                "uid": "cf545f6a-3bc4-412c-b450-945896745837",
                "resourceVersion": "194303122",
                "creationTimestamp": "2021-07-26T05:55:01Z"
            },
            "involvedObject": {
                "kind": "CronJob",
                "namespace": "yorktest999",
                "name": "hello1",
                "uid": "ea46ce58-cb68-4337-94d1-9286a28c4b25",
                "apiVersion": "batch/v1beta1",
                "resourceVersion": "194301642"
            },
            "reason": "SuccessfulCreate",
            "message": "Created job hello1-1627278900",
            "source": {
                "component": "cronjob-controller"
            },
            "firstTimestamp": "2021-07-26T05:55:01Z",
            "lastTimestamp": "2021-07-26T05:55:01Z",
            "count": 1,
            "type": "Normal",
            "eventTime": null,
            "reportingComponent": "",
            "reportingInstance": ""
        },
        {
            "metadata": {
                "name": "hello1.169541982b80e0f9",
                "namespace": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999/events/hello1.169541982b80e0f9",
                "uid": "ee91ea4c-416f-4406-9f49-4f948b0c824a",
                "resourceVersion": "194304693",
                "creationTimestamp": "2021-07-26T05:56:02Z"
            },
            "involvedObject": {
                "kind": "CronJob",
                "namespace": "yorktest999",
                "name": "hello1",
                "uid": "ea46ce58-cb68-4337-94d1-9286a28c4b25",
                "apiVersion": "batch/v1beta1",
                "resourceVersion": "194303121"
            },
            "reason": "SuccessfulCreate",
            "message": "Created job hello1-1627278960",
            "source": {
                "component": "cronjob-controller"
            },
            "firstTimestamp": "2021-07-26T05:56:02Z",
            "lastTimestamp": "2021-07-26T05:56:02Z",
            "count": 1,
            "type": "Normal",
            "eventTime": null,
            "reportingComponent": "",
            "reportingInstance": ""
        }
    ]
}
```

### 删除cronjob

#### 请求

DELETE-/v1/namespaces/{namespace}/cronjobs/{name}

#### 路径参数

| Parameter |  Description  |
| :-------: | :-----------: |
| namespace |   命名空间    |
|   Name    | cronjob的名字 |

#### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

