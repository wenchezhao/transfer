### PV列表

##### 请求

GET /v1/persistentvolumes

##### 查询参数

|    参数名     |                        描述                        |
| :-----------: | :------------------------------------------------: |
|   clusterID   |                   可用区唯一标识                   |
| labelSelector | 标签选择器，默认选中所有的pvc。使用示例k1=v1,k2=v2 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "List",
    "apiVersion": "v1",
    "metadata": {
        "selfLink": "/api/v1/persistentvolumes",
        "resourceVersion": "221063792"
    },
    "items": [
        {
            "kind": "PersistentVolume",
            "apiVersion": "v1",
            "metadata": {
                "name": "dce-registry",
                "selfLink": "/api/v1/persistentvolumes/dce-registry",
                "uid": "c3f1ce88-ba51-492f-9965-9538b74df4b1",
                "resourceVersion": "1275",
                "creationTimestamp": "2021-03-13T13:13:45Z",
                "labels": {
                    "app.kubernetes.io/managed-by": "Helm",
                    "k8s-app": "dce-registry"
                },
                "annotations": {
                    "helm.sh/resource-policy": "keep",
                    "meta.helm.sh/release-name": "dce-components",
                    "meta.helm.sh/release-namespace": "kube-system",
                    "pv.kubernetes.io/bound-by-controller": "yes"
                },
                "finalizers": [
                    "kubernetes.io/pv-protection"
                ]
            }
        }
    ]
}
```

### PV详情

##### 请求

GET /v1/persistentvolumes/{name}

##### 路径参数

| 参数名 |  描述  |
| :----: | :----: |
|  name  | pv名称 |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "PersistentVolume",
    "apiVersion": "v1",
    "metadata": {
        "name": "prometheus-dx-insight-0",
        "selfLink": "/api/v1/persistentvolumes/prometheus-dx-insight-0",
        "uid": "ba3ece95-7d02-492b-a7c2-6deafd10f6e3",
        "resourceVersion": "104637581",
        "creationTimestamp": "2021-04-25T03:38:24Z",
        "labels": {
            "app": "prometheus-dx-insight"
        },
        "finalizers": [
            "kubernetes.io/pv-protection"
        ]
    },
    "spec": {
        "capacity": {
            "storage": "10Gi"
        },
        "local": {
            "path": "/var/local/dx-insight/prometheus"
        },
        "accessModes": [
            "ReadWriteOnce"
        ],
        "claimRef": {
            "kind": "PersistentVolumeClaim",
            "namespace": "dx-insight",
            "name": "prometheus-dx-insight-prometheus-db-prometheus-dx-insight-prometheus-0",
            "uid": "b74facec-5636-4c40-99e7-f380124e920f",
            "apiVersion": "v1",
            "resourceVersion": "101562282"
        },
        "persistentVolumeReclaimPolicy": "Delete",
        "volumeMode": "Filesystem",
        "nodeAffinity": {
            "required": {
                "nodeSelectorTerms": [
                    {
                        "matchExpressions": [
                            {
                                "key": "dx-insight.daocloud.io",
                                "operator": "Exists"
                            }
                        ]
                    }
                ]
            }
        }
    },
    "status": {
        "phase": "Bound"
    }
}
```

### 创建PV

##### 请求

POST /v1/persistentvolumes

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### 请求体

```json
{
    "apiVersion":"v1",
    "kind":"PersistentVolume",
    "metadata":{
        "name":"task-pv-volume",
        "labels":{
            "type":"local"
        }
    },
    "spec":{
        "storageClassName":"manual",
        "capacity":{
            "storage":"10Gi"
        },
        "accessModes":[
            "ReadWriteOnce"
        ],
        "hostPath":{
            "path":"/mnt/data"
        }
    }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "PersistentVolume",
    "apiVersion": "v1",
    "metadata": {
        "name": "task-pv-volume",
        "selfLink": "/api/v1/persistentvolumes/task-pv-volume",
        "uid": "c7d00e5a-af95-4e66-9ff6-f1d4cad03743",
        "resourceVersion": "221071730",
        "creationTimestamp": "2021-08-09T02:12:35Z",
        "labels": {
            "type": "local"
        },
        "finalizers": [
            "kubernetes.io/pv-protection"
        ]
    },
    "spec": {
        "capacity": {
            "storage": "10Gi"
        },
        "hostPath": {
            "path": "/mnt/data",
            "type": ""
        },
        "accessModes": [
            "ReadWriteOnce"
        ],
        "persistentVolumeReclaimPolicy": "Retain",
        "storageClassName": "manual",
        "volumeMode": "Filesystem"
    },
    "status": {
        "phase": "Pending"
    }
}
```

### 更新PV

##### 请求

PUT /v1/persistentvolumes/{name}

##### 路径参数

| 参数名 |  描述  |
| :----: | :----: |
|  name  | pv名称 |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### 请求体

```json
{
    "apiVersion":"v1",
    "kind":"PersistentVolume",
    "metadata":{
        "name":"task-pv-volume",
        "labels":{
            "type":"local",
            "haha":"hehe"
        }
    },
    "spec":{
        "storageClassName":"manual",
        "capacity":{
            "storage":"10Gi"
        },
        "accessModes":[
            "ReadWriteOnce"
        ],
        "hostPath":{
            "path":"/mnt/data"
        }
    }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "PersistentVolume",
    "apiVersion": "v1",
    "metadata": {
        "name": "task-pv-volume",
        "selfLink": "/api/v1/persistentvolumes/task-pv-volume",
        "uid": "c7d00e5a-af95-4e66-9ff6-f1d4cad03743",
        "resourceVersion": "221073905",
        "creationTimestamp": "2021-08-09T02:12:35Z",
        "labels": {
            "haha": "hehe",
            "type": "local"
        }
    },
    "spec": {
        "capacity": {
            "storage": "10Gi"
        },
        "hostPath": {
            "path": "/mnt/data",
            "type": ""
        },
        "accessModes": [
            "ReadWriteOnce"
        ],
        "persistentVolumeReclaimPolicy": "Retain",
        "storageClassName": "manual",
        "volumeMode": "Filesystem"
    },
    "status": {
        "phase": "Available"
    }
}
```

### 删除PV

##### 请求

DELETE /v1/persistentvolumes/{name}

##### 路径参数

| 参数名 |  描述  |
| :----: | :----: |
|  name  | pv名称 |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### PV 事件列表

##### 请求

DELETE /v1/persistentvolumes/{name}

##### 路径参数

| 参数名 |  描述  |
| :----: | :----: |
|  name  | pv名称 |

##### 查询参数

|  参数名   |      描述      |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "List",
    "apiVersion": "v1",
    "metadata": {
        "selfLink": "/api/v1/events",
        "resourceVersion": "221454606"
    },
    "items": []
}
```

