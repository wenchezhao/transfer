### 获取Deployment列表

##### 请求

GET  /v1/namespaces/{namespace}/deployments

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |


##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {
                "annotations": {
                    "deployment.kubernetes.io/revision": "1"
                },
                "creationTimestamp": "2019-04-22T12:55:15Z",
                "generation": 2,
                "labels": {
                    "k8s-app": "kube-dns"
                },
                "name": "coredns",
                "namespace": "kube-system",
                "resourceVersion": "7754",
                "selfLink": "/apis/apps/v1/namespaces/kube-system/deployments/coredns",
                "uid": "e00d0967-64fd-11e9-a452-000c29f93cb4"
            },
            "spec": {
                "progressDeadlineSeconds": 600,
                "replicas": 1,
                "revisionHistoryLimit": 10,
                "selector": {
                    "matchLabels": {
                        "k8s-app": "kube-dns"
                    }
                },
                "strategy": {
                    "rollingUpdate": {
                        "maxSurge": "25%",
                        "maxUnavailable": 1
                    },
                    "type": "RollingUpdate"
                },
                "template": {
                    "metadata": {
                        "creationTimestamp": null,
                        "labels": {
                            "k8s-app": "kube-dns"
                        }
                    },
                    "spec": {
                        "containers": [
                            {
                                "args": [
                                    "-conf",
                                    "/etc/coredns/Corefile"
                                ],
                                "image": "k8s.gcr.io/coredns:1.2.6",
                                "imagePullPolicy": "IfNotPresent",
                                "livenessProbe": {
                                    "failureThreshold": 5,
                                    "httpGet": {
                                        "path": "/health",
                                        "port": 8080,
                                        "scheme": "HTTP"
                                    },
                                    "initialDelaySeconds": 60,
                                    "periodSeconds": 10,
                                    "successThreshold": 1,
                                    "timeoutSeconds": 5
                                },
                                "name": "coredns",
                                "ports": [
                                    {
                                        "containerPort": 53,
                                        "name": "dns",
                                        "protocol": "UDP"
                                    },
                                    {
                                        "containerPort": 53,
                                        "name": "dns-tcp",
                                        "protocol": "TCP"
                                    },
                                    {
                                        "containerPort": 9153,
                                        "name": "metrics",
                                        "protocol": "TCP"
                                    }
                                ],
                                "resources": {
                                    "limits": {
                                        "memory": "170Mi"
                                    },
                                    "requests": {
                                        "cpu": "100m",
                                        "memory": "70Mi"
                                    }
                                },
                                "securityContext": {
                                    "allowPrivilegeEscalation": false,
                                    "capabilities": {
                                        "add": [
                                            "NET_BIND_SERVICE"
                                        ],
                                        "drop": [
                                            "all"
                                        ]
                                    },
                                    "procMount": "Default",
                                    "readOnlyRootFilesystem": true
                                },
                                "terminationMessagePath": "/dev/termination-log",
                                "terminationMessagePolicy": "File",
                                "volumeMounts": [
                                    {
                                        "mountPath": "/etc/coredns",
                                        "name": "config-volume",
                                        "readOnly": true
                                    }
                                ]
                            }
                        ],
                        "dnsPolicy": "Default",
                        "restartPolicy": "Always",
                        "schedulerName": "default-scheduler",
                        "securityContext": {},
                        "serviceAccount": "coredns",
                        "serviceAccountName": "coredns",
                        "terminationGracePeriodSeconds": 30,
                        "tolerations": [
                            {
                                "key": "CriticalAddonsOnly",
                                "operator": "Exists"
                            },
                            {
                                "effect": "NoSchedule",
                                "key": "node-role.kubernetes.io/master"
                            }
                        ],
                        "volumes": [
                            {
                                "configMap": {
                                    "defaultMode": 420,
                                    "items": [
                                        {
                                            "key": "Corefile",
                                            "path": "Corefile"
                                        }
                                    ],
                                    "name": "coredns"
                                },
                                "name": "config-volume"
                            }
                        ]
                    }
                }
            },
            "status": {
                "availableReplicas": 1,
                "conditions": [
                    {
                        "lastTransitionTime": "2019-04-22T12:55:17Z",
                        "lastUpdateTime": "2019-04-22T12:55:17Z",
                        "message": "Deployment has minimum availability.",
                        "reason": "MinimumReplicasAvailable",
                        "status": "True",
                        "type": "Available"
                    },
                    {
                        "lastTransitionTime": "2019-04-22T12:55:16Z",
                        "lastUpdateTime": "2019-04-22T12:55:17Z",
                        "message": "ReplicaSet \"coredns-86c58d9df4\" has successfully progressed.",
                        "reason": "NewReplicaSetAvailable",
                        "status": "True",
                        "type": "Progressing"
                    }
                ],
                "observedGeneration": 2,
                "readyReplicas": 1,
                "replicas": 1,
                "updatedReplicas": 1
            }
        },
        {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {
                "annotations": {
                    "deployment.kubernetes.io/revision": "3",
                    "kubectl.kubernetes.io/last-applied-configuration": "{\"apiVersion\":\"apps/v1\",\"kind\":\"Deployment\",\"metadata\":{\"annotations\":{},\"labels\":{\"addonmanager.kubernetes.io/mode\":\"Reconcile\",\"kubernetes.io/minikube-addons\":\"dashboard\",\"version\":\"v1.10.1\"},\"name\":\"kubernetes-dashboard\",\"namespace\":\"kube-system\"},\"spec\":{\"replicas\":1,\"selector\":{\"matchLabels\":{\"addonmanager.kubernetes.io/mode\":\"Reconcile\",\"app\":\"kubernetes-dashboard\",\"version\":\"v1.10.1\"}},\"template\":{\"metadata\":{\"labels\":{\"addonmanager.kubernetes.io/mode\":\"Reconcile\",\"app\":\"kubernetes-dashboard\",\"version\":\"v1.10.1\"}},\"spec\":{\"containers\":[{\"image\":\"k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1\",\"imagePullPolicy\":\"IfNotPresent\",\"livenessProbe\":{\"httpGet\":{\"path\":\"/\",\"port\":9090},\"initialDelaySeconds\":30,\"timeoutSeconds\":30},\"name\":\"kubernetes-dashboard\",\"ports\":[{\"containerPort\":9090,\"protocol\":\"TCP\"}]}]}}}}\n"
                },
                "creationTimestamp": "2019-04-26T15:56:46Z",
                "generation": 3,
                "labels": {
                    "addonmanager.kubernetes.io/mode": "Reconcile",
                    "kubernetes.io/minikube-addons": "dashboard",
                    "version": "v1.10.1"
                },
                "name": "kubernetes-dashboard",
                "namespace": "kube-system",
                "resourceVersion": "114593",
                "selfLink": "/apis/apps/v1/namespaces/kube-system/deployments/kubernetes-dashboard",
                "uid": "e50235c3-683b-11e9-a330-000c29f93cb4"
            },
            "spec": {
                "progressDeadlineSeconds": 600,
                "replicas": 1,
                "revisionHistoryLimit": 10,
                "selector": {
                    "matchLabels": {
                        "addonmanager.kubernetes.io/mode": "Reconcile",
                        "app": "kubernetes-dashboard",
                        "version": "v1.10.1"
                    }
                },
                "strategy": {
                    "rollingUpdate": {
                        "maxSurge": "25%",
                        "maxUnavailable": "25%"
                    },
                    "type": "RollingUpdate"
                },
                "template": {
                    "metadata": {
                        "creationTimestamp": null,
                        "labels": {
                            "addonmanager.kubernetes.io/mode": "Reconcile",
                            "app": "kubernetes-dashboard",
                            "version": "v1.10.1"
                        }
                    },
                    "spec": {
                        "containers": [
                            {
                                "image": "k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1",
                                "imagePullPolicy": "IfNotPresent",
                                "livenessProbe": {
                                    "failureThreshold": 3,
                                    "httpGet": {
                                        "path": "/",
                                        "port": 9090,
                                        "scheme": "HTTP"
                                    },
                                    "initialDelaySeconds": 30,
                                    "periodSeconds": 10,
                                    "successThreshold": 1,
                                    "timeoutSeconds": 30
                                },
                                "name": "kubernetes-dashboard",
                                "ports": [
                                    {
                                        "containerPort": 9090,
                                        "protocol": "TCP"
                                    }
                                ],
                                "resources": {},
                                "terminationMessagePath": "/dev/termination-log",
                                "terminationMessagePolicy": "File"
                            }
                        ],
                        "dnsPolicy": "ClusterFirst",
                        "restartPolicy": "Always",
                        "schedulerName": "default-scheduler",
                        "securityContext": {},
                        "terminationGracePeriodSeconds": 30
                    }
                }
            },
            "status": {
                "availableReplicas": 1,
                "conditions": [
                    {
                        "lastTransitionTime": "2019-04-26T15:56:46Z",
                        "lastUpdateTime": "2019-04-26T16:00:45Z",
                        "message": "ReplicaSet \"kubernetes-dashboard-ccc79bfc9\" has successfully progressed.",
                        "reason": "NewReplicaSetAvailable",
                        "status": "True",
                        "type": "Progressing"
                    },
                    {
                        "lastTransitionTime": "2019-04-28T06:49:00Z",
                        "lastUpdateTime": "2019-04-28T06:49:00Z",
                        "message": "Deployment has minimum availability.",
                        "reason": "MinimumReplicasAvailable",
                        "status": "True",
                        "type": "Available"
                    }
                ],
                "observedGeneration": 3,
                "readyReplicas": 1,
                "replicas": 1,
                "updatedReplicas": 1
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 获取 Deployment

##### 请求

GET  /v1/namespaces/{namespace}/deployments/{name}

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|   name    |      deployment的名称       |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |


##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "apps/v1", // 资源版本
    "kind": "Deployment", //资源类型
    "metadata": {
        "annotations": { // 注解
            "deployment.kubernetes.io/revision": "1"
        },
        "creationTimestamp": "2019-04-22T12:55:15Z", //创建时间
        "generation": 2,
        "labels": { // deployment标签
            "k8s-app": "kube-dns"
        },
        "name": "coredns", // 资源名称
        "namespace": "kube-system", // 命名空间
        "resourceVersion": "7754",
        "selfLink": "/apis/apps/v1/namespaces/kube-system/deployments/coredns",
        "uid": "e00d0967-64fd-11e9-a452-000c29f93cb4"
    },
    "spec": {
        "progressDeadlineSeconds": 600,
        "replicas": 1, // 副本数
        "revisionHistoryLimit": 10, // 保留的历史版本上限
        "selector": {
            "matchLabels": { // 选择POD的标签
                "k8s-app": "kube-dns"
            }
        },
        "strategy": { // 滚动更新的策略
            "rollingUpdate": {
                "maxSurge": "25%",
                "maxUnavailable": 1
            },
            "type": "RollingUpdate"
        },
        "template": { // POD模版
            "metadata": {
                "creationTimestamp": null,
                "labels": { // POD的标签
                    "k8s-app": "kube-dns"
                }
            },
            "spec": {
                "containers": [
                    {
                        "args": [ // 启动参数
                            "-conf",
                            "/etc/coredns/Corefile"
                        ],
                        "image": "k8s.gcr.io/coredns:1.2.6",
                        "imagePullPolicy": "IfNotPresent",
                        "livenessProbe": {
                            "failureThreshold": 5,
                            "httpGet": {
                                "path": "/health",
                                "port": 8080,
                                "scheme": "HTTP"
                            },
                            "initialDelaySeconds": 60,
                            "periodSeconds": 10,
                            "successThreshold": 1,
                            "timeoutSeconds": 5
                        },
                        "name": "coredns", // 容器名
                        "ports": [ // 容器端口
                            {
                                "containerPort": 53,
                                "name": "dns", // 端口名
                                "protocol": "UDP" // 端口协议
                            },
                            {
                                "containerPort": 53,
                                "name": "dns-tcp",
                                "protocol": "TCP"
                            },
                            {
                                "containerPort": 9153,
                                "name": "metrics",
                                "protocol": "TCP"
                            }
                        ],
                        "resources": { // 资料限制
                            "limits": {
                                "memory": "170Mi" // 限制内存
                            },
                            "requests": {
                                "cpu": "100m",
                                "memory": "70Mi"
                            }
                        },
                        "securityContext": { // 设置安全上下文
                            "allowPrivilegeEscalation": false,
                            "capabilities": {
                                "add": [
                                    "NET_BIND_SERVICE"
                                ],
                                "drop": [
                                    "all"
                                ]
                            },
                            "procMount": "Default",
                            "readOnlyRootFilesystem": true
                        },
                        "terminationMessagePath": "/dev/termination-log",
                        "terminationMessagePolicy": "File",
                        "volumeMounts": [ // 容器挂载数据卷
                            {
                                "mountPath": "/etc/coredns", // 挂载路径
                                "name": "config-volume", // 使用的数据卷的名称
                                "readOnly": true // 设置为只读
                            }
                        ]
                    }
                ],
                "dnsPolicy": "Default", // dns策略
                "restartPolicy": "Always",
                "schedulerName": "default-scheduler",
                "securityContext": {},
                "serviceAccount": "coredns",
                "serviceAccountName": "coredns",
                "terminationGracePeriodSeconds": 30,
                "tolerations": [ // 容忍
                    {
                        "key": "CriticalAddonsOnly",
                        "operator": "Exists"
                    },
                    {
                        "effect": "NoSchedule",
                        "key": "node-role.kubernetes.io/master"
                    }
                ],
                "volumes": [ // 数据卷
                    {
                        "configMap": { // 将ConfigMap作为数据卷
                            "defaultMode": 420,
                            "items": [
                                {
                                    "key": "Corefile",
                                    "path": "Corefile"
                                }
                            ],
                            "name": "coredns"
                        },
                        "name": "config-volume"
                    }
                ]
            }
        }
    },
    "status": {
        "availableReplicas": 1,
        "conditions": [
            {
                "lastTransitionTime": "2019-04-22T12:55:17Z",
                "lastUpdateTime": "2019-04-22T12:55:17Z",
                "message": "Deployment has minimum availability.",
                "reason": "MinimumReplicasAvailable",
                "status": "True",
                "type": "Available"
            },
            {
                "lastTransitionTime": "2019-04-22T12:55:16Z",
                "lastUpdateTime": "2019-04-22T12:55:17Z",
                "message": "ReplicaSet \"coredns-86c58d9df4\" has successfully progressed.",
                "reason": "NewReplicaSetAvailable",
                "status": "True",
                "type": "Progressing"
            }
        ],
        "observedGeneration": 2,
        "readyReplicas": 1,
        "replicas": 1,
        "updatedReplicas": 1
    }
}
```

### 创建Deployment

##### 请求

POST /v1/namespaces/{namespace}/deployments

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 请求体

```json
{
    "apiVersion": "apps/v1", // 资源版本
    "kind": "Deployment", //资源类型
    "metadata": {
        "labels": { // deployment标签
            "k8s-app": "kube-dns"
        },
        "name": "coredns", // 资源名称
        "namespace": "kube-system", // 命名空间
    },
    "spec": {
        "replicas": 1, // 副本数
        "selector": {
            "matchLabels": { // 选择POD的标签
                "k8s-app": "kube-dns"
            }
        },
        "strategy": { // 滚动更新的策略
            "rollingUpdate": {
                "maxSurge": "25%",
                "maxUnavailable": 1
            },
            "type": "RollingUpdate"
        },
        "template": { // POD模版
            "metadata": {
                "labels": { // POD的标签
                    "k8s-app": "kube-dns"
                }
            },
            "spec": {
                "containers": [
                    {
                        "args": [ // 启动参数
                            "-conf",
                            "/etc/coredns/Corefile"
                        ],
                        "image": "k8s.gcr.io/coredns:1.2.6",
                        "imagePullPolicy": "IfNotPresent",
                        "livenessProbe": {
                            "failureThreshold": 5,
                            "httpGet": {
                                "path": "/health",
                                "port": 8080,
                                "scheme": "HTTP"
                            },
                            "initialDelaySeconds": 60,
                            "periodSeconds": 10,
                            "successThreshold": 1,
                            "timeoutSeconds": 5
                        },
                        "name": "coredns", // 容器名
                        "ports": [ // 容器端口
                            {
                                "containerPort": 53,
                                "name": "dns", // 端口名
                                "protocol": "UDP" // 端口协议
                            },
                            {
                                "containerPort": 53,
                                "name": "dns-tcp",
                                "protocol": "TCP"
                            },
                            {
                                "containerPort": 9153,
                                "name": "metrics",
                                "protocol": "TCP"
                            }
                        ],
                        "resources": { // 资源限制
                            "limits": {
                                "memory": "170Mi" // 限制内存
                            },
                            "requests": {
                                "cpu": "100m",
                                "memory": "70Mi"
                            }
                        },
                        "securityContext": { // 设置安全上下文
                            "allowPrivilegeEscalation": false,
                            "capabilities": {
                                "add": [
                                    "NET_BIND_SERVICE"
                                ],
                                "drop": [
                                    "all"
                                ]
                            },
                            "procMount": "Default",
                            "readOnlyRootFilesystem": true
                        },
                        "terminationMessagePath": "/dev/termination-log",
                        "terminationMessagePolicy": "File",
                        "volumeMounts": [ // 容器挂载数据卷
                            {
                                "mountPath": "/etc/coredns", // 挂载路径
                                "name": "config-volume", // 使用的数据卷的名称
                                "readOnly": true // 设置为只读
                            }
                        ]
                    }
                ],
                "serviceAccountName": "coredns",
                "tolerations": [ // 容忍
                    {
                        "key": "CriticalAddonsOnly",
                        "operator": "Exists"
                    },
                    {
                        "effect": "NoSchedule",
                        "key": "node-role.kubernetes.io/master"
                    }
                ],
                "volumes": [ // 数据卷
                    {
                        "configMap": { // 将ConfigMap作为数据卷
                            "defaultMode": 420,
                            "items": [
                                {
                                    "key": "Corefile",
                                    "path": "Corefile"
                                }
                            ],
                            "name": "coredns"
                        },
                        "name": "config-volume"
                    }
                ]
            }
        }
    }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "apps/v1", // 资源版本
    "kind": "Deployment", //资源类型
    "metadata": {
        "annotations": { // 注解
            "deployment.kubernetes.io/revision": "1"
        },
        "creationTimestamp": "2019-04-22T12:55:15Z", //创建时间
        "generation": 2,
        "labels": { // deployment标签
            "k8s-app": "kube-dns"
        },
        "name": "coredns", // 资源名称
        "namespace": "kube-system", // 命名空间
        "resourceVersion": "7754",
        "selfLink": "/apis/apps/v1/namespaces/kube-system/deployments/coredns",
        "uid": "e00d0967-64fd-11e9-a452-000c29f93cb4"
    },
    "spec": {
        "progressDeadlineSeconds": 600,
        "replicas": 1, // 副本数
        "revisionHistoryLimit": 10, // 保留的历史版本上限
        "selector": {
            "matchLabels": { // 选择POD的标签
                "k8s-app": "kube-dns"
            }
        },
        "strategy": { // 滚动更新的策略
            "rollingUpdate": {
                "maxSurge": "25%",
                "maxUnavailable": 1
            },
            "type": "RollingUpdate"
        },
        "template": { // POD模版
            "metadata": {
                "creationTimestamp": null,
                "labels": { // POD的标签
                    "k8s-app": "kube-dns"
                }
            },
            "spec": {
                "containers": [
                    {
                        "args": [ // 启动参数
                            "-conf",
                            "/etc/coredns/Corefile"
                        ],
                        "image": "k8s.gcr.io/coredns:1.2.6",
                        "imagePullPolicy": "IfNotPresent",
                        "livenessProbe": {
                            "failureThreshold": 5,
                            "httpGet": {
                                "path": "/health",
                                "port": 8080,
                                "scheme": "HTTP"
                            },
                            "initialDelaySeconds": 60,
                            "periodSeconds": 10,
                            "successThreshold": 1,
                            "timeoutSeconds": 5
                        },
                        "name": "coredns", // 容器名
                        "ports": [ // 容器端口
                            {
                                "containerPort": 53,
                                "name": "dns", // 端口名
                                "protocol": "UDP" // 端口协议
                            },
                            {
                                "containerPort": 53,
                                "name": "dns-tcp",
                                "protocol": "TCP"
                            },
                            {
                                "containerPort": 9153,
                                "name": "metrics",
                                "protocol": "TCP"
                            }
                        ],
                        "resources": { // 资料限制
                            "limits": {
                                "memory": "170Mi" // 限制内存
                            },
                            "requests": {
                                "cpu": "100m",
                                "memory": "70Mi"
                            }
                        },
                        "securityContext": { // 设置安全上下文
                            "allowPrivilegeEscalation": false,
                            "capabilities": {
                                "add": [
                                    "NET_BIND_SERVICE"
                                ],
                                "drop": [
                                    "all"
                                ]
                            },
                            "procMount": "Default",
                            "readOnlyRootFilesystem": true
                        },
                        "terminationMessagePath": "/dev/termination-log",
                        "terminationMessagePolicy": "File",
                        "volumeMounts": [ // 容器挂载数据卷
                            {
                                "mountPath": "/etc/coredns", // 挂载路径
                                "name": "config-volume", // 使用的数据卷的名称
                                "readOnly": true // 设置为只读
                            }
                        ]
                    }
                ],
                "dnsPolicy": "Default", // dns策略
                "restartPolicy": "Always",
                "schedulerName": "default-scheduler",
                "securityContext": {},
                "serviceAccount": "coredns",
                "serviceAccountName": "coredns",
                "terminationGracePeriodSeconds": 30,
                "tolerations": [ // 容忍
                    {
                        "key": "CriticalAddonsOnly",
                        "operator": "Exists"
                    },
                    {
                        "effect": "NoSchedule",
                        "key": "node-role.kubernetes.io/master"
                    }
                ],
                "volumes": [ // 数据卷
                    {
                        "configMap": { // 将ConfigMap作为数据卷
                            "defaultMode": 420,
                            "items": [
                                {
                                    "key": "Corefile",
                                    "path": "Corefile"
                                }
                            ],
                            "name": "coredns"
                        },
                        "name": "config-volume"
                    }
                ]
            }
        }
    },
    "status": {
        "availableReplicas": 1,
        "conditions": [
            {
                "lastTransitionTime": "2019-04-22T12:55:17Z",
                "lastUpdateTime": "2019-04-22T12:55:17Z",
                "message": "Deployment has minimum availability.",
                "reason": "MinimumReplicasAvailable",
                "status": "True",
                "type": "Available"
            },
            {
                "lastTransitionTime": "2019-04-22T12:55:16Z",
                "lastUpdateTime": "2019-04-22T12:55:17Z",
                "message": "ReplicaSet \"coredns-86c58d9df4\" has successfully progressed.",
                "reason": "NewReplicaSetAvailable",
                "status": "True",
                "type": "Progressing"
            }
        ],
        "observedGeneration": 2,
        "readyReplicas": 1,
        "replicas": 1,
        "updatedReplicas": 1
    }
}
```

### 更新Deployment

##### 请求

PUT /v1/namespaces/{namespace}/deployments/{name}

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
| name | deployment的名称 |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 请求体

```json
{
    "apiVersion": "apps/v1", // 资源版本
    "kind": "Deployment", //资源类型
    "metadata": {
        "annotations": { // 注解
            "deployment.kubernetes.io/revision": "1"
        },
        "creationTimestamp": "2019-04-22T12:55:15Z", //创建时间
        "generation": 2,
        "labels": { // deployment标签
            "k8s-app": "kube-dns"
        },
        "name": "coredns", // 资源名称
        "namespace": "kube-system", // 命名空间
        "resourceVersion": "7754",
        "selfLink": "/apis/apps/v1/namespaces/kube-system/deployments/coredns",
        "uid": "e00d0967-64fd-11e9-a452-000c29f93cb4"
    },
    "spec": {
        "progressDeadlineSeconds": 600,
        "replicas": 1, // 副本数
        "revisionHistoryLimit": 10, // 保留的历史版本上限
        "selector": {
            "matchLabels": { // 选择POD的标签
                "k8s-app": "kube-dns"
            }
        },
        "strategy": { // 滚动更新的策略
            "rollingUpdate": {
                "maxSurge": "25%",
                "maxUnavailable": 1
            },
            "type": "RollingUpdate"
        },
        "template": { // POD模版
            "metadata": {
                "creationTimestamp": null,
                "labels": { // POD的标签
                    "k8s-app": "kube-dns"
                }
            },
            "spec": {
                "containers": [
                    {
                        "args": [ // 启动参数
                            "-conf",
                            "/etc/coredns/Corefile"
                        ],
                        "image": "k8s.gcr.io/coredns:1.2.6",
                        "imagePullPolicy": "IfNotPresent",
                        "livenessProbe": {
                            "failureThreshold": 5,
                            "httpGet": {
                                "path": "/health",
                                "port": 8080,
                                "scheme": "HTTP"
                            },
                            "initialDelaySeconds": 60,
                            "periodSeconds": 10,
                            "successThreshold": 1,
                            "timeoutSeconds": 5
                        },
                        "name": "coredns", // 容器名
                        "ports": [ // 容器端口
                            {
                                "containerPort": 53,
                                "name": "dns", // 端口名
                                "protocol": "UDP" // 端口协议
                            },
                            {
                                "containerPort": 53,
                                "name": "dns-tcp",
                                "protocol": "TCP"
                            },
                            {
                                "containerPort": 9153,
                                "name": "metrics",
                                "protocol": "TCP"
                            }
                        ],
                        "resources": { // 资料限制
                            "limits": {
                                "memory": "170Mi" // 限制内存
                            },
                            "requests": {
                                "cpu": "100m",
                                "memory": "70Mi"
                            }
                        },
                        "securityContext": { // 设置安全上下文
                            "allowPrivilegeEscalation": false,
                            "capabilities": {
                                "add": [
                                    "NET_BIND_SERVICE"
                                ],
                                "drop": [
                                    "all"
                                ]
                            },
                            "procMount": "Default",
                            "readOnlyRootFilesystem": true
                        },
                        "terminationMessagePath": "/dev/termination-log",
                        "terminationMessagePolicy": "File",
                        "volumeMounts": [ // 容器挂载数据卷
                            {
                                "mountPath": "/etc/coredns", // 挂载路径
                                "name": "config-volume", // 使用的数据卷的名称
                                "readOnly": true // 设置为只读
                            }
                        ]
                    }
                ],
                "dnsPolicy": "Default", // dns策略
                "restartPolicy": "Always",
                "schedulerName": "default-scheduler",
                "securityContext": {},
                "serviceAccount": "coredns",
                "serviceAccountName": "coredns",
                "terminationGracePeriodSeconds": 30,
                "tolerations": [ // 容忍
                    {
                        "key": "CriticalAddonsOnly",
                        "operator": "Exists"
                    },
                    {
                        "effect": "NoSchedule",
                        "key": "node-role.kubernetes.io/master"
                    }
                ],
                "volumes": [ // 数据卷
                    {
                        "configMap": { // 将ConfigMap作为数据卷
                            "defaultMode": 420,
                            "items": [
                                {
                                    "key": "Corefile",
                                    "path": "Corefile"
                                }
                            ],
                            "name": "coredns"
                        },
                        "name": "config-volume"
                    }
                ]
            }
        }
    },
    "status": {
        "availableReplicas": 1,
        "conditions": [
            {
                "lastTransitionTime": "2019-04-22T12:55:17Z",
                "lastUpdateTime": "2019-04-22T12:55:17Z",
                "message": "Deployment has minimum availability.",
                "reason": "MinimumReplicasAvailable",
                "status": "True",
                "type": "Available"
            },
            {
                "lastTransitionTime": "2019-04-22T12:55:16Z",
                "lastUpdateTime": "2019-04-22T12:55:17Z",
                "message": "ReplicaSet \"coredns-86c58d9df4\" has successfully progressed.",
                "reason": "NewReplicaSetAvailable",
                "status": "True",
                "type": "Progressing"
            }
        ],
        "observedGeneration": 2,
        "readyReplicas": 1,
        "replicas": 1,
        "updatedReplicas": 1
    }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "apps/v1", // 资源版本
    "kind": "Deployment", //资源类型
    "metadata": {
        "annotations": { // 注解
            "deployment.kubernetes.io/revision": "1"
        },
        "creationTimestamp": "2019-04-22T12:55:15Z", //创建时间
        "generation": 2,
        "labels": { // deployment标签
            "k8s-app": "kube-dns"
        },
        "name": "coredns", // 资源名称
        "namespace": "kube-system", // 命名空间
        "resourceVersion": "7754",
        "selfLink": "/apis/apps/v1/namespaces/kube-system/deployments/coredns",
        "uid": "e00d0967-64fd-11e9-a452-000c29f93cb4"
    },
    "spec": {
        "progressDeadlineSeconds": 600,
        "replicas": 1, // 副本数
        "revisionHistoryLimit": 10, // 保留的历史版本上限
        "selector": {
            "matchLabels": { // 选择POD的标签
                "k8s-app": "kube-dns"
            }
        },
        "strategy": { // 滚动更新的策略
            "rollingUpdate": {
                "maxSurge": "25%",
                "maxUnavailable": 1
            },
            "type": "RollingUpdate"
        },
        "template": { // POD模版
            "metadata": {
                "creationTimestamp": null,
                "labels": { // POD的标签
                    "k8s-app": "kube-dns"
                }
            },
            "spec": {
                "containers": [
                    {
                        "args": [ // 启动参数
                            "-conf",
                            "/etc/coredns/Corefile"
                        ],
                        "image": "k8s.gcr.io/coredns:1.2.6",
                        "imagePullPolicy": "IfNotPresent",
                        "livenessProbe": {
                            "failureThreshold": 5,
                            "httpGet": {
                                "path": "/health",
                                "port": 8080,
                                "scheme": "HTTP"
                            },
                            "initialDelaySeconds": 60,
                            "periodSeconds": 10,
                            "successThreshold": 1,
                            "timeoutSeconds": 5
                        },
                        "name": "coredns", // 容器名
                        "ports": [ // 容器端口
                            {
                                "containerPort": 53,
                                "name": "dns", // 端口名
                                "protocol": "UDP" // 端口协议
                            },
                            {
                                "containerPort": 53,
                                "name": "dns-tcp",
                                "protocol": "TCP"
                            },
                            {
                                "containerPort": 9153,
                                "name": "metrics",
                                "protocol": "TCP"
                            }
                        ],
                        "resources": { // 资料限制
                            "limits": {
                                "memory": "170Mi" // 限制内存
                            },
                            "requests": {
                                "cpu": "100m",
                                "memory": "70Mi"
                            }
                        },
                        "securityContext": { // 设置安全上下文
                            "allowPrivilegeEscalation": false,
                            "capabilities": {
                                "add": [
                                    "NET_BIND_SERVICE"
                                ],
                                "drop": [
                                    "all"
                                ]
                            },
                            "procMount": "Default",
                            "readOnlyRootFilesystem": true
                        },
                        "terminationMessagePath": "/dev/termination-log",
                        "terminationMessagePolicy": "File",
                        "volumeMounts": [ // 容器挂载数据卷
                            {
                                "mountPath": "/etc/coredns", // 挂载路径
                                "name": "config-volume", // 使用的数据卷的名称
                                "readOnly": true // 设置为只读
                            }
                        ]
                    }
                ],
                "dnsPolicy": "Default", // dns策略
                "restartPolicy": "Always",
                "schedulerName": "default-scheduler",
                "securityContext": {},
                "serviceAccount": "coredns",
                "serviceAccountName": "coredns",
                "terminationGracePeriodSeconds": 30,
                "tolerations": [ // 容忍
                    {
                        "key": "CriticalAddonsOnly",
                        "operator": "Exists"
                    },
                    {
                        "effect": "NoSchedule",
                        "key": "node-role.kubernetes.io/master"
                    }
                ],
                "volumes": [ // 数据卷
                    {
                        "configMap": { // 将ConfigMap作为数据卷
                            "defaultMode": 420,
                            "items": [
                                {
                                    "key": "Corefile",
                                    "path": "Corefile"
                                }
                            ],
                            "name": "coredns"
                        },
                        "name": "config-volume"
                    }
                ]
            }
        }
    },
    "status": {
        "availableReplicas": 1,
        "conditions": [
            {
                "lastTransitionTime": "2019-04-22T12:55:17Z",
                "lastUpdateTime": "2019-04-22T12:55:17Z",
                "message": "Deployment has minimum availability.",
                "reason": "MinimumReplicasAvailable",
                "status": "True",
                "type": "Available"
            },
            {
                "lastTransitionTime": "2019-04-22T12:55:16Z",
                "lastUpdateTime": "2019-04-22T12:55:17Z",
                "message": "ReplicaSet \"coredns-86c58d9df4\" has successfully progressed.",
                "reason": "NewReplicaSetAvailable",
                "status": "True",
                "type": "Progressing"
            }
        ],
        "observedGeneration": 2,
        "readyReplicas": 1,
        "replicas": 1,
        "updatedReplicas": 1
    }
}
```

### 删除Deployment

##### 请求

DELETE /v1/namespaces/{namespace}/deployments/{name}

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
| name | deployment的名称 |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 获取deployment下的pod列表

##### 请求

GET /v1/namespaces/{namespace}/deployments/{name}/pods

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
| name | deployment的名称 |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "List",
    "apiVersion": "v1",
    "metadata": {
        "selfLink": "/api/v1/namespaces/kube-system/pods",
        "resourceVersion": "11334709"
    },
    "items": [
        {
            "kind": "Pod",
            "apiVersion": "v1",
            "metadata": {
                "name": "coredns-0",
                "generateName": "coredns-",
                "namespace": "kube-system",
                "selfLink": "/api/v1/namespaces/kube-system/pods/coredns-0",
                "uid": "0d3e1285-7164-11e9-83af-005056b595d6",
                "resourceVersion": "11125381",
                "creationTimestamp": "2019-05-08T07:36:54Z",
                "labels": {
                    "controller-revision-hash": "coredns-74fc4c94dc",
                    "k8s-app": "kube-dns",
                    "statefulset.kubernetes.io/pod-name": "coredns-0"
                },
                "ownerReferences": [
                    {
                        "apiVersion": "apps/v1",
                        "kind": "StatefulSet",
                        "name": "coredns",
                        "uid": "0d3b15db-7164-11e9-83af-005056b595d6",
                        "controller": true,
                        "blockOwnerDeletion": true
                    }
                ]
            },
            "spec": {
                "volumes": [
                    {
                        "name": "config-volume",
                        "configMap": {
                            "name": "coredns",
                            "items": [
                                {
                                    "key": "Corefile",
                                    "path": "Corefile"
                                }
                            ],
                            "defaultMode": 420
                        }
                    },
                    {
                        "name": "default-token-9v654",
                        "secret": {
                            "secretName": "default-token-9v654",
                            "defaultMode": 420
                        }
                    }
                ],
                "containers": [
                    {
                        "name": "coredns",
                        "image": "k8s.gcr.io/coredns:1.2.6",
                        "args": [
                            "-conf",
                            "/etc/coredns/Corefile"
                        ],
                        "ports": [
                            {
                                "name": "dns",
                                "containerPort": 53,
                                "protocol": "UDP"
                            },
                            {
                                "name": "dns-tcp",
                                "containerPort": 53,
                                "protocol": "TCP"
                            },
                            {
                                "name": "metrics",
                                "containerPort": 9153,
                                "protocol": "TCP"
                            }
                        ],
                        "resources": {
                            "limits": {
                                "memory": "170Mi"
                            },
                            "requests": {
                                "cpu": "100m",
                                "memory": "70Mi"
                            }
                        },
                        "volumeMounts": [
                            {
                                "name": "config-volume",
                                "readOnly": true,
                                "mountPath": "/etc/coredns"
                            },
                            {
                                "name": "default-token-9v654",
                                "readOnly": true,
                                "mountPath": "/var/run/secrets/kubernetes.io/serviceaccount"
                            }
                        ],
                        "livenessProbe": {
                            "httpGet": {
                                "path": "/health",
                                "port": 8080,
                                "scheme": "HTTP"
                            },
                            "initialDelaySeconds": 60,
                            "timeoutSeconds": 5,
                            "periodSeconds": 10,
                            "successThreshold": 1,
                            "failureThreshold": 5
                        },
                        "terminationMessagePath": "/dev/terminationlog",
                        "terminationMessagePolicy": "File",
                        "imagePullPolicy": "IfNotPresent",
                        "securityContext": {
                            "capabilities": {
                                "add": [
                                    "NET_BIND_SERVICE"
                                ],
                                "drop": [
                                    "all"
                                ]
                            },
                            "readOnlyRootFilesystem": true,
                            "allowPrivilegeEscalation": false
                        }
                    }
                ],
                "restartPolicy": "Always",
                "terminationGracePeriodSeconds": 30,
                "dnsPolicy": "ClusterFirst",
                "serviceAccountName": "default",
                "serviceAccount": "default",
                "nodeName": "ruyiyundev01",
                "securityContext": {},
                "imagePullSecrets": [
                    {
                        "name": "default-dockercfg-wd745"
                    }
                ],
                "hostname": "coredns-0",
                "schedulerName": "default-scheduler",
                "tolerations": [
                    {
                        "key": "node.kubernetes.io/memory-pressure",
                        "operator": "Exists",
                        "effect": "NoSchedule"
                    },
                    {
                        "key": "CriticalAddonsOnly",
                        "operator": "Exists"
                    },
                    {
                        "key": "node-role.kubernetes.io/master",
                        "effect": "NoSchedule"
                    }
                ],
                "priority": 0
            },
            "status": {
                "phase": "Pending",
                "conditions": [
                    {
                        "type": "Initialized",
                        "status": "True",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-05-08T07:36:54Z"
                    },
                    {
                        "type": "Ready",
                        "status": "False",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-05-08T07:36:54Z",
                        "reason": "ContainersNotReady",
                        "message": "containers with unready status: [coredns]"
                    },
                    {
                        "type": "ContainersReady",
                        "status": "False",
                        "lastProbeTime": null,
                        "lastTransitionTime": null,
                        "reason": "ContainersNotReady",
                        "message": "containers with unready status: [coredns]"
                    },
                    {
                        "type": "PodScheduled",
                        "status": "True",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-05-08T07:36:54Z"
                    }
                ],
                "hostIP": "10.203.121.53",
                "startTime": "2019-05-08T07:36:54Z",
                "containerStatuses": [
                    {
                        "name": "coredns",
                        "state": {
                            "waiting": {
                                "reason": "ContainerCreating"
                            }
                        },
                        "lastState": {},
                        "ready": false,
                        "restartCount": 0,
                        "image": "k8s.gcr.io/coredns:1.2.6",
                        "imageID": ""
                    }
                ],
                "qosClass": "Burstable"
            }
        }
    ]
}
```

### 重启deployment

##### 请求

PUT /v1/namespaces/{namespace}/deployments/{name}/restart

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
| name | deployment的名称 |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 获取deployment下的event事件列表

##### 请求

GET /v1/namespaces/{namespace}/deployments/{name}/events

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
| name | deployment的名称 |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "v1",
            "count": 63892,
            "eventTime": null,
            "firstTimestamp": "2019-04-29T09:03:32Z",
            "involvedObject": {
                "apiVersion": "v1",
                "kind": "PersistentVolumeClaim",
                "name": "demo11",
                "namespace": "daocloudcsp",
                "resourceVersion": "9191134",
                "uid": "aa188578-6a5d-11e9-83af-005056b595d6"
            },
            "kind": "Event",
            "lastTimestamp": "2019-05-10T02:43:36Z",
            "message": "no persistent volumes available for this claim and no storage class is set",
            "metadata": {
                "creationTimestamp": "2019-04-29T09:03:32Z",
                "name": "demo11.1599e686d3613168",
                "namespace": "daocloudcsp",
                "resourceVersion": "11618906",
                "selfLink": "/api/v1/namespaces/daocloudcsp/events/demo11.1599e686d3613168",
                "uid": "aa195fa5-6a5d-11e9-83af-005056b595d6"
            },
            "reason": "FailedBinding",
            "reportingComponent": "",
            "reportingInstance": "",
            "source": {
                "component": "persistentvolume-controller"
            },
            "type": "Normal"
        },
        {
            "apiVersion": "v1",
            "count": 130843,
            "eventTime": null,
            "firstTimestamp": "2019-04-18T02:59:24Z",
            "involvedObject": {
                "apiVersion": "v1",
                "kind": "PersistentVolumeClaim",
                "name": "sss",
                "namespace": "daocloudcsp",
                "resourceVersion": "7097245",
                "uid": "f90b0c74-6185-11e9-83af-005056b595d6"
            },
            "kind": "Event",
            "lastTimestamp": "2019-05-10T02:39:36Z",
            "message": "no persistent volumes available for this claim and no storage class is set",
            "metadata": {
                "creationTimestamp": "2019-04-18T02:59:24Z",
                "name": "sss.15967245ab178e56",
                "namespace": "daocloudcsp",
                "resourceVersion": "11618098",
                "selfLink": "/api/v1/namespaces/daocloudcsp/events/sss.15967245ab178e56",
                "uid": "f90ec963-6185-11e9-83af-005056b595d6"
            },
            "reason": "FailedBinding",
            "reportingComponent": "",
            "reportingInstance": "",
            "source": {
                "component": "persistentvolume-controller"
            },
            "type": "Normal"
        },
        {
            "apiVersion": "v1",
            "count": 449,
            "eventTime": null,
            "firstTimestamp": "2019-05-08T05:43:05Z",
            "involvedObject": {
                "apiVersion": "apps/v1",
                "kind": "ReplicaSet",
                "name": "yxltest-c7c9d98df",
                "namespace": "daocloudcsp",
                "resourceVersion": "11104002",
                "uid": "26f406bc-7154-11e9-83af-005056b595d6"
            },
            "kind": "Event",
            "lastTimestamp": "2019-05-10T02:42:50Z",
            "message": "Error creating: pods \"yxltest-c7c9d98df-\" is forbidden: unable to validate against any security context constraint: [capabilities.add: Invalid value: \"NET_BIND_SERVICE\": capability may not be added capabilities.add: Invalid value: \"NET_BIND_SERVICE\": capability may not be added]",
            "metadata": {
                "creationTimestamp": "2019-05-08T05:43:05Z",
                "name": "yxltest-c7c9d98df.159c9ecf99ecbde3",
                "namespace": "daocloudcsp",
                "resourceVersion": "11618731",
                "selfLink": "/api/v1/namespaces/daocloudcsp/events/yxltest-c7c9d98df.159c9ecf99ecbde3",
                "uid": "26f6f966-7154-11e9-83af-005056b595d6"
            },
            "reason": "FailedCreate",
            "reportingComponent": "",
            "reportingInstance": "",
            "source": {
                "component": "replicaset-controller"
            },
            "type": "Warning"
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 更改Deployment的副本数

##### Http Request

PUT /v1/namespaces/{namespace}/deployments/{name}/scale

##### Path Parameters

| Parameter |     Description      |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|   name    |   Deployment的名字   |

##### Query Parameters

| Parameter |             Description              |
| :-------: | :----------------------------------: |
|   zone    | 可用区的唯一标识，为空表示默认可用区 |
| replicas  |            表示期望副本数            |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
  "kind": "Scale",
  "apiVersion": "extensions/v1beta1",
  "metadata": {
    "name": "coredns",
    "namespace": "kube-system",
    "selfLink": "/apis/extensions/v1beta1/namespaces/kube-system/deployments/coredns/scale",
    "uid": "e00d0967-64fd-11e9-a452-000c29f93cb4",
    "resourceVersion": "7754",
    "creationTimestamp": "2019-04-22T12:55:15Z"
  },
  "spec": {
    "replicas": 1 // 期望副本数
  },
  "status": { // 状态
    "replicas": 1, // 当前副本数
    "selector": { 
      "k8s-app": "kube-dns" 
    },
    "targetSelector": "k8s-app=kube-dns"
  }
}
```

### 获取Deployment的历史版本

##### 请求 

##### GET /v1/namespaces/{namespace}/deployments/{name}/replicasets

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|   name    |  deployments的名称   |

##### 查询参数

| 参数名 |                    描述                    |
| :----: | :----------------------------------------: |
|  zone  | 可用区唯一标识，当zone为空时表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [ // replicasets资源对象列表，根据`deployment.kubernetes.io/revision`从大到小排序
        {
            "apiVersion": "extensions/v1beta1",
            "kind": "ReplicaSet",
            "metadata": {
                "annotations": {
                    "deployment.kubernetes.io/desired-replicas": "1", // 记录这个版本的期望副本数，但是由于k8s实现方式的缘故，回滚时此值不起作用
                    "deployment.kubernetes.io/max-replicas": "2", // 记录这个版本的最大副本数数
                    "deployment.kubernetes.io/revision": "11", // 记录这个版本的版本号
                    "deployment.kubernetes.io/revision-history": "1,3,5,7,9" // 记录与这个版本相等的其他历史版本
                },
                "creationTimestamp": "2019-04-26T15:56:46Z",
                "generation": 9,
                "labels": { // rs的标签
                    "addonmanager.kubernetes.io/mode": "Reconcile",
                    "app": "kubernetes-dashboard",
                    "pod-template-hash": "ccc79bfc9", // 记录这个rs对应的pod
                    "version": "v1.10.1"
                },
                "name": "kubernetes-dashboard-ccc79bfc9",
                "namespace": "kube-system",
                "ownerReferences": [
                    {
                        "apiVersion": "apps/v1",
                        "blockOwnerDeletion": true,
                        "controller": true,
                        "kind": "Deployment",
                        "name": "kubernetes-dashboard",
                        "uid": "e50235c3-683b-11e9-a330-000c29f93cb4"
                    }
                ],
                "resourceVersion": "493996",
                "selfLink": "/apis/extensions/v1beta1/namespaces/kube-system/replicasets/kubernetes-dashboard-ccc79bfc9",
                "uid": "e52532bf-683b-11e9-a330-000c29f93cb4"
            },
            "spec": {
                "replicas": 1,
                "selector": {
                    "matchLabels": {
                        "addonmanager.kubernetes.io/mode": "Reconcile",
                        "app": "kubernetes-dashboard",
                        "pod-template-hash": "ccc79bfc9",
                        "version": "v1.10.1"
                    }
                },
                "template": {
                    "metadata": {
                        "creationTimestamp": null,
                        "labels": {
                            "addonmanager.kubernetes.io/mode": "Reconcile",
                            "app": "kubernetes-dashboard",
                            "pod-template-hash": "ccc79bfc9",
                            "version": "v1.10.1"
                        }
                    },
                    "spec": {
                        "containers": [
                            {
                                "image": "k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1",
                                "imagePullPolicy": "IfNotPresent",
                                "livenessProbe": {
                                    "failureThreshold": 3,
                                    "httpGet": {
                                        "path": "/",
                                        "port": 9090,
                                        "scheme": "HTTP"
                                    },
                                    "initialDelaySeconds": 30,
                                    "periodSeconds": 10,
                                    "successThreshold": 1,
                                    "timeoutSeconds": 30
                                },
                                "name": "kubernetes-dashboard",
                                "ports": [
                                    {
                                        "containerPort": 9090,
                                        "protocol": "TCP"
                                    }
                                ],
                                "resources": {},
                                "terminationMessagePath": "/dev/termination-log",
                                "terminationMessagePolicy": "File"
                            }
                        ],
                        "dnsPolicy": "ClusterFirst",
                        "restartPolicy": "Always",
                        "schedulerName": "default-scheduler",
                        "securityContext": {},
                        "terminationGracePeriodSeconds": 30
                    }
                }
            },
            "status": {
                "availableReplicas": 1,
                "fullyLabeledReplicas": 1,
                "observedGeneration": 9,
                "readyReplicas": 1,
                "replicas": 1
            }
        },
        {
            "apiVersion": "extensions/v1beta1",
            "kind": "ReplicaSet",
            "metadata": {
                "annotations": {
                    "deployment.kubernetes.io/desired-replicas": "1",
                    "deployment.kubernetes.io/max-replicas": "2",
                    "deployment.kubernetes.io/revision": "10",
                    "deployment.kubernetes.io/revision-history": "2,4,6,8"
                },
                "creationTimestamp": "2019-04-26T15:58:44Z",
                "generation": 10,
                "labels": {
                    "addonmanager.kubernetes.io/mode": "Reconcile",
                    "app": "kubernetes-dashboard",
                    "pod-template-hash": "f6bddc8f6",
                    "version": "v1.10.1"
                },
                "name": "kubernetes-dashboard-f6bddc8f6",
                "namespace": "kube-system",
                "ownerReferences": [
                    {
                        "apiVersion": "apps/v1",
                        "blockOwnerDeletion": true,
                        "controller": true,
                        "kind": "Deployment",
                        "name": "kubernetes-dashboard",
                        "uid": "e50235c3-683b-11e9-a330-000c29f93cb4"
                    }
                ],
                "resourceVersion": "286569",
                "selfLink": "/apis/extensions/v1beta1/namespaces/kube-system/replicasets/kubernetes-dashboard-f6bddc8f6",
                "uid": "2b03b8bd-683c-11e9-a330-000c29f93cb4"
            },
            "spec": {
                "replicas": 0,
                "selector": {
                    "matchLabels": {
                        "addonmanager.kubernetes.io/mode": "Reconcile",
                        "app": "kubernetes-dashboard",
                        "pod-template-hash": "f6bddc8f6",
                        "version": "v1.10.1"
                    }
                },
                "template": {
                    "metadata": {
                        "creationTimestamp": null,
                        "labels": {
                            "addonmanager.kubernetes.io/mode": "Reconcile",
                            "app": "kubernetes-dashboard",
                            "pod-template-hash": "f6bddc8f6",
                            "version": "v1.10.1"
                        }
                    },
                    "spec": {
                        "containers": [
                            {
                                "image": "k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1",
                                "imagePullPolicy": "IfNotPresent",
                                "name": "kubernetes-dashboard",
                                "ports": [
                                    {
                                        "containerPort": 9090,
                                        "protocol": "TCP"
                                    }
                                ],
                                "resources": {},
                                "terminationMessagePath": "/dev/termination-log",
                                "terminationMessagePolicy": "File"
                            }
                        ],
                        "dnsPolicy": "ClusterFirst",
                        "restartPolicy": "Always",
                        "schedulerName": "default-scheduler",
                        "securityContext": {},
                        "terminationGracePeriodSeconds": 30
                    }
                }
            },
            "status": {
                "observedGeneration": 10,
                "replicas": 0
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 回滚Deployment到指定版本

##### 请求 

##### PUT /v1/namespaces/{namespace}/deployments/{name}/rollback

##### 路径参数

|  参数名   |      描述      |
| :-------: | :------------: |
| namespace |    命名空间    |
|   name    | Deployment名称 |

##### 查询参数

|  参数名  |                    描述                    |
| :------: | :----------------------------------------: |
|   zone   | 可用区唯一标识，当zone为空时表示默认可用区 |
| revision |                某个历史版本                |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```