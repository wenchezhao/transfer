### 创建SCC

##### 请求

POST /v1/securitycontextconstraints

##### 路径参数

无

##### 请求头参数

| 参数名       | 描述      |
|:---------:|:-------:|
| clusterID | 可用区唯一标识 |

##### 请求体参数

```json
{
    "allowHostDirVolumePlugin": true,
    "allowHostIPC": false,
    "allowHostNetwork": false,
    "allowHostPID": false,
    "allowHostPorts": false,
    "allowPrivilegedContainer": false,
    "allowedCapabilities": [
        "*"
    ],
    "apiVersion": "v1",
    "defaultAddCapabilities": [],
    "fsGroup": {
        "type": "RunAsAny"
    },
    "groups": [
        "system:authenticated"
    ],
    "kind": "SecurityContextConstraints",
    "metadata": {
        "annotations": {
            "kubernetes.io/description": "for test scc"
        },
        "name": "new-scc"
    },
    "priority": null,
    "readOnlyRootFilesystem": false,
    "runAsUser": {
        "type": "RunAsAny"
    },
    "seLinuxContext": {
        "type": "RunAsAny"
    },
    "supplementalGroups": {
        "type": "RunAsAny"
    },
    "volumes": [
        "configMap",
        "downwardAPI",
        "emptyDir",
        "persistentVolumeClaim",
        "projected",
        "secret"
    ]
}
```

 ##### 响应

| Code | Description |
|:----:|:-----------:|
| 200  | OK          |

```json
{
    "kind": "SecurityContextConstraints",
    "apiVersion": "security.openshift.io/v1",
    "metadata": {
        "name": "new-scc",
        "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/new-scc",
        "uid": "8510f4a7-aa4f-11ec-9887-005056b4eb0e",
        "resourceVersion": "111030087",
        "creationTimestamp": "2022-03-23T02:18:25Z",
        "annotations": {
            "kubernetes.io/description": "for test scc"
        }
    },
    "priority": null,
    "allowPrivilegedContainer": false,
    "defaultAddCapabilities": null,
    "requiredDropCapabilities": null,
    "allowedCapabilities": [
        "*"
    ],
    "allowHostDirVolumePlugin": true,
    "volumes": [
        "configMap",
        "downwardAPI",
        "emptyDir",
        "hostPath",
        "persistentVolumeClaim",
        "projected",
        "secret"
    ],
    "allowHostNetwork": false,
    "allowHostPorts": false,
    "allowHostPID": false,
    "allowHostIPC": false,
    "allowPrivilegeEscalation": true,
    "seLinuxContext": {
        "type": "RunAsAny"
    },
    "runAsUser": {
        "type": "RunAsAny"
    },
    "supplementalGroups": {
        "type": "RunAsAny"
    },
    "fsGroup": {
        "type": "RunAsAny"
    },
    "readOnlyRootFilesystem": false,
    "users": [],
    "groups": [
        "system:authenticated"
    ]
}
```

### 更新SCC

##### 请求

##### PUT /v1/securitycontextconstraints/{name}

##### 路径参数

| 参数名  | 描述     |
|:----:|:------:|
| name | scc的名称 |

##### 请求头参数

| 参数名       | 描述      |
|:---------:|:-------:|
| clusterID | 可用区唯一标识 |

##### 请求体参数

```json
{
    "allowHostDirVolumePlugin": true,
    "allowHostIPC": false,
    "allowHostNetwork": false,
    "allowHostPID": false,
    "allowHostPorts": false,
    "allowPrivilegedContainer": false,
    "allowedCapabilities": [
        "*"
    ],
    "apiVersion": "v1",
    "defaultAddCapabilities": [],
    "fsGroup": {
        "type": "RunAsAny"
    },
    "groups": [
        "system:authenticated"
    ],
    "kind": "SecurityContextConstraints",
    "metadata": {
        "annotations": {
            "kubernetes.io/description": "for test scc"
        },
        "name": "new-scc"
    },
    "priority": null,
    "readOnlyRootFilesystem": false,
    "runAsUser": {
        "type": "RunAsAny"
    },
    "seLinuxContext": {
        "type": "RunAsAny"      
    },
    "supplementalGroups": {
        "type": "MustRunAs"
    },
    "volumes": [
        "configMap",
        "downwardAPI",
        "emptyDir",
        "persistentVolumeClaim",
        "projected",
        "secret"
    ]
}
```

##### 响应

| Code | Description |
|:----:|:-----------:|
| 200  | OK          |

```json
{
    "kind": "SecurityContextConstraints",
    "apiVersion": "security.openshift.io/v1",
    "metadata": {
        "name": "new-scc",
        "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/new-scc",
        "uid": "8510f4a7-aa4f-11ec-9887-005056b4eb0e",
        "resourceVersion": "111032180",
        "creationTimestamp": "2022-03-23T02:18:25Z",
        "annotations": {
            "kubernetes.io/description": "for test scc"
        }
    },
    "priority": null,
    "allowPrivilegedContainer": false,
    "defaultAddCapabilities": null,
    "requiredDropCapabilities": null,
    "allowedCapabilities": [
        "*"
    ],
    "allowHostDirVolumePlugin": true,
    "volumes": [
        "configMap",
        "downwardAPI",
        "emptyDir",
        "hostPath",
        "persistentVolumeClaim",
        "projected",
        "secret"
    ],
    "allowHostNetwork": false,
    "allowHostPorts": false,
    "allowHostPID": false,
    "allowHostIPC": false,
    "allowPrivilegeEscalation": true,
    "seLinuxContext": {
        "type": "RunAsAny"
    },
    "runAsUser": {
        "type": "RunAsAny"
    },
    "supplementalGroups": {
        "type": "MustRunAs"
    },
    "fsGroup": {
        "type": "RunAsAny"
    },
    "readOnlyRootFilesystem": false,
    "users": [],
    "groups": [
        "system:authenticated"
    ]
}
```

### 获取SCC列表

##### 请求

GET /v1/securitycontextconstraints

##### 路径参数

无

##### 请求头参数

| 参数名       | 描述      |
|:---------:|:-------:|
| clusterID | 可用区唯一标识 |

##### 响应

| Code | Description |
|:----:|:-----------:|
| 200  | OK          |

```json
{
    "kind": "SecurityContextConstraints",
    "apiVersion": "security.openshift.io/v1",
    "metadata": {
        "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints",
        "resourceVersion": "110704364"
    },
    "items": [
        {
            "metadata": {
                "name": "anyuid",
                "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/anyuid",
                "uid": "e9f00e2d-a33a-11eb-9306-005056b4eb0e",
                "resourceVersion": "15089714",
                "creationTimestamp": "2021-04-22T07:18:19Z",
                "annotations": {
                    "kubernetes.io/description": "anyuid provides all features of the restricted SCC but allows users to run with any UID and any GID."
                }
            },
            "priority": 10,
            "allowPrivilegedContainer": false,
            "defaultAddCapabilities": null,
            "requiredDropCapabilities": [
                "MKNOD"
            ],
            "allowedCapabilities": null,
            "allowHostDirVolumePlugin": false,
            "volumes": [
                "configMap",
                "downwardAPI",
                "emptyDir",
                "persistentVolumeClaim",
                "projected",
                "secret"
            ],
            "allowHostNetwork": false,
            "allowHostPorts": false,
            "allowHostPID": false,
            "allowHostIPC": false,
            "allowPrivilegeEscalation": true,
            "seLinuxContext": {
                "type": "MustRunAs"
            },
            "runAsUser": {
                "type": "RunAsAny"
            },
            "supplementalGroups": {
                "type": "RunAsAny"
            },
            "fsGroup": {
                "type": "RunAsAny"
            },
            "readOnlyRootFilesystem": false,
            "users": [
                "system:serviceaccount:yanggang2:default"
            ],
            "groups": [
                "system:cluster-admins"
            ]
        },
        {
            "metadata": {
                "name": "hostaccess",
                "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/hostaccess",
                "uid": "e9eeed63-a33a-11eb-9306-005056b4eb0e",
                "resourceVersion": "52",
                "creationTimestamp": "2021-04-22T07:18:19Z",
                "annotations": {
                    "kubernetes.io/description": "hostaccess allows access to all host namespaces but still requires pods to be run with a UID and SELinux context that are allocated to the namespace. WARNING: this SCC allows host access to namespaces, file systems, and PIDS.  It should only be used by trusted pods.  Grant with caution."
                }
            },
            "priority": null,
            "allowPrivilegedContainer": false,
            "defaultAddCapabilities": null,
            "requiredDropCapabilities": [
                "KILL",
                "MKNOD",
                "SETUID",
                "SETGID"
            ],
            "allowedCapabilities": null,
            "allowHostDirVolumePlugin": true,
            "volumes": [
                "configMap",
                "downwardAPI",
                "emptyDir",
                "hostPath",
                "persistentVolumeClaim",
                "projected",
                "secret"
            ],
            "allowHostNetwork": true,
            "allowHostPorts": true,
            "allowHostPID": true,
            "allowHostIPC": true,
            "allowPrivilegeEscalation": true,
            "seLinuxContext": {
                "type": "MustRunAs"
            },
            "runAsUser": {
                "type": "MustRunAsRange"
            },
            "supplementalGroups": {
                "type": "RunAsAny"
            },
            "fsGroup": {
                "type": "MustRunAs"
            },
            "readOnlyRootFilesystem": false,
            "users": [],
            "groups": []
        },
        {
            "metadata": {
                "name": "hostmount-anyuid",
                "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/hostmount-anyuid",
                "uid": "e9ee54b2-a33a-11eb-9306-005056b4eb0e",
                "resourceVersion": "206618",
                "creationTimestamp": "2021-04-22T07:18:19Z",
                "annotations": {
                    "kubernetes.io/description": "hostmount-anyuid provides all the features of the restricted SCC but allows host mounts and any UID by a pod.  This is primarily used by the persistent volume recycler. WARNING: this SCC allows host file system access as any UID, including UID 0.  Grant with caution."
                }
            },
            "priority": null,
            "allowPrivilegedContainer": false,
            "defaultAddCapabilities": null,
            "requiredDropCapabilities": [
                "MKNOD"
            ],
            "allowedCapabilities": null,
            "allowHostDirVolumePlugin": true,
            "volumes": [
                "configMap",
                "downwardAPI",
                "emptyDir",
                "hostPath",
                "nfs",
                "persistentVolumeClaim",
                "projected",
                "secret"
            ],
            "allowHostNetwork": false,
            "allowHostPorts": false,
            "allowHostPID": false,
            "allowHostIPC": false,
            "allowPrivilegeEscalation": true,
            "seLinuxContext": {
                "type": "MustRunAs"
            },
            "runAsUser": {
                "type": "RunAsAny"
            },
            "supplementalGroups": {
                "type": "RunAsAny"
            },
            "fsGroup": {
                "type": "RunAsAny"
            },
            "readOnlyRootFilesystem": false,
            "users": [
                "system:serviceaccount:openshift-infra:pv-recycler-controller",
                "system:serviceaccount:kube-service-catalog:service-catalog-apiserver",
                "system:serviceaccount:nfs-provisoner:nfs-client-provisioner"
            ],
            "groups": []
        },
        {
            "metadata": {
                "name": "hostnetwork",
                "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/hostnetwork",
                "uid": "e9f08a57-a33a-11eb-9306-005056b4eb0e",
                "resourceVersion": "17327",
                "creationTimestamp": "2021-04-22T07:18:19Z",
                "annotations": {
                    "kubernetes.io/description": "hostnetwork allows using host networking and host ports but still requires pods to be run with a UID and SELinux context that are allocated to the namespace."
                }
            },
            "priority": null,
            "allowPrivilegedContainer": false,
            "defaultAddCapabilities": null,
            "requiredDropCapabilities": [
                "KILL",
                "MKNOD",
                "SETUID",
                "SETGID"
            ],
            "allowedCapabilities": null,
            "allowHostDirVolumePlugin": false,
            "volumes": [
                "configMap",
                "downwardAPI",
                "emptyDir",
                "persistentVolumeClaim",
                "projected",
                "secret"
            ],
            "allowHostNetwork": true,
            "allowHostPorts": true,
            "allowHostPID": false,
            "allowHostIPC": false,
            "allowPrivilegeEscalation": true,
            "seLinuxContext": {
                "type": "MustRunAs"
            },
            "runAsUser": {
                "type": "MustRunAsRange"
            },
            "supplementalGroups": {
                "type": "MustRunAs"
            },
            "fsGroup": {
                "type": "MustRunAs"
            },
            "readOnlyRootFilesystem": false,
            "users": [
                "system:serviceaccount:default:router",
                "system:serviceaccount:default:registry"
            ],
            "groups": []
        },
        {
            "metadata": {
                "name": "node-exporter",
                "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/node-exporter",
                "uid": "1c8f940f-a353-11eb-b42d-005056b4eb0e",
                "resourceVersion": "18317",
                "creationTimestamp": "2021-04-22T10:11:32Z",
                "annotations": {
                    "kubernetes.io/description": "node-exporter scc is used for the Prometheus node exporter"
                }
            },
            "priority": null,
            "allowPrivilegedContainer": false,
            "defaultAddCapabilities": null,
            "requiredDropCapabilities": null,
            "allowedCapabilities": null,
            "allowHostDirVolumePlugin": true,
            "volumes": [
                "*"
            ],
            "allowHostNetwork": true,
            "allowHostPorts": true,
            "allowHostPID": true,
            "allowHostIPC": false,
            "allowPrivilegeEscalation": true,
            "seLinuxContext": {
                "type": "RunAsAny"
            },
            "runAsUser": {
                "type": "RunAsAny"
            },
            "supplementalGroups": {
                "type": "RunAsAny"
            },
            "fsGroup": {
                "type": "RunAsAny"
            },
            "readOnlyRootFilesystem": false,
            "users": [
                "system:serviceaccount:openshift-monitoring:node-exporter"
            ],
            "groups": []
        },
        {
            "metadata": {
                "name": "nonroot",
                "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/nonroot",
                "uid": "e9ed9bd2-a33a-11eb-9306-005056b4eb0e",
                "resourceVersion": "46",
                "creationTimestamp": "2021-04-22T07:18:19Z",
                "annotations": {
                    "kubernetes.io/description": "nonroot provides all features of the restricted SCC but allows users to run with any non-root UID.  The user must specify the UID or it must be specified on the by the manifest of the container runtime."
                }
            },
            "priority": null,
            "allowPrivilegedContainer": false,
            "defaultAddCapabilities": null,
            "requiredDropCapabilities": [
                "KILL",
                "MKNOD",
                "SETUID",
                "SETGID"
            ],
            "allowedCapabilities": null,
            "allowHostDirVolumePlugin": false,
            "volumes": [
                "configMap",
                "downwardAPI",
                "emptyDir",
                "persistentVolumeClaim",
                "projected",
                "secret"
            ],
            "allowHostNetwork": false,
            "allowHostPorts": false,
            "allowHostPID": false,
            "allowHostIPC": false,
            "allowPrivilegeEscalation": true,
            "seLinuxContext": {
                "type": "MustRunAs"
            },
            "runAsUser": {
                "type": "MustRunAsNonRoot"
            },
            "supplementalGroups": {
                "type": "RunAsAny"
            },
            "fsGroup": {
                "type": "RunAsAny"
            },
            "readOnlyRootFilesystem": false,
            "users": [],
            "groups": []
        },
        {
            "metadata": {
                "name": "privileged",
                "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/privileged",
                "uid": "e9ed18ef-a33a-11eb-9306-005056b4eb0e",
                "resourceVersion": "166616",
                "creationTimestamp": "2021-04-22T07:18:19Z",
                "annotations": {
                    "kubernetes.io/description": "privileged allows access to all privileged and host features and the ability to run as any user, any group, any fsGroup, and with any SELinux context.  WARNING: this is the most relaxed SCC and should be used only for cluster administration. Grant with caution."
                }
            },
            "priority": null,
            "allowPrivilegedContainer": true,
            "defaultAddCapabilities": null,
            "requiredDropCapabilities": null,
            "allowedCapabilities": [
                "*"
            ],
            "allowHostDirVolumePlugin": true,
            "volumes": [
                "*"
            ],
            "allowHostNetwork": true,
            "allowHostPorts": true,
            "allowHostPID": true,
            "allowHostIPC": true,
            "allowPrivilegeEscalation": true,
            "seLinuxContext": {
                "type": "RunAsAny"
            },
            "runAsUser": {
                "type": "RunAsAny"
            },
            "supplementalGroups": {
                "type": "RunAsAny"
            },
            "fsGroup": {
                "type": "RunAsAny"
            },
            "readOnlyRootFilesystem": false,
            "users": [
                "system:admin",
                "system:serviceaccount:openshift-infra:build-controller",
                "system:serviceaccount:openshift-node:sync",
                "system:serviceaccount:openshift-sdn:sdn",
                "system:serviceaccount:management-infra:management-admin",
                "system:serviceaccount:management-infra:inspector-admin",
                "system:serviceaccount:openshift-logging:aggregated-logging-fluentd",
                "system:serviceaccount:openshift-logging:aggregated-logging-elasticsearch"
            ],
            "groups": [
                "system:cluster-admins",
                "system:nodes",
                "system:masters"
            ],
            "seccompProfiles": [
                "*"
            ],
            "allowedUnsafeSysctls": [
                "*"
            ]
        },
        {
            "metadata": {
                "name": "restricted",
                "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/restricted",
                "uid": "e9efb878-a33a-11eb-9306-005056b4eb0e",
                "resourceVersion": "53",
                "creationTimestamp": "2021-04-22T07:18:19Z",
                "annotations": {
                    "kubernetes.io/description": "restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users."
                }
            },
            "priority": null,
            "allowPrivilegedContainer": false,
            "defaultAddCapabilities": null,
            "requiredDropCapabilities": [
                "KILL",
                "MKNOD",
                "SETUID",
                "SETGID"
            ],
            "allowedCapabilities": null,
            "allowHostDirVolumePlugin": false,
            "volumes": [
                "configMap",
                "downwardAPI",
                "emptyDir",
                "persistentVolumeClaim",
                "projected",
                "secret"
            ],
            "allowHostNetwork": false,
            "allowHostPorts": false,
            "allowHostPID": false,
            "allowHostIPC": false,
            "allowPrivilegeEscalation": true,
            "seLinuxContext": {
                "type": "MustRunAs"
            },
            "runAsUser": {
                "type": "MustRunAsRange"
            },
            "supplementalGroups": {
                "type": "RunAsAny"
            },
            "fsGroup": {
                "type": "MustRunAs"
            },
            "readOnlyRootFilesystem": false,
            "users": [],
            "groups": [
                "system:authenticated"
            ]
        }
    ]
}
```

### 获取指定的SCC

##### 请求

GET /v1/securitycontextconstraints/{name}

##### 路径参数

| 参数名  | 描述    |
|:----:|:-----:|
| name | scc名称 |

##### 请求头参数

| 参数名       | 描述                     |
|:---------:|:----------------------:|
| clusterID | 可用区唯一标识 |

##### 响应

| Code | Description |
|:----:|:-----------:|
| 200  | OK          |

```json
{
    "kind": "SecurityContextConstraints",
    "apiVersion": "security.openshift.io/v1",
    "metadata": {
        "name": "new-scc",
        "selfLink": "/apis/security.openshift.io/v1/securitycontextconstraints/new-scc",
        "uid": "8510f4a7-aa4f-11ec-9887-005056b4eb0e",
        "resourceVersion": "111032180",
        "creationTimestamp": "2022-03-23T02:18:25Z",
        "annotations": {
            "kubernetes.io/description": "for test scc"
        }
    },
    "priority": null,
    "allowPrivilegedContainer": false,
    "defaultAddCapabilities": null,
    "requiredDropCapabilities": null,
    "allowedCapabilities": [
        "*"
    ],
    "allowHostDirVolumePlugin": true,
    "volumes": [
        "configMap",
        "downwardAPI",
        "emptyDir",
        "hostPath",
        "persistentVolumeClaim",
        "projected",
        "secret"
    ],
    "allowHostNetwork": false,
    "allowHostPorts": false,
    "allowHostPID": false,
    "allowHostIPC": false,
    "allowPrivilegeEscalation": true,
    "seLinuxContext": {
        "type": "RunAsAny"
    },
    "runAsUser": {
        "type": "RunAsAny"
    },
    "supplementalGroups": {
        "type": "MustRunAs"
    },
    "fsGroup": {
        "type": "RunAsAny"
    },
    "readOnlyRootFilesystem": false,
    "users": [],
    "groups": [
        "system:authenticated"
    ]
}
```

### 删除SCC

##### 请求

DELETE /v1/securitycontextconstraints/{name}

##### 路径参数

| 参数名  | 描述    |
|:----:|:-----:|
| name | SCC名称 |

##### 请求头参数

| 参数名       | 描述      |
|:---------:|:-------:|
| clusterID | 可用区唯一标识 |

##### 响应

| Code | Description |
|:----:|:-----------:|
| 200  | OK          |

```json
{}  
```


