### 获取 horizontalpodautoscaler 列表

##### 请求

GET /v1/namespaces/{namespace}/horizontalpodautoscalers

##### 路径参数

| Parameter |          Description          |
| :-------: | :---------------------------: |
| namespace |           命名空间            |

##### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
|   zone    | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "autoscaling/v2beta1",
            "kind": "HorizontalPodAutoscaler",
            "metadata": {
                "creationTimestamp": "2019-07-04T10:07:03Z",
                "name": "foo",
                "namespace": "carlory",
                "resourceVersion": "26755527",
                "selfLink": "/apis/autoscaling/v2beta1/namespaces/carlory/horizontalpodautoscalers/foo",
                "uid": "78721c94-9e43-11e9-83af-005056b595d6"
            },
            "spec": {
                "maxReplicas": 3,
                "metrics": [
                    {
                        "resource": {
                            "name": "cpu",
                            "targetAverageUtilization": 50
                        },
                        "type": "Resource"
                    }
                ],
                "minReplicas": 1,
            },
            "status": {
                "conditions": [
                    {
                        "lastTransitionTime": "2019-07-04T10:07:33Z",
                        "message": "the HPA controller was able to update the target scale to 3",
                        "reason": "SucceededRescale",
                        "status": "True",
                        "type": "AbleToScale"
                    },
                    {
                        "lastTransitionTime": "2019-07-04T10:07:33Z",
                        "message": "the HPA was unable to compute the replica count: unable to get metrics for resource cpu: unable to fetch metrics from resource metrics API: the server could not find the requested resource (get pods.metrics.k8s.io)",
                        "reason": "FailedGetResourceMetric",
                        "status": "False",
                        "type": "ScalingActive"
                    }
                ],
                "currentMetrics": null,
                "currentReplicas": 4,
                "desiredReplicas": 3,
                "lastScaleTime": "2019-07-04T12:19:43Z"
            }
        },
        {
            "apiVersion": "autoscaling/v2beta1",
            "kind": "HorizontalPodAutoscaler",
            "metadata": {
                "creationTimestamp": "2019-07-04T10:35:30Z",
                "name": "foo1",
                "namespace": "carlory",
                "resourceVersion": "26755592",
                "selfLink": "/apis/autoscaling/v2beta1/namespaces/carlory/horizontalpodautoscalers/foo1",
                "uid": "72380c30-9e47-11e9-a6ef-005056b595d6"
            },
            "spec": {
                "maxReplicas": 10,
                "metrics": [
                    {
                        "resource": {
                            "name": "cpu",
                            "targetAverageUtilization": 50
                        },
                        "type": "Resource"
                    }
                ],
                "minReplicas": 4,
            },
            "status": {
                "conditions": [
                    {
                        "lastTransitionTime": "2019-07-04T10:36:00Z",
                        "message": "the HPA controller was able to update the target scale to 4",
                        "reason": "SucceededRescale",
                        "status": "True",
                        "type": "AbleToScale"
                    },
                    {
                        "lastTransitionTime": "2019-07-04T10:38:30Z",
                        "message": "the HPA was unable to compute the replica count: unable to get metrics for resource cpu: unable to fetch metrics from resource metrics API: the server could not find the requested resource (get pods.metrics.k8s.io)",
                        "reason": "FailedGetResourceMetric",
                        "status": "False",
                        "type": "ScalingActive"
                    }
                ],
                "currentMetrics": null,
                "currentReplicas": 3,
                "desiredReplicas": 4,
                "lastScaleTime": "2019-07-04T12:20:04Z"
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "26755626",
        "selfLink": "/apis/autoscaling/v2beta1/namespaces/carlory/horizontalpodautoscalers"
    }
}
```


### 获取 horizontalpodautoscaler

##### 请求

GET /v1/namespaces/{namespace}/horizontalpodautoscalers/{name}

##### 路径参数

| Parameter |          Description          |
| :-------: | :---------------------------: |
| namespace |           命名空间            |
|   name    | horizontalpodautoscaler的名称 |

##### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
|   zone    | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "autoscaling/v2beta1",
    "kind": "HorizontalPodAutoscaler",
    "metadata": {
        "creationTimestamp": "2019-07-04T10:35:30Z",
        "name": "foo1",
        "namespace": "carlory",
        "resourceVersion": "26755592",
        "selfLink": "/apis/autoscaling/v2beta1/namespaces/carlory/horizontalpodautoscalers/foo1",
        "uid": "72380c30-9e47-11e9-a6ef-005056b595d6"
    },
    "spec": {
        "maxReplicas": 10,
        "metrics": [
            {
                "resource": {
                    "name": "cpu",
                    "targetAverageUtilization": 50
                },
                "type": "Resource"
            }
        ],
        "minReplicas": 4,
    },
    "status": {
        "conditions": [
            {
                "lastTransitionTime": "2019-07-04T10:36:00Z",
                "message": "the HPA controller was able to update the target scale to 4",
                "reason": "SucceededRescale",
                "status": "True",
                "type": "AbleToScale"
            },
            {
                "lastTransitionTime": "2019-07-04T10:38:30Z",
                "message": "the HPA was unable to compute the replica count: unable to get metrics for resource cpu: unable to fetch metrics from resource metrics API: the server could not find the requested resource (get pods.metrics.k8s.io)",
                "reason": "FailedGetResourceMetric",
                "status": "False",
                "type": "ScalingActive"
            }
        ],
        "currentMetrics": null,
        "currentReplicas": 3,
        "desiredReplicas": 4,
        "lastScaleTime": "2019-07-04T12:20:04Z"
    }
}
```

##### 请求

PUT /v1/namespaces/{namespace}/horizontalpodautoscalers/{name}

##### 路径参数

| Parameter |          Description          |
| :-------: | :---------------------------: |
| namespace |           命名空间            |
|   name    | horizontalpodautoscaler的名称 |

##### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
|   zone    | 可用区唯一标识 |

##### 请求体

```json
{
    "apiVersion": "autoscaling/v2beta1",
    "kind": "HorizontalPodAutoscaler",
    "metadata": {
        "creationTimestamp": "2019-07-04T10:35:30Z",
        "name": "foo1",
        "namespace": "carlory",
        "resourceVersion": "26755592",
        "selfLink": "/apis/autoscaling/v2beta1/namespaces/carlory/horizontalpodautoscalers/foo1",
        "uid": "72380c30-9e47-11e9-a6ef-005056b595d6"
    },
    "spec": {
        "maxReplicas": 10,
        "metrics": [
            {
                "resource": {
                    "name": "cpu",
                    "targetAverageUtilization": 50
                },
                "type": "Resource"
            }
        ],
        "minReplicas": 4,
    }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "autoscaling/v2beta1",
    "kind": "HorizontalPodAutoscaler",
    "metadata": {
        "creationTimestamp": "2019-07-04T10:35:30Z",
        "name": "foo1",
        "namespace": "carlory",
        "resourceVersion": "26755592",
        "selfLink": "/apis/autoscaling/v2beta1/namespaces/carlory/horizontalpodautoscalers/foo1",
        "uid": "72380c30-9e47-11e9-a6ef-005056b595d6"
    },
    "spec": {
        "maxReplicas": 10,
        "metrics": [
            {
                "resource": {
                    "name": "cpu",
                    "targetAverageUtilization": 50
                },
                "type": "Resource"
            }
        ],
        "minReplicas": 4,
    },
    "status": {
        "conditions": [
            {
                "lastTransitionTime": "2019-07-04T10:36:00Z",
                "message": "the HPA controller was able to update the target scale to 4",
                "reason": "SucceededRescale",
                "status": "True",
                "type": "AbleToScale"
            },
            {
                "lastTransitionTime": "2019-07-04T10:38:30Z",
                "message": "the HPA was unable to compute the replica count: unable to get metrics for resource cpu: unable to fetch metrics from resource metrics API: the server could not find the requested resource (get pods.metrics.k8s.io)",
                "reason": "FailedGetResourceMetric",
                "status": "False",
                "type": "ScalingActive"
            }
        ],
        "currentMetrics": null,
        "currentReplicas": 3,
        "desiredReplicas": 4,
        "lastScaleTime": "2019-07-04T12:20:04Z"
    }
}
```

### 删除 horizontalpodautoscaler

##### 请求

DELETE /v1/namespaces/{namespace}/horizontalpodautoscalers/{name}

##### 路径参数

| Parameter |          Description          |
| :-------: | :---------------------------: |
| namespace |           命名空间            |
|   name    | horizontalpodautoscaler的名称 |

##### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
|   zone    | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```