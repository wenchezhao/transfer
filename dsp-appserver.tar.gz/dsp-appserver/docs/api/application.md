## 应用接口设计

### 创建应用(表单)

##### 请求

POST /v1/applications

##### 请求体参数

```json
{
    "id": "applicationid", // 应用的ID字段，字段值由如意云后端程序自动生成，平台范围内唯一
    "name": "application name", // 应用的名称，在如意云平台不唯一，由用户输入决定
    "zone": "zone name", // 应用部署的可用区的唯一标识，这里接受如意云后端程序传过来的可用区的ID
    "namespace": "namespace", // 应用部署的命名空间或项目名称，这里接受如意云后端程序传过来的项目组的唯一标识，这个字段由用户创建项目组指定
    "replicas": 2, // 应用副本数
    "image": "busybox", // 应用程序的镜像名称，如果是私有镜像，须配置 字段，确保镜像可以被拉取
    "imagePullSecret": { // 当镜像为私有镜像时，以该用户身份拉取镜像
        "username": "username", // 拉取镜像时，使用的用户名
        "password": "password", // 拉取镜像时，使用的密码
        "registry": "docker.io" // 拉取镜像时，须从该镜像仓库获取镜像，考虑是否将该字段作为可选字段，当不设置该值时，由程序自动根据image的值动态计算出
    },
    "command": [ // 设置应用的启动命令，该字段的值会覆盖镜像里指定的EntryPoint指令的值
        "sleep"
    ], 
    "args": [ // 设置应用的启动命令参数，该字段的值会追加到容器的EntryPoint的值后
        "1000"
    ], 
    "port": 8080, // 应用暴露的端口
    "livenessProbe": { //refer https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.11/#probe-v1-core
        "failureThreshold": 3,
        "httpGet": {
            "path": "healthz",
            "port": 8080,
            "scheme": "HTTP"
        },
        "initialDelaySeconds": 45,
        "periodSeconds": 10,
        "successThreshold": 1,
        "timeoutSeconds": 10
    },
    "readinessProbe": { //refer https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.11/#probe-v1-core
        "failureThreshold": 3,
        "httpGet": {
            "path": "healthz/ready",
            "port": 8080,
            "scheme": "HTTP"
        },
        "initialDelaySeconds": 10,
        "periodSeconds": 10,
        "successThreshold": 1,
        "timeoutSeconds": 10
    },
    "podAntiAffinity": {
    	"preferredDuringSchedulingIgnoredDuringExecution": [
      		{
        		"labelSelector": {
          			"matchExpressions": [
           	 			{
              				"key": "k8s-app",
              				"operator": "In",
              				"values": ["dao-2048-dao-2048"]
            			}
          			]
        		},
        			"topologyKey": "zone1"
      		}
    	]
  	},
    "podAffinity": {
    	"preferredDuringSchedulingIgnoredDuringExecution": [
      		{
        		"labelSelector": {
          			"matchExpressions": [
           	 			{
              				"key": "k8s-app",
              				"operator": "In",
              				"values": ["dao-2048-dao-2048"]
            			}
          			]
        		},
        			"topologyKey": "zone1"
      		}
    	]
  	},
    "envs": [  // 设置应用的环境变量
        {
            "name": "VERSION", // 环境变量的名称
            "value": "1.0" // 环境变量的值
        }
    ],
    "envsFrom": [ // 从ConfigMap或Secret资源对象获取环境环境
        {
            "type": "Secret|ConfigMap", // openshift资源类型，目前仅支持ConfigMap和Secret这两种
            "resourceName": "foo", // 资源对象名称
            "prefix": "XXX_"  // 环境变量前缀
        }
    ],
    "volumes": [ // 设置容器需要挂载的PVC和挂载路径
        {
            "name": "pvc name", // PVC的名称
            "containerPath": "/etc/foo" // 容器内的路径
        }
    ],
    "configFiles": [ // 挂载ConfigMap或Secret资源对象到特定路径
        {
            "type": "Secret|ConfigMap", // openshift资源类型，目前仅支持ConfigMap和Secret这两种
            "containerPath": "/etc/bar", // 容器内的路径
            "resourceName": "bar", // 资源对象名称
            "items": [ // 当字段为空时，挂载所有key到containerPath下，当不为空时，仅挂
                {
                    "key": "k1",
                    "subPath": "k1"
                }
            ]
        }
    ],
    "limits": { // 设置应用的资源上限，目前仅包括cpu、memory两个维度
        "cpu": 100m, // 设置应用可使用的CPU资源的上限
        "memory": 100Mi // 设置应用可使用的内存资源的上限
    },
    "requests": { // 设置应用的资源请求值，目前仅包括cpu、memory两个维度
        "cpu": 50m, // 设置应用CPU资源的请求值
        "memory": 10Mi // 设置应用内存资源的请求值
    }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 创建应用(YAML)

##### 请求

POST /v1/applications/:id/yaml

##### 路径参数

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   id   | 应用的ID字段，字段值由如意云后端程序自动生成，平台范围内唯一 |

##### 查询参数


|  参数名   |      描述      |
| :-------: | :------------: |
| namespace |    命名空间    |
|   zone    | 可用区唯一标识 |

##### 请求体参数

```json
apiVersion: v1
kind: Service
metadata:
  name: foo
  namespace: foo
spec:
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: foo
  namespace: foo
spec:
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 获取应用

##### 请求

GET /v1/applications/:id

##### 路径参数

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   id   | 应用的ID字段，字段值由如意云后端程序自动生成，平台范围内唯一 |

##### 查询参数


| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   namespace   | 命名空间 |
|   zone   | 可用区唯一标识 |


##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
 [ // 与应用相关的kubernetes或openshift资源对象集合
     {}
 ]
```

### 获取应用的YAML

##### 请求

GET /v1/applications/:id/yaml

##### 路径参数

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   id   | 应用的ID字段，字段值由如意云后端程序自动生成，平台范围内唯一 |

##### 请求参数

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   zone   | 可用区唯一标识|
|   namespace   | 命名空间 |


##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```yaml
apiVersion: v1
kind: Service
metadata:
  name: foo
  namespace: foo
spec:
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: foo
  namespace: foo
spec:
```

### 通过YAML更新应用

##### 请求

PUT /v1/applications/:id/yaml

##### 路径参数

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   id   | 应用的ID字段，字段值由如意云后端程序自动生成，平台范围内唯一 |

##### 请求参数

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   zone   | 可用区唯一标识|
|   namespace   | 命名空间 |


##### 请求体参数

```yaml
apiVersion: v1
kind: Service
metadata:
  name: foo
  namespace: foo
spec:
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: foo
  namespace: foo
spec:
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 删除应用

##### 请求

DELETE /v1/applications/:id

##### 路径参数

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   id   | 应用的ID字段，字段值由如意云后端程序自动生成，平台范围内唯一 |

##### 查询参数


| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   namespace   | 命名空间 |
|   zone   | 可用区唯一标识 |


##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 获取应用事件列表

##### 请求

GET  /v1/applications/:id/events

##### 路径参数

| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   id   | 应用的ID字段，字段值由如意云后端程序自动生成，平台范围内唯一 |

##### 查询参数


| 参数名 |                             描述                             |
| :----: | :----------------------------------------------------------: |
|   namespace   | 命名空间 |
|   zone   | 可用区唯一标识 |
| timestamp | 查询数据时的起始时间戳（单位毫秒） |
| limit | 查询数据最大个数，查询时按时间从大到小进行查询 |


##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{	
	"firstTimestamp": 1557266215, // 单位毫秒，其值等于最后一条数据的firstTimestamp
	"lastTimestamp": 1557266215,  // 单位毫秒，其值等于第一条数据的firstTimestamp
	"items": [ // kubernetes event资源对象集合，按firstTimestamp值从大到小排序
		{
		    "count": 1,
		    "firstTimestamp": "2019-05-08T05:56:55Z",
		    "involvedObject": {
		        "apiVersion": "v1",
		        "fieldPath": "spec.containers{dsp-redis}",
		        "kind": "Pod",
		        "name": "dsp-redis-546c66ccfd-j77vn",
		        "namespace": "daocloudcsp",
		        "resourceVersion": "11106733",
		        "uid": "84b13023-7155-11e9-83af-005056b595d6"
		    },
		    "lastTimestamp": "2019-05-08T05:56:55Z",
		    "message": "Started container",
		    "metadata": {
		        "creationTimestamp": "2019-05-08T05:56:58Z",
		        "name": "dsp-redis-546c66ccfd-j77vn.159c9f90e912b4b4",
		        "namespace": "daocloudcsp",
		        "resourceVersion": "11106783",
		        "selfLink": "/api/v1/namespaces/daocloudcsp/events/dsp-redis-546c66ccfd-j77vn.159c9f90e912b4b4",
		        "uid": "17220524-7156-11e9-83af-005056b595d6"
		    },
		    "reason": "Started",
		    "source": {
		        "component": "kubelet",
		        "host": "ruyiyundev02"
		    },
		    "type": "Normal"
		}
	]
}
```

### 获取应用HPA

##### 请求

POST /v1/namespaces/:namespace/applications/:id/hpa

##### 路径参数

|  参数名   |                             描述                             |
| :-------: | :----------------------------------------------------------: |
|    id     | 应用的ID字段，字段值由如意云后端程序自动生成，平台范围内唯一 |
| namespace |                           命名空间                           |

##### 请求体

```yaml
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  annotations:
    deployment.kubernetes.io/revision: "1"
  creationTimestamp: "2022-01-04T07:43:13Z"
  generation: 2
  labels:
    app: test
  name: test
  namespace: yorktest
  resourceVersion: "364971892"
  selfLink: /apis/extensions/v1beta1/namespaces/yorktest/deployments/test
  uid: c4a9fe66-6225-47ba-8f27-310cb1993f04
spec:
  progressDeadlineSeconds: 600
  replicas: 0
  revisionHistoryLimit: 10
  selector:
    matchLabels:
      app: test
  strategy:
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
    type: RollingUpdate
  template:
    metadata:
      creationTimestamp: null
      labels:
        app: test
    spec:
      containers:
      - image: nginx
        imagePullPolicy: Always
        name: nginx
        resources: {}
        terminationMessagePath: /dev/termination-log
        terminationMessagePolicy: File
      dnsPolicy: ClusterFirst
      restartPolicy: Always
      schedulerName: default-scheduler
      securityContext: {}
      terminationGracePeriodSeconds: 30

```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
[
    {
        "metadata": {
            "name": "test",
            "namespace": "yorktest",
            "selfLink": "/apis/autoscaling/v1/namespaces/yorktest/horizontalpodautoscalers/test",
            "uid": "2029c090-974c-4e4c-8080-a10b2121d286",
            "resourceVersion": "364972145",
            "creationTimestamp": "2022-01-12T02:08:20Z",
            "annotations": {
                "autoscaling.alpha.kubernetes.io/conditions": "[{\"type\":\"AbleToScale\",\"status\":\"True\",\"lastTransitionTime\":\"2022-01-12T02:08:35Z\",\"reason\":\"SucceededGetScale\",\"message\":\"the HPA controller was able to get the target's current scale\"},{\"type\":\"ScalingActive\",\"status\":\"False\",\"lastTransitionTime\":\"2022-01-12T02:08:35Z\",\"reason\":\"ScalingDisabled\",\"message\":\"scaling is disabled since the replica count of the target is zero\"}]",
                "kubectl.kubernetes.io/last-applied-configuration": "{\"apiVersion\":\"autoscaling/v2beta2\",\"kind\":\"HorizontalPodAutoscaler\",\"metadata\":{\"annotations\":{},\"name\":\"test\",\"namespace\":\"yorktest\"},\"spec\":{\"maxReplicas\":3,\"metrics\":[{\"resource\":{\"name\":\"cpu\",\"target\":{\"averageUtilization\":50,\"type\":\"Utilization\"}},\"type\":\"Resource\"}],\"minReplicas\":1,\"scaleTargetRef\":{\"apiVersion\":\"apps/v1\",\"kind\":\"Deployment\",\"name\":\"test\"}}}\n"
            }
        },
        "spec": {
            "scaleTargetRef": {
                "kind": "Deployment",
                "name": "test",
                "apiVersion": "apps/v1"
            },
            "minReplicas": 1,
            "maxReplicas": 3,
            "targetCPUUtilizationPercentage": 50
        },
        "status": {
            "currentReplicas": 0,
            "desiredReplicas": 0
        }
    }
]
```

### 获取应用VPA

##### 请求

POST /v1/namespaces/:namespace/applications/:id/vpa

##### 路径参数

|  参数名   |                             描述                             |
| :-------: | :----------------------------------------------------------: |
|    id     | 应用的ID字段，字段值由如意云后端程序自动生成，平台范围内唯一 |
| namespace |                           命名空间                           |

##### 请求体
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  annotations:
    deployment.kubernetes.io/revision: "9"
  creationTimestamp: "2022-04-14T07:51:57Z"
  generation: 11
  labels:
    app: nginx01
  name: nginx01
  namespace: zztest01
  resourceVersion: "238339314"
  selfLink: /apis/apps/v1/namespaces/zztest01/deployments/nginx01
  uid: bb82cboa-4649-4601-a57b-554140801de1
spec:
  progressDeadlineSeconds: 600
  replicas: 1
  revisionHistoryLimit: 10
  selector:
    matchLabels:
      app: nginx01
  strategy:
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
    type: RollingUpdate
  template:
    metadata:
      creationTimestamp: null
      labels:
        app: nginx01
    spec:
      containers:
        - image: nginx
          imagePullPolicy: Always
          name: nginx01
          resources: {}
          terminationMessagePath: /dev/termination-log
          terminationMessagePolicy: File
      dnsPolicy: ClusterFirst
      restartPolicy: Always
      schedulerName: default-scheduler
      securityContext: {}
      terminationGracePeriodSeconds: 30
```

##### 响应
| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
[
  {
    "vpa": {
      "apiVersion": "autoscaling.k8s.io/v1beta2",
      "kind": "VerticalPodAutoscaler",
      "metadata": {
        "selfLink": "/apis/autoscaling.k8s.io/v1/namespaces/zztest01/verticalpodautoscalers/deployment-nginx01-vpa",
        "uid": "3c59bof1-b767-443c-a045-f4c2ddd2054d",
        "resourceVersion": "235562128",
        "creationTimestamp": "2022-04-14T08:22:50Z",
        "name": "deployment-nginx01-vpa",
        "namespace": "zztest01"
      },
      "spec": {
        "targetRef": {
          "apiVersion": "apps/v1",
          "kind": "Deployment",
          "name": "nginx01"
        },
        "updatePolicy": {
          "updateMode": "Initial"
        },
        "recommendation": {
          "containerRecommendation": [
            {
              "containerName": "nginx01",
              "lowerBound": {
                "cpu": "100m",
                "memory": "524288k"
              },
              "target": {
                "cpu": "100m",
                "memory": "524288k"
              },
              "uncappedTarget": {
                "cpu": "100m",
                "memory": "524288k"
              },
              "upperBound": {
                "cpu": "100m",
                "memory": "524288k"
              }
            }
          ]
        }
      }
    },
    "vpaResources": [
      {
        "actual": {
          "limitCpu": 2000,
          "limitMen": 2097152000,
          "requestCpu": 100,
          "requestsMem": 524288000
        },
        "expect": {
          "limitCpu": 0,
          "limitMen": 0,
          "requestCpu": 0,
          "requestsMem": 0
        },
        "name": "nginx01",
        "recommand": {
          "cpu": 100,
          "memory": 524288000
        }
      }
    ]
  }
]
```