## 获取namespace列表

#### 请求

GET-/v1/namespaces

#### 路径参数

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |

#### 查询参数

|   Parameter   |                         Description                          |
| :-----------: | :----------------------------------------------------------: |
|   clusterID   |                        可用区唯一标识                        |
| labelSelector | 标签选择器，默认选中所有的ns。使用示例ccnp.cib/system-code=%s |

#### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "List",
    "apiVersion": "v1",
    "metadata": {
        "selfLink": "/api/v1/namespaces",
        "resourceVersion": "194313498"
    },
    "items": [
        {
            "metadata": {
                "name": "yorktest999",
                "selfLink": "/api/v1/namespaces/yorktest999",
                "uid": "1c1f6779-8dda-46e9-a60c-e7ddb9ab2b0f",
                "resourceVersion": "192919535",
                "creationTimestamp": "2021-07-23T07:48:59Z",
                "labels": {
                    "aa": "aa"
                },
                "annotations": {
                    "dce.daocloud.io/limitRangeInited": "true"
                }
            },
            "spec": {
                "finalizers": [
                    "kubernetes"
                ]
            },
            "status": {
                "phase": "Active"
            }
        }
    ]
}
```

## 绑定namespace

#### 请求

POST-/v1/bindnamespaces

#### 请求体

```json
{
    "namespaces":["yorktest111","yorktest222"],
    "clusters":["test111"],
    "systemCode":"yorkcode"
}
```

#### 响应

| Code | Description |
| :--: | ----------- |
| 200  |             |

```json
{}
```

