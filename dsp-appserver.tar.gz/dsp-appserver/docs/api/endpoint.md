### endpoint列表

##### Http Request

GET /v1/namespaces/{namespace}/endpoints

##### Path Parameters

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |

##### Query Parameters

| Parameter |  Description   |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "List",
    "apiVersion": "v1",
    "metadata": {
        "selfLink": "/api/v1/namespaces/zyktest-eintoma/endpoints",
        "resourceVersion": "239768398"
    },
    "items": [
        {
            "kind": "EndPoints",
            "apiVersion": "apps.openshift.io/v1",
            "metadata": {
                "name": "ps-log416-729-2-v1",
                "namespace": "zyktest-eintoma",
                "selfLink": "/api/v1/namespaces/zyktest-eintoma/endpoints/ps-log416-729-2-v1",
                "uid": "6112949e-247a-453c-a984-6da01513622b",
                "resourceVersion": "202671669",
                "creationTimestamp": "2021-07-29T08:08:55Z",
                "labels": {
                    "dsp.daocloud.io/application": "c5c7d92c-5c47-48f7-84cf-eed71ff8ec49"
                }
            }
        },
        {
            "kind": "EndPoints",
            "apiVersion": "apps.openshift.io/v1",
            "metadata": {
                "name": "ps-log50-4-729-zyk-v1",
                "namespace": "zyktest-eintoma",
                "selfLink": "/api/v1/namespaces/zyktest-eintoma/endpoints/ps-log50-4-729-zyk-v1",
                "uid": "52939940-a617-47a8-8210-74f81d27ec5d",
                "resourceVersion": "202671699",
                "creationTimestamp": "2021-07-29T09:00:56Z",
                "labels": {
                    "dsp.daocloud.io/application": "0eda7ba5-354f-40f7-9541-7bc6fab6e6b2"
                }
            }
        },
        {
            "kind": "EndPoints",
            "apiVersion": "apps.openshift.io/v1",
            "metadata": {
                "name": "ps-log561-726-v1",
                "namespace": "zyktest-eintoma",
                "selfLink": "/api/v1/namespaces/zyktest-eintoma/endpoints/ps-log561-726-v1",
                "uid": "b4de5a44-c951-4d2b-a2a9-a0772aacbeb1",
                "resourceVersion": "202671698",
                "creationTimestamp": "2021-07-26T06:53:28Z",
                "labels": {
                    "dsp.daocloud.io/application": "5db2bc74-e110-4cbf-89b7-da1367a82bb5"
                }
            }
        },
        {
            "kind": "EndPoints",
            "apiVersion": "apps.openshift.io/v1",
            "metadata": {
                "name": "ps-log588-zyk-729-3-v1",
                "namespace": "zyktest-eintoma",
                "selfLink": "/api/v1/namespaces/zyktest-eintoma/endpoints/ps-log588-zyk-729-3-v1",
                "uid": "bca4e95e-440d-4713-8a02-a3db84a1b072",
                "resourceVersion": "202646637",
                "creationTimestamp": "2021-07-29T08:41:25Z",
                "labels": {
                    "dsp.daocloud.io/application": "69a5f589-056e-458d-bc2d-371ef0ea703d"
                }
            }
        },
        {
            "kind": "EndPoints",
            "apiVersion": "apps.openshift.io/v1",
            "metadata": {
                "name": "svc-zyk-729-1",
                "namespace": "zyktest-eintoma",
                "selfLink": "/api/v1/namespaces/zyktest-eintoma/endpoints/svc-zyk-729-1",
                "uid": "a714c05b-c6a3-4e9c-a737-70bb107a1541",
                "resourceVersion": "200450404",
                "creationTimestamp": "2021-07-29T08:05:30Z",
                "annotations": {
                    "endpoints.kubernetes.io/last-change-trigger-time": "2021-07-29T08:05:30Z"
                }
            }
        },
        {
            "kind": "EndPoints",
            "apiVersion": "apps.openshift.io/v1",
            "metadata": {
                "name": "zyk-729-5-cfgtest-v1",
                "namespace": "zyktest-eintoma",
                "selfLink": "/api/v1/namespaces/zyktest-eintoma/endpoints/zyk-729-5-cfgtest-v1",
                "uid": "9a8e2082-9f34-4b15-bcb0-c654bf1af77c",
                "resourceVersion": "202671728",
                "creationTimestamp": "2021-07-29T09:47:51Z",
                "labels": {
                    "dsp.daocloud.io/application": "df73dafe-f4a4-4e75-ba1a-bc5daeb6dd91"
                }
            }
        }
    ]
}
```

### endpoint详情

##### Http Request

GET /v1/namespaces/{namespace}/endpoints/{name}

##### Path Parameters

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |
|   Name    | endpoint名  |

##### Query Parameters

| Parameter |  Description   |
| :-------: | :------------: |
| clusterID | 可用区唯一标识 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "EndPoints",
    "apiVersion": "v1",
    "metadata": {
        "name": "ps-log416-729-2-v1",
        "namespace": "zyktest-eintoma",
        "selfLink": "/api/v1/namespaces/zyktest-eintoma/endpoints/ps-log416-729-2-v1",
        "uid": "6112949e-247a-453c-a984-6da01513622b",
        "resourceVersion": "202671669",
        "creationTimestamp": "2021-07-29T08:08:55Z",
        "labels": {
            "dsp.daocloud.io/application": "c5c7d92c-5c47-48f7-84cf-eed71ff8ec49"
        }
    }
}
```

