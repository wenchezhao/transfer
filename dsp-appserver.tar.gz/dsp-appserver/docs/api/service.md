## Service

### 获取 Service 列表

##### 请求

GET /v1/namespaces/{namespace}/services

##### 路径参数

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |

##### 查询参数

| Parameter |    Description    |
| :-------: | :---------------: |
|   zone    | 可用区唯一标识 |
| labelSelector | 标签选择器，默认选中所有services。使用示例k1=v2,k2=v2 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "v1",
            "kind": "Service",
            "metadata": {
                "creationTimestamp": "2019-04-11T23:08:27Z",
                "labels": {
                    "run": "nginx"
                },
                "name": "nginx",
                "namespace": "easyops",
                "resourceVersion": "6964613",
                "selfLink": "/api/v1/namespaces/easyops/services/nginx",
                "uid": "b6e1a6f1-5cae-11e9-ada9-005056a117fe"
            },
            "spec": {
                "clusterIP": "10.110.227.251",
                "ports": [
                    {
                        "port": 80,
                        "protocol": "TCP",
                        "targetPort": 80
                    }
                ],
                "selector": {
                    "run": "nginx"
                },
                "sessionAffinity": "None",
                "type": "ClusterIP"
            },
            "status": {
                "loadBalancer": {}
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 获取 Service

##### 请求

GET /v1/namespaces/{namespace}/services/{name}

##### 路径参数

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |
|   name    |  服务名称   |

##### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
|   zone    | 可用区唯一标识 |

##### 响应
| Code | Description |
| :--: | :---------: |
| 200  |     OK      |
```json
{
    "apiVersion": "v1",
    "kind": "Service",
    "metadata": {
        "creationTimestamp": "2019-04-11T23:08:27Z",
        "labels": {
            "run": "nginx"
        },
        "name": "nginx",
        "namespace": "easyops",
        "resourceVersion": "6964613",
        "selfLink": "/api/v1/namespaces/easyops/services/nginx",
        "uid": "b6e1a6f1-5cae-11e9-ada9-005056a117fe"
    },
    "spec": {
        "clusterIP": "10.110.227.251",
        "ports": [
            {
                "port": 80,
                "protocol": "TCP",
                "targetPort": 80
            }
        ],
        "selector": {
            "run": "nginx"
        },
        "sessionAffinity": "None",
        "type": "ClusterIP"
    },
    "status": {
        "loadBalancer": {}
    }
}
```

### 创建 Service

##### 请求

POST /v1/namespaces/{namespace}/services

##### 路径参数

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |

##### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
|   zone    | 可用区唯一标识 |

##### 请求体

```json
{
    "apiVersion": "v1", 
    "kind": "Service",
    "metadata": {
        "labels": {   // Service 标签
            "run": "nginx"
        },
        "name": "nginx", // Service 名字
        "namespace": "easyops", 
    },
    "spec": {
        "ports": [
            {
                "port": 80,  // Service的端口
                "protocol": "TCP", // Service端口协议
                "targetPort": 80 // TargetPort 如果不写默认等于Port的值，TargetPort的类型是String或Int，指的是容器的端口
            }
        ],
        "selector": { // 选择器，通过标签选择一批POD
            "run": "nginx" // 满足这个规则的POD被选上
        },
        "sessionAffinity": "None", // 设置会话的亲和性，可选值为 None | ClientIP
        "type": "ClusterIP" //设置Service的类型，可选值为ClusterIP | NodePort | ExternalName
    }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |
```json
{
    "apiVersion": "v1",
    "kind": "Service",
    "metadata": {
        "creationTimestamp": "2019-04-11T23:08:27Z",
        "labels": {
            "run": "nginx"
        },
        "name": "nginx",
        "namespace": "easyops",
        "resourceVersion": "6964613",
        "selfLink": "/api/v1/namespaces/easyops/services/nginx",
        "uid": "b6e1a6f1-5cae-11e9-ada9-005056a117fe"
    },
    "spec": {
        "clusterIP": "10.110.227.251",
        "ports": [
            {
                "port": 80,
                "protocol": "TCP",
                "targetPort": 80
            }
        ],
        "selector": {
            "run": "nginx"
        },
        "sessionAffinity": "None",
        "type": "ClusterIP"
    },
    "status": {
        "loadBalancer": {}
    }
}
```

### 更新 Service

##### 请求

PUT /v1/namespaces/{namespace}/services/{name}

##### 路径参数

| Parameter |  Description  |
| :-------: | :-----------: |
| namespace |   命名空间    |
|   name    | Service的名称 |

##### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
|   zone    | 可用区唯一标识 |

##### 请求体

```json
{
    "apiVersion": "v1",
    "kind": "Service",
    "metadata": {
        "creationTimestamp": "2019-04-11T23:08:27Z",
        "labels": {
            "run": "nginx"
        },
        "name": "nginx",
        "namespace": "easyops",
        "resourceVersion": "6964613",
        "selfLink": "/api/v1/namespaces/easyops/services/nginx",
        "uid": "b6e1a6f1-5cae-11e9-ada9-005056a117fe"
    },
    "spec": {
        "clusterIP": "10.110.227.251",
        "ports": [
            {
                "port": 80,
                "protocol": "TCP",
                "targetPort": 80
            }
        ],
        "selector": {
            "run": "nginx"
        },
        "sessionAffinity": "None",
        "type": "ClusterIP"
    },
    "status": {
        "loadBalancer": {}
    }
}
```

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |
```json
{
    "apiVersion": "v1",
    "kind": "Service",
    "metadata": {
        "creationTimestamp": "2019-04-11T23:08:27Z",
        "labels": {
            "run": "nginx"
        },
        "name": "nginx",
        "namespace": "easyops",
        "resourceVersion": "6964613",
        "selfLink": "/api/v1/namespaces/easyops/services/nginx",
        "uid": "b6e1a6f1-5cae-11e9-ada9-005056a117fe"
    },
    "spec": {
        "clusterIP": "10.110.227.251",
        "ports": [
            {
                "port": 80,
                "protocol": "TCP",
                "targetPort": 80
            }
        ],
        "selector": {
            "run": "nginx"
        },
        "sessionAffinity": "None",
        "type": "ClusterIP"
    },
    "status": {
        "loadBalancer": {}
    }
}
```

### 删除Service

##### 请求

DELETE /v1/namespaces/{namespace}/services/{name}

##### 路径参数

| Parameter |  Description  |
| :-------: | :-----------: |
| namespace |   命名空间    |
|   name    | Service的名称 |

##### 查询参数

| Parameter |  Description   |
| :-------: | :------------: |
|   zone    | 可用区唯一标识 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 获取Service下的容器列表

##### 请求

GET /v1/namespaces/{namespace}/services/{name}/pods

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|   name    |    service的名称     |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "kind": "List",
    "apiVersion": "v1",
    "metadata": {
        "selfLink": "/api/v1/namespaces/kube-system/pods",
        "resourceVersion": "11334709"
    },
    "items": [
        {
            "kind": "Pod",
            "apiVersion": "v1",
            "metadata": {
                "name": "coredns-0",
                "generateName": "coredns-",
                "namespace": "kube-system",
                "selfLink": "/api/v1/namespaces/kube-system/pods/coredns-0",
                "uid": "0d3e1285-7164-11e9-83af-005056b595d6",
                "resourceVersion": "11125381",
                "creationTimestamp": "2019-05-08T07:36:54Z",
                "labels": {
                    "controller-revision-hash": "coredns-74fc4c94dc",
                    "k8s-app": "kube-dns",
                    "statefulset.kubernetes.io/pod-name": "coredns-0"
                },
                "ownerReferences": [
                    {
                        "apiVersion": "apps/v1",
                        "kind": "StatefulSet",
                        "name": "coredns",
                        "uid": "0d3b15db-7164-11e9-83af-005056b595d6",
                        "controller": true,
                        "blockOwnerDeletion": true
                    }
                ]
            },
            "spec": {
                "volumes": [
                    {
                        "name": "config-volume",
                        "configMap": {
                            "name": "coredns",
                            "items": [
                                {
                                    "key": "Corefile",
                                    "path": "Corefile"
                                }
                            ],
                            "defaultMode": 420
                        }
                    },
                    {
                        "name": "default-token-9v654",
                        "secret": {
                            "secretName": "default-token-9v654",
                            "defaultMode": 420
                        }
                    }
                ],
                "containers": [
                    {
                        "name": "coredns",
                        "image": "k8s.gcr.io/coredns:1.2.6",
                        "args": [
                            "-conf",
                            "/etc/coredns/Corefile"
                        ],
                        "ports": [
                            {
                                "name": "dns",
                                "containerPort": 53,
                                "protocol": "UDP"
                            },
                            {
                                "name": "dns-tcp",
                                "containerPort": 53,
                                "protocol": "TCP"
                            },
                            {
                                "name": "metrics",
                                "containerPort": 9153,
                                "protocol": "TCP"
                            }
                        ],
                        "resources": {
                            "limits": {
                                "memory": "170Mi"
                            },
                            "requests": {
                                "cpu": "100m",
                                "memory": "70Mi"
                            }
                        },
                        "volumeMounts": [
                            {
                                "name": "config-volume",
                                "readOnly": true,
                                "mountPath": "/etc/coredns"
                            },
                            {
                                "name": "default-token-9v654",
                                "readOnly": true,
                                "mountPath": "/var/run/secrets/kubernetes.io/serviceaccount"
                            }
                        ],
                        "livenessProbe": {
                            "httpGet": {
                                "path": "/health",
                                "port": 8080,
                                "scheme": "HTTP"
                            },
                            "initialDelaySeconds": 60,
                            "timeoutSeconds": 5,
                            "periodSeconds": 10,
                            "successThreshold": 1,
                            "failureThreshold": 5
                        },
                        "terminationMessagePath": "/dev/terminationlog",
                        "terminationMessagePolicy": "File",
                        "imagePullPolicy": "IfNotPresent",
                        "securityContext": {
                            "capabilities": {
                                "add": [
                                    "NET_BIND_SERVICE"
                                ],
                                "drop": [
                                    "all"
                                ]
                            },
                            "readOnlyRootFilesystem": true,
                            "allowPrivilegeEscalation": false
                        }
                    }
                ],
                "restartPolicy": "Always",
                "terminationGracePeriodSeconds": 30,
                "dnsPolicy": "ClusterFirst",
                "serviceAccountName": "default",
                "serviceAccount": "default",
                "nodeName": "ruyiyundev01",
                "securityContext": {},
                "imagePullSecrets": [
                    {
                        "name": "default-dockercfg-wd745"
                    }
                ],
                "hostname": "coredns-0",
                "schedulerName": "default-scheduler",
                "tolerations": [
                    {
                        "key": "node.kubernetes.io/memory-pressure",
                        "operator": "Exists",
                        "effect": "NoSchedule"
                    },
                    {
                        "key": "CriticalAddonsOnly",
                        "operator": "Exists"
                    },
                    {
                        "key": "node-role.kubernetes.io/master",
                        "effect": "NoSchedule"
                    }
                ],
                "priority": 0
            },
            "status": {
                "phase": "Pending",
                "conditions": [
                    {
                        "type": "Initialized",
                        "status": "True",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-05-08T07:36:54Z"
                    },
                    {
                        "type": "Ready",
                        "status": "False",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-05-08T07:36:54Z",
                        "reason": "ContainersNotReady",
                        "message": "containers with unready status: [coredns]"
                    },
                    {
                        "type": "ContainersReady",
                        "status": "False",
                        "lastProbeTime": null,
                        "lastTransitionTime": null,
                        "reason": "ContainersNotReady",
                        "message": "containers with unready status: [coredns]"
                    },
                    {
                        "type": "PodScheduled",
                        "status": "True",
                        "lastProbeTime": null,
                        "lastTransitionTime": "2019-05-08T07:36:54Z"
                    }
                ],
                "hostIP": "10.203.121.53",
                "startTime": "2019-05-08T07:36:54Z",
                "containerStatuses": [
                    {
                        "name": "coredns",
                        "state": {
                            "waiting": {
                                "reason": "ContainerCreating"
                            }
                        },
                        "lastState": {},
                        "ready": false,
                        "restartCount": 0,
                        "image": "k8s.gcr.io/coredns:1.2.6",
                        "imageID": ""
                    }
                ],
                "qosClass": "Burstable"
            }
        }
    ]
}
```

### 获取service下的event事件列表

##### 请求

GET /v1/namespaces/{namespace}/services/{name}/events

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|   name    |    service的名称     |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "v1",
            "count": 63892,
            "eventTime": null,
            "firstTimestamp": "2019-04-29T09:03:32Z",
            "involvedObject": {
                "apiVersion": "v1",
                "kind": "PersistentVolumeClaim",
                "name": "demo11",
                "namespace": "daocloudcsp",
                "resourceVersion": "9191134",
                "uid": "aa188578-6a5d-11e9-83af-005056b595d6"
            },
            "kind": "Event",
            "lastTimestamp": "2019-05-10T02:43:36Z",
            "message": "no persistent volumes available for this claim and no storage class is set",
            "metadata": {
                "creationTimestamp": "2019-04-29T09:03:32Z",
                "name": "demo11.1599e686d3613168",
                "namespace": "daocloudcsp",
                "resourceVersion": "11618906",
                "selfLink": "/api/v1/namespaces/daocloudcsp/events/demo11.1599e686d3613168",
                "uid": "aa195fa5-6a5d-11e9-83af-005056b595d6"
            },
            "reason": "FailedBinding",
            "reportingComponent": "",
            "reportingInstance": "",
            "source": {
                "component": "persistentvolume-controller"
            },
            "type": "Normal"
        },
        {
            "apiVersion": "v1",
            "count": 130843,
            "eventTime": null,
            "firstTimestamp": "2019-04-18T02:59:24Z",
            "involvedObject": {
                "apiVersion": "v1",
                "kind": "PersistentVolumeClaim",
                "name": "sss",
                "namespace": "daocloudcsp",
                "resourceVersion": "7097245",
                "uid": "f90b0c74-6185-11e9-83af-005056b595d6"
            },
            "kind": "Event",
            "lastTimestamp": "2019-05-10T02:39:36Z",
            "message": "no persistent volumes available for this claim and no storage class is set",
            "metadata": {
                "creationTimestamp": "2019-04-18T02:59:24Z",
                "name": "sss.15967245ab178e56",
                "namespace": "daocloudcsp",
                "resourceVersion": "11618098",
                "selfLink": "/api/v1/namespaces/daocloudcsp/events/sss.15967245ab178e56",
                "uid": "f90ec963-6185-11e9-83af-005056b595d6"
            },
            "reason": "FailedBinding",
            "reportingComponent": "",
            "reportingInstance": "",
            "source": {
                "component": "persistentvolume-controller"
            },
            "type": "Normal"
        },
        {
            "apiVersion": "v1",
            "count": 449,
            "eventTime": null,
            "firstTimestamp": "2019-05-08T05:43:05Z",
            "involvedObject": {
                "apiVersion": "apps/v1",
                "kind": "ReplicaSet",
                "name": "yxltest-c7c9d98df",
                "namespace": "daocloudcsp",
                "resourceVersion": "11104002",
                "uid": "26f406bc-7154-11e9-83af-005056b595d6"
            },
            "kind": "Event",
            "lastTimestamp": "2019-05-10T02:42:50Z",
            "message": "Error creating: pods \"yxltest-c7c9d98df-\" is forbidden: unable to validate against any security context constraint: [capabilities.add: Invalid value: \"NET_BIND_SERVICE\": capability may not be added capabilities.add: Invalid value: \"NET_BIND_SERVICE\": capability may not be added]",
            "metadata": {
                "creationTimestamp": "2019-05-08T05:43:05Z",
                "name": "yxltest-c7c9d98df.159c9ecf99ecbde3",
                "namespace": "daocloudcsp",
                "resourceVersion": "11618731",
                "selfLink": "/api/v1/namespaces/daocloudcsp/events/yxltest-c7c9d98df.159c9ecf99ecbde3",
                "uid": "26f6f966-7154-11e9-83af-005056b595d6"
            },
            "reason": "FailedCreate",
            "reportingComponent": "",
            "reportingInstance": "",
            "source": {
                "component": "replicaset-controller"
            },
            "type": "Warning"
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    
```

### 获取与Service相关的route列表

##### 请求

GET /v1/namespaces/{namespace}/services/{name}/routes

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|   name    |    service的名称     |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "route.openshift.io/v1",
            "kind": "Route",
            "metadata": {
                "creationTimestamp": "2019-04-29T09:17:01Z",
                "labels": {
                    "app": "game2048"
                },
                "name": "demo",
                "namespace": "daocloudcsp",
                "resourceVersion": "9193183",
                "selfLink": "/apis/route.openshift.io/v1/namespaces/daocloudcsp/routes/demo",
                "uid": "8be0312d-6a5f-11e9-83af-005056b595d6"
            },
            "spec": {
                "alternateBackends": [
                    {
                        "kind": "Service",
                        "name": "game2048-test",
                        "weight": 1
                    },
                    {
                        "kind": "Service",
                        "name": "email-broker",
                        "weight": 1
                    }
                ],
                "host": "demo",
                "path": "/dsds",
                "port": {
                    "targetPort": "80-tcp"
                },
                "tls": {
                    "caCertificate": "-----BEGIN CERTIFICATE----\nMIICzTCCAbWgAwIBAgIQRsrdx5MMtSHKfNlyX7JIizANBgkqhkiG9w0BAQsFADAQ\nM Q4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBAx DjAMBgNVBAoTBWRpanVuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC\nAQEAnub 3vKSOBy/+8tPwRj0R2IuaccgeUABetDV3Mjlq8274kQJQ+u1g/aa6d0HD\nz6ZL7FsyKh KLonRw4fgR6htMWMuDt6AvxdSlnIRbllT3A+sLTvUpGAs5ooDPEB1o\nUGZyVSE8QvVPB Aj+2yyrBLjkvJ7Yxk0hWRI9XPxAJNTjAmOO+wzU0Pxu14eiY0I8\n9B2KfKtUYM7gQMkq y7CW8YdJo5ra2yn498+r6YKscAPVXmsmhjxqVa59cLjA+iav\ngpmeKwcRI47YE69+h1t Lqc6qDQmcdkxQ+OJgnIt6WosFvuEPyCgPxtSlLb2gw1j9\n6LrEgZUkId+I8Zb5TPdmj+ 2FNwIDAQABoyMwITAOBgNVHQ8BAf8EBAMCAqwwDwYD\nVR0TAQH/BAUwAwEB/zANBgkqh kiG9w0BAQsFAAOCAQEAYBBT1uqQpnbjH67HoVW7\nVAHaCB1SSh+2tdVoJFvcl8h/GHzD 2VWXI2Wy3WPpODklDVNw9NkKm4HmjY0sqc6X\nU2TpZVUGNLFIGyu16+5T+NiVLX0YoMx oMQzexT9nuz302mIoLoq7xj9+P+S9z3sq\nvZfuYFT0stwkmKANqzfggdMH9lienntUT3 61l9P9lYNj9ZmQqSnrFcOIdhdHYWlB\nciUzv7lotf84omzfQmfdbslBPEqSgtG6AyylZ 7esjGrsM2JusK1nnOidi0bpRagU\ntFLC421NxD6Mi6tv25Tlh7Vt1T7QnBjeErWJ8JVr pc1r0OHN6Ia+PnwcAmBkZtYe\nJw==\n-----END CERTIFICATE-----\n",
                    "certificate": "-----BEGIN CERTIFICATE----\nMIIC6zCCAdOgAwIBAgIQOECWN0TcC2lxCzXuoLKChTANBgkqhkiG9w0BAQsFADAQ\nM Q4wDAYDVQQKEwVkaWp1bjAeFw0xODEyMjIwNDM1MDBaFw0yMTEyMDYwNDM1MDBa\nMBwx GjAYBgNVBAoMEWRpanVuLjxib290c3RyYXA+MIIBIjANBgkqhkiG9w0BAQEF\nAAOCAQ8 AMIIBCgKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB\n+qp36lrkSw HZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8u\nbJTnTcfFGuXUA PlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA\n1OCw2FN64HvyReYe jREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xu\nUjJwfuNrQHW96de/yic uQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeft\nbauY6CwtB+e0kjApjlQpnt hZZnVJta1rlnlQCd659QIDAQABozUwMzAOBgNVHQ8B\nAf8EBAMCB4AwEwYDVR0lBAwwC gYIKwYBBQUHAwIwDAYDVR0TAQH/BAIwADANBgkq\nhkiG9w0BAQsFAAOCAQEAFie0nDiW P3Pa3x+tntWAnfX1id6ne6xmr1cwvO7AeiX2\nQ9sxCguOQq/96dJzYoyGZQwoBmwuv77 PpPq9Do01xGJzyk4PWIjNADRT4ik/NSZp\npYYtDrxe8gJDJNaNR33cgDQkrj+cfqPqdy JaK5EsgPCZqDxJla4Koabn4Ws8PzA/\nVW7M1niv3mUqv7m8HeG4YO62yEcjoDxYVTzdP nHmqUDqYSJhFVcnRhkv8Ox4+b1l\nfiswT+YivqPM3R64OXtAbi2ZTor7knbQclddnSIQ Xte2/GbDwi2BzvktnbAXepiI\n83waIT9IpAdHffuefGaYFkgMd2Af1om4pwLbE66+fA= =\n-----END CERTIFICATE-----\n",
                    "key": "-----BEGIN RSA PRIVATE KEY----\nMIIEpQIBAAKCAQEAvsF4vihA7M7v3JQ+0Oh8RbrntXP/sFiFKMjqVwxmZzVB+qp3\n6 lrkSwHZ810zYM7fY7KLiWQ2UkcuiULcfbWLJhwcP9cFtqLxxbWVkU086f8ubJTn\nTcfF GuXUAPlwC0nIRiu7XRl+TpG28bJB4o8w8jC5EImvukl4k64Rz1g/cacA1OCw\n2FN64Hv yReYejREOVlpLpmRcwDWZ6wIRaqPvW89h0vGhgO8w2GtFvbcBF6xuUjJw\nfuNrQHW96d e/yicuQThl0BTmGNTQVBWyHY0ff1nUnr+juMMv9LPKhmlCOeftbauY\n6CwtB+e0kjApj lQpnthZZnVJta1rlnlQCd659QIDAQABAoIBAQCNJv7gv0qjsNEf\nCPeegJoMwyxYQfjP FgGa12lIdp2D+43SHbhUS2Oo+Tq88ZdmKE53KJRGW0gzBAc0\nfKxJvT+1OJHSz5qjtdl v8lk1xtCvWiuRH3I1RQDeUXjaK7m0MKmo+w1O6+Fh5ENa\ngAxuyIRwgos+6JOHJny50t HM+0EfKCzSpz/ck+2E1u7vB6uOCBaXO2xhPICNDYNF\nUNQG6PcQmiJDgSiaqNBvzZkR+ 7nXvo6CAaogpCXQUBxAlP+ry66mjxz61Hc/9QKM\nY7/lbl7+yt1YKVW61wquhFAeLM1A jAxJRTdvgstbczYxdLQbv85nxbXXbZZszny5\nfkkoWvAVAoGBANw4WCJ0I749RjlUSeJ VkA1Mci1/yQEeNH+2r0Lh2SSE3cyWbFqG\nDazUb+OxXnuzItCPmctv1zKRPYQ5F8qKdy qefr5Np24YtaAx2p6I8S2RqdavReRs\nzJmJWgH1zR+QpDkVj4Z9RQv7iMWXOAbZQVRyT gsHdkYcnv8JfTWJPJ7PAoGBAN2/\nnH3sD6FPV3dhTvsVBM87CucHx1vQjaKo0U2ZRd1Y LN2bT75Qzv3VVmRN9U94u4WG\n7DgyH+IGECkspOhZJq0WPphdWKdVhxb/sHudsrCFqDM WqD/mdjvYrTk9hUEhDo1a\nQsM0NP5VQOddWkMQhozwl69VRSkpEKd5ThTRqev7AoGBAM FDpX1fJXswNS/c3BaI\n9qnlHBL4IUQc6P/oKHlu0W0uOaTxolfza47wxN0zbPLsbDJSx Cr4lQho1G701/9F\nc31wqVSDu9twTf0vo2gcUGSogD/LhHAKV6irFNXBjOoVuznpxRLH X1A7yHV315CT\nG7VrtzgQrWisd5DlGABi11ObAoGBAL0DNKsI6hG/hXiWkzHlqqHRW+u tb7rNO80o\nRK/2M90F6chDOGeqjaVDkU4SPUUuTfj1FqiX4SFRtbjC+xWp2BO1YEmTV5 vahTmP\nXKkhtExOwR4689Lz6Ff+yzh9PfZT7QmDpGCrQXiAxr/vjJ6ZmXbNJR4oerko7 a8y\n8OFCDaq9AoGAE35E+Un/UiBpEIquB4jV0GBpH2GapWpqR1wOPEQxNDhcRD2MDK7p \n7rCxOQHIXpVmYd0sWywmqT0W4YSHHXcvFt+RnbAeXR5qJalZNCI6Rs0VeCS8YzCZ\nt hKNQfMe+D/xLRHmfQ+/IfH7PjE5SUIahECq4kYGr42UvABfMcCUfMI=\n-----END RSA PRIVATE KEY-----\n",
                    "termination": "edge"
                },
                "to": {
                    "kind": "Service",
                    "name": "game2048",
                    "weight": 1
                },
                "wildcardPolicy": "None"
            },
            "status": {
                "ingress": [
                    {
                        "conditions": [
                            {
                                "lastTransitionTime": "2019-04-29T09:17:01Z",
                                "message": "a route in another namespace holds demo and is older than demo",
                                "reason": "HostAlreadyClaimed",
                                "status": "False",
                                "type": "Admitted"
                            }
                        ],
                        "host": "demo",
                        "routerName": "router",
                        "wildcardPolicy": "None"
                    }
                ]
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 获取与Service相关的route&ingress列表

##### 请求

GET /v1/namespaces/{namespace}/services/{name}/trafficobjects

##### 路径参数

|  参数名   |         描述         |
| :-------: | :------------------: |
| namespace | 命名空间，对应项目组 |
|   name    |    service的名称     |

##### 查询参数

| 参数名 |                      描述                      |
| :----: | :--------------------------------------------: |
|  zone  | 可用区的唯一标识，当其值为空时，表示默认可用区 |

##### 响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
[
    {
        "apiVersion": "route.openshift.io/v1",
        "kind": "Route",
        "metadata": {
            "creationTimestamp": "2019-08-30T06:33:39Z",
            "name": "test123-84vgw",
            "namespace": "test",
            "ownerReferences": [
                {
                    "apiVersion": "extensions/v1beta1",
                    "controller": true,
                    "kind": "Ingress",
                    "name": "test123",
                    "uid": "a9be30bb-ca17-11e9-84d7-005056b4d66c"
                }
            ],
            "resourceVersion": "3740324",
            "selfLink": "/apis/route.openshift.io/v1/namespaces/test/routes/test123-84vgw",
            "uid": "1a3ec268-caf0-11e9-84d7-005056b4d66c"
        },
        "spec": {
            "host": "test1234.inapps.ocp.dsp.local",
            "path": "/",
            "port": {
                "targetPort": 8080
            },
            "to": {
                "kind": "Service",
                "name": "test123-v1",
                "weight": 100
            },
            "wildcardPolicy": "None"
        },
        "status": {
            "ingress": [
                {
                    "conditions": [
                        {
                            "lastTransitionTime": "2019-08-30T06:33:39Z",
                            "status": "True",
                            "type": "Admitted"
                        }
                    ],
                    "host": "test1234.inapps.ocp.dsp.local",
                    "routerName": "router",
                    "wildcardPolicy": "None"
                }
            ]
        }
    },
    {
        "apiVersion": "route.openshift.io/v1",
        "kind": "Route",
        "metadata": {
            "creationTimestamp": "2019-08-29T04:44:19Z",
            "name": "test123-skggw",
            "namespace": "test",
            "ownerReferences": [
                {
                    "apiVersion": "extensions/v1beta1",
                    "controller": true,
                    "kind": "Ingress",
                    "name": "test123",
                    "uid": "a9be30bb-ca17-11e9-84d7-005056b4d66c"
                }
            ],
            "resourceVersion": "3419921",
            "selfLink": "/apis/route.openshift.io/v1/namespaces/test/routes/test123-skggw",
            "uid": "a9e0614c-ca17-11e9-84d7-005056b4d66c"
        },
        "spec": {
            "host": "test123.inapps.ocp.dsp.local",
            "path": "/",
            "port": {
                "targetPort": 8080
            },
            "to": {
                "kind": "Service",
                "name": "test123-v1",
                "weight": 100
            },
            "wildcardPolicy": "None"
        },
        "status": {
            "ingress": [
                {
                    "conditions": [
                        {
                            "lastTransitionTime": "2019-08-29T04:44:19Z",
                            "status": "True",
                            "type": "Admitted"
                        }
                    ],
                    "host": "test123.inapps.ocp.dsp.local",
                    "routerName": "router",
                    "wildcardPolicy": "None"
                }
            ]
        }
    },
    {
        "apiVersion": "extensions/v1beta1",
        "kind": "Ingress",
        "metadata": {
            "creationTimestamp": "2019-08-29T04:44:19Z",
            "generation": 2,
            "name": "test123",
            "namespace": "test",
            "resourceVersion": "3740322",
            "selfLink": "/apis/extensions/v1beta1/namespaces/test/ingresses/test123",
            "uid": "a9be30bb-ca17-11e9-84d7-005056b4d66c"
        },
        "spec": {
            "rules": [
                {
                    "host": "test123.inapps.ocp.dsp.local",
                    "http": {
                        "paths": [
                            {
                                "backend": {
                                    "serviceName": "test123-v1",
                                    "servicePort": 8080
                                },
                                "path": "/"
                            }
                        ]
                    }
                },
                {
                    "host": "test1234.inapps.ocp.dsp.local",
                    "http": {
                        "paths": [
                            {
                                "backend": {
                                    "serviceName": "test123-v1",
                                    "servicePort": 8080
                                },
                                "path": "/"
                            }
                        ]
                    }
                }
            ]
        },
        "status": {
            "loadBalancer": {}
        }
    }
]
```