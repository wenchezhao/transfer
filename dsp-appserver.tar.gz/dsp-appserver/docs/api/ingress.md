### 获取 Ingress 列表

##### Http Request

GET /v1/namespaces/{namespace}/ingresses

##### Path Parameters

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |

##### Query Parameters

|   Parameter   |                         Description                          |
| :-----------: | :----------------------------------------------------------: |
|     zone      |             可用区唯一标识，为空时表示默认可用区             |
| labelSelector | 标签选择器，默认为选中所有的ingress。取值示例为k1=v2,k2=v2 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "extensions/v1beta1",
            "kind": "Ingress",
            "metadata": {
                "annotations": {
                    "kubectl.kubernetes.io/last-applied-configuration": "{\"apiVersion\":\"extensions/v1beta1\",\"kind\":\"Ingress\",\"metadata\":{\"annotations\":{\"kubernetes.io/ingress.class\":\"nginx\",\"nginx.ingress.kubernetes.io/ssl-passthrough\":\"true\"},\"name\":\"kubernetes-dashboard\",\"namespace\":\"kube-system\"},\"spec\":{\"rules\":[{\"host\":\"kubedash.inapps.k8s.dsp.local\",\"http\":{\"paths\":[{\"backend\":{\"serviceName\":\"kubernetes-dashboard\",\"servicePort\":443}}]}}],\"tls\":[{\"hosts\":[\"kubedash.inapps.k8s.dsp.local\"]}]}}\n",
                    "kubernetes.io/ingress.class": "nginx",
                    "nginx.ingress.kubernetes.io/ssl-passthrough": "true"
                },
                "creationTimestamp": "2019-08-15T10:05:29Z",
                "generation": 2,
                "name": "kubernetes-dashboard",
                "namespace": "kube-system",
                "resourceVersion": "21879",
                "selfLink": "/apis/extensions/v1beta1/namespaces/kube-system/ingresses/kubernetes-dashboard",
                "uid": "4c9385f8-2f14-4e4c-a9c8-6896c82d085a"
            },
            "spec": {
                "rules": [
                    {
                        "host": "kubedash.inapps.k8s.dsp.local",
                        "http": {
                            "paths": [
                                {
                                    "backend": {
                                        "serviceName": "kubernetes-dashboard",
                                        "servicePort": 443
                                    }
                                }
                            ]
                        }
                    }
                ],
                "tls": [
                    {
                        "hosts": [
                            "kubedash.inapps.k8s.dsp.local"
                        ]
                    }
                ]
            },
            "status": {
                "loadBalancer": {}
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 获取 Ingress

##### Http Request

GET /v1/namespaces/{namespace}/ingresses/{name}

##### Path Parameters

| Parameter |   Description   |
| :-------: | :-------------: |
| namespace |    命名空间     |
|   name    | ingress的名字 |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区唯一标识，当为空时，表示默认可用区 |

##### Response
| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "extensions/v1beta1",
    "kind": "Ingress",
    "metadata": {
        "annotations": {
            "kubectl.kubernetes.io/last-applied-configuration": "{\"apiVersion\":\"extensions/v1beta1\",\"kind\":\"Ingress\",\"metadata\":{\"annotations\":{\"kubernetes.io/ingress.class\":\"nginx\",\"nginx.ingress.kubernetes.io/ssl-passthrough\":\"true\"},\"name\":\"kubernetes-dashboard\",\"namespace\":\"kube-system\"},\"spec\":{\"rules\":[{\"host\":\"kubedash.inapps.k8s.dsp.local\",\"http\":{\"paths\":[{\"backend\":{\"serviceName\":\"kubernetes-dashboard\",\"servicePort\":443}}]}}],\"tls\":[{\"hosts\":[\"kubedash.inapps.k8s.dsp.local\"]}]}}\n",
            "kubernetes.io/ingress.class": "nginx",
            "nginx.ingress.kubernetes.io/ssl-passthrough": "true"
        },
        "creationTimestamp": "2019-08-15T10:05:29Z",
        "generation": 2,
        "name": "kubernetes-dashboard",
        "namespace": "kube-system",
        "resourceVersion": "21879",
        "selfLink": "/apis/extensions/v1beta1/namespaces/kube-system/ingresses/kubernetes-dashboard",
        "uid": "4c9385f8-2f14-4e4c-a9c8-6896c82d085a"
    },
    "spec": {
        "rules": [
            {
                "host": "kubedash.inapps.k8s.dsp.local",
                "http": {
                    "paths": [
                        {
                            "backend": {
                                "serviceName": "kubernetes-dashboard",
                                "servicePort": 443
                            }
                        }
                    ]
                }
            }
        ],
        "tls": [
            {
                "hosts": [
                    "kubedash.inapps.k8s.dsp.local"
                ]
            }
        ]
    },
    "status": {
        "loadBalancer": {}
    }
}
```

### 获取 Ingress 的 Pod 列表

##### Http Request

GET /v1/namespaces/{namespace}/ingresses/{name}/pods

##### Path Parameters

| Parameter |   Description   |
| :-------: | :-------------: |
| namespace |    命名空间     |
|   name    | ingress的名字 |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区唯一标识，当为空时，表示默认可用区 |

##### Response
| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
[
    {
        "kind": "Pod",
        "apiVersion": "v1",
        "metadata": {
            "name": "kubernetes-dashboard-88ffc9487-ptjhw",
            "generateName": "kubernetes-dashboard-88ffc9487-",
            "namespace": "kube-system",
            "selfLink": "/api/v1/namespaces/kube-system/pods/kubernetes-dashboard-88ffc9487-ptjhw",
            "uid": "c5e0e27b-eee4-4dce-a6fc-f5e392dd1b1e",
            "resourceVersion": "3600",
            "creationTimestamp": "2019-08-15T08:04:01Z",
            "labels": {
                "k8s-app": "kubernetes-dashboard",
                "pod-template-hash": "88ffc9487"
            },
            "annotations": {
                "cni.projectcalico.org/podIP": "10.244.174.193/32"
            },
            "ownerReferences": [
                {
                    "apiVersion": "apps/v1",
                    "kind": "ReplicaSet",
                    "name": "kubernetes-dashboard-88ffc9487",
                    "uid": "3335fe93-8c13-4913-84a8-cfa7fdb992f8",
                    "controller": true,
                    "blockOwnerDeletion": true
                }
            ]
        },
        "spec": {
            "volumes": [
                {
                    "name": "kubernetes-dashboard-certs",
                    "secret": {
                        "secretName": "kubernetes-dashboard-certs",
                        "defaultMode": 420
                    }
                },
                {
                    "name": "tmp-volume",
                    "emptyDir": {}
                },
                {
                    "name": "kubernetes-dashboard-token-dd8r6",
                    "secret": {
                        "secretName": "kubernetes-dashboard-token-dd8r6",
                        "defaultMode": 420
                    }
                }
            ],
            "containers": [
                {
                    "name": "kubernetes-dashboard",
                    "image": "harbor.k8s.dsp.local/k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1",
                    "args": [
                        "--auto-generate-certificates"
                    ],
                    "ports": [
                        {
                            "containerPort": 8443,
                            "protocol": "TCP"
                        }
                    ],
                    "resources": {},
                    "volumeMounts": [
                        {
                            "name": "kubernetes-dashboard-certs",
                            "mountPath": "/certs"
                        },
                        {
                            "name": "tmp-volume",
                            "mountPath": "/tmp"
                        },
                        {
                            "name": "kubernetes-dashboard-token-dd8r6",
                            "readOnly": true,
                            "mountPath": "/var/run/secrets/kubernetes.io/serviceaccount"
                        }
                    ],
                    "livenessProbe": {
                        "httpGet": {
                            "path": "/",
                            "port": 8443,
                            "scheme": "HTTPS"
                        },
                        "initialDelaySeconds": 30,
                        "timeoutSeconds": 30,
                        "periodSeconds": 10,
                        "successThreshold": 1,
                        "failureThreshold": 3
                    },
                    "terminationMessagePath": "/dev/termination-log",
                    "terminationMessagePolicy": "File",
                    "imagePullPolicy": "IfNotPresent"
                }
            ],
            "restartPolicy": "Always",
            "terminationGracePeriodSeconds": 30,
            "dnsPolicy": "ClusterFirst",
            "serviceAccountName": "kubernetes-dashboard",
            "serviceAccount": "kubernetes-dashboard",
            "nodeName": "k8s-node-03.k8s.dsp.local",
            "securityContext": {},
            "schedulerName": "default-scheduler",
            "tolerations": [
                {
                    "key": "node-role.kubernetes.io/master",
                    "effect": "NoSchedule"
                },
                {
                    "key": "node.kubernetes.io/not-ready",
                    "operator": "Exists",
                    "effect": "NoExecute",
                    "tolerationSeconds": 300
                },
                {
                    "key": "node.kubernetes.io/unreachable",
                    "operator": "Exists",
                    "effect": "NoExecute",
                    "tolerationSeconds": 300
                }
            ],
            "priority": 0
        },
        "status": {
            "phase": "Running",
            "conditions": [
                {
                    "type": "Initialized",
                    "status": "True",
                    "lastProbeTime": null,
                    "lastTransitionTime": "2019-08-15T08:04:01Z"
                },
                {
                    "type": "Ready",
                    "status": "True",
                    "lastProbeTime": null,
                    "lastTransitionTime": "2019-08-15T08:04:06Z"
                },
                {
                    "type": "ContainersReady",
                    "status": "True",
                    "lastProbeTime": null,
                    "lastTransitionTime": "2019-08-15T08:04:06Z"
                },
                {
                    "type": "PodScheduled",
                    "status": "True",
                    "lastProbeTime": null,
                    "lastTransitionTime": "2019-08-15T08:04:01Z"
                }
            ],
            "hostIP": "192.168.120.12",
            "podIP": "10.244.174.193",
            "startTime": "2019-08-15T08:04:01Z",
            "containerStatuses": [
                {
                    "name": "kubernetes-dashboard",
                    "state": {
                        "running": {
                            "startedAt": "2019-08-15T08:04:06Z"
                        }
                    },
                    "lastState": {},
                    "ready": true,
                    "restartCount": 0,
                    "image": "harbor.k8s.dsp.local/k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1",
                    "imageID": "docker-pullable://harbor.k8s.dsp.local/k8s.gcr.io/kubernetes-dashboard-amd64@sha256:0ae6b69432e78069c5ce2bcde0fe409c5c4d6f0f4d9cd50a17974fea38898747",
                    "containerID": "docker://3306343b232ea7717fbbae45f5774b78b5fa67792e927921cbc2133bbb4e152c"
                }
            ],
            "qosClass": "BestEffort"
        }
    }
]
```

### 创建 Ingress

##### Http Request

POST /v1/namespaces/{namespace}/ingresses

#####  Path Parameters

| Parameter |   Description   |
| :-------: | :-------------: |
| namespace |    命名空间     |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区的唯一标识，为空时，表示默认可用区 |

#### Body Parameter

```json
{
    "apiVersion": "extensions/v1beta1",
    "kind": "Ingress",
    "metadata": {
        "name": "kubernetes-dashboard",
        "namespace": "kube-system",
    },
    "spec": {
        "rules": [
            {
                "host": "kubedash.inapps.k8s.dsp.local",
                "http": {
                    "paths": [
                        {
                            "backend": {
                                "serviceName": "kubernetes-dashboard",
                                "servicePort": 443
                            }
                        }
                    ]
                }
            }
        ],
        "tls": [
            {
                "hosts": [
                    "kubedash.inapps.k8s.dsp.local"
                ]
            }
        ]
    },
    "status": {
        "loadBalancer": {}
    }
}
```
##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "extensions/v1beta1",
    "kind": "Ingress",
    "metadata": {
        "creationTimestamp": "2019-08-15T10:05:29Z",
        "generation": 2,
        "name": "kubernetes-dashboard",
        "namespace": "kube-system",
        "resourceVersion": "21879",
        "selfLink": "/apis/extensions/v1beta1/namespaces/kube-system/ingresses/kubernetes-dashboard",
        "uid": "4c9385f8-2f14-4e4c-a9c8-6896c82d085a"
    },
    "spec": {
        "rules": [
            {
                "host": "kubedash.inapps.k8s.dsp.local",
                "http": {
                    "paths": [
                        {
                            "backend": {
                                "serviceName": "kubernetes-dashboard",
                                "servicePort": 443
                            }
                        }
                    ]
                }
            }
        ],
        "tls": [
            {
                "hosts": [
                    "kubedash.inapps.k8s.dsp.local"
                ]
            }
        ]
    },
    "status": {
        "loadBalancer": {}
    }
}
```

### 更新 Ingress

##### Http Request

PUT /v1/namespaces/{namespace}/ingresses/{name}

#####  Path Parameters

| Parameter |   Description   |
| :-------: | :-------------: |
| namespace |    命名空间     |
|   name    | ingress的名字 |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区的唯一标识，为空时，表示默认可用区 |

#### Body Parameter

```json
{
    "apiVersion": "extensions/v1beta1",
    "kind": "Ingress",
    "metadata": {
        "creationTimestamp": "2019-08-15T10:05:29Z",
        "generation": 2,
        "name": "kubernetes-dashboard",
        "namespace": "kube-system",
        "resourceVersion": "21879",
        "selfLink": "/apis/extensions/v1beta1/namespaces/kube-system/ingresses/kubernetes-dashboard",
        "uid": "4c9385f8-2f14-4e4c-a9c8-6896c82d085a"
    },
    "spec": {
        "rules": [
            {
                "host": "kubedash.inapps.k8s.dsp.local",
                "http": {
                    "paths": [
                        {
                            "backend": {
                                "serviceName": "kubernetes-dashboard",
                                "servicePort": 443
                            }
                        }
                    ]
                }
            }
        ],
        "tls": [
            {
                "hosts": [
                    "kubedash.inapps.k8s.dsp.local"
                ]
            }
        ]
    },
    "status": {
        "loadBalancer": {}
    }
}
```
##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "extensions/v1beta1",
    "kind": "Ingress",
    "metadata": {
        "creationTimestamp": "2019-08-15T10:05:29Z",
        "generation": 2,
        "name": "kubernetes-dashboard",
        "namespace": "kube-system",
        "resourceVersion": "21879",
        "selfLink": "/apis/extensions/v1beta1/namespaces/kube-system/ingresses/kubernetes-dashboard",
        "uid": "4c9385f8-2f14-4e4c-a9c8-6896c82d085a"
    },
    "spec": {
        "rules": [
            {
                "host": "kubedash.inapps.k8s.dsp.local",
                "http": {
                    "paths": [
                        {
                            "backend": {
                                "serviceName": "kubernetes-dashboard",
                                "servicePort": 443
                            }
                        }
                    ]
                }
            }
        ],
        "tls": [
            {
                "hosts": [
                    "kubedash.inapps.k8s.dsp.local"
                ]
            }
        ]
    },
    "status": {
        "loadBalancer": {}
    }
}
```

### 删除Ingress

##### Http Request

DELETE /v1/namespaces/{namespace}/ingresses/{name}

#####  Path Parameters

| Parameter |   Description   |
| :-------: | :-------------: |
| namespace |    命名空间     |
|   name    | ingress的名字 |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区的唯一标识，为空时，表示默认可用区 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```