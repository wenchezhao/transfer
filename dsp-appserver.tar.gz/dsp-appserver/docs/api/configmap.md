### 获取 ConfigMap 列表

##### Http Request

GET /v1/namespaces/{namespace}/configmaps

##### Path Parameters

| Parameter | Description |
| :-------: | :---------: |
| namespace |  命名空间   |

##### Query Parameters

|   Parameter   |                         Description                          |
| :-----------: | :----------------------------------------------------------: |
|     zone      |             可用区唯一标识，为空时表示默认可用区             |
| labelSelector | 标签选择器，默认为选中所有的configmap。取值示例为k1=v2,k2=v2 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "v1",
            "data": {
                "key": "value"
            },
            "kind": "ConfigMap",
            "metadata": {
                "creationTimestamp": "2019-04-15T11:18:32Z",
                "name": "demo",
                "namespace": "default",
                "resourceVersion": "7279359",
                "selfLink": "/api/v1/namespaces/default/configmaps/demo",
                "uid": "342eed86-5f70-11e9-b53c-005056a117fe"
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```

### 获取 ConfigMap

##### Http Request

GET /v1/namespaces/{namespace}/configmaps/{name}

##### Path Parameters

| Parameter |   Description   |
| :-------: | :-------------: |
| namespace |    命名空间     |
|   name    | configmap的名字 |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区唯一标识，当为空时，表示默认可用区 |

##### Response
| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "data": {
        "key": "value"
    },
    "kind": "ConfigMap",
    "metadata": {
        "creationTimestamp": "2019-04-15T11:18:32Z",
        "name": "demo",
        "namespace": "default",
        "resourceVersion": "7279359",
        "selfLink": "/api/v1/namespaces/default/configmaps/demo",
        "uid": "342eed86-5f70-11e9-b53c-005056a117fe"
    }
}
```

### 创建 ConfigMap

##### Http Request

POST /v1/namespaces/{namespace}/configmaps

#####  Path Parameters

| Parameter |   Description   |
| :-------: | :-------------: |
| namespace |    命名空间     |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区的唯一标识，为空时，表示默认可用区 |

#### Body Parameter

```json
{
    "apiVersion": "v1",
    "data": {
        "key": "val"
    },
    "kind": "ConfigMap",
    "metadata": {
        "name": "demo",
        "namespace": "default",
    }
}
```
##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "data": {
        "key": "val"
    },
    "kind": "ConfigMap",
    "metadata": {
        "creationTimestamp": "2019-04-15T11:19:32Z",
        "name": "demo",
        "namespace": "default",
        "resourceVersion": "7279360",
        "selfLink": "/api/v1/namespaces/default/configmaps/demo",
        "uid": "342eed86-5f70-11e9-b53c-005056a117fe"
    }
}
```

### 更新 ConfigMap

##### Http Request

PUT /v1/namespaces/{namespace}/configmaps/{name}

#####  Path Parameters

| Parameter |   Description   |
| :-------: | :-------------: |
| namespace |    命名空间     |
|   name    | configmap的名字 |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区的唯一标识，为空时，表示默认可用区 |

#### Body Parameter

```json
{
    "apiVersion": "v1",
    "data": {
        "key": "val"
    },
    "kind": "ConfigMap",
    "metadata": {
        "creationTimestamp": "2019-04-15T11:18:32Z",
        "name": "demo",
        "namespace": "default",
        "resourceVersion": "7279359",
        "selfLink": "/api/v1/namespaces/default/configmaps/demo",
        "uid": "342eed86-5f70-11e9-b53c-005056a117fe"
    }
}
```
##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "data": {
        "key": "val"
    },
    "kind": "ConfigMap",
    "metadata": {
        "creationTimestamp": "2019-04-15T11:19:32Z",
        "name": "demo",
        "namespace": "default",
        "resourceVersion": "7279360",
        "selfLink": "/api/v1/namespaces/default/configmaps/demo",
        "uid": "342eed86-5f70-11e9-b53c-005056a117fe"
    }
}
```

### 删除ConfigMap

##### Http Request

DELETE /v1/namespaces/{namespace}/configmaps/{name}

#####  Path Parameters

| Parameter |   Description   |
| :-------: | :-------------: |
| namespace |    命名空间     |
|   name    | configmap的名字 |

##### Query Parameters

| Parameter |               Description                |
| :-------: | :--------------------------------------: |
|   zone    | 可用区的唯一标识，为空时，表示默认可用区 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{}
```

### 获取使用ConfigMap的资源对象引用列表

目前仅会查询Deployment, CronJob, StatusfulSet, DaemonSet这四类资源。

##### 请求

GET /v1/namespaces/{namespace}/configmaps/{name}/objrefs

路径参数

|  参数名   |   描述   |
| :-------: | :------: |
| namespace | 命名空间 |
|   name    | ConfigMap名称  |

##### 查询参数

| 参数名 |                    描述                    |
| :----: | :----------------------------------------: |
|  zone  | 可用区唯一标识，当zone为空时表示默认可用区 |

响应

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
[
    {
        "apiVersion": "extensions/v1beta1",
        "kind": "Deployment",
        "namespace": "dsp-system",
        "name": "mysql",
        "resourceVersion": "681676",
        "uid": "0c266300-c256-11e9-84d7-005056b4d66c"
    }
]
```