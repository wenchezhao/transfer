### 获取 ReplicationControllers 列表

##### Http Request

GET /api/v1/namespaces/{namespace}/replicationcontrollers

##### Path Parameters

| Parameter |                        Description                         |
| :-------: | :--------------------------------------------------------: |
| namespace | object name and auth scope, such as for teams and projects |

##### Query Parameters

|   Parameter   |                    Description                    |
| :-----------: | :-----------------------------------------------: |
|     zone      |                 openshift cluster                 |
| labelSelector | 标签选择器，默认返回所有的rc。使用示例k1=v1,k2=v2 |

##### Response

| Code | Description |
| :--: | :---------: |
| 200  |     OK      |

```json
{
    "apiVersion": "v1",
    "items": [
        {
            "apiVersion": "v1",
            "kind": "ReplicationController",
            "metadata": {
                "creationTimestamp": "2019-04-14T10:19:25Z",
                "generation": 1,
                "labels": {
                    "name": "mysql-rc"
                },
                "name": "mysql-rc",
                "namespace": "default",
                "resourceVersion": "7229556",
                "selfLink": "/api/v1/namespaces/default/replicationcontrollers/mysql-rc",
                "uid": "c75c6672-5e9e-11e9-bfa9-005056a117fe"
            },
            "spec": {
                "replicas": 1,
                "selector": {
                    "name": "mysql-pod"
                },
                "template": {
                    "metadata": {
                        "creationTimestamp": null,
                        "labels": {
                            "name": "mysql-pod"
                        }
                    },
                    "spec": {
                        "containers": [
                            {
                                "env": [
                                    {
                                        "name": "MYSQL_ROOT_PASSWORD",
                                        "value": "mysql"
                                    }
                                ],
                                "image": "mysql",
                                "imagePullPolicy": "IfNotPresent",
                                "name": "mysql",
                                "ports": [
                                    {
                                        "containerPort": 3306,
                                        "hostPort": 3306,
                                        "protocol": "TCP"
                                    }
                                ],
                                "resources": {},
                                "terminationMessagePath": "/dev/termination-log",
                                "terminationMessagePolicy": "File"
                            }
                        ],
                        "dnsPolicy": "ClusterFirst",
                        "restartPolicy": "Always",
                        "schedulerName": "default-scheduler",
                        "securityContext": {},
                        "terminationGracePeriodSeconds": 30
                    }
                }
            },
            "status": {
                "availableReplicas": 1,
                "fullyLabeledReplicas": 1,
                "observedGeneration": 1,
                "readyReplicas": 1,
                "replicas": 1
            }
        }
    ],
    "kind": "List",
    "metadata": {
        "resourceVersion": "",
        "selfLink": ""
    }
}
```